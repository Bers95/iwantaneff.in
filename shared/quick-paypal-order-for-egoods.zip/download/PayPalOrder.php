<?php

/*
	PayPal Quick Order (c)2009 by SuperSite.Me
	
	Instruction.
	==========================================
	
	Please create folder, "download" and make it writable - if required, 
	set permissions 777 if you use Linux or use console 
	to set writable permissions in Windows server
	
	Upload your file (e-book, zip archive) to "download" folder,
	and set configuration below :
	
		- your PayPal address (this is where money should come)
		- your product filename (example your zip filename)
		- your product name (this will appear as payment description)
		- your product price (this is how much your customers will be charged, in USD.)
		- URL address to this file (example http://www.mydomain.com/PayPalOrder.php)
*/

# Quick Configuration.

# Your PayPal E-mail address
define('PayPalAddress','your@address.com');

# Product Filename/Path (file should be located in "download" folder)
define('ProductPath','sample.zip');

# Product Name (this will appear as order description)
define('ProductDescription','My Sample Product');

# Product Price in USD (example 5.00 or 5.99)
define('ProductPrice','5.00');

# Expire After... Number of days. Set "0" for non-expire links.
define('ProductDownloadExpire','0');

# URL address to this file (example http://www.mydomain.com/PayPalOrder.php)
define('OrderFormURL','http://www.mydomain.com/PayPalOrder.php');

# URL address to redirect user when cancel (example http://www.mydomain.com)
define('OrderFormURLCancel','http://www.mydomain.com');

//$SandBox = 'sandbox.'; // uncomment this line to get sandbox/test mode

# Optional settings for email.

define('emailFrom','Shop Admin');
define('emailSubject','Thank you! Order Completed.');
define('emailMessage',"Thank you!

Your order is complete now. 
You can download ordered product here: 

[DOWNLOAD]


---
Please don't hesistate to contact us with any additional questions!
");

if(!$_POST && !$_GET['download']){
	// this is the order form.
	// if there was any post here - it's probably call from PayPal.
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PayPal Order</title>
</head>
<style>
#PayPalOrder-Main {

	width:450px;
	margin:0 auto;
	font-family:"Trebuchet MS", Arial, Helvetica, sans-serif;
	
}
#PayPalOrder-Main h1 {

	margin-bottom:10px;
	padding-bottom:10px;
	border-bottom:1px solid #999;
	
}
#PayPalOrder-Product img { float:left; padding: 0 10px 10px 0; }
#PayPalOrder-Product h2 { font-size:15px; margin:0; }
#PayPalOrder-Product em { font-size:15px; margin:0; display:block; color:#F00; font-weight:bold; font-style:normal; }

#PayPalOrder-Final { margin-top: 10px; padding-top: 10px; border-top: 1px solid #999; font-size: 13px; text-align:center; } 
#PayPalOrder-Final img { display:block; margin:10px auto; background:#fff; padding:10px } 
#PayPalOrder-Final div { border:1px solid #F90; background:#FFC; padding:10px;} 
#PayPalOrder-Final input { display:block; margin:10px auto;} 
</style>
<body>

<? 

	
	if($_GET['status']) {

?>
        <div id="PayPalOrder-Main">
        
        <h1>Order Completed!</h1>
        
        <div id="PayPalOrder-Product">
        <h2>Your order is completed now</h2>
        <em>Please check your mailbox! (SPAM folder too)</em>
        </div>
        
        </div>
<?
		
	} else { 
	
	?>
<form name="form" action="https://www.<?php echo $SandBox;?>paypal.com/cgi-bin/webscr" method="post" target="_top">
        
        <input type="hidden" name="cmd" value="_xclick">
        <input type="hidden" name="business" value="<?=PayPalAddress?>">
        <input type="hidden" name="item_name" value="<?=ProductDescription?>">
        <input type="hidden" name="return" value="<?=OrderFormURL?>">
        <input type="hidden" name="cancel_return" value="<?=OrderFormURLCancel?>">
        <input type="hidden" name="no_note" value="1">
        <input type="hidden" name="currency_code" value="USD">
        <input type="hidden" name="lc" value="US">
        <input type="hidden" name="bn" value="PP-BuyNowBF">
        <input type="hidden" name="amount" value="<?=ProductPrice?>">
        <input type="hidden" name="notify_url" value="<?=OrderFormURL?>">
        
        
        <div id="PayPalOrder-Main">
        
        <h1>Quick PayPal Order</h1>
        
        <div id="PayPalOrder-Product">
        <img src="img/WebAppers_com__Save.png" alt="">
        <h2>My Super Product</h2>Buy my e-book with great SEO tips
        <em>$5.00</em>
        </div>
        
        
        <div id="PayPalOrder-Final">
        	<div>
            <img src="img/paypal_logo.gif" alt="">
            Click below button to pay with PayPal. As soon as your order is completed, you'll get ordered product to your e-mail address<input type="submit" value="Pay With PayPal.com!" id="payNowSubmit">
        	</div>
        </div>
        
        </div>
        
        </form>
        
        
        <? } ?>
</body>
</html>
<? } elseif($_GET['download']) { 

	// first - please check, if that file didn't expire...
	if(constant('ProductDownloadExpire')>0){
		// there is some expiration date.
		$fstat=stat('download/'.addslashes($_GET['download']));
		// print_r($fstat); // this would show all info we have.
		
		// how much need to add? 
		// need to calculate number of seconds, so in 1 day, there is 24 hours,
		// in hour there is 60 minutes and there is 60 seconds in a minute.
		$allowedTime=ProductDownloadExpire*24*60*60; 
		// add these values, to have maximum allowed file time:
		$allowedTime = $allowedTime+$fstat['mtime'];
		
		// now - if allowed time is exceeded - less than current time, 
		// file will be not sent to user.
		
		if($allowedTime<time()){
			die('File Expired!');
			exit;
		}
		
		
		
	}
	if(file_exists('download/'.addslashes($_GET['download']))){
		
		header("Pragma: public"); // required
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Cache-Control: private",false); // required for certain browsers 
		header("Content-Type: $ctype");
		// change, added quotes to allow spaces in filenames, by Rajkumar Singh
		header("Content-Disposition: attachment; filename=\"".basename(ProductPath)."\";" );
		header("Content-Transfer-Encoding: binary");
		header("Content-Length: ".filesize('download/'.addslashes($_GET['download'])));
		readfile('download/'.addslashes($_GET['download']));
		exit();
		
	} else {
	
		die("File doesn't exists!");
	}

} else { // there is POST sent, probably this is PayPal verification...

$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
	$value = urlencode(stripslashes($value));
	$req .= "&$key=$value";
}

$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";

// send verification request to PayPal...
$fp = fsockopen('www.'.$SandBox.'paypal.com', 80, $errno, $errstr, 30);

if (!$fp) {
	// no result? Probably some error...
	die('Problem with connection to PayPal, is "fsockopen" allowed?');
} else {
	// there was connection...
	fputs ($fp, $header . $req);
	while (!feof($fp)) {
		$res = fgets ($fp, 1024);
		if (strcmp($res, "VERIFIED") == 0) {
			
			if($_POST['payment_status'] == 'Completed' || $_POST['payment_status'] == 'Pending'){
				
				if($_REQUEST['mc_gross']==ProductPrice && $_POST['mc_currency'] == 'USD'){
					// price is good, currency is good. We can complete this order...

					// wasn't order completed?
					if(file_exists('download/tkey_'.$_POST['txn_id'].'.txt')){
						header("location: ".OrderFormURL."?status=complete");
						exit;
					}
					
					// done? Add file with transaction ID, so it can't be generated again 
					// - example by page refresh, etc
					
					$f = fopen('download/tkey_'.$_POST['txn_id'].'.txt', 'w');
					fwrite($f, 'ok');
					fclose($f);
					/*
					POST variables which are sent from PayPal:
					
					$_POST['item_name'] - name of our product
					$_POST['payment_status'] - status of payment
					$_POST['mc_gross'] - total amount sent by customer
					$_POST['mc_currency'] - currency - example USD
					$_POST['txn_id'] - transaction ID
					$_POST['payer_email'] - customer's email, which was used to pay for this order
					*/
					
					// create download link for this user.
					$UniqueId=md5(microtime());
					$DownloadLink=OrderFormURL."?download=".$UniqueId;
					if(!copy('download/'.ProductPath,'download/'.$UniqueId))
						die('Problem when creating unique copy, is copy() function allowed?');
					
					// we will send an email to customer now
					if(mail($_POST['payer_email'],emailSubject,str_replace('[DOWNLOAD]',$DownloadLink,emailMessage),'From: '.emailFrom.' <'.PayPalAddress.'>')){
						// done? Add file with transaction ID, so it can't be generated again 
						// - example by page refresh, etc
						
						$f = fopen('download/tkey_'.$_POST['txn_id'].'.txt', 'w');
						fwrite($f, 'ok');
						fclose($f);

						header("location: ".OrderFormURL."?status=complete");
					} else {
						die("Problem when sending an email...");
					}
				}
				
			}
					
		} elseif (strcmp ($res, "INVALID") == 0) {
			// some problems. Skip it.
		}
	} // endof WHILE

	fclose ($fp);
}

}
?>