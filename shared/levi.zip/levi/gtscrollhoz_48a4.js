ns4 = (document.layers)?true:false
ie4 = (document.all)?true:false
dom = (document.getElementById)?true:false

var mouseX
var mouseY
var id
var clickDrag
var contentY
var contentH
var barY
var barSize = 41
var scrollTimer = setTimeout("",500)
var btnSize = 13
var speed = 6
var height
var boxCSS = "<style type='text/css'>\n"
var boxHTML = "<span id='dummyClip'><span id='dummy'></span></span>\n"

boxes = new Array()

function scrollBox(x, y, w, h, i){
	l = boxes.length
	boxes[l] = this
	this.x = x
	this.y = y
	this.w = w
	this.h = h
	this.i = i
	this.leftX = y
	this.rightY = y + (h - btnSize)
	this.rightX = x + (w - btnSize)
	boxCSS += "#"+i+"Clip {position:absolute;top:"+y+";left:"+x+";height:"+h+";width:"+w+";clip:rect(0,"+w+","+h+",0);overflow:hidden;z-index:10}\n"
	boxCSS += "#"+i+" {position:absolute;left:0;top:0;height:"+(h-btnSize)+";}\n"
	boxCSS += "#"+i+"barBg {position:absolute;top:"+(y+(h-btnSize))+";left:"+x+";height:"+btnSize+";width:"+w+";clip:rect(0,"+w+","+btnSize+",0);background-image:url('"+ barbg +"');layer-background-image:url('"+ barbg +"');z-index:11}"
	boxHTML += "<span id="+i+"barBg></span>"
	boxCSS += "#"+i+"verBar {position:absolute;top:"+(y+(h-btnSize))+";left:"+(x+btnSize)+";z-index:13}\n"
	boxHTML += "<span id='"+i+"verBar'><img src='"+ bar +"' width='41' height='13' border='0'></span>\n"	
	boxCSS += "#"+i+"UpBtn {position:absolute;top:"+(y+(h-btnSize))+";left:"+x+";z-index:13}\n"
	boxHTML += "<span id='"+i+"UpBtn'><img src='"+ leftarrow +"' width='13' height='13' border='0'></span>\n"
	boxCSS += "#"+i+"DnBtn {position:absolute;top:"+(y+(h-btnSize))+";left:"+(x+(w-btnSize))+";z-index:13}\n"
	boxHTML += "<span id='"+i+"DnBtn' style=''><img src='"+ rightarrow +"' width='13' height='13' border='0'></span>\n"
}

function scrollCSS(){
	boxCSS += "</style>\n"
	document.open()
	document.write(boxCSS)
	document.close()
}

function scrollHTML(){
	document.open()
	document.write(boxHTML)
	document.close()
	boxHTML = ""
	for (l = 0;l < boxes.length; l++){
		i = boxes[l].i
		if (dom){
			document.getElementById(i).contentW = document.getElementById(i).offsetWidth
			document.getElementById(i).style.left = 0
			document.getElementById(i+"verBar").x = boxes[l].x + btnSize
			if (document.getElementById(i).contentW < boxes[l].w) document.getElementById(i+"verBar").style.visibility = "hidden"
		} else if (ie4){
			document.all[i].contentW = document.all[i].offsetWidth
			document.all[i].style.left = 0
			document.all[i+"verBar"].x = boxes[l].x + btnSize
			if (document.all[i].contentW <= boxes[l].w) document.all[i+"verBar"].style.visibility = "hidden"
		} else if (ns4){
			document[i+"Clip"].document[i].contentW = document[i+"Clip"].document[i].document.width
			document[i+"verBar"].x = boxes[l].x + btnSize
			if (document[i+"Clip"].document[i].contentW <= boxes[l].w) document[i+"verBar"].visibility = "hide"
		}
	}
}

function down(e){
	getMouse(e)
	for (i=0; i < boxes.length; i++) {
		box = boxes[i]
		if (mouseY > (box.y + (box.h - btnSize)) && mouseY < (box.y + box.h) && mouseX > box.x && mouseX < (box.rightX + btnSize) ) {
			id = box.i
			width = box.w
			barStop = (box.x + box.w) - (barSize + btnSize)
			barT = box.x + btnSize
			if (dom) dragTop = document.getElementById(id+"verBar").x
			if (ie4) dragTop = document.all[id+"verBar"].x
			if (ns4) dragTop = document[id+"verBar"].x
			if (mouseX > box.leftX && mouseX < (box.leftY+btnSize)) return scrollUp()
			if (mouseX > box.rightX && mouseX < (box.rightX+btnSize)) return scrollDn()
			if (mouseX < box.rightX && mouseX > (dragTop + barSize)) return scrollDn()
			if (mouseX > (box.leftX + btnSize) && mouseX < dragTop) return scrollUp()
			if (mouseX > dragTop && mouseX < (dragTop + barSize)){
				clickDrag = true
				return false
			}
		}
	}
}

function move(e){
	if(clickDrag){
		getMouse(e)
		getPos()
		barX = mouseX - (barSize / 2)
		if (barX < barT) barX = barT
		if (barX > barStop) barX = barStop
		if (dom) document.getElementById(id+"verBar").x = barX
		if (ie4) document.all[id+"verBar"].x = barX
		if (ns4) document[id+"verBar"].x = barX
		barPosition = (barX - barT) / (width - ((btnSize * 2) + barSize))
		position = barPosition * (contentW - width)
		contentX = -position
		scroll()
	}
	if(ie4)return false
}

function up(){
	clearTimeout(scrollTimer)
	clickDrag = false
}

function scrollUp(){
	getPos()
	if (mouseX > barX){
		return up()
	} else {
		if (contentX < 0){
			contentX = contentX + speed
			if (contentX > 0) contentX = 0
			barX = barX - (speed / (contentW - width)) * ((width - (btnSize*2)) - barSize)
			if (barX < barT) barX = barT
			if (dom) document.getElementById(id+"verBar").x = barX
			if (ie4) document.all[id+"verBar"].x = barX
			if (ns4) document[id+"verBar"].x = barX
			scroll()
			scrollTimer = setTimeout("scrollUp()",25)
		}
	}
	return false
}

function scrollDn(){
	getPos()
	if (mouseX < (barX + barSize)){
		return up()
	} else {
		if (contentX > (-contentW + width)){
			contentX = contentX - speed
			if (contentY < (-contentH + height)) contentX = (-contentH + height)
			barX = barX + (speed / (contentW - width)) * ((width - (btnSize*2)) - barSize)
			if (barX > barStop) barX = barStop
			if (dom) document.getElementById(id+"verBar").x = barX
			if (ie4) document.all[id+"verBar"].x = barX
			if (ns4) document[id+"verBar"].x = barX
			scroll()
			scrollTimer = setTimeout("scrollDn()",25)
		}
	}
	return false
}

function scroll(){
	if (dom){
		document.getElementById(id+"verBar").style.left = barX
		document.getElementById(id).style.left = contentX
	} else if (ie4){
		document.all[id+"verBar"].style.left = barX
		document.all[id].style.left = contentX
	} else if (ns4){
		document[id+"verBar"].left = barX
		document[id+"Clip"].document[id].left = contentX
	}
}

function getPos(){
	if (dom){
		contentX = parseInt(document.getElementById(id).style.left)
		barX = document.getElementById(id+"verBar").x
		contentW = document.getElementById(id).contentW
	} else if (ie4){
		contentX = parseInt(document.all[id].style.left)
		barX = document.all[id+"verBar"].x
		contentW = document.all[id].contentW
	} else if (ns4){
		contentX = document[id+"Clip"].document[id].left
		barX = document[id+"verBar"].x
		contentW = document[id+"Clip"].document[id].contentW
	}
	return true
}

function getMouse(e){
	if (ie4){
		mouseY = event.clientY + document.body.scrollTop
		mouseX = event.clientX + document.body.scrollLeft
	} else if (ns4 || dom){
		mouseY = e.pageY
		mouseX = e.pageX
	}
}

function init(){
}
	if(ns4){
		document.captureEvents(Event.MOUSEDOWN | Event.MOUSEMOVE | Event.MOUSEUP)
	}
	document.onmousedown = down
	document.onmousemove = move
	document.onmouseup = up

dummy = new scrollBox(0,0,0,0,"dummy")