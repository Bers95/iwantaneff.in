#!/usr/bin/perl

# $Id: compress.pl,v 1.15 2003/01/23 04:26:23 tedshroyer Exp $
# Copyright (c) 2000-2003 Alex Russell
# Licensed under the Academic Free License version 1.1

foreach $arg ( @ARGV ){
	$FullString = ""; #Clear the string before reading next file
	#Open and read the original file
	open(Original, "<".$arg); # open file for reading
	while(<Original>){
		$FullString .= $_; # read in the source file
	}
	close(Original); # close the source file
	
	# Make a backup of the original
	system("touch $arg.bak"); # create a backup file for the script
	open(Backup, ">".$arg.".bak"); # open a file for writing	
	print Backup $FullString;
	close(Backup);
	
	# Compress and overwrite the original
	open(Overwrite, ">".$arg);
	$CompressString = JS_compress($FullString);
	print Overwrite $CompressString;
	close(Overwrite);	
}

#note - need to figure out how to add ';' if a line doesn't have one
#or leave in \n just to be sure.
sub JS_compress {
	$string = shift(@_);
	$_ = $string;
	
	# strip tabs
	s/\t//g;
	# make sure we just use \n for carriage return
	s/(\r)/\n/g;
	# strip single line comments
	while(m/([\s|\;|\)|\}|\{])\/\/.*?\n/){
		s/([\s|\;|\)|\}|\{])\/\/.*?\n/$1/g;
	}
	s/^\/\/.*?\n/$1/g;
	# fix function endings for single line
	s/(})\n/$1;/g;
	# remove inline docbook comments that we didin't catch before
	s/<\!--//g;	
	# cleanup '{', '}', '(', ')' ';'
	s/(\s+\{)/{/g;
	s/(\s+\})/}/g;
	s/(\s+\()/(/g;
	s/(\s+\))/)/g;
	s/(\{\s+)/{/g;
	s/(\}\s+)/}/g;
	s/(\(\s+)/(/g;
	s/(\)\s+)/)/g;
	s/(\;\s+)/\;/g;
	# shrink around '='
	s/\s+=/=/g;
	s/=\s+/=/g;
	# strip extra white space
	s/\s+/ /g;
	# strip /* */ comment
	# be sure to use minimal matching
	s/\/\*.*?\*\///g;
	# strip leading and trailing white space
	s/^\s+//g;
	s/\s+$//g;		
	return $_;
}
