RELEASE NOTES
$Id: README.txt,v 1.6 2003/03/03 17:12:26 russcoon Exp $
_______________________________________________________________________________
0.3.0

OVERVIEW:
	netWindows 0.3 represents a major architectural overhaul for the project.
	Signals and Slots have been made ubiquitous and many core components have
	seen rewrites to core functionality. As a result, we feel that 0.3 is the
	most stable, most robust netWindows release to date. In addition to the
	major strides made regarding the internals of the toolkit, this release
	also includes several new high-quality widgets, as well as retrofits of
	all old widgets to take advantages of new capabilities and various other
	API changes.
	
	What's included in this release:
		* the netWindows core 
		* 17 release-quality widgets
		* per-widget example pages (see /docs/widget_test_pages/)
		* sample environment pages

CHANGES:
		* a new FAQ document available in /docs/FAQ.html provides answers to
		  most common newbie questions.
		* total re-working of all inline constructor parsers
		* major re-structuring of inline constructor syntax for all widgets
		  that provide inline constructors
		* Signals and Slots event mechanism now widely used throughout the API
		* new configuration directives
		* new ways to apply configuration options
		* dependency on blank.html removed
		* CSS-only themeing now available on all widgets
		* NW_getFileTxt() now supports same-page URL caching
		* resizeable components can now have minimum and maximum widths and
		  heights
		* ability to dissable page-wide inline constructor searching
		  (increases load time performance)
		* ability to provide an explicit array of IDs to be searched for
		  inline constructors as children. Combined with dissabling full page
		  constructor searching, can allow authors that "know what's comming"
		  to optimize NW inline constructor performance (espically on large
		  pages)
		* singleton objects now declared using var __obj__ = new Object();
		  syntax instead of creating classes for each. Cuts down on possible
		  namespace contention.
		* __data__ rewritten to support "parser profiles" which allow shallow
		  data requests to be highly optimized using new parsers.
		* __sig__ now allow arbitrary number of arguments to any method
		  (removing previous hard limit of 13)
		* __sig__.addBareSig allows non-connected functions and methods to be
		  registered, enhancing anonymity of components.
		* __util__ now includes methods for setting and getting class and
		  attribute values, abstracting browser-specific problems away
		
		* New Widgets!
			- Split Pane widget: provides user-resizeable (or not) "panes"
			  which can form the basis of many application interface layouts.
			  Provides support for both horizontal and vertical splitting.
			- Combo Box widget: supports partial (incremental) option
			  matching, first substring matching and any-word substring
			  matching, inline or external file option loading (via
			  NW_getFileTxt(), not __data__), option "groups" to seperate
			  sections of potential options, and optional search indexes for
			  external file inputs. The Combo Box also provides 2 form
			  returns: the text the user inputs into the text box as well as
			  any value that may have matched from the options list, allowing
			  application developers to determine if the user choose from the
			  provided list or wrote in their own value. With external input
			  files (using optional search indexes), the combo-box has been
			  shown to provide good performance on data sets in the 10,000
			  record range on moderate hardware (~300MHz).
			- Sort Table: apply this widget constructor to a well-formed HTML
			  table to provide sorting capability to any table! 3 different
			  sort types are available as well as onLoad sorting to provided a
			  sorted table to the user without server-side sorting.
			  (programatic constructor not provided).
			- Scroll Table: provides a sortable table with headings that
			  always stay in view.  Provides runtime addition, removal, and
			  updating of rows.  Key-accelerated highlighting.  The Scroll
			  Table also supports most of the features of the Sort Table.
			- Text Expander.  A widget that provides a textarea with a twist:
			  it can automatically expand acronyms and shorthand words into
			  full strings of arbitrary length.  Handy for text-intensive
			  applications that involve repetitive text entry and/or lots of
			  professiona-specific shorthand and acronyms.  The Text Expander
			  also supports "tabbing" between configurable key characters.


FEATURES:
	netWindows is a new type of DHTML API that helps facilitate the creation
	and usage of "truly" dynamic interfaces. That is, DHTML interfaces that
	are created entirely on-the-fly on the client. netWindows is designed to
	help create and manage these sophisticated web application interfaces.  In
	addition to the widgets provided with this archive, the netWindows core
	scripts provide the following services to all netWindows pages:
		* an asynchronous, queued content loading mechanism
		* automatic tooltip support
		* on-the-fly theme changing (no page reload required)
		* keystroke event support
		* automatic script dependency satisfaction
		* an advanced, unified event model (signals and slots)
		* an extensible component framework
		* automatic environment setup (include a single file and go).
		
	The widgets provided with netWindows also provide many features specific
	to their intended applications, but common features among them include:
		* true widget anonymity
		* on-the-fly creation and destruction (developer need not know or care)
		* inline constructor functions for "codeless" widget instantiation
		* true seperation of data from presentation logic (even on the client)
		* almost all widgets are fully themed

SUPPORT:
	netWindows is provided without support or warranty (see license agreement
	below). This aside, a mailing list is available for those using the
	toolkit, and the primary netWindows developers watch this list and enjoy
	and are often happy to answer questions users may have. To subscribe to
	this list, visit:

		http://netwindows.org/mailman/listinfo/devel_netwindows.org

DOCUMENTATION:
	see the netWindows/docs/ directory for documentation and tutorials on both
	widget usage and the netWindows framework in general.

THANKS:
	For this release, Alex would like to thank Mark Anderson of Discerning
	Software for his invaluable help, advice, prodding, probing questions,
	incredible support, and persistant push that has made this release the
	giant leap above 0.2.4 that I suspected it could be so many long months
	ago.

About netWindows
_______________________________________________________________________________
netWindows is an Open Source DOM based DHTML API and framework for building
web application interfaces. The project strives to provide a standards-compliant 
development framework and sample applications for developers. Anyone interested
in being part of the project can contact Alex Russell (the project admin) at
alex@netWindows.org


COPYRIGHT NOTICE
_______________________________________________________________________________
all code in this distribution, all documentation, and any other work provided in
this archive, unless otherwise stated in the file itself, is copyright 2000-2003
Alex Russell


LICENSE NOTICE
_______________________________________________________________________________
netWindows is distributed under the Academic Free License, as follows:

Copyright (c) 2000-2002 Alex Russell

Academic Free License 
	Version 1.1

This Academic Free License applies to any original work of authorship (the
"Original Work") whose owner (the "Licensor") has placed the following notice
immediately following the copyright notice for the Original Work: "Licensed
under the Academic Free License version 1.1."

Grant of License. Licensor hereby grants to any person obtaining a copy of the
Original Work ("You") a world-wide, royalty-free, non-exclusive, perpetual,
non-sublicenseable license (1) to use, copy, modify, merge, publish, perform,
distribute and/or sell copies of the Original Work and derivative works
thereof, and (2) under patent claims owned or controlled by the Licensor that
are embodied in the Original Work as furnished by the Licensor, to make, use,
sell and offer for sale the Original Work and derivative works thereof,
subject to the following conditions.

Right of Attribution. Redistributions of the Original Work must reproduce all
copyright notices in the Original Work as furnished by the Licensor, both in
the Original Work itself and in any documentation and/or other materials
provided with the distribution of the Original Work in executable form.

Exclusions from License Grant. Neither the names of Licensor, nor the names of
any contributors to the Original Work, nor any of their trademarks or service
marks, may be used to endorse or promote products derived from this Original
Work without express prior written permission of the Licensor.

WARRANTY AND DISCLAIMERS. LICENSOR WARRANTS THAT THE COPYRIGHT IN AND TO THE
ORIGINAL WORK IS OWNED BY THE LICENSOR OR THAT THE ORIGINAL WORK IS
DISTRIBUTED BY LICENSOR UNDER A VALID CURRENT LICENSE FROM THE COPYRIGHT
OWNER. EXCEPT AS EXPRESSLY STATED IN THE IMMEDIATELY PRECEEDING SENTENCE, THE
ORIGINAL WORK IS PROVIDED UNDER THIS LICENSE ON AN "AS IS" BASIS, WITHOUT
WARRANTY, EITHER EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, THE
WARRANTY OF NON-INFRINGEMENT AND WARRANTIES THAT THE ORIGINAL WORK IS
MERCHANTABLE OR FIT FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS TO THE
QUALITY OF THE ORIGINAL WORK IS WITH YOU. THIS DISCLAIMER OF WARRANTY
CONSTITUTES AN ESSENTIAL PART OF THIS LICENSE. NO LICENSE TO ORIGINAL WORK IS
GRANTED HEREUNDER EXCEPT UNDER THIS DISCLAIMER.

LIMITATION OF LIABILITY. UNDER NO CIRCUMSTANCES AND UNDER NO LEGAL THEORY,
WHETHER TORT (INCLUDING NEGLIGENCE), CONTRACT, OR OTHERWISE, SHALL THE
LICENSOR BE LIABLE TO ANY PERSON FOR ANY DIRECT, INDIRECT, SPECIAL,
INCIDENTAL, OR CONSEQUENTIAL DAMAGES OF ANY CHARACTER ARISING AS A RESULT OF
THIS LICENSE OR THE USE OF THE ORIGINAL WORK INCLUDING, WITHOUT LIMITATION,
DAMAGES FOR LOSS OF GOODWILL, WORK STOPPAGE, COMPUTER FAILURE OR MALFUNCTION,
OR ANY AND ALL OTHER COMMERCIAL DAMAGES OR LOSSES, EVEN IF SUCH PERSON SHALL
HAVE BEEN INFORMED OF THE POSSIBILITY OF SUCH DAMAGES. THIS LIMITATION OF
LIABILITY SHALL NOT APPLY TO LIABILITY FOR DEATH OR PERSONAL INJURY RESULTING
FROM SUCH PARTY'S NEGLIGENCE TO THE EXTENT APPLICABLE LAW PROHIBITS SUCH
LIMITATION. SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OR LIMITATION OF
INCIDENTAL OR CONSEQUENTIAL DAMAGES, SO THIS EXCLUSION AND LIMITATION MAY NOT
APPLY TO YOU.

License to Source Code. The term "Source Code" means the preferred form of the
Original Work for making modifications to it and all available documentation
describing how to access and modify the Original Work. Licensor hereby agrees
to provide a machine-readable copy of the Source Code of the Original Work
along with each copy of the Original Work that Licensor distributes. Licensor
reserves the right to satisfy this obligation by placing a machine-readable
copy of the Source Code in an information repository reasonably calculated to
permit inexpensive and convenient access by You for as long as Licensor
continues to distribute the Original Work, and by publishing the address of
that information repository in a notice immediately following the copyright
notice that applies to the Original Work.

Mutual Termination for Patent Action. This License shall terminate
automatically and You may no longer exercise any of the rights granted to You
by this License if You file a lawsuit in any court alleging that any OSI
Certified open source software that is licensed under any license containing
this "Mutual Termination for Patent Action" clause infringes any patent claims
that are essential to use that software.

This license is Copyright (C) 2002 Lawrence E. Rosen. All rights reserved.
Permission is hereby granted to copy and distribute this license without
modification. This license may not be modified without the express written
permission of its copyright owner.

-- 
END OF LICENSE. The following is intended to describe the essential
differences between the Academic Free License (AFL) version 1.0 and other
open source licenses: 

The Academic Free License is similar to the BSD, MIT, UoI/NCSA and Apache
licenses in many respects but it is intended to solve a few problems with
those licenses.

	The AFL is written so as to make it clear what software is being
	licensed (by the inclusion of a statement following the copyright
	notice in the software).  This way, the license functions better than
	a template license. The BSD, MIT and UoI/NCSA licenses apply to
	unidentified software.

	The AFL contains a complete copyright grant to the software. The BSD
	and Apache licenses are vague and incomplete in that respect.  The AFL
	contains a complete patent grant to the software. The BSD, MIT,
	UoI/NCSA and Apache licenses rely on an implied patent license and
	contain no explicit patent grant.

	The AFL makes it clear that no trademark rights are granted to the
	licensor's trademarks. The Apache license contains such a provision,
	but the BSD, MIT and UoI/NCSA licenses do not.

	The AFL includes the warranty by the licensor that it either owns the
	copyright or that it is distributing the software under a license.
	None of the other licenses contain that warranty. All other warranties
	are disclaimed, as is the case for the other licenses.

	The AFL is itself copyrighted (with the right granted to copy and
	distribute without modification). This ensures that the owner of the
	copyright to the license will control changes. The Apache license
	contains a copyright notice, but the BSD, MIT and UoI/NCSA licenses do
	not.

CONTACT
_______________________________________________________________________________
Alex Russell
alex@netWindows.org
http://netWindows.org
http://alex.netWindows.org
