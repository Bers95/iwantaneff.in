=== Reorder ===
Contributors: Ben Kennedy
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=benjitastic%40gmail%2ecom&lc=US&item_name=Ben%20Kennedy%20%2d%20Reorder%20Wordpress%20Plugin&no_note=0&currency_code=USD&bn=PP%2dDonationsBF%3abtn_donateCC_LG%2egif%3aNonHostedGuest
Tags: reorder, order, orderby, posts, custom posts, custom, post type, menu order, menu_order, drag, drop
Requires at least: 3.0
Tested up to: 3.0+
Stable tag: 3.2

This plugin allows users to easily change the order and hierarchy of Posts, Pages and custom content types in Wordpress. A drag and drop interface makes this a slick and easy experience.

MUST HAVE VERSION 3.0 OF WORDPRESS

== Description ==

Enables simple drag and drop reordering of all post types.

== Installation ==

1. Upload the `reorder` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Done

No extra configuration needs to be done when using the standard loop or query_posts() to reorder posts.

== Screenshots ==

== Changelog ==
= 3.0 =
* Initial Release
= 3.1 =
* Now backwards compatible to Wordpress 2.7
= 3.2 =
* Error when reordering more than 251 posts. Transmit data using $post method instead of $get method due to max URL parameter length.

== Upgrade Notice ==
-