ROADMAP
-------

v0.8.8
----
* Write more thorough tests

v9 ++
----
* Accordion functionality