<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">

<title><?php woo_title(); ?></title>
<?php woo_meta(); ?>

<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo('stylesheet_directory'); ?>/css/effects.css" />
<link rel="alternate" type="application/rss+xml" title="RSS 2.0" href="<?php $GLOBALS['feedurl'] = get_option('woo_feed_url'); if ( !empty($feedurl) ) { echo $feedurl; } else { echo get_bloginfo_rss('rss2_url'); } ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />

<script type='text/javascript' src='<?php bloginfo('template_directory'); ?>/includes/swfobject.js'></script>
      
<?php wp_head(); ?>
<?php woo_head(); ?>

</head>

<body <?php body_class(); ?>>

<?php woo_top(); ?>

<div id="top-pattern"></div>
<div id="wrapper" class="col-full">
           
	<div id="header">
 		       
		<div id="logo">
	       
		<?php if (get_option('woo_texttitle') <> "true") : $logo = get_option('woo_logo'); ?>
            <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>">
                <img src="<?php if ($logo) echo $logo; else { bloginfo('template_directory'); ?>/images/logo.png<?php } ?>" alt="<?php bloginfo('name'); ?>" />
            </a>
        <?php endif; ?> 
        
        <?php if( is_singular() ) : ?>
            <span class="site-title"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></span>
        <?php else : ?>
            <h1 class="site-title"><a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></h1>
        <?php endif; ?>
            <span class="site-description"><?php bloginfo('description'); ?></span>
	      	
		</div><!-- /#logo -->
	       
		<?php if (get_option('woo_about_text') != '') { ?>
        <div class="about fr">
	    	
	    	<p>
	    		<?php echo get_option('woo_about_text'); ?>
	    		<a href="<?php if(get_option('woo_about_more_url') != '') echo get_option('woo_about_more_url'); ?>" title="<?php _e('Read More', 'woothemes') ?>">
	    			<?php if(get_option('woo_about_more_text') != '') echo get_option('woo_about_more_text'); ?>
	    		</a>
	    	</p>
	    	
	   	</div><!-- /.about -->
        <?php } ?>
        
        <div class="fix"></div>
       
	</div><!-- /#header -->
    
    <div class="fix"></div>
    
    <div id="nav-search-wrap">
    
	<div id="navigation">
	
	    <span class="home">
	    	<a href="<?php bloginfo('url'); ?>" title="<?php _e('Home', 'woothemes') ?>">
	    		<img src="<?php bloginfo('template_directory'); ?>/images/ico-home.png" alt="<?php _e('Home', 'woothemes') ?>" />
	    	</a>
	    </span>
	
		<?php
		if ( function_exists('has_nav_menu') && has_nav_menu('primary-menu') ) {
			wp_nav_menu( array( 'depth' => 6, 'sort_column' => 'menu_order', 'container' => 'ul', 'menu_id' => 'main-nav', 'menu_class' => 'nav fl', 'theme_location' => 'primary-menu' ) );
		} else {
		?>
        <ul id="main-nav" class="nav fl">
			<?php 
        	if ( get_option('woo_custom_nav_menu') == 'true' ) {
        		if ( function_exists('woo_custom_navigation_output') )
					woo_custom_navigation_output();

			} else { ?>
            	
	            <?php 
	    		if ( get_option('woo_cat_menu') == 'true' ) 
	    			wp_list_categories('sort_column=menu_order&depth=6&title_li=&exclude='.get_option('woo_nav_exclude')); 
	    		else
	    			wp_list_pages('sort_column=menu_order&depth=6&title_li=&exclude='.get_option('woo_nav_exclude')); 

			}
			?>
        </ul><!-- /#nav -->
        
        <?php } ?>
        <ul class="rss fr">
            <?php $email = get_option('woo_subscribe_email'); if ( $email ) { ?>
            <li class="sub-email">
            	<a href="<?php echo $email; ?>" title="<?php _e('Subscribe via Email', 'woothemes') ?>" target="_blank">
            		<img src="<?php bloginfo('template_directory'); ?>/images/ico-mail.png" alt="<?php _e('Subscribe via Email', 'woothemes') ?>" />
            	</a>
            </li>
            <?php } ?>
            <li class="sub-rss">
            	<a href="<?php if ( $GLOBALS[feedurl] ) { echo $GLOBALS[feedurl]; } else { echo get_bloginfo_rss('rss2_url'); } ?>" title="<?php _e('Subscribe to RSS', 'woothemes') ?>">
            		<img src="<?php bloginfo('template_directory'); ?>/images/ico-rss.png" alt="<?php _e('RSS', 'woothemes') ?>" />
            	</a>
            </li>
        </ul>
        
         <div class="fix"></div>
        
	</div><!-- /#navigation -->
	
	<div id="search-bar">
		
		<div class="search-input fr">
		
			<form method="get" class="searchform" action="<?php bloginfo('url'); ?>" >
        		<input type="text" class="field s" name="s" value="<?php _e('Search...', 'woothemes') ?>" onfocus="if (this.value == '<?php _e('Search...', 'woothemes') ?>') {this.value = '';}" onblur="if (this.value == '') {this.value = '<?php _e('Search...', 'woothemes') ?>';}" />
    		</form>
		
		</div><!-- /.search-input -->
		
		<div class="fix"></div>
		
	</div><!-- /#search-bar -->
	<div class="search-bar-bg"></div>
	
	</div><!-- /#nav-search-wrap -->
       