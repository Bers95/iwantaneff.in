<div id="sidebar" class="col-right">

	<?php if (is_active_sidebar('primary')) : ?>
		<?php dynamic_sidebar('primary'); ?>       
	<?php endif; ?>
    
	
</div><!-- /#sidebar -->