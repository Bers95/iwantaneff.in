	
	<div class="fix"></div>
		
	<div id="footer">
	
		<?php if(get_option('woo_footer_custom') == 'true'){
		
				echo stripslashes(get_option('woo_footer_custom_text'));	

		} else { ?>
		
			<p>&copy; <?php echo date('Y'); ?> <?php bloginfo(); ?>. <?php _e('All Rights Reserved.', 'woothemes') ?> <?php _e('Powered by', 'woothemes') ?> <a href="http://www.templategets.com">Wordpress</a>. <?php _e('Designed by', 'woothemes') ?> <a href="<?php $aff = get_option('woo_footer_aff_link'); if(!empty($aff)) { echo $aff; } else { echo 'http://www.templategets.com'; } ?>"><img src="<?php bloginfo('template_directory'); ?>/images/woothemes.png" width="74" height="19" alt="Woo Themes" /></a></p>
			
		<?php } ?>
		
	</div><!-- /#footer  -->

</div><!-- /#wrapper -->
<div id="bottom-pattern"></div>
<?php wp_footer(); ?>
<?php woo_foot(); ?>
</body>
</html>