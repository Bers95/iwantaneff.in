jQuery(document).ready(function(){

	//Remove Border from last Twitter <li>
	jQuery('.widget_woo_twitter li:last-child').css('border-bottom', 'none');
	
	//Remove Border from last Recent Comments <li>
	jQuery('.widget_recent_comments li:last-child').css('border-bottom', 'none');
	
	//Insert <div> in PageNAvi for background
	if (jQuery('.wp-pagenavi').length>0) {
    	jQuery('.wp-pagenavi').before('<div class="pagination-bg"></div>');
	}
	
	//NAVIGATION - Keep parent item highlighted while hovering dropdown
	
	jQuery('.nav li ul').mouseover(function(){
	
	    if(! jQuery(this).parent().hasClass('fake')){
	    	jQuery(this).parent().addClass('fake');
	    }
	    
	});
	jQuery('.nav li ul').mouseleave(function(){
	
	    if(jQuery(this).parent().hasClass('fake')){
	    	jQuery(this).parent().removeClass('fake');
	    }
	});
	
	//NAVIGATION - Display second level menu for current page
	
	jQuery('.nav > li.current_page_item > ul, .nav > li.current_page_ancestor > ul').css('left', '75px');
	
	jQuery('.nav > li:not(.current_page_item,.current_page_ancestor)').mouseover(function(){
		//alert('what');
		jQuery('.nav > li.current_page_item > ul, .nav > li.current_page_ancestor > ul').css('left', '-9999px');
	});
	
	
	jQuery('.nav > li:not(.current_page_item,.current_page_ancestor)').mouseout(function(){
		//alert('what');
		jQuery('.nav > li.current_page_item > ul, .nav > li.current_page_ancestor > ul').css('left', '75px');
	});
	
	//NAVIGATION - Sub-nav indicator
	
	jQuery('.nav > li > ul').each(function(){
	
		jQuery(this).parent('li').addClass('has-dropdown');
	
	});
	
	jQuery('.nav > li > ul > li > ul').each(function(){
	
		jQuery(this).parent('li').addClass('has-sub-dropdown');
	
	});
	
});