<?php

add_action('init','woo_options');  
if (!function_exists('woo_options')) {
function woo_options(){
	
// VARIABLES
$themename = "Crisp";
$manualurl = 'http://www.woothemes.com/support/theme-documentation/crisp/';
$shortname = "woo";

// Populate WooThemes option in array for use in theme
global $woo_options;
$woo_options = get_option('woo_options');

$GLOBALS['template_path'] = get_bloginfo('template_directory');

//Access the WordPress Categories via an Array
$woo_categories = array();  
$woo_categories_obj = get_categories('hide_empty=0');
foreach ($woo_categories_obj as $woo_cat) {
    $woo_categories[$woo_cat->cat_ID] = $woo_cat->cat_name;}
$categories_tmp = array_unshift($woo_categories, "Select a category:");    
       
//Access the WordPress Pages via an Array
$woo_pages = array();
$woo_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($woo_pages_obj as $woo_page) {
    $woo_pages[$woo_page->ID] = $woo_page->post_name; }
$woo_pages_tmp = array_unshift($woo_pages, "Select a page:");       

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center"); 

// Image Links to Options
$options_image_link_to = array("image" => "The Image","post" => "The Post"); 

//Testing 
$options_select = array("one","two","three","four","five"); 
$options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five"); 

//URL Shorteners
if (_iscurlinstalled()) {
	$options_select = array("Off","TinyURL","Bit.ly");
	$short_url_msg = 'Select the URL shortening service you would like to use.'; 
} else {
	$options_select = array("Off");
	$short_url_msg = '<strong>cURL was not detected on your server, and is required in order to use the URL shortening services.</strong>'; 
}

//Stylesheets Reader
$alt_stylesheet_path = TEMPLATEPATH . '/styles/';
$alt_stylesheets = array();

if ( is_dir($alt_stylesheet_path) ) {
    if ($alt_stylesheet_dir = opendir($alt_stylesheet_path) ) { 
        while ( ($alt_stylesheet_file = readdir($alt_stylesheet_dir)) !== false ) {
            if(stristr($alt_stylesheet_file, ".css") !== false) {
                $alt_stylesheets[] = $alt_stylesheet_file;
            }
        }    
    }
}

//More Options
$all_uploads_path = get_bloginfo('home') . '/wp-content/uploads/';
$all_uploads = get_option('woo_uploads');
$other_entries = array("Select a number:","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$body_repeat = array("repeat","repeat-x","repeat-y","no-repeat");
$body_pos = array("top left","top center","top right","center left","center center","center right","bottom left","bottom center","bottom right");

// THIS IS THE DIFFERENT FIELDS
$options = array();   

$options[] = array( "name" => "General Settings",
                    "type" => "heading");
                        
$options[] = array( "name" => "Theme Stylesheet",
					"desc" => "Select your themes alternative color scheme.",
					"id" => $shortname."_alt_stylesheet",
					"std" => "default.css",
					"type" => "select",
					"options" => $alt_stylesheets);

$options[] = array( "name" => "Custom Logo",
					"desc" => "Upload a logo for your theme, or specify the image address of your online logo. (http://yoursite.com/logo.png)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "upload");    
                                                                                     
$options[] = array( "name" => "Text Title",
					"desc" => "Enable text-based Site Title and Tagline. Setup title & tagline in Settings->General.",
					"id" => $shortname."_texttitle",
					"std" => "false",
					"class" => "collapsed",
					"type" => "checkbox");

$options[] = array( "name" => "Site Title",
					"desc" => "Change the site title (must have 'Text Title' option enabled).",
					"id" => $shortname."_font_site_title",
					"std" => array('size' => '40','unit' => 'px','face' => 'Georgia','style' => '','color' => '#000000'),
					"class" => "hidden",
					"type" => "typography");  

$options[] = array( "name" => "Site Description",
					"desc" => "Change the site description (must have 'Text Title' option enabled).",
					"id" => $shortname."_font_tagline",
					"std" => array('size' => '14','unit' => 'px','face' => 'Georgia','style' => 'italic','color' => '#999999'),
					"class" => "hidden last",
					"type" => "typography");  

$options[] = array( "name" => "Custom Favicon",
					"desc" => "Upload a 16px x 16px Png/Gif image that will represent your website's favicon.",
					"id" => $shortname."_custom_favicon",
					"std" => "",
					"type" => "upload"); 
                                               
$options[] = array( "name" => "Tracking Code",
					"desc" => "Paste your Google Analytics (or other) tracking code here. This will be added into the footer template of your theme.",
					"id" => $shortname."_google_analytics",
					"std" => "",
					"type" => "textarea");        

$options[] = array( "name" => "RSS URL",
					"desc" => "Enter your preferred RSS URL. (Feedburner or other)",
					"id" => $shortname."_feed_url",
					"std" => "",
					"type" => "text");
                    
$options[] = array( "name" => "E-Mail URL",
					"desc" => "Enter your preferred E-mail subscription URL. (Feedburner or other)",
					"id" => $shortname."_subscribe_email",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Contact Form E-Mail",
					"desc" => "Enter your E-mail address to use on the Contact Form Page Template. Add the contact form by adding a new page and selecting 'Contact Form' as page template.",
					"id" => $shortname."_contactform_email",
					"std" => "",
					"type" => "text");



$options[] = array( "name" => "Custom CSS",
                    "desc" => "Quickly add some CSS to your theme by adding it to this block.",
                    "id" => $shortname."_custom_css",
                    "std" => "",
                    "type" => "textarea");

$options[] = array( "name" => "Post/Page Comments",
					"desc" => "Select if you want to enable/disable comments on posts and/or pages. ",
					"id" => $shortname."_comments",
					"type" => "select2",
					"options" => array("post" => "Posts Only", "page" => "Pages Only", "both" => "Pages / Posts", "none" => "None") );                                                          

$options[] = array( "name" => "Tumblog Setup",
				    "type" => "heading");  

$options[] = array( "name" => "Use Custom Tumblog RSS Feed",
					"desc" => "Replaces the default WordPress RSS feed output with Tumblog RSS output.",
					"id" => $shortname."_custom_rss",
					"std" => "true",
					"type" => "checkbox"); 
					
$options[] = array( "name" => "Full Content Home",
					"desc" => "Show the full content in posts on homepage instead of the excerpt.",
					"id" => $shortname."_home_content",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Full Content Archive",
					"desc" => "Show the full content in posts on archive pages instead of the excerpt.",
					"id" => $shortname."_archive_content",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Articles",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_articles_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);  				     					

$options[] = array( "name" => "Images",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_images_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);  				     					

$options[] = array( "name" => "Images Link to",
					"desc" => "Select where your Tumblog Images will link to when clicked.",
					"id" => $shortname."_image_link_to",
					"std" => "post",
					"type" => "radio",
					"options" => $options_image_link_to); 	
					
$options[] = array( "name" => "Videos",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_videos_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);  				     					

$options[] = array( "name" => "Quotes",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_quotes_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);  		

$options[] = array( "name" => "Links",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_links_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);  
					
$options[] = array( "name" => "Audio",
					"desc" => "Select the category that you would like to use for this post type.",
					"id" => $shortname."_audio_category",
					"std" => "Select a category:",
					"type" => "select",
					"class" => "hidden",
					"options" => $woo_categories);

$options[] = array( "name" => "About Options",
                    "type" => "heading");
                    
$options[] = array( "name" => "About Text",
					"desc" => "Enter a short description about yourself to go in the site header",
					"id" => $shortname."_about_text",
					"std" => "",
					"type" => "textarea");
					
$options[] = array( "name" => "More link text",
					"desc" => "Enter text for the read more link",
					"id" => $shortname."_about_more_text",
					"std" => "",
					"type" => "text");
					
$options[] = array( "name" => "More link URL",
					"desc" => "Enter a URL for the read more link",
					"id" => $shortname."_about_more_url",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "URL Shortening",
				    "type" => "heading");    

$options[] = array( "name" => "URL Shortening Service",
					"desc" => $short_url_msg,
					"id" => $shortname."_url_shorten",
					"std" => "Select a Service:",
					"type" => "select",
					"options" => $options_select);

$options[] = array( "name" => "Bit.ly Login Name",
					"desc" => "Your Bit.ly login name - get this here <a href='http://bit.ly/account/' target='_blank'>http://bit.ly/account/</a>",
					"id" => $shortname."_bitly_api_login",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Bit.ly API Key",
					"desc" => "Your Bit.ly API Key - get this here <a href='http://bit.ly/account/' target='_blank'>http://bit.ly/account/</a>",
					"id" => $shortname."_bitly_api_key",
					"std" => "",
					"type" => "text");

$options[] = array( "name" => "Styling Options",
					"type" => "heading");   
					
$options[] = array( "name" =>  "Body Background Color",
					"desc" => "Pick a custom color for background color of the theme e.g. #697e09",
					"id" => "woo_body_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" => "Body background image",
					"desc" => "Upload an image for the theme's background",
					"id" => $shortname."_body_img",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Background image repeat",
                    "desc" => "Select how you would like to repeat the background-image",
                    "id" => $shortname."_body_repeat",
                    "std" => "repeat",
                    "type" => "select",
                    "options" => $body_repeat);

$options[] = array( "name" => "Background image position",
                    "desc" => "Select how you would like to position the background",
                    "id" => $shortname."_body_pos",
                    "std" => "top",
                    "type" => "select",
                    "options" => $body_pos);

$options[] = array( "name" =>  "Link Color",
					"desc" => "Pick a custom color for links or add a hex color code e.g. #697e09",
					"id" => "woo_link_color",
					"std" => "",
					"type" => "color");   

$options[] = array( "name" =>  "Link Hover Color",
					"desc" => "Pick a custom color for links hover or add a hex color code e.g. #697e09",
					"id" => "woo_link_hover_color",
					"std" => "",
					"type" => "color");                    

$options[] = array( "name" =>  "Button Color",
					"desc" => "Pick a custom color for buttons or add a hex color code e.g. #697e09",
					"id" => "woo_button_color",
					"std" => "",
					"type" => "color");                    

$options[] = array( "name" => "Layout Options",
					"type" => "heading");    

$options[] = array( "name" => "Category Navigation",
					"desc" => "Swap the Page navigation for a Category navigation. ",
					"id" => $shortname."_cat_menu",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Exclude Pages or Categories from Navigation",
					"desc" => "Enter a comma-separated list of <a href='http://support.wordpress.com/pages/8/'>ID's</a> that you'd like to exclude from the top navigation. (e.g. 12,23,27,44)",
					"id" => $shortname."_nav_exclude",
					"std" => "",
					"type" => "text"); 
 					                   
$options[] = array( "name" => "Dynamic Images",
				    "type" => "heading");  
				    
				   
$options[] = array( "name" => "Enable WordPress Post Images Support",
					"desc" => "Use WordPress 2.9+ built in thumbnail/post-image support.",
					"id" => $shortname."_post_image_support",
					"std" => "false",
					"class" => "collapsed",
					"type" => "checkbox"); 
					
$options[] = array( "name" => "Hard Crop?",
					"desc" => "The image is cropped to match the target aspect ratio, and is then shrunk to fit in the specified dimensions exactly.",
					"id" => $shortname."_pis_hard_crop",
					"std" => "false",
					"class" => "hidden last",
					"type" => "checkbox"); 									   

$options[] = array( "name" => "Enable Dynamic Image Resizer",
					"desc" => "This will enable the thumb.php script. It dynamicaly resizes images on your site.",
					"id" => $shortname."_resize",
					"std" => "true",
					"type" => "checkbox");    
                    
$options[] = array( "name" => "Automatic Image Thumbs",
					"desc" => "If no image is specified in the 'image' custom field then the first uploaded post image is used.",
					"id" => $shortname."_auto_img",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Dynamic Image Height",
					"desc" => "If this is enabled, the height of your images will be dynamically calculated based on the width's as set below.",
					"id" => $shortname."_dynamic_img_height",
					"std" => "true",
					"type" => "checkbox"); 
					
$options[] = array( "name" => "Thumbnail Image Dimensions",
					"desc" => "Enter an integer value i.e. 250 for the desired size which will be used when dynamically creating the images.",
					"id" => $shortname."_image_dimensions",
					"std" => "",
					"type" => array( 
									array(  'id' => $shortname. '_thumb_w',
											'type' => 'text',
											'std' => 440,
											'meta' => 'Width'),
									array(  'id' => $shortname. '_thumb_h',
											'type' => 'text',
											'std' => 200,
											'meta' => 'Height')
								  ));
                                                                                                
$options[] = array( "name" => "Thumbnail Image alignment",
					"desc" => "Select how to align your thumbnails with posts.",
					"id" => $shortname."_thumb_align",
					"std" => "alignleft",
					"type" => "radio",
					"options" => $options_thumb_align); 

$options[] = array( "name" => "Show thumbnail in Single Posts",
					"desc" => "Show the attached image in the single post page.",
					"id" => $shortname."_thumb_single",
					"class" => "collapsed",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Single Image Dimensions",
					"desc" => "Enter an integer value i.e. 250 for the image size. Max width is 576.",
					"id" => $shortname."_image_dimensions",
					"std" => "",
					"class" => "hidden last",
					"type" => array( 
									array(  'id' => $shortname. '_single_w',
											'type' => 'text',
											'std' => 440,
											'meta' => 'Width'),
									array(  'id' => $shortname. '_single_h',
											'type' => 'text',
											'std' => 200,
											'meta' => 'Height')
								  ));

$options[] = array( "name" => "Add thumbnail to RSS feed",
					"desc" => "Add the the image uploaded via your Custom Settings to your RSS feed",
					"id" => $shortname."_rss_thumb",
					"std" => "false",
					"type" => "checkbox");  
					
//Footer
$options[] = array( "name" => "Footer Customization",
                    "type" => "heading");
					
					
$options[] = array( "name" => "Custom Affiliate Link",
					"desc" => "Add an affiliate link to the WooThemes logo in the footer of the theme.",
					"id" => $shortname."_footer_aff_link",
					"std" => "",
					"type" => "text");	
									
$options[] = array( "name" => "Enable Custom Footer",
					"desc" => "Activate to add the custom text below to the theme footer.",
					"id" => $shortname."_footer_custom",
					"class" => "collapsed",
					"std" => "false",
					"type" => "checkbox");    

$options[] = array( "name" => "Custom Text (Left)",
					"desc" => "Custom HTML and Text that will appear in the footer of your theme.",
					"id" => $shortname."_footer_custom_text",
					"class" => "hidden last",
					"std" => "<p></p>",
					"type" => "textarea");
							
//Advertising
                     
                                              

update_option('woo_template',$options);      
update_option('woo_themename',$themename);   
update_option('woo_shortname',$shortname);
update_option('woo_manual',$manualurl);

                                     
// Woo Metabox Options
$woo_metaboxes = array(

        "image" => array (
            "name" => "image",
            "label" => "Image",
            "type" => "upload",
            "desc" => "Upload file here..."
        ),
        "video-embed" => array (
            "name" => "video-embed",
            "label" => "Embed Code (Videos)",
            "type" => "textarea",
            "desc" => "Add embed code for video services like Youtube or Vimeo"
        ),
        "quote-author" => array (
            "name"  => "quote-author",
            "std"  => "Unknown",
            "label" => "Quote Author",
            "type" => "text",
            "desc" => "Enter the name of the Quote Author."
        ),
        "quote-url" => array (
            "name"  => "quote-url",
            "std"  => "http://",
            "label" => "Link to Quote",
            "type" => "text",
            "desc" => "Enter the url/web address of the Quote if available."
        ),
        "quote-copy" => array (
            "name"  => "quote-copy",
            "std"  => "Unknown",
            "label" => "Quote",
            "type" => "textarea",
            "desc" => "Enter the Quote."
        ),
        "audio" => array (
            "name"  => "audio",
            "std"  => "http://",
            "label" => "Audio URL",
            "type" => "text",
            "desc" => "Enter the url/web address of the Audio file."
        ),
        "link-url" => array (
            "name"  => "link-url",
            "std"  => "http://",
            "label" => "Link URL",
            "type" => "text",
            "desc" => "Enter the url/web address of the Link."
        ),
	
    );
    
update_option('woo_custom_template',$woo_metaboxes);      

}
}

?>