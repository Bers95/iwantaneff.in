


        TXTcollector 2.0.2
        Copyright (C) 1997-2011 David De Groot
        Updates and other freeware: http://bluefive.pair.com/
        Frequently Asked Questions: http://bluefive.pair.com/faq.htm


        -------------------------------------------------------------------------
        Intro
        -------------------------------------------------------------------------
        TXTcollector grabs all .txt files from the directory of your choice and
        combines them into a new (larger) text file. This can come in handy:
        I use TXTcollector myself to grab a CD full of readme's to enable me to
        read them all in one go.


        -------------------------------------------------------------------------
        Requirements
        -------------------------------------------------------------------------
        Windows 95/98 users need the VBruntime.
        You can read about this file and download it at the BlueFive homepage at
        http://bluefive.pair.com/vbrun.htm


        -------------------------------------------------------------------------
        Installation
        -------------------------------------------------------------------------
        Automatic installation (double-click the Setup.exe file).

        To uninstall:
        double-click the 'Uninstall TXTcollector' icon in the Start menu, or go
        to Control Panel/"Add/Remove Programs", select TXTcollector and click
        "Remove".


        -------------------------------------------------------------------------
        Usage
        -------------------------------------------------------------------------
        * No Carriage Returns

          If you work with continuous text files, and want to merge them without
          adding a carriage return between each segment (which would allow a
          continuous flow) then tick the "No Carriage Returns" checkbox.

        * Add Space Char

          Additionally you may need to add a space between the segments: in that
          case also tick the "Add Space Char" checkbox.

        TIPS:

        1. To merge files without any 'headers' like this:

           d:\my docs\memos\winxp\winXP_admin_and_restricted_user_setup.txt
           -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-

           -> Tick the "No Separator" box to not print any separator.
           -> Tick the "No Filename"  box to not print any reference to a file.

        2. When you click on the status label "xx files found", TXTcollector
           will popup a list with filenames.

        3. You can add your own extensions to TXTcollector. Use the
           extensions.txt file located in the TXTcollector application data
           dir* for that purpose. Keep in mind though that TXTcollector only
           handles plain text files, no matter what extension is used...

        4. There is also the option to add self-made separators to
           TXTcollector. You have to add your creations to the separators.txt
           file (also to be found in the TXTcollector application data dir*).

           * Click the "Extensions and Separators" link to open up this folder.


        -------------------------------------------------------------------------
        Limitations
        -------------------------------------------------------------------------
        1. Sometimes files are skipped:

           Files that fail the TXTcollector merge-routine are either:

           * no plain text files,
           * occupied (in use) by the system or a program, or
           * they just do not permit access...

           Tip: to avoid files from being skipped it helps when you save your
                text files using the ANSI encoding.

           You can recognize skipped files by the
           [Error] - File could not be written... line in the combined.txt file.
           (Do a simple search for "[Error" in your text editor to find it
           quickly).

           Here's an example of a file that failed to be merged:

           c:\windows\inf\apcompat.inf
           **********************************************************************
           [Error] - File could not be written...


        2. Maximum of 32765 files

           TXTcollector stops merging at a count of 32765 files. It will
           automatically disregard files above that amount but still offer you a
           a merged file with the files it processed up to that point.


        -------------------------------------------------------------------------
        Thanks
        -------------------------------------------------------------------------
        Special thanks to Brad Martinez for his superb CCRP BrowseDialog Server.
        More info: http://www.mvps.org/ccrp/


        -------------------------------------------------------------------------
        Distribution
        -------------------------------------------------------------------------
        This program is freeware. There is no charge for using it and it may be
        distributed freely so long as the files are kept together and unaltered.
        You may neither sell nor profit from distribution of this software in any
        way. Distribution on CD/DVD, Shareware-disks, in shops or through
        networks are allowed as long as

        a) no money (for the program itself) is taken
        b) each file of the original ZIP-file is included and
        c) you informed me about it.

        Distribution via web sites is granted as long as

        a) the original ZIP-file is used and
        b) a working link to http://bluefive.pair.com/ is provided.


        -------------------------------------------------------------------------
        Disclaimer
        -------------------------------------------------------------------------
        This software is provided as is and without warranty.
        The author assumes no liability for damages, either direct or
        consequential, which may result from the use of this product.



        Thanks for using TXTcollector!
        David De Groot
        ddg AT telenet.be

        �������������������������������������������������������������������������
        Keep your copy up-to-date! Please check regularly for updates at:
        http://bluefive.pair.com/

        �������������������������������������������������������������������������





