</div> <!-- /main content -->



<div id="footer" class="clearfix">
	
	<div class="secondary">
		
		<?php th_fsidebar(); ?>
		
	</div> <!-- /secondary -->
	
	<div class="primary">
		
		<?php th_fmain(); ?>
		
	</div> <!-- /primary -->
	
	<div id="theme-info" class="clearfix">
		
		<?php th_footer(); ?>
		
	</div> <!-- /theme-info -->
	
</div> <!-- /footer -->

</div><?php wp_footer(); ?></body></html>
