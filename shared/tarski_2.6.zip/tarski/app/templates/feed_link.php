<div class="secondary">
	<p><a class="feed" href="<?php echo get_feed_link(); ?>"><?php _e('Subscribe to feed', 'tarski'); ?></a></p>
</div>