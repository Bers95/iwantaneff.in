<?php $catalog = array (
  0 => 
  array (
    'mapid' => '#e-000',
    'unicode' => 
    array (
      0 => 9728,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK SUN WITH RAYS',
      'desc' => '= ARIB-9364
Temporary Notes: clear weather for Japanese mobile carriers, usually in red color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58942,
      ),
      'sjis' => 
      array (
        0 => 63647,
      ),
      'jis' => 
      array (
        0 => 30017,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 44,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58504,
      ),
      'sjis' => 
      array (
        0 => 63072,
      ),
      'jis' => 
      array (
        0 => 30017,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 81,
      ),
      'number_old' => 
      array (
        0 => 74,
      ),
      'unicode' => 
      array (
        0 => 57418,
      ),
      'sjis' => 
      array (
        0 => 63883,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040384,
      ),
    ),
  ),
  1 => 
  array (
    'mapid' => '#e-001',
    'unicode' => 
    array (
      0 => 9729,
    ),
    'char_name' => 
    array (
      'title' => 'CLOUD',
      'desc' => '= ARIB-9365',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 2,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58943,
      ),
      'sjis' => 
      array (
        0 => 63648,
      ),
      'jis' => 
      array (
        0 => 30022,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 107,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58509,
      ),
      'sjis' => 
      array (
        0 => 63077,
      ),
      'jis' => 
      array (
        0 => 30022,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 83,
      ),
      'number_old' => 
      array (
        0 => 73,
      ),
      'unicode' => 
      array (
        0 => 57417,
      ),
      'sjis' => 
      array (
        0 => 63882,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040385,
      ),
    ),
  ),
  2 => 
  array (
    'mapid' => '#e-002',
    'unicode' => 
    array (
      0 => 9748,
    ),
    'char_name' => 
    array (
      'title' => 'UMBRELLA WITH RAIN DROPS',
      'desc' => '= ARIB-9381',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 3,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58944,
      ),
      'sjis' => 
      array (
        0 => 63649,
      ),
      'jis' => 
      array (
        0 => 30021,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58508,
      ),
      'sjis' => 
      array (
        0 => 63076,
      ),
      'jis' => 
      array (
        0 => 30021,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 82,
      ),
      'number_old' => 
      array (
        0 => 75,
      ),
      'unicode' => 
      array (
        0 => 57419,
      ),
      'sjis' => 
      array (
        0 => 63884,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040386,
      ),
    ),
  ),
  3 => 
  array (
    'mapid' => '#e-003',
    'unicode' => 
    array (
      0 => 9924,
    ),
    'char_name' => 
    array (
      'title' => 'SNOWMAN WITHOUT SNOW',
      'desc' => '= ARIB-9367',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 4,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58945,
      ),
      'sjis' => 
      array (
        0 => 63650,
      ),
      'jis' => 
      array (
        0 => 30014,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 191,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58501,
      ),
      'sjis' => 
      array (
        0 => 63069,
      ),
      'jis' => 
      array (
        0 => 30014,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 84,
      ),
      'number_old' => 
      array (
        0 => 72,
      ),
      'unicode' => 
      array (
        0 => 57416,
      ),
      'sjis' => 
      array (
        0 => 63881,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040387,
      ),
    ),
  ),
  4 => 
  array (
    'mapid' => '#e-004',
    'unicode' => 
    array (
      0 => 9889,
    ),
    'char_name' => 
    array (
      'title' => 'HIGH VOLTAGE SIGN',
      'desc' => '= ARIB-9385
= lightning symbol
= thunder
Temporary Notes: Unified with ARIB-9385=⚡ U+26A1 HIGH VOLTAGE SIGN following the pattern established by ARIB-9385 where the proposal says "different meaning but similar glyph"; see also ☇ U+2607 LIGHTNING.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 5,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58946,
      ),
      'sjis' => 
      array (
        0 => 63651,
      ),
      'jis' => 
      array (
        0 => 30016,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 16,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58503,
      ),
      'sjis' => 
      array (
        0 => 63071,
      ),
      'jis' => 
      array (
        0 => 30016,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 86,
      ),
      'number_old' => 
      array (
        0 => 151,
      ),
      'unicode' => 
      array (
        0 => 57661,
      ),
      'sjis' => 
      array (
        0 => 63357,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040388,
      ),
    ),
  ),
  5 => 
  array (
    'mapid' => '#e-005',
    'unicode' => 
    array (
      0 => 127744,
    ),
    'char_name' => 
    array (
      'title' => 'CYCLONE',
      'desc' => '= typhoon, hurricane',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 6,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58947,
      ),
      'sjis' => 
      array (
        0 => 63652,
      ),
      'jis' => 
      array (
        0 => 29986,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 190,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58473,
      ),
      'sjis' => 
      array (
        0 => 63041,
      ),
      'jis' => 
      array (
        0 => 29986,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 87,
      ),
      'number_old' => 
      array (
        0 => 414,
      ),
      'unicode' => 
      array (
        0 => 58435,
      ),
      'sjis' => 
      array (
        0 => 64388,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040389,
      ),
    ),
  ),
  6 => 
  array (
    'mapid' => '#e-006',
    'unicode' => 
    array (
      0 => 127745,
    ),
    'char_name' => 
    array (
      'title' => 'FOGGY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 7,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58948,
      ),
      'sjis' => 
      array (
        0 => 63653,
      ),
      'jis' => 
      array (
        0 => 30775,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 305,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58776,
      ),
      'sjis' => 
      array (
        0 => 63413,
      ),
      'jis' => 
      array (
        0 => 30775,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[霧]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040390,
      ),
    ),
  ),
  7 => 
  array (
    'mapid' => '#e-007',
    'unicode' => 
    array (
      0 => 127746,
    ),
    'char_name' => 
    array (
      'title' => 'CLOSED UMBRELLA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 8,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58949,
      ),
      'sjis' => 
      array (
        0 => 63654,
      ),
      'jis' => 
      array (
        0 => 31294,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 481,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60136,
      ),
      'sjis' => 
      array (
        0 => 62396,
      ),
      'jis' => 
      array (
        0 => 31294,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 228,
      ),
      'number_old' => 
      array (
        0 => 407,
      ),
      'unicode' => 
      array (
        0 => 58428,
      ),
      'sjis' => 
      array (
        0 => 64380,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040391,
      ),
    ),
  ),
  8 => 
  array (
    'mapid' => '#e-008',
    'unicode' => 
    array (
      0 => 127747,
    ),
    'char_name' => 
    array (
      'title' => 'NIGHT WITH STARS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 172,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59059,
      ),
      'sjis' => 
      array (
        0 => 63831,
      ),
      'jis' => 
      array (
        0 => 31303,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 490,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60145,
      ),
      'sjis' => 
      array (
        0 => 62405,
      ),
      'jis' => 
      array (
        0 => 31303,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 307,
      ),
      'number_old' => 
      array (
        0 => 422,
      ),
      'unicode' => 
      array (
        0 => 58443,
      ),
      'sjis' => 
      array (
        0 => 64396,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040392,
      ),
    ),
  ),
  9 => 
  array (
    'mapid' => '#e-009',
    'unicode' => 
    array (
      0 => 127748,
    ),
    'char_name' => 
    array (
      'title' => 'SUNRISE OVER MOUNTAINS',
      'desc' => 'Temporary Notes: Softbank sunrise 1',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58942,
      ),
      'sjis' => 
      array (
        0 => 63647,
      ),
      'jis' => 
      array (
        0 => 30017,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 493,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60148,
      ),
      'sjis' => 
      array (
        0 => 62408,
      ),
      'jis' => 
      array (
        0 => 31306,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 303,
      ),
      'number_old' => 
      array (
        0 => 77,
      ),
      'unicode' => 
      array (
        0 => 57421,
      ),
      'sjis' => 
      array (
        0 => 63886,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040393,
      ),
    ),
  ),
  10 => 
  array (
    'mapid' => '#e-00A',
    'unicode' => 
    array (
      0 => 127749,
    ),
    'char_name' => 
    array (
      'title' => 'SUNRISE',
      'desc' => 'Temporary Notes: Sunrise over horizon (Softbank sunrise 2)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58942,
      ),
      'sjis' => 
      array (
        0 => 63647,
      ),
      'jis' => 
      array (
        0 => 30017,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 493,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60148,
      ),
      'sjis' => 
      array (
        0 => 62408,
      ),
      'jis' => 
      array (
        0 => 31306,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 304,
      ),
      'number_old' => 
      array (
        0 => 420,
      ),
      'unicode' => 
      array (
        0 => 58441,
      ),
      'sjis' => 
      array (
        0 => 64394,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040394,
      ),
    ),
  ),
  11 => 
  array (
    'mapid' => '#e-00B',
    'unicode' => 
    array (
      0 => 127750,
    ),
    'char_name' => 
    array (
      'title' => 'CITYSCAPE AT DUSK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[夕焼け]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 371,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58842,
      ),
      'sjis' => 
      array (
        0 => 62285,
      ),
      'jis' => 
      array (
        0 => 31022,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 306,
      ),
      'number_old' => 
      array (
        0 => 160,
      ),
      'unicode' => 
      array (
        0 => 57670,
      ),
      'sjis' => 
      array (
        0 => 63367,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040395,
      ),
    ),
  ),
  12 => 
  array (
    'mapid' => '#e-00C',
    'unicode' => 
    array (
      0 => 127751,
    ),
    'char_name' => 
    array (
      'title' => 'SUNSET OVER BUILDINGS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58942,
      ),
      'sjis' => 
      array (
        0 => 63647,
      ),
      'jis' => 
      array (
        0 => 30017,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 371,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58842,
      ),
      'sjis' => 
      array (
        0 => 62285,
      ),
      'jis' => 
      array (
        0 => 31022,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 305,
      ),
      'number_old' => 
      array (
        0 => 421,
      ),
      'unicode' => 
      array (
        0 => 58442,
      ),
      'sjis' => 
      array (
        0 => 64395,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040396,
      ),
    ),
  ),
  13 => 
  array (
    'mapid' => '#e-00D',
    'unicode' => 
    array (
      0 => 127752,
    ),
    'char_name' => 
    array (
      'title' => 'RAINBOW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[虹]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 491,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60146,
      ),
      'sjis' => 
      array (
        0 => 62406,
      ),
      'jis' => 
      array (
        0 => 31304,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 89,
      ),
      'number_old' => 
      array (
        0 => 423,
      ),
      'unicode' => 
      array (
        0 => 58444,
      ),
      'sjis' => 
      array (
        0 => 64397,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040397,
      ),
    ),
  ),
  14 => 
  array (
    'mapid' => '#e-00E',
    'unicode' => 
    array (
      0 => 10052,
    ),
    'char_name' => 
    array (
      'title' => 'SNOWFLAKE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[雪結晶]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 60,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58506,
      ),
      'sjis' => 
      array (
        0 => 63074,
      ),
      'jis' => 
      array (
        0 => 30019,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[雪結晶]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040398,
      ),
    ),
  ),
  15 => 
  array (
    'mapid' => '#e-00F',
    'unicode' => 
    array (
      0 => 9925,
    ),
    'char_name' => 
    array (
      'title' => 'SUN BEHIND CLOUD',
      'desc' => '= ARIB-9380',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 1,
        1 => 2,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58942,
        1 => 58943,
      ),
      'sjis' => 
      array (
        0 => 63647,
        1 => 63648,
      ),
      'jis' => 
      array (
        0 => 30017,
        1 => 30022,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 167,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58510,
      ),
      'sjis' => 
      array (
        0 => 63078,
      ),
      'jis' => 
      array (
        0 => 30023,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 81,
        1 => 83,
      ),
      'number_old' => 
      array (
        0 => 74,
        1 => 73,
      ),
      'unicode' => 
      array (
        0 => 57418,
        1 => 57417,
      ),
      'sjis' => 
      array (
        0 => 63883,
        1 => 63882,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040399,
      ),
    ),
  ),
  16 => 
  array (
    'mapid' => '#e-010',
    'unicode' => 
    array (
      0 => 127753,
    ),
    'char_name' => 
    array (
      'title' => 'BRIDGE AT NIGHT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 172,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59059,
      ),
      'sjis' => 
      array (
        0 => 63831,
      ),
      'jis' => 
      array (
        0 => 31303,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 227,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58559,
      ),
      'sjis' => 
      array (
        0 => 63128,
      ),
      'jis' => 
      array (
        0 => 30072,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 307,
      ),
      'number_old' => 
      array (
        0 => 422,
      ),
      'unicode' => 
      array (
        0 => 58443,
      ),
      'sjis' => 
      array (
        0 => 64396,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040400,
      ),
    ),
  ),
  17 => 
  array (
    'mapid' => '#e-038',
    'unicode' => 
    array (
      0 => 127754,
    ),
    'char_name' => 
    array (
      'title' => 'WATER WAVE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59199,
      ),
      'sjis' => 
      array (
        0 => 63972,
      ),
      'jis' => 
      array (
        0 => 31585,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 810,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60284,
      ),
      'sjis' => 
      array (
        0 => 62593,
      ),
      'jis' => 
      array (
        0 => 31585,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 88,
      ),
      'number_old' => 
      array (
        0 => 409,
      ),
      'unicode' => 
      array (
        0 => 58430,
      ),
      'sjis' => 
      array (
        0 => 64382,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040440,
      ),
    ),
  ),
  18 => 
  array (
    'mapid' => '#e-03A',
    'unicode' => 
    array (
      0 => 127755,
    ),
    'char_name' => 
    array (
      'title' => 'VOLCANO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[火山]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 769,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60243,
      ),
      'sjis' => 
      array (
        0 => 62551,
      ),
      'jis' => 
      array (
        0 => 31544,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[火山]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040442,
      ),
    ),
  ),
  19 => 
  array (
    'mapid' => '#e-03B',
    'unicode' => 
    array (
      0 => 127756,
    ),
    'char_name' => 
    array (
      'title' => 'MILKY WAY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 172,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59059,
      ),
      'sjis' => 
      array (
        0 => 63831,
      ),
      'jis' => 
      array (
        0 => 31303,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 781,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60255,
      ),
      'sjis' => 
      array (
        0 => 62563,
      ),
      'jis' => 
      array (
        0 => 31556,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 307,
      ),
      'number_old' => 
      array (
        0 => 422,
      ),
      'unicode' => 
      array (
        0 => 58443,
      ),
      'sjis' => 
      array (
        0 => 64396,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040443,
      ),
    ),
  ),
  20 => 
  array (
    'mapid' => '#e-039',
    'unicode' => 
    array (
      0 => 127759,
    ),
    'char_name' => 
    array (
      'title' => 'EARTH GLOBE ASIA-AUSTRALIA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[地球]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 332,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58803,
      ),
      'sjis' => 
      array (
        0 => 63440,
      ),
      'jis' => 
      array (
        0 => 30802,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[地球]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040441,
      ),
    ),
  ),
  21 => 
  array (
    'mapid' => '#e-011',
    'unicode' => 
    array (
      0 => 127761,
    ),
    'char_name' => 
    array (
      'title' => 'NEW MOON SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 321,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58792,
      ),
      'sjis' => 
      array (
        0 => 63429,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '●',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040401,
      ),
    ),
  ),
  22 => 
  array (
    'mapid' => '#e-012',
    'unicode' => 
    array (
      0 => 127764,
    ),
    'char_name' => 
    array (
      'title' => 'WAXING GIBBOUS MOON SYMBOL',
      'desc' => '= waxing moon',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 96,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59037,
      ),
      'sjis' => 
      array (
        0 => 63809,
      ),
      'jis' => 
      array (
        0 => 30792,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 322,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58793,
      ),
      'sjis' => 
      array (
        0 => 63430,
      ),
      'jis' => 
      array (
        0 => 30792,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
        0 => 76,
      ),
      'unicode' => 
      array (
        0 => 57420,
      ),
      'sjis' => 
      array (
        0 => 63885,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040402,
      ),
    ),
  ),
  23 => 
  array (
    'mapid' => '#e-013',
    'unicode' => 
    array (
      0 => 127763,
    ),
    'char_name' => 
    array (
      'title' => 'FIRST QUARTER MOON SYMBOL',
      'desc' => '= half moon',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 97,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59038,
      ),
      'sjis' => 
      array (
        0 => 63810,
      ),
      'jis' => 
      array (
        0 => 30793,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 323,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58794,
      ),
      'sjis' => 
      array (
        0 => 63431,
      ),
      'jis' => 
      array (
        0 => 30793,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
        0 => 76,
      ),
      'unicode' => 
      array (
        0 => 57420,
      ),
      'sjis' => 
      array (
        0 => 63885,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040403,
      ),
    ),
  ),
  24 => 
  array (
    'mapid' => '#e-014',
    'unicode' => 
    array (
      0 => 127769,
    ),
    'char_name' => 
    array (
      'title' => 'CRESCENT MOON',
      'desc' => '* may indicate either the first or last quarter moon
x (first quarter moon - 263D)
x (last quarter moon - 263E)
Temporary Notes: Not unified with ☽ U+263D or ☾ U+263E. (Japanese carriers don\'t pay attention which quarter moon their symbols refer to.)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 98,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59039,
      ),
      'sjis' => 
      array (
        0 => 63811,
      ),
      'jis' => 
      array (
        0 => 30015,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 15,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58502,
      ),
      'sjis' => 
      array (
        0 => 63070,
      ),
      'jis' => 
      array (
        0 => 30015,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
        0 => 76,
      ),
      'unicode' => 
      array (
        0 => 57420,
      ),
      'sjis' => 
      array (
        0 => 63885,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040404,
      ),
    ),
  ),
  25 => 
  array (
    'mapid' => '#e-015',
    'unicode' => 
    array (
      0 => 127765,
    ),
    'char_name' => 
    array (
      'title' => 'FULL MOON SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 99,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59040,
      ),
      'sjis' => 
      array (
        0 => 63812,
      ),
      'jis' => 
      array (
        0 => 32292,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '○',
    ),
    'softbank' => 
    array (
      'kaomoji' => '○',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040405,
      ),
    ),
  ),
  26 => 
  array (
    'mapid' => '#e-016',
    'unicode' => 
    array (
      0 => 127771,
    ),
    'char_name' => 
    array (
      'title' => 'FIRST QUARTER MOON WITH FACE',
      'desc' => '= half moon with face
Temporary Notes: (KDDI\'s with face)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 97,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59038,
      ),
      'sjis' => 
      array (
        0 => 63810,
      ),
      'jis' => 
      array (
        0 => 30793,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 47,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58505,
      ),
      'sjis' => 
      array (
        0 => 63073,
      ),
      'jis' => 
      array (
        0 => 30018,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
        0 => 76,
      ),
      'unicode' => 
      array (
        0 => 57420,
      ),
      'sjis' => 
      array (
        0 => 63885,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040406,
      ),
    ),
  ),
  27 => 
  array (
    'mapid' => '#e-B69',
    'unicode' => 
    array (
      0 => 127775,
    ),
    'char_name' => 
    array (
      'title' => 'GLOWING STAR',
      'desc' => 'Temporary Notes: Animated pulsating star in orange color',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[☆]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 69,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58507,
      ),
      'sjis' => 
      array (
        0 => 63075,
      ),
      'jis' => 
      array (
        0 => 30020,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 50,
      ),
      'number_old' => 
      array (
        0 => 323,
      ),
      'unicode' => 
      array (
        0 => 58165,
      ),
      'sjis' => 
      array (
        0 => 63957,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043305,
      ),
    ),
  ),
  28 => 
  array (
    'mapid' => '#e-B6A',
    'unicode' => 
    array (
      0 => 127776,
    ),
    'char_name' => 
    array (
      'title' => 'SHOOTING STAR',
      'desc' => 'Temporary Notes: Animated glowing star in blue color',
    ),
    'docomo' => 
    array (
      'kaomoji' => '☆彡',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 75,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58472,
      ),
      'sjis' => 
      array (
        0 => 63040,
      ),
      'jis' => 
      array (
        0 => 29985,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '☆彡',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043306,
      ),
    ),
  ),
  29 => 
  array (
    'mapid' => '#e-01E',
    'unicode' => 
    array (
      0 => 128336,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE ONE OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 361,
      ),
      'number_old' => 
      array (
        0 => 36,
      ),
      'unicode' => 
      array (
        0 => 57380,
      ),
      'sjis' => 
      array (
        0 => 63844,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040414,
      ),
    ),
  ),
  30 => 
  array (
    'mapid' => '#e-01F',
    'unicode' => 
    array (
      0 => 128337,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE TWO OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 362,
      ),
      'number_old' => 
      array (
        0 => 37,
      ),
      'unicode' => 
      array (
        0 => 57381,
      ),
      'sjis' => 
      array (
        0 => 63845,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040415,
      ),
    ),
  ),
  31 => 
  array (
    'mapid' => '#e-020',
    'unicode' => 
    array (
      0 => 128338,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE THREE OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 363,
      ),
      'number_old' => 
      array (
        0 => 38,
      ),
      'unicode' => 
      array (
        0 => 57382,
      ),
      'sjis' => 
      array (
        0 => 63846,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040416,
      ),
    ),
  ),
  32 => 
  array (
    'mapid' => '#e-021',
    'unicode' => 
    array (
      0 => 128339,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE FOUR OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 364,
      ),
      'number_old' => 
      array (
        0 => 39,
      ),
      'unicode' => 
      array (
        0 => 57383,
      ),
      'sjis' => 
      array (
        0 => 63847,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040417,
      ),
    ),
  ),
  33 => 
  array (
    'mapid' => '#e-022',
    'unicode' => 
    array (
      0 => 128340,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE FIVE OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 365,
      ),
      'number_old' => 
      array (
        0 => 40,
      ),
      'unicode' => 
      array (
        0 => 57384,
      ),
      'sjis' => 
      array (
        0 => 63848,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040418,
      ),
    ),
  ),
  34 => 
  array (
    'mapid' => '#e-023',
    'unicode' => 
    array (
      0 => 128341,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE SIX OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 366,
      ),
      'number_old' => 
      array (
        0 => 41,
      ),
      'unicode' => 
      array (
        0 => 57385,
      ),
      'sjis' => 
      array (
        0 => 63849,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040419,
      ),
    ),
  ),
  35 => 
  array (
    'mapid' => '#e-024',
    'unicode' => 
    array (
      0 => 128342,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE SEVEN OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 367,
      ),
      'number_old' => 
      array (
        0 => 42,
      ),
      'unicode' => 
      array (
        0 => 57386,
      ),
      'sjis' => 
      array (
        0 => 63850,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040420,
      ),
    ),
  ),
  36 => 
  array (
    'mapid' => '#e-025',
    'unicode' => 
    array (
      0 => 128343,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE EIGHT OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 368,
      ),
      'number_old' => 
      array (
        0 => 43,
      ),
      'unicode' => 
      array (
        0 => 57387,
      ),
      'sjis' => 
      array (
        0 => 63851,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040421,
      ),
    ),
  ),
  37 => 
  array (
    'mapid' => '#e-026',
    'unicode' => 
    array (
      0 => 128344,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE NINE OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 369,
      ),
      'number_old' => 
      array (
        0 => 44,
      ),
      'unicode' => 
      array (
        0 => 57388,
      ),
      'sjis' => 
      array (
        0 => 63852,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040422,
      ),
    ),
  ),
  38 => 
  array (
    'mapid' => '#e-027',
    'unicode' => 
    array (
      0 => 128345,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE TEN OCLOCK',
      'desc' => 'Design Note: For the representative font, make it look like the rest of the SB clock series rather than making it look like the new alarm clock Emoji.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 239,
      ),
      'number_old' => 
      array (
        0 => 45,
      ),
      'unicode' => 
      array (
        0 => 57389,
      ),
      'sjis' => 
      array (
        0 => 63853,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040423,
      ),
    ),
  ),
  39 => 
  array (
    'mapid' => '#e-028',
    'unicode' => 
    array (
      0 => 128346,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE ELEVEN OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 370,
      ),
      'number_old' => 
      array (
        0 => 46,
      ),
      'unicode' => 
      array (
        0 => 57390,
      ),
      'sjis' => 
      array (
        0 => 63854,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040424,
      ),
    ),
  ),
  40 => 
  array (
    'mapid' => '#e-029',
    'unicode' => 
    array (
      0 => 128347,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCK FACE TWELVE OCLOCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 360,
      ),
      'number_old' => 
      array (
        0 => 47,
      ),
      'unicode' => 
      array (
        0 => 57391,
      ),
      'sjis' => 
      array (
        0 => 63855,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040425,
      ),
    ),
  ),
  41 => 
  array (
    'mapid' => '#e-01D',
    'unicode' => 
    array (
      0 => 8986,
    ),
    'char_name' => 
    array (
      'title' => 'WATCH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59167,
      ),
      'sjis' => 
      array (
        0 => 63940,
      ),
      'jis' => 
      array (
        0 => 30583,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 25,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58746,
      ),
      'sjis' => 
      array (
        0 => 63383,
      ),
      'jis' => 
      array (
        0 => 30583,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[腕時計]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040413,
      ),
    ),
  ),
  42 => 
  array (
    'mapid' => '#e-01C',
    'unicode' => 
    array (
      0 => 8987,
    ),
    'char_name' => 
    array (
      'title' => 'HOURGLASS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59164,
      ),
      'sjis' => 
      array (
        0 => 63937,
      ),
      'jis' => 
      array (
        0 => 30005,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 57,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58747,
      ),
      'sjis' => 
      array (
        0 => 63384,
      ),
      'jis' => 
      array (
        0 => 30584,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[砂時計]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040412,
      ),
    ),
  ),
  43 => 
  array (
    'mapid' => '#e-02A',
    'unicode' => 
    array (
      0 => 9200,
    ),
    'char_name' => 
    array (
      'title' => 'ALARM CLOCK',
      'desc' => 'x (watch - 231A)
x (clock face one oclock - 1F550)
Temporary Notes: a general clock symbol
Design Note: Make the glyph look like an alarm clock.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59066,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58772,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
        0 => 30771,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 239,
      ),
      'number_old' => 
      array (
        0 => 45,
      ),
      'unicode' => 
      array (
        0 => 57389,
      ),
      'sjis' => 
      array (
        0 => 63853,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040426,
      ),
    ),
  ),
  44 => 
  array (
    'mapid' => '#e-01B',
    'unicode' => 
    array (
      0 => 9203,
    ),
    'char_name' => 
    array (
      'title' => 'HOURGLASS WITH FLOWING SAND',
      'desc' => 'x (hourglass - 231B)
Temporary Notes: Sometimes animated as by KDDI/AU. Might be allocated in the U+23xx Miscellaneous Technical block with U+231B HOURGLASS=e-01C.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59164,
      ),
      'sjis' => 
      array (
        0 => 63937,
      ),
      'jis' => 
      array (
        0 => 30005,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 58,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58492,
      ),
      'sjis' => 
      array (
        0 => 63060,
      ),
      'jis' => 
      array (
        0 => 30005,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[砂時計]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040411,
      ),
    ),
  ),
  45 => 
  array (
    'mapid' => '#e-02B',
    'unicode' => 
    array (
      0 => 9800,
    ),
    'char_name' => 
    array (
      'title' => 'ARIES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 9,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58950,
      ),
      'sjis' => 
      array (
        0 => 63655,
      ),
      'jis' => 
      array (
        0 => 30024,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 192,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58511,
      ),
      'sjis' => 
      array (
        0 => 63079,
      ),
      'jis' => 
      array (
        0 => 30024,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 405,
      ),
      'number_old' => 
      array (
        0 => 243,
      ),
      'unicode' => 
      array (
        0 => 57919,
      ),
      'sjis' => 
      array (
        0 => 63455,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040427,
      ),
    ),
  ),
  46 => 
  array (
    'mapid' => '#e-02C',
    'unicode' => 
    array (
      0 => 9801,
    ),
    'char_name' => 
    array (
      'title' => 'TAURUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 10,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58951,
      ),
      'sjis' => 
      array (
        0 => 63656,
      ),
      'jis' => 
      array (
        0 => 30025,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 193,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58512,
      ),
      'sjis' => 
      array (
        0 => 63080,
      ),
      'jis' => 
      array (
        0 => 30025,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 406,
      ),
      'number_old' => 
      array (
        0 => 244,
      ),
      'unicode' => 
      array (
        0 => 57920,
      ),
      'sjis' => 
      array (
        0 => 63456,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040428,
      ),
    ),
  ),
  47 => 
  array (
    'mapid' => '#e-02D',
    'unicode' => 
    array (
      0 => 9802,
    ),
    'char_name' => 
    array (
      'title' => 'GEMINI',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58952,
      ),
      'sjis' => 
      array (
        0 => 63657,
      ),
      'jis' => 
      array (
        0 => 30026,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 194,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58513,
      ),
      'sjis' => 
      array (
        0 => 63081,
      ),
      'jis' => 
      array (
        0 => 30026,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 407,
      ),
      'number_old' => 
      array (
        0 => 245,
      ),
      'unicode' => 
      array (
        0 => 57921,
      ),
      'sjis' => 
      array (
        0 => 63457,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040429,
      ),
    ),
  ),
  48 => 
  array (
    'mapid' => '#e-02E',
    'unicode' => 
    array (
      0 => 9803,
    ),
    'char_name' => 
    array (
      'title' => 'CANCER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 12,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58953,
      ),
      'sjis' => 
      array (
        0 => 63658,
      ),
      'jis' => 
      array (
        0 => 30027,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 195,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58514,
      ),
      'sjis' => 
      array (
        0 => 63082,
      ),
      'jis' => 
      array (
        0 => 30027,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 408,
      ),
      'number_old' => 
      array (
        0 => 246,
      ),
      'unicode' => 
      array (
        0 => 57922,
      ),
      'sjis' => 
      array (
        0 => 63458,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040430,
      ),
    ),
  ),
  49 => 
  array (
    'mapid' => '#e-02F',
    'unicode' => 
    array (
      0 => 9804,
    ),
    'char_name' => 
    array (
      'title' => 'LEO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58954,
      ),
      'sjis' => 
      array (
        0 => 63659,
      ),
      'jis' => 
      array (
        0 => 30028,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 196,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58515,
      ),
      'sjis' => 
      array (
        0 => 63083,
      ),
      'jis' => 
      array (
        0 => 30028,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 409,
      ),
      'number_old' => 
      array (
        0 => 247,
      ),
      'unicode' => 
      array (
        0 => 57923,
      ),
      'sjis' => 
      array (
        0 => 63459,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040431,
      ),
    ),
  ),
  50 => 
  array (
    'mapid' => '#e-030',
    'unicode' => 
    array (
      0 => 9805,
    ),
    'char_name' => 
    array (
      'title' => 'VIRGO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 14,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58955,
      ),
      'sjis' => 
      array (
        0 => 63660,
      ),
      'jis' => 
      array (
        0 => 30029,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 197,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58516,
      ),
      'sjis' => 
      array (
        0 => 63084,
      ),
      'jis' => 
      array (
        0 => 30029,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 410,
      ),
      'number_old' => 
      array (
        0 => 248,
      ),
      'unicode' => 
      array (
        0 => 57924,
      ),
      'sjis' => 
      array (
        0 => 63460,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040432,
      ),
    ),
  ),
  51 => 
  array (
    'mapid' => '#e-031',
    'unicode' => 
    array (
      0 => 9806,
    ),
    'char_name' => 
    array (
      'title' => 'LIBRA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 15,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58956,
      ),
      'sjis' => 
      array (
        0 => 63661,
      ),
      'jis' => 
      array (
        0 => 30030,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 198,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58517,
      ),
      'sjis' => 
      array (
        0 => 63085,
      ),
      'jis' => 
      array (
        0 => 30030,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 411,
      ),
      'number_old' => 
      array (
        0 => 249,
      ),
      'unicode' => 
      array (
        0 => 57925,
      ),
      'sjis' => 
      array (
        0 => 63461,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040433,
      ),
    ),
  ),
  52 => 
  array (
    'mapid' => '#e-032',
    'unicode' => 
    array (
      0 => 9807,
    ),
    'char_name' => 
    array (
      'title' => 'SCORPIUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 16,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58957,
      ),
      'sjis' => 
      array (
        0 => 63662,
      ),
      'jis' => 
      array (
        0 => 30031,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 199,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58518,
      ),
      'sjis' => 
      array (
        0 => 63086,
      ),
      'jis' => 
      array (
        0 => 30031,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 412,
      ),
      'number_old' => 
      array (
        0 => 250,
      ),
      'unicode' => 
      array (
        0 => 57926,
      ),
      'sjis' => 
      array (
        0 => 63462,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040434,
      ),
    ),
  ),
  53 => 
  array (
    'mapid' => '#e-033',
    'unicode' => 
    array (
      0 => 9808,
    ),
    'char_name' => 
    array (
      'title' => 'SAGITTARIUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58958,
      ),
      'sjis' => 
      array (
        0 => 63663,
      ),
      'jis' => 
      array (
        0 => 30032,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 200,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58519,
      ),
      'sjis' => 
      array (
        0 => 63087,
      ),
      'jis' => 
      array (
        0 => 30032,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 413,
      ),
      'number_old' => 
      array (
        0 => 251,
      ),
      'unicode' => 
      array (
        0 => 57927,
      ),
      'sjis' => 
      array (
        0 => 63463,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040435,
      ),
    ),
  ),
  54 => 
  array (
    'mapid' => '#e-034',
    'unicode' => 
    array (
      0 => 9809,
    ),
    'char_name' => 
    array (
      'title' => 'CAPRICORN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 18,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58959,
      ),
      'sjis' => 
      array (
        0 => 63664,
      ),
      'jis' => 
      array (
        0 => 30033,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 201,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58520,
      ),
      'sjis' => 
      array (
        0 => 63088,
      ),
      'jis' => 
      array (
        0 => 30033,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 414,
      ),
      'number_old' => 
      array (
        0 => 252,
      ),
      'unicode' => 
      array (
        0 => 57928,
      ),
      'sjis' => 
      array (
        0 => 63464,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040436,
      ),
    ),
  ),
  55 => 
  array (
    'mapid' => '#e-035',
    'unicode' => 
    array (
      0 => 9810,
    ),
    'char_name' => 
    array (
      'title' => 'AQUARIUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 19,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58960,
      ),
      'sjis' => 
      array (
        0 => 63665,
      ),
      'jis' => 
      array (
        0 => 30034,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 202,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58521,
      ),
      'sjis' => 
      array (
        0 => 63089,
      ),
      'jis' => 
      array (
        0 => 30034,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 415,
      ),
      'number_old' => 
      array (
        0 => 253,
      ),
      'unicode' => 
      array (
        0 => 57929,
      ),
      'sjis' => 
      array (
        0 => 63465,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040437,
      ),
    ),
  ),
  56 => 
  array (
    'mapid' => '#e-036',
    'unicode' => 
    array (
      0 => 9811,
    ),
    'char_name' => 
    array (
      'title' => 'PISCES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 20,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58961,
      ),
      'sjis' => 
      array (
        0 => 63666,
      ),
      'jis' => 
      array (
        0 => 30035,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 203,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58522,
      ),
      'sjis' => 
      array (
        0 => 63090,
      ),
      'jis' => 
      array (
        0 => 30035,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 416,
      ),
      'number_old' => 
      array (
        0 => 254,
      ),
      'unicode' => 
      array (
        0 => 57930,
      ),
      'sjis' => 
      array (
        0 => 63466,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040438,
      ),
    ),
  ),
  57 => 
  array (
    'mapid' => '#e-037',
    'unicode' => 
    array (
      0 => 9934,
    ),
    'char_name' => 
    array (
      'title' => 'OPHIUCHUS',
      'desc' => 'Temporary Notes: letter symbol /Serpentarius (13th zodiacal symbol, not counted as astrological sign)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[蛇使座]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 204,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58523,
      ),
      'sjis' => 
      array (
        0 => 63091,
      ),
      'jis' => 
      array (
        0 => 30036,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 417,
      ),
      'number_old' => 
      array (
        0 => 255,
      ),
      'unicode' => 
      array (
        0 => 57931,
      ),
      'sjis' => 
      array (
        0 => 63467,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040439,
      ),
    ),
  ),
  58 => 
  array (
    'mapid' => '#e-03C',
    'unicode' => 
    array (
      0 => 127808,
    ),
    'char_name' => 
    array (
      'title' => 'FOUR LEAF CLOVER',
      'desc' => 'x (shamrock - 2618)
Temporary Notes: Disunified from ☘ U+2618 SHAMROCK',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59201,
      ),
      'sjis' => 
      array (
        0 => 63974,
      ),
      'jis' => 
      array (
        0 => 30318,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 53,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58643,
      ),
      'sjis' => 
      array (
        0 => 63212,
      ),
      'jis' => 
      array (
        0 => 30318,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 94,
      ),
      'number_old' => 
      array (
        0 => 106,
      ),
      'unicode' => 
      array (
        0 => 57616,
      ),
      'sjis' => 
      array (
        0 => 63312,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040444,
      ),
    ),
  ),
  59 => 
  array (
    'mapid' => '#e-03D',
    'unicode' => 
    array (
      0 => 127799,
    ),
    'char_name' => 
    array (
      'title' => 'TULIP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59203,
      ),
      'sjis' => 
      array (
        0 => 63976,
      ),
      'jis' => 
      array (
        0 => 30271,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 113,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58596,
      ),
      'sjis' => 
      array (
        0 => 63165,
      ),
      'jis' => 
      array (
        0 => 30271,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 92,
      ),
      'number_old' => 
      array (
        0 => 274,
      ),
      'unicode' => 
      array (
        0 => 58116,
      ),
      'sjis' => 
      array (
        0 => 63908,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040445,
      ),
    ),
  ),
  60 => 
  array (
    'mapid' => '#e-03E',
    'unicode' => 
    array (
      0 => 127793,
    ),
    'char_name' => 
    array (
      'title' => 'SEEDLING',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59206,
      ),
      'sjis' => 
      array (
        0 => 63979,
      ),
      'jis' => 
      array (
        0 => 31586,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 811,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60285,
      ),
      'sjis' => 
      array (
        0 => 62594,
      ),
      'jis' => 
      array (
        0 => 31586,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 94,
      ),
      'number_old' => 
      array (
        0 => 106,
      ),
      'unicode' => 
      array (
        0 => 57616,
      ),
      'sjis' => 
      array (
        0 => 63312,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040446,
      ),
    ),
  ),
  61 => 
  array (
    'mapid' => '#e-03F',
    'unicode' => 
    array (
      0 => 127809,
    ),
    'char_name' => 
    array (
      'title' => 'MAPLE LEAF',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59207,
      ),
      'sjis' => 
      array (
        0 => 63980,
      ),
      'jis' => 
      array (
        0 => 30249,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 133,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58574,
      ),
      'sjis' => 
      array (
        0 => 63143,
      ),
      'jis' => 
      array (
        0 => 30249,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 93,
      ),
      'number_old' => 
      array (
        0 => 114,
      ),
      'unicode' => 
      array (
        0 => 57624,
      ),
      'sjis' => 
      array (
        0 => 63320,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040447,
      ),
    ),
  ),
  62 => 
  array (
    'mapid' => '#e-040',
    'unicode' => 
    array (
      0 => 127800,
    ),
    'char_name' => 
    array (
      'title' => 'CHERRY BLOSSOM',
      'desc' => 'Temporary Notes: SAKURA',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59208,
      ),
      'sjis' => 
      array (
        0 => 63981,
      ),
      'jis' => 
      array (
        0 => 30245,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 235,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58570,
      ),
      'sjis' => 
      array (
        0 => 63139,
      ),
      'jis' => 
      array (
        0 => 30245,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 91,
      ),
      'number_old' => 
      array (
        0 => 48,
      ),
      'unicode' => 
      array (
        0 => 57392,
      ),
      'sjis' => 
      array (
        0 => 63856,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040448,
      ),
    ),
  ),
  63 => 
  array (
    'mapid' => '#e-041',
    'unicode' => 
    array (
      0 => 127801,
    ),
    'char_name' => 
    array (
      'title' => 'ROSE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[バラ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 339,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58810,
      ),
      'sjis' => 
      array (
        0 => 63466,
      ),
      'jis' => 
      array (
        0 => 30828,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
        0 => 50,
      ),
      'unicode' => 
      array (
        0 => 57394,
      ),
      'sjis' => 
      array (
        0 => 63858,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040449,
      ),
    ),
  ),
  64 => 
  array (
    'mapid' => '#e-042',
    'unicode' => 
    array (
      0 => 127810,
    ),
    'char_name' => 
    array (
      'title' => 'FALLEN LEAF',
      'desc' => '= leaf
Temporary Notes: autumn leaf',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59207,
      ),
      'sjis' => 
      array (
        0 => 63980,
      ),
      'jis' => 
      array (
        0 => 30249,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 358,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58829,
      ),
      'sjis' => 
      array (
        0 => 62272,
      ),
      'jis' => 
      array (
        0 => 31009,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 103,
      ),
      'number_old' => 
      array (
        0 => 115,
      ),
      'unicode' => 
      array (
        0 => 57625,
      ),
      'sjis' => 
      array (
        0 => 63321,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040450,
      ),
    ),
  ),
  65 => 
  array (
    'mapid' => '#e-043',
    'unicode' => 
    array (
      0 => 127811,
    ),
    'char_name' => 
    array (
      'title' => 'LEAF FLUTTERING IN WIND',
      'desc' => 'Temporary Notes: animated Softbank symbol',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[風に舞う葉]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 358,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58829,
      ),
      'sjis' => 
      array (
        0 => 62272,
      ),
      'jis' => 
      array (
        0 => 31009,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 101,
      ),
      'number_old' => 
      array (
        0 => 418,
      ),
      'unicode' => 
      array (
        0 => 58439,
      ),
      'sjis' => 
      array (
        0 => 64392,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040451,
      ),
    ),
  ),
  66 => 
  array (
    'mapid' => '#e-045',
    'unicode' => 
    array (
      0 => 127802,
    ),
    'char_name' => 
    array (
      'title' => 'HIBISCUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ハイビスカス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 397,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60052,
      ),
      'sjis' => 
      array (
        0 => 62311,
      ),
      'jis' => 
      array (
        0 => 31048,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 96,
      ),
      'number_old' => 
      array (
        0 => 273,
      ),
      'unicode' => 
      array (
        0 => 58115,
      ),
      'sjis' => 
      array (
        0 => 63907,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040453,
      ),
    ),
  ),
  67 => 
  array (
    'mapid' => '#e-046',
    'unicode' => 
    array (
      0 => 127803,
    ),
    'char_name' => 
    array (
      'title' => 'SUNFLOWER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ひまわり]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 256,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58595,
      ),
      'sjis' => 
      array (
        0 => 63164,
      ),
      'jis' => 
      array (
        0 => 30270,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 97,
      ),
      'number_old' => 
      array (
        0 => 275,
      ),
      'unicode' => 
      array (
        0 => 58117,
      ),
      'sjis' => 
      array (
        0 => 63909,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040454,
      ),
    ),
  ),
  68 => 
  array (
    'mapid' => '#e-047',
    'unicode' => 
    array (
      0 => 127796,
    ),
    'char_name' => 
    array (
      'title' => 'PALM TREE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ヤシ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 255,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58594,
      ),
      'sjis' => 
      array (
        0 => 63163,
      ),
      'jis' => 
      array (
        0 => 30269,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 99,
      ),
      'number_old' => 
      array (
        0 => 277,
      ),
      'unicode' => 
      array (
        0 => 58119,
      ),
      'sjis' => 
      array (
        0 => 63911,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040455,
      ),
    ),
  ),
  69 => 
  array (
    'mapid' => '#e-048',
    'unicode' => 
    array (
      0 => 127797,
    ),
    'char_name' => 
    array (
      'title' => 'CACTUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サボテン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 399,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60054,
      ),
      'sjis' => 
      array (
        0 => 62313,
      ),
      'jis' => 
      array (
        0 => 31050,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 100,
      ),
      'number_old' => 
      array (
        0 => 278,
      ),
      'unicode' => 
      array (
        0 => 58120,
      ),
      'sjis' => 
      array (
        0 => 63912,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040456,
      ),
    ),
  ),
  70 => 
  array (
    'mapid' => '#e-049',
    'unicode' => 
    array (
      0 => 127806,
    ),
    'char_name' => 
    array (
      'title' => 'EAR OF RICE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[稲穂]',
    ),
    'au' => 
    array (
      'kaomoji' => '[稲穂]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 102,
      ),
      'number_old' => 
      array (
        0 => 415,
      ),
      'unicode' => 
      array (
        0 => 58436,
      ),
      'sjis' => 
      array (
        0 => 64389,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040457,
      ),
    ),
  ),
  71 => 
  array (
    'mapid' => '#e-04A',
    'unicode' => 
    array (
      0 => 127805,
    ),
    'char_name' => 
    array (
      'title' => 'EAR OF MAIZE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[とうもろこし]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 740,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60214,
      ),
      'sjis' => 
      array (
        0 => 62455,
      ),
      'jis' => 
      array (
        0 => 31353,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[とうもろこし]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040458,
      ),
    ),
  ),
  72 => 
  array (
    'mapid' => '#e-04B',
    'unicode' => 
    array (
      0 => 127812,
    ),
    'char_name' => 
    array (
      'title' => 'MUSHROOM',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[キノコ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 741,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60215,
      ),
      'sjis' => 
      array (
        0 => 62456,
      ),
      'jis' => 
      array (
        0 => 31354,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[キノコ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040459,
      ),
    ),
  ),
  73 => 
  array (
    'mapid' => '#e-04C',
    'unicode' => 
    array (
      0 => 127792,
    ),
    'char_name' => 
    array (
      'title' => 'CHESTNUT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[栗]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 742,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60216,
      ),
      'sjis' => 
      array (
        0 => 62457,
      ),
      'jis' => 
      array (
        0 => 31355,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[栗]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040460,
      ),
    ),
  ),
  74 => 
  array (
    'mapid' => '#e-04D',
    'unicode' => 
    array (
      0 => 127804,
    ),
    'char_name' => 
    array (
      'title' => 'BLOSSOM',
      'desc' => '= daisy',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 759,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60233,
      ),
      'sjis' => 
      array (
        0 => 62541,
      ),
      'jis' => 
      array (
        0 => 31534,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 97,
      ),
      'number_old' => 
      array (
        0 => 275,
      ),
      'unicode' => 
      array (
        0 => 58117,
      ),
      'sjis' => 
      array (
        0 => 63909,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040461,
      ),
    ),
  ),
  75 => 
  array (
    'mapid' => '#e-04E',
    'unicode' => 
    array (
      0 => 127807,
    ),
    'char_name' => 
    array (
      'title' => 'HERB',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59201,
      ),
      'sjis' => 
      array (
        0 => 63974,
      ),
      'jis' => 
      array (
        0 => 30318,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 816,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60290,
      ),
      'sjis' => 
      array (
        0 => 62599,
      ),
      'jis' => 
      array (
        0 => 31591,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 94,
      ),
      'number_old' => 
      array (
        0 => 106,
      ),
      'unicode' => 
      array (
        0 => 57616,
      ),
      'sjis' => 
      array (
        0 => 63312,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040462,
      ),
    ),
  ),
  76 => 
  array (
    'mapid' => '#e-04F',
    'unicode' => 
    array (
      0 => 127826,
    ),
    'char_name' => 
    array (
      'title' => 'CHERRIES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59202,
      ),
      'sjis' => 
      array (
        0 => 63975,
      ),
      'jis' => 
      array (
        0 => 30253,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 241,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58578,
      ),
      'sjis' => 
      array (
        0 => 63147,
      ),
      'jis' => 
      array (
        0 => 30253,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[さくらんぼ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040463,
      ),
    ),
  ),
  77 => 
  array (
    'mapid' => '#e-050',
    'unicode' => 
    array (
      0 => 127820,
    ),
    'char_name' => 
    array (
      'title' => 'BANANA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59204,
      ),
      'sjis' => 
      array (
        0 => 63977,
      ),
      'jis' => 
      array (
        0 => 31352,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 739,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60213,
      ),
      'sjis' => 
      array (
        0 => 62454,
      ),
      'jis' => 
      array (
        0 => 31352,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[バナナ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040464,
      ),
    ),
  ),
  78 => 
  array (
    'mapid' => '#e-051',
    'unicode' => 
    array (
      0 => 127822,
    ),
    'char_name' => 
    array (
      'title' => 'RED APPLE',
      'desc' => 'Old name: APPLE-1
Temporary Notes: Usually in red color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59205,
      ),
      'sjis' => 
      array (
        0 => 63978,
      ),
      'jis' => 
      array (
        0 => 31085,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 434,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60089,
      ),
      'sjis' => 
      array (
        0 => 62349,
      ),
      'jis' => 
      array (
        0 => 31085,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 190,
      ),
      'number_old' => 
      array (
        0 => 339,
      ),
      'unicode' => 
      array (
        0 => 58181,
      ),
      'sjis' => 
      array (
        0 => 63973,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040465,
      ),
    ),
  ),
  79 => 
  array (
    'mapid' => '#e-052',
    'unicode' => 
    array (
      0 => 127818,
    ),
    'char_name' => 
    array (
      'title' => 'TANGERINE',
      'desc' => 'Temporary Notes: Mikan, Orange',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[みかん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 435,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60090,
      ),
      'sjis' => 
      array (
        0 => 62350,
      ),
      'jis' => 
      array (
        0 => 31086,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 192,
      ),
      'number_old' => 
      array (
        0 => 340,
      ),
      'unicode' => 
      array (
        0 => 58182,
      ),
      'sjis' => 
      array (
        0 => 63974,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040466,
      ),
    ),
  ),
  80 => 
  array (
    'mapid' => '#e-053',
    'unicode' => 
    array (
      0 => 127827,
    ),
    'char_name' => 
    array (
      'title' => 'STRAWBERRY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[イチゴ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 243,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58580,
      ),
      'sjis' => 
      array (
        0 => 63149,
      ),
      'jis' => 
      array (
        0 => 30255,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 191,
      ),
      'number_old' => 
      array (
        0 => 341,
      ),
      'unicode' => 
      array (
        0 => 58183,
      ),
      'sjis' => 
      array (
        0 => 63975,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040467,
      ),
    ),
  ),
  81 => 
  array (
    'mapid' => '#e-054',
    'unicode' => 
    array (
      0 => 127817,
    ),
    'char_name' => 
    array (
      'title' => 'WATERMELON',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[スイカ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 238,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58573,
      ),
      'sjis' => 
      array (
        0 => 63142,
      ),
      'jis' => 
      array (
        0 => 30248,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 193,
      ),
      'number_old' => 
      array (
        0 => 342,
      ),
      'unicode' => 
      array (
        0 => 58184,
      ),
      'sjis' => 
      array (
        0 => 63976,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040468,
      ),
    ),
  ),
  82 => 
  array (
    'mapid' => '#e-055',
    'unicode' => 
    array (
      0 => 127813,
    ),
    'char_name' => 
    array (
      'title' => 'TOMATO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[トマト]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 436,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60091,
      ),
      'sjis' => 
      array (
        0 => 62351,
      ),
      'jis' => 
      array (
        0 => 31087,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 194,
      ),
      'number_old' => 
      array (
        0 => 343,
      ),
      'unicode' => 
      array (
        0 => 58185,
      ),
      'sjis' => 
      array (
        0 => 63977,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040469,
      ),
    ),
  ),
  83 => 
  array (
    'mapid' => '#e-056',
    'unicode' => 
    array (
      0 => 127814,
    ),
    'char_name' => 
    array (
      'title' => 'AUBERGINE',
      'desc' => '= eggplant',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ナス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 437,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60092,
      ),
      'sjis' => 
      array (
        0 => 62352,
      ),
      'jis' => 
      array (
        0 => 31088,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 195,
      ),
      'number_old' => 
      array (
        0 => 344,
      ),
      'unicode' => 
      array (
        0 => 58186,
      ),
      'sjis' => 
      array (
        0 => 63978,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040470,
      ),
    ),
  ),
  84 => 
  array (
    'mapid' => '#e-057',
    'unicode' => 
    array (
      0 => 127816,
    ),
    'char_name' => 
    array (
      'title' => 'MELON',
      'desc' => 'Temporary Notes: also honeydew melon',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[メロン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 736,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60210,
      ),
      'sjis' => 
      array (
        0 => 62451,
      ),
      'jis' => 
      array (
        0 => 31349,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[メロン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040471,
      ),
    ),
  ),
  85 => 
  array (
    'mapid' => '#e-058',
    'unicode' => 
    array (
      0 => 127821,
    ),
    'char_name' => 
    array (
      'title' => 'PINEAPPLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[パイナップル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 737,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60211,
      ),
      'sjis' => 
      array (
        0 => 62452,
      ),
      'jis' => 
      array (
        0 => 31350,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[パイナップル]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040472,
      ),
    ),
  ),
  86 => 
  array (
    'mapid' => '#e-059',
    'unicode' => 
    array (
      0 => 127815,
    ),
    'char_name' => 
    array (
      'title' => 'GRAPES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ブドウ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 738,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60212,
      ),
      'sjis' => 
      array (
        0 => 62453,
      ),
      'jis' => 
      array (
        0 => 31351,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ブドウ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040473,
      ),
    ),
  ),
  87 => 
  array (
    'mapid' => '#e-05A',
    'unicode' => 
    array (
      0 => 127825,
    ),
    'char_name' => 
    array (
      'title' => 'PEACH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[モモ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 743,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60217,
      ),
      'sjis' => 
      array (
        0 => 62458,
      ),
      'jis' => 
      array (
        0 => 31356,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[モモ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040474,
      ),
    ),
  ),
  88 => 
  array (
    'mapid' => '#e-05B',
    'unicode' => 
    array (
      0 => 127823,
    ),
    'char_name' => 
    array (
      'title' => 'GREEN APPLE',
      'desc' => 'Old name: APPLE-2
Temporary Notes: Usually in green color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59205,
      ),
      'sjis' => 
      array (
        0 => 63978,
      ),
      'jis' => 
      array (
        0 => 31085,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 776,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60250,
      ),
      'sjis' => 
      array (
        0 => 62558,
      ),
      'jis' => 
      array (
        0 => 31551,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 190,
      ),
      'number_old' => 
      array (
        0 => 339,
      ),
      'unicode' => 
      array (
        0 => 58181,
      ),
      'sjis' => 
      array (
        0 => 63973,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040475,
      ),
    ),
  ),
  89 => 
  array (
    'mapid' => '#e-190',
    'unicode' => 
    array (
      0 => 128064,
    ),
    'char_name' => 
    array (
      'title' => 'EYES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 84,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59025,
      ),
      'sjis' => 
      array (
        0 => 63730,
      ),
      'jis' => 
      array (
        0 => 30787,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 317,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58788,
      ),
      'sjis' => 
      array (
        0 => 63425,
      ),
      'jis' => 
      array (
        0 => 30787,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 65,
      ),
      'number_old' => 
      array (
        0 => 372,
      ),
      'unicode' => 
      array (
        0 => 58393,
      ),
      'sjis' => 
      array (
        0 => 64345,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040784,
      ),
    ),
  ),
  90 => 
  array (
    'mapid' => '#e-191',
    'unicode' => 
    array (
      0 => 128066,
    ),
    'char_name' => 
    array (
      'title' => 'EAR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59026,
      ),
      'sjis' => 
      array (
        0 => 63731,
      ),
      'jis' => 
      array (
        0 => 30788,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 318,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58789,
      ),
      'sjis' => 
      array (
        0 => 63426,
      ),
      'jis' => 
      array (
        0 => 30788,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 66,
      ),
      'number_old' => 
      array (
        0 => 374,
      ),
      'unicode' => 
      array (
        0 => 58395,
      ),
      'sjis' => 
      array (
        0 => 64347,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040785,
      ),
    ),
  ),
  91 => 
  array (
    'mapid' => '#e-192',
    'unicode' => 
    array (
      0 => 128067,
    ),
    'char_name' => 
    array (
      'title' => 'NOSE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[鼻]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 457,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60112,
      ),
      'sjis' => 
      array (
        0 => 62372,
      ),
      'jis' => 
      array (
        0 => 31270,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 67,
      ),
      'number_old' => 
      array (
        0 => 373,
      ),
      'unicode' => 
      array (
        0 => 58394,
      ),
      'sjis' => 
      array (
        0 => 64346,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040786,
      ),
    ),
  ),
  92 => 
  array (
    'mapid' => '#e-193',
    'unicode' => 
    array (
      0 => 128068,
    ),
    'char_name' => 
    array (
      'title' => 'MOUTH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 149,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59129,
      ),
      'sjis' => 
      array (
        0 => 63902,
      ),
      'jis' => 
      array (
        0 => 30278,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 458,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60113,
      ),
      'sjis' => 
      array (
        0 => 62373,
      ),
      'jis' => 
      array (
        0 => 31271,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 64,
      ),
      'number_old' => 
      array (
        0 => 375,
      ),
      'unicode' => 
      array (
        0 => 58396,
      ),
      'sjis' => 
      array (
        0 => 64348,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040787,
      ),
    ),
  ),
  93 => 
  array (
    'mapid' => '#e-194',
    'unicode' => 
    array (
      0 => 128069,
    ),
    'char_name' => 
    array (
      'title' => 'TONGUE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59176,
      ),
      'sjis' => 
      array (
        0 => 63949,
      ),
      'jis' => 
      array (
        0 => 30274,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 757,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60231,
      ),
      'sjis' => 
      array (
        0 => 62539,
      ),
      'jis' => 
      array (
        0 => 31532,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
        0 => 356,
      ),
      'unicode' => 
      array (
        0 => 58377,
      ),
      'sjis' => 
      array (
        0 => 64329,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040788,
      ),
    ),
  ),
  94 => 
  array (
    'mapid' => '#e-195',
    'unicode' => 
    array (
      0 => 128132,
    ),
    'char_name' => 
    array (
      'title' => 'LIPSTICK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59152,
      ),
      'sjis' => 
      array (
        0 => 63925,
      ),
      'jis' => 
      array (
        0 => 30308,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 295,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58633,
      ),
      'sjis' => 
      array (
        0 => 63202,
      ),
      'jis' => 
      array (
        0 => 30308,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 231,
      ),
      'number_old' => 
      array (
        0 => 298,
      ),
      'unicode' => 
      array (
        0 => 58140,
      ),
      'sjis' => 
      array (
        0 => 63932,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040789,
      ),
    ),
  ),
  95 => 
  array (
    'mapid' => '#e-196',
    'unicode' => 
    array (
      0 => 128133,
    ),
    'char_name' => 
    array (
      'title' => 'NAIL POLISH',
      'desc' => 'Old name: NAIL CARE
= manicure, nail care',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[マニキュア]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 409,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60064,
      ),
      'sjis' => 
      array (
        0 => 62323,
      ),
      'jis' => 
      array (
        0 => 31060,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 272,
      ),
      'number_old' => 
      array (
        0 => 299,
      ),
      'unicode' => 
      array (
        0 => 58141,
      ),
      'sjis' => 
      array (
        0 => 63933,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040790,
      ),
    ),
  ),
  96 => 
  array (
    'mapid' => '#e-197',
    'unicode' => 
    array (
      0 => 128134,
    ),
    'char_name' => 
    array (
      'title' => 'FACE MASSAGE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[エステ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 297,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58635,
      ),
      'sjis' => 
      array (
        0 => 63204,
      ),
      'jis' => 
      array (
        0 => 30310,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 273,
      ),
      'number_old' => 
      array (
        0 => 300,
      ),
      'unicode' => 
      array (
        0 => 58142,
      ),
      'sjis' => 
      array (
        0 => 63934,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040791,
      ),
    ),
  ),
  97 => 
  array (
    'mapid' => '#e-198',
    'unicode' => 
    array (
      0 => 128135,
    ),
    'char_name' => 
    array (
      'title' => 'HAIRCUT',
      'desc' => '* usually indicates a beauty parlor
Design Note: The glyph needs to represent a female as this Emoji refers to a beauty parlor.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 56,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58997,
      ),
      'sjis' => 
      array (
        0 => 63702,
      ),
      'jis' => 
      array (
        0 => 30321,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 410,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60065,
      ),
      'sjis' => 
      array (
        0 => 62324,
      ),
      'jis' => 
      array (
        0 => 31061,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 271,
      ),
      'number_old' => 
      array (
        0 => 301,
      ),
      'unicode' => 
      array (
        0 => 58143,
      ),
      'sjis' => 
      array (
        0 => 63935,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040792,
      ),
    ),
  ),
  98 => 
  array (
    'mapid' => '#e-199',
    'unicode' => 
    array (
      0 => 128136,
    ),
    'char_name' => 
    array (
      'title' => 'BARBER POLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[床屋]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 411,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60066,
      ),
      'sjis' => 
      array (
        0 => 62325,
      ),
      'jis' => 
      array (
        0 => 31062,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 270,
      ),
      'number_old' => 
      array (
        0 => 302,
      ),
      'unicode' => 
      array (
        0 => 58144,
      ),
      'sjis' => 
      array (
        0 => 63936,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040793,
      ),
    ),
  ),
  99 => 
  array (
    'mapid' => '#e-19A',
    'unicode' => 
    array (
      0 => 128100,
    ),
    'char_name' => 
    array (
      'title' => 'BUST IN SILHOUETTE',
      'desc' => '= guest account',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 170,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59057,
      ),
      'sjis' => 
      array (
        0 => 63829,
      ),
      'jis' => 
      array (
        0 => 32300,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '〓',
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040794,
      ),
    ),
  ),
  100 => 
  array (
    'mapid' => '#e-19B',
    'unicode' => 
    array (
      0 => 128102,
    ),
    'char_name' => 
    array (
      'title' => 'BOY',
      'desc' => 'Old name: BOYS HEAD',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 80,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58620,
      ),
      'sjis' => 
      array (
        0 => 63189,
      ),
      'jis' => 
      array (
        0 => 30295,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 280,
      ),
      'number_old' => 
      array (
        0 => 1,
      ),
      'unicode' => 
      array (
        0 => 57345,
      ),
      'sjis' => 
      array (
        0 => 63809,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040795,
      ),
    ),
  ),
  101 => 
  array (
    'mapid' => '#e-19C',
    'unicode' => 
    array (
      0 => 128103,
    ),
    'char_name' => 
    array (
      'title' => 'GIRL',
      'desc' => 'Old name: GIRLS HEAD',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 50,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58618,
      ),
      'sjis' => 
      array (
        0 => 63187,
      ),
      'jis' => 
      array (
        0 => 30293,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 281,
      ),
      'number_old' => 
      array (
        0 => 2,
      ),
      'unicode' => 
      array (
        0 => 57346,
      ),
      'sjis' => 
      array (
        0 => 63810,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040796,
      ),
    ),
  ),
  102 => 
  array (
    'mapid' => '#e-19D',
    'unicode' => 
    array (
      0 => 128104,
    ),
    'char_name' => 
    array (
      'title' => 'MAN',
      'desc' => 'Old name: MANS HEAD',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 80,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58620,
      ),
      'sjis' => 
      array (
        0 => 63189,
      ),
      'jis' => 
      array (
        0 => 30295,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 282,
      ),
      'number_old' => 
      array (
        0 => 4,
      ),
      'unicode' => 
      array (
        0 => 57348,
      ),
      'sjis' => 
      array (
        0 => 63812,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040797,
      ),
    ),
  ),
  103 => 
  array (
    'mapid' => '#e-19E',
    'unicode' => 
    array (
      0 => 128105,
    ),
    'char_name' => 
    array (
      'title' => 'WOMAN',
      'desc' => 'Old name: WOMANS HEAD',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 50,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58618,
      ),
      'sjis' => 
      array (
        0 => 63187,
      ),
      'jis' => 
      array (
        0 => 30293,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 283,
      ),
      'number_old' => 
      array (
        0 => 5,
      ),
      'unicode' => 
      array (
        0 => 57349,
      ),
      'sjis' => 
      array (
        0 => 63813,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040798,
      ),
    ),
  ),
  104 => 
  array (
    'mapid' => '#e-19F',
    'unicode' => 
    array (
      0 => 128106,
    ),
    'char_name' => 
    array (
      'title' => 'FAMILY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[家族]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 163,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58625,
      ),
      'sjis' => 
      array (
        0 => 63194,
      ),
      'jis' => 
      array (
        0 => 30300,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[家族]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040799,
      ),
    ),
  ),
  105 => 
  array (
    'mapid' => '#e-1A0',
    'unicode' => 
    array (
      0 => 128107,
    ),
    'char_name' => 
    array (
      'title' => 'MAN AND WOMAN HOLDING HANDS',
      'desc' => 'Old name: COUPLE
Temporary Notes: A couple holding hands',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カップル]',
    ),
    'au' => 
    array (
      'kaomoji' => '[カップル]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 279,
      ),
      'number_old' => 
      array (
        0 => 387,
      ),
      'unicode' => 
      array (
        0 => 58408,
      ),
      'sjis' => 
      array (
        0 => 64360,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040800,
      ),
    ),
  ),
  106 => 
  array (
    'mapid' => '#e-1A1',
    'unicode' => 
    array (
      0 => 128110,
    ),
    'char_name' => 
    array (
      'title' => 'POLICE OFFICER',
      'desc' => 'Temporary Notes: represents the police (Note: there is also just a police cap icon by Softbank.)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[警官]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 374,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58845,
      ),
      'sjis' => 
      array (
        0 => 62288,
      ),
      'jis' => 
      array (
        0 => 31025,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 288,
      ),
      'number_old' => 
      array (
        0 => 172,
      ),
      'unicode' => 
      array (
        0 => 57682,
      ),
      'sjis' => 
      array (
        0 => 63379,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040801,
      ),
    ),
  ),
  107 => 
  array (
    'mapid' => '#e-1A2',
    'unicode' => 
    array (
      0 => 128111,
    ),
    'char_name' => 
    array (
      'title' => 'WOMAN WITH BUNNY EARS',
      'desc' => 'Temporary Notes: a showgirl?',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[バニー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 468,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60123,
      ),
      'sjis' => 
      array (
        0 => 62383,
      ),
      'jis' => 
      array (
        0 => 31281,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 276,
      ),
      'number_old' => 
      array (
        0 => 388,
      ),
      'unicode' => 
      array (
        0 => 58409,
      ),
      'sjis' => 
      array (
        0 => 64361,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040802,
      ),
    ),
  ),
  108 => 
  array (
    'mapid' => '#e-1A3',
    'unicode' => 
    array (
      0 => 128112,
    ),
    'char_name' => 
    array (
      'title' => 'BRIDE WITH VEIL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花嫁]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 482,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60137,
      ),
      'sjis' => 
      array (
        0 => 62397,
      ),
      'jis' => 
      array (
        0 => 31295,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[花嫁]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040803,
      ),
    ),
  ),
  109 => 
  array (
    'mapid' => '#e-1A4',
    'unicode' => 
    array (
      0 => 128113,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON WITH BLOND HAIR',
      'desc' => 'Old name: WESTERN PERSON
Temporary Notes: both male and female icons exist',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[白人]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 705,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60179,
      ),
      'sjis' => 
      array (
        0 => 62420,
      ),
      'jis' => 
      array (
        0 => 31318,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 290,
      ),
      'number_old' => 
      array (
        0 => 444,
      ),
      'unicode' => 
      array (
        0 => 58645,
      ),
      'sjis' => 
      array (
        0 => 64437,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040804,
      ),
    ),
  ),
  110 => 
  array (
    'mapid' => '#e-1A5',
    'unicode' => 
    array (
      0 => 128114,
    ),
    'char_name' => 
    array (
      'title' => 'MAN WITH GUA PI MAO',
      'desc' => 'Design Note: The glyph should show a skullcap',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[中国人]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 706,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60180,
      ),
      'sjis' => 
      array (
        0 => 62421,
      ),
      'jis' => 
      array (
        0 => 31319,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 291,
      ),
      'number_old' => 
      array (
        0 => 445,
      ),
      'unicode' => 
      array (
        0 => 58646,
      ),
      'sjis' => 
      array (
        0 => 64438,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040805,
      ),
    ),
  ),
  111 => 
  array (
    'mapid' => '#e-1A6',
    'unicode' => 
    array (
      0 => 128115,
    ),
    'char_name' => 
    array (
      'title' => 'MAN WITH TURBAN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[インド人]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 707,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60181,
      ),
      'sjis' => 
      array (
        0 => 62422,
      ),
      'jis' => 
      array (
        0 => 31320,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 292,
      ),
      'number_old' => 
      array (
        0 => 446,
      ),
      'unicode' => 
      array (
        0 => 58647,
      ),
      'sjis' => 
      array (
        0 => 64439,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040806,
      ),
    ),
  ),
  112 => 
  array (
    'mapid' => '#e-1A7',
    'unicode' => 
    array (
      0 => 128116,
    ),
    'char_name' => 
    array (
      'title' => 'OLDER MAN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[おじいさん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 708,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60182,
      ),
      'sjis' => 
      array (
        0 => 62423,
      ),
      'jis' => 
      array (
        0 => 31321,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 284,
      ),
      'number_old' => 
      array (
        0 => 447,
      ),
      'unicode' => 
      array (
        0 => 58648,
      ),
      'sjis' => 
      array (
        0 => 64440,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040807,
      ),
    ),
  ),
  113 => 
  array (
    'mapid' => '#e-1A8',
    'unicode' => 
    array (
      0 => 128117,
    ),
    'char_name' => 
    array (
      'title' => 'OLDER WOMAN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[おばあさん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 709,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60183,
      ),
      'sjis' => 
      array (
        0 => 62424,
      ),
      'jis' => 
      array (
        0 => 31322,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 285,
      ),
      'number_old' => 
      array (
        0 => 448,
      ),
      'unicode' => 
      array (
        0 => 58649,
      ),
      'sjis' => 
      array (
        0 => 64441,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040808,
      ),
    ),
  ),
  114 => 
  array (
    'mapid' => '#e-1A9',
    'unicode' => 
    array (
      0 => 128118,
    ),
    'char_name' => 
    array (
      'title' => 'BABY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[赤ちゃん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 710,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60184,
      ),
      'sjis' => 
      array (
        0 => 62425,
      ),
      'jis' => 
      array (
        0 => 31323,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 286,
      ),
      'number_old' => 
      array (
        0 => 449,
      ),
      'unicode' => 
      array (
        0 => 58650,
      ),
      'sjis' => 
      array (
        0 => 64442,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040809,
      ),
    ),
  ),
  115 => 
  array (
    'mapid' => '#e-1AA',
    'unicode' => 
    array (
      0 => 128119,
    ),
    'char_name' => 
    array (
      'title' => 'CONSTRUCTION WORKER',
      'desc' => 'Temporary Notes: here this is male',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[工事現場の人]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 711,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60185,
      ),
      'sjis' => 
      array (
        0 => 62426,
      ),
      'jis' => 
      array (
        0 => 31324,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 289,
      ),
      'number_old' => 
      array (
        0 => 450,
      ),
      'unicode' => 
      array (
        0 => 58651,
      ),
      'sjis' => 
      array (
        0 => 64443,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040810,
      ),
    ),
  ),
  116 => 
  array (
    'mapid' => '#e-1AB',
    'unicode' => 
    array (
      0 => 128120,
    ),
    'char_name' => 
    array (
      'title' => 'PRINCESS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[お姫様]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 712,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60186,
      ),
      'sjis' => 
      array (
        0 => 62427,
      ),
      'jis' => 
      array (
        0 => 31325,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 295,
      ),
      'number_old' => 
      array (
        0 => 451,
      ),
      'unicode' => 
      array (
        0 => 58652,
      ),
      'sjis' => 
      array (
        0 => 64444,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040811,
      ),
    ),
  ),
  117 => 
  array (
    'mapid' => '#e-1AC',
    'unicode' => 
    array (
      0 => 128121,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE OGRE',
      'desc' => 'Old name: OGRE
Temporary Notes: In Japanese, "Oni" - could be a red or blue faced demon. Also refers to "Namahage" - a local year-end event in Akita.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[なまはげ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 754,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60228,
      ),
      'sjis' => 
      array (
        0 => 62536,
      ),
      'jis' => 
      array (
        0 => 31529,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[なまはげ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040812,
      ),
    ),
  ),
  118 => 
  array (
    'mapid' => '#e-1AD',
    'unicode' => 
    array (
      0 => 128122,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE GOBLIN',
      'desc' => 'Old name: GOBLIN
Temporary Notes: In Japanese "Tengu" [天狗] (long-nosed goblin, braggart)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[天狗]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 755,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60229,
      ),
      'sjis' => 
      array (
        0 => 62537,
      ),
      'jis' => 
      array (
        0 => 31530,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[天狗]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040813,
      ),
    ),
  ),
  119 => 
  array (
    'mapid' => '#e-1AE',
    'unicode' => 
    array (
      0 => 128123,
    ),
    'char_name' => 
    array (
      'title' => 'GHOST',
      'desc' => 'Temporary Notes: Ghost (cute)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[お化け]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58571,
      ),
      'sjis' => 
      array (
        0 => 63140,
      ),
      'jis' => 
      array (
        0 => 30246,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 298,
      ),
      'number_old' => 
      array (
        0 => 117,
      ),
      'unicode' => 
      array (
        0 => 57627,
      ),
      'sjis' => 
      array (
        0 => 63323,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040814,
      ),
    ),
  ),
  120 => 
  array (
    'mapid' => '#e-1AF',
    'unicode' => 
    array (
      0 => 128124,
    ),
    'char_name' => 
    array (
      'title' => 'BABY ANGEL',
      'desc' => 'Old name: CHERUB',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[天使]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 344,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58815,
      ),
      'sjis' => 
      array (
        0 => 63471,
      ),
      'jis' => 
      array (
        0 => 30833,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 296,
      ),
      'number_old' => 
      array (
        0 => 78,
      ),
      'unicode' => 
      array (
        0 => 57422,
      ),
      'sjis' => 
      array (
        0 => 63887,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040815,
      ),
    ),
  ),
  121 => 
  array (
    'mapid' => '#e-1B0',
    'unicode' => 
    array (
      0 => 128125,
    ),
    'char_name' => 
    array (
      'title' => 'EXTRATERRESTRIAL ALIEN',
      'desc' => 'Temporary Notes: Alien (big eyed type), or UFO',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[UFO]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 302,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58638,
      ),
      'sjis' => 
      array (
        0 => 63207,
      ),
      'jis' => 
      array (
        0 => 30313,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 300,
      ),
      'number_old' => 
      array (
        0 => 102,
      ),
      'unicode' => 
      array (
        0 => 57612,
      ),
      'sjis' => 
      array (
        0 => 63308,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040816,
      ),
    ),
  ),
  122 => 
  array (
    'mapid' => '#e-1B1',
    'unicode' => 
    array (
      0 => 128126,
    ),
    'char_name' => 
    array (
      'title' => 'ALIEN MONSTER',
      'desc' => 'Temporary Notes: Alien (monster type)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[宇宙人]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 274,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58604,
      ),
      'sjis' => 
      array (
        0 => 63173,
      ),
      'jis' => 
      array (
        0 => 30279,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 301,
      ),
      'number_old' => 
      array (
        0 => 133,
      ),
      'unicode' => 
      array (
        0 => 57643,
      ),
      'sjis' => 
      array (
        0 => 63339,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040817,
      ),
    ),
  ),
  123 => 
  array (
    'mapid' => '#e-1B2',
    'unicode' => 
    array (
      0 => 128127,
    ),
    'char_name' => 
    array (
      'title' => 'IMP',
      'desc' => 'Temporary Notes: Devil (cute)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[アクマ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 277,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58607,
      ),
      'sjis' => 
      array (
        0 => 63176,
      ),
      'jis' => 
      array (
        0 => 30282,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 297,
      ),
      'number_old' => 
      array (
        0 => 116,
      ),
      'unicode' => 
      array (
        0 => 57626,
      ),
      'sjis' => 
      array (
        0 => 63322,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040818,
      ),
    ),
  ),
  124 => 
  array (
    'mapid' => '#e-1B3',
    'unicode' => 
    array (
      0 => 128128,
    ),
    'char_name' => 
    array (
      'title' => 'SKULL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ドクロ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 286,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58616,
      ),
      'sjis' => 
      array (
        0 => 63185,
      ),
      'jis' => 
      array (
        0 => 30291,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 299,
      ),
      'number_old' => 
      array (
        0 => 118,
      ),
      'unicode' => 
      array (
        0 => 57628,
      ),
      'sjis' => 
      array (
        0 => 63324,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040819,
      ),
    ),
  ),
  125 => 
  array (
    'mapid' => '#e-1B4',
    'unicode' => 
    array (
      0 => 128129,
    ),
    'char_name' => 
    array (
      'title' => 'INFORMATION DESK PERSON',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[案内]',
    ),
    'au' => 
    array (
      'kaomoji' => '[案内]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 287,
      ),
      'number_old' => 
      array (
        0 => 263,
      ),
      'unicode' => 
      array (
        0 => 57939,
      ),
      'sjis' => 
      array (
        0 => 63475,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040820,
      ),
    ),
  ),
  126 => 
  array (
    'mapid' => '#e-1B5',
    'unicode' => 
    array (
      0 => 128130,
    ),
    'char_name' => 
    array (
      'title' => 'GUARDSMAN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[衛兵]',
    ),
    'au' => 
    array (
      'kaomoji' => '[衛兵]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 293,
      ),
      'number_old' => 
      array (
        0 => 453,
      ),
      'unicode' => 
      array (
        0 => 58654,
      ),
      'sjis' => 
      array (
        0 => 64446,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040821,
      ),
    ),
  ),
  127 => 
  array (
    'mapid' => '#e-1B6',
    'unicode' => 
    array (
      0 => 128131,
    ),
    'char_name' => 
    array (
      'title' => 'DANCER',
      'desc' => 'Temporary Notes: Dancer (SoftBank = flamenco, KDDI = disco, oh well--it\'s their mapping)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ダンス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 714,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60188,
      ),
      'sjis' => 
      array (
        0 => 62429,
      ),
      'jis' => 
      array (
        0 => 31327,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 275,
      ),
      'number_old' => 
      array (
        0 => 454,
      ),
      'unicode' => 
      array (
        0 => 58655,
      ),
      'sjis' => 
      array (
        0 => 64447,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040822,
      ),
    ),
  ),
  128 => 
  array (
    'mapid' => '#e-1B9',
    'unicode' => 
    array (
      0 => 128012,
    ),
    'char_name' => 
    array (
      'title' => 'SNAIL',
      'desc' => '* fifth of the signs of the Asian zodiac, used in Kazakhstan',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59214,
      ),
      'sjis' => 
      array (
        0 => 63987,
      ),
      'jis' => 
      array (
        0 => 31587,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 812,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60286,
      ),
      'sjis' => 
      array (
        0 => 62595,
      ),
      'jis' => 
      array (
        0 => 31587,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[カタツムリ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040825,
      ),
    ),
  ),
  129 => 
  array (
    'mapid' => '#e-1D3',
    'unicode' => 
    array (
      0 => 128013,
    ),
    'char_name' => 
    array (
      'title' => 'SNAKE',
      'desc' => '* sixth of the signs of the Asian zodiac',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ヘビ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 720,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60194,
      ),
      'sjis' => 
      array (
        0 => 62435,
      ),
      'jis' => 
      array (
        0 => 31333,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 133,
      ),
      'number_old' => 
      array (
        0 => 468,
      ),
      'unicode' => 
      array (
        0 => 58669,
      ),
      'sjis' => 
      array (
        0 => 64461,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040851,
      ),
    ),
  ),
  130 => 
  array (
    'mapid' => '#e-7DC',
    'unicode' => 
    array (
      0 => 128014,
    ),
    'char_name' => 
    array (
      'title' => 'HORSE',
      'desc' => '* seventh of the signs of the Asian zodiac',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59220,
      ),
      'sjis' => 
      array (
        0 => 63993,
      ),
      'jis' => 
      array (
        0 => 30259,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 248,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58584,
      ),
      'sjis' => 
      array (
        0 => 63153,
      ),
      'jis' => 
      array (
        0 => 30259,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 121,
      ),
      'number_old' => 
      array (
        0 => 142,
      ),
      'unicode' => 
      array (
        0 => 57652,
      ),
      'sjis' => 
      array (
        0 => 63348,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042396,
      ),
    ),
  ),
  131 => 
  array (
    'mapid' => '#e-1D4',
    'unicode' => 
    array (
      0 => 128020,
    ),
    'char_name' => 
    array (
      'title' => 'CHICKEN',
      'desc' => '* tenth of the signs of the Asian zodiac, used in Persia
= hen
= poultry (on menus)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ニワトリ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 721,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60195,
      ),
      'sjis' => 
      array (
        0 => 62436,
      ),
      'jis' => 
      array (
        0 => 31334,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 124,
      ),
      'number_old' => 
      array (
        0 => 469,
      ),
      'unicode' => 
      array (
        0 => 58670,
      ),
      'sjis' => 
      array (
        0 => 64462,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040852,
      ),
    ),
  ),
  132 => 
  array (
    'mapid' => '#e-1D5',
    'unicode' => 
    array (
      0 => 128023,
    ),
    'char_name' => 
    array (
      'title' => 'BOAR',
      'desc' => '* twelfth of the signs of the Asian zodiac, used in Japan',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[イノシシ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 722,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60196,
      ),
      'sjis' => 
      array (
        0 => 62437,
      ),
      'jis' => 
      array (
        0 => 31335,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 118,
      ),
      'number_old' => 
      array (
        0 => 470,
      ),
      'unicode' => 
      array (
        0 => 58671,
      ),
      'sjis' => 
      array (
        0 => 64463,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040853,
      ),
    ),
  ),
  133 => 
  array (
    'mapid' => '#e-1D6',
    'unicode' => 
    array (
      0 => 128043,
    ),
    'char_name' => 
    array (
      'title' => 'BACTRIAN CAMEL',
      'desc' => '* has two humps',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ラクダ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 723,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60197,
      ),
      'sjis' => 
      array (
        0 => 62438,
      ),
      'jis' => 
      array (
        0 => 31336,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 119,
      ),
      'number_old' => 
      array (
        0 => 471,
      ),
      'unicode' => 
      array (
        0 => 58672,
      ),
      'sjis' => 
      array (
        0 => 64464,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040854,
      ),
    ),
  ),
  134 => 
  array (
    'mapid' => '#e-1CC',
    'unicode' => 
    array (
      0 => 128024,
    ),
    'char_name' => 
    array (
      'title' => 'ELEPHANT',
      'desc' => '* twelfth of the signs of the Asian zodiac, used in Thailand',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ゾウ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 717,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60191,
      ),
      'sjis' => 
      array (
        0 => 62432,
      ),
      'jis' => 
      array (
        0 => 31330,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 122,
      ),
      'number_old' => 
      array (
        0 => 461,
      ),
      'unicode' => 
      array (
        0 => 58662,
      ),
      'sjis' => 
      array (
        0 => 64454,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040844,
      ),
    ),
  ),
  135 => 
  array (
    'mapid' => '#e-1CD',
    'unicode' => 
    array (
      0 => 128040,
    ),
    'char_name' => 
    array (
      'title' => 'KOALA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[コアラ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 718,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60192,
      ),
      'sjis' => 
      array (
        0 => 62433,
      ),
      'jis' => 
      array (
        0 => 31331,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 113,
      ),
      'number_old' => 
      array (
        0 => 462,
      ),
      'unicode' => 
      array (
        0 => 58663,
      ),
      'sjis' => 
      array (
        0 => 64455,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040845,
      ),
    ),
  ),
  136 => 
  array (
    'mapid' => '#e-1CE',
    'unicode' => 
    array (
      0 => 128018,
    ),
    'char_name' => 
    array (
      'title' => 'MONKEY',
      'desc' => '* ninth of the signs of the Asian zodiac',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 249,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58585,
      ),
      'sjis' => 
      array (
        0 => 63154,
      ),
      'jis' => 
      array (
        0 => 30260,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 120,
      ),
      'number_old' => 
      array (
        0 => 463,
      ),
      'unicode' => 
      array (
        0 => 58664,
      ),
      'sjis' => 
      array (
        0 => 64456,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040846,
      ),
    ),
  ),
  137 => 
  array (
    'mapid' => '#e-1CF',
    'unicode' => 
    array (
      0 => 128017,
    ),
    'char_name' => 
    array (
      'title' => 'SHEEP',
      'desc' => '* eighth of the signs of the Asian zodiac, used in Persia
Temporary Notes: Note Aries (sheep) by KDDI. Zodiac',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ヒツジ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 192,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58511,
      ),
      'sjis' => 
      array (
        0 => 63079,
      ),
      'jis' => 
      array (
        0 => 30024,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 123,
      ),
      'number_old' => 
      array (
        0 => 464,
      ),
      'unicode' => 
      array (
        0 => 58665,
      ),
      'sjis' => 
      array (
        0 => 64457,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040847,
      ),
    ),
  ),
  138 => 
  array (
    'mapid' => '#e-1C5',
    'unicode' => 
    array (
      0 => 128025,
    ),
    'char_name' => 
    array (
      'title' => 'OCTOPUS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[タコ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 352,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58823,
      ),
      'sjis' => 
      array (
        0 => 63479,
      ),
      'jis' => 
      array (
        0 => 30841,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 132,
      ),
      'number_old' => 
      array (
        0 => 100,
      ),
      'unicode' => 
      array (
        0 => 57610,
      ),
      'sjis' => 
      array (
        0 => 63306,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040837,
      ),
    ),
  ),
  139 => 
  array (
    'mapid' => '#e-1C6',
    'unicode' => 
    array (
      0 => 128026,
    ),
    'char_name' => 
    array (
      'title' => 'SPIRAL SHELL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[巻貝]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 485,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60140,
      ),
      'sjis' => 
      array (
        0 => 62400,
      ),
      'jis' => 
      array (
        0 => 31298,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 135,
      ),
      'number_old' => 
      array (
        0 => 412,
      ),
      'unicode' => 
      array (
        0 => 58433,
      ),
      'sjis' => 
      array (
        0 => 64386,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040838,
      ),
    ),
  ),
  140 => 
  array (
    'mapid' => '#e-1CB',
    'unicode' => 
    array (
      0 => 128027,
    ),
    'char_name' => 
    array (
      'title' => 'BUG',
      'desc' => 'Temporary Notes: This Emoji may point to a centipede or hairy catepillar. It typically indicates something "distasteful".',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ゲジゲジ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 716,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60190,
      ),
      'sjis' => 
      array (
        0 => 62431,
      ),
      'jis' => 
      array (
        0 => 31329,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 134,
      ),
      'number_old' => 
      array (
        0 => 460,
      ),
      'unicode' => 
      array (
        0 => 58661,
      ),
      'sjis' => 
      array (
        0 => 64453,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040843,
      ),
    ),
  ),
  141 => 
  array (
    'mapid' => '#e-1DA',
    'unicode' => 
    array (
      0 => 128028,
    ),
    'char_name' => 
    array (
      'title' => 'ANT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[アリ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 253,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58589,
      ),
      'sjis' => 
      array (
        0 => 63158,
      ),
      'jis' => 
      array (
        0 => 30264,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[アリ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040858,
      ),
    ),
  ),
  142 => 
  array (
    'mapid' => '#e-1E1',
    'unicode' => 
    array (
      0 => 128029,
    ),
    'char_name' => 
    array (
      'title' => 'HONEYBEE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ミツバチ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 773,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60247,
      ),
      'sjis' => 
      array (
        0 => 62555,
      ),
      'jis' => 
      array (
        0 => 31548,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ミツバチ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040865,
      ),
    ),
  ),
  143 => 
  array (
    'mapid' => '#e-1E2',
    'unicode' => 
    array (
      0 => 128030,
    ),
    'char_name' => 
    array (
      'title' => 'LADY BEETLE',
      'desc' => 'Old name: LADYBUG
= ladybird, ladybug, coccinellids',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[てんとう虫]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 774,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60248,
      ),
      'sjis' => 
      array (
        0 => 62556,
      ),
      'jis' => 
      array (
        0 => 31549,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[てんとう虫]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040866,
      ),
    ),
  ),
  144 => 
  array (
    'mapid' => '#e-1C9',
    'unicode' => 
    array (
      0 => 128032,
    ),
    'char_name' => 
    array (
      'title' => 'TROPICAL FISH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59217,
      ),
      'sjis' => 
      array (
        0 => 63990,
      ),
      'jis' => 
      array (
        0 => 31328,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 715,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60189,
      ),
      'sjis' => 
      array (
        0 => 62430,
      ),
      'jis' => 
      array (
        0 => 31328,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 131,
      ),
      'number_old' => 
      array (
        0 => 457,
      ),
      'unicode' => 
      array (
        0 => 58658,
      ),
      'sjis' => 
      array (
        0 => 64450,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040841,
      ),
    ),
  ),
  145 => 
  array (
    'mapid' => '#e-1D9',
    'unicode' => 
    array (
      0 => 128033,
    ),
    'char_name' => 
    array (
      'title' => 'BLOWFISH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59217,
      ),
      'sjis' => 
      array (
        0 => 63990,
      ),
      'jis' => 
      array (
        0 => 31328,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 242,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58579,
      ),
      'sjis' => 
      array (
        0 => 63148,
      ),
      'jis' => 
      array (
        0 => 30254,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 130,
      ),
      'number_old' => 
      array (
        0 => 25,
      ),
      'unicode' => 
      array (
        0 => 57369,
      ),
      'sjis' => 
      array (
        0 => 63833,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040857,
      ),
    ),
  ),
  146 => 
  array (
    'mapid' => '#e-1DC',
    'unicode' => 
    array (
      0 => 128034,
    ),
    'char_name' => 
    array (
      'title' => 'TURTLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カメ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 365,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58836,
      ),
      'sjis' => 
      array (
        0 => 62279,
      ),
      'jis' => 
      array (
        0 => 31016,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[カメ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040860,
      ),
    ),
  ),
  147 => 
  array (
    'mapid' => '#e-1BA',
    'unicode' => 
    array (
      0 => 128036,
    ),
    'char_name' => 
    array (
      'title' => 'BABY CHICK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59215,
      ),
      'sjis' => 
      array (
        0 => 63988,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 78,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58592,
      ),
      'sjis' => 
      array (
        0 => 63161,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
        0 => 458,
      ),
      'unicode' => 
      array (
        0 => 58659,
      ),
      'sjis' => 
      array (
        0 => 64451,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040826,
      ),
    ),
  ),
  148 => 
  array (
    'mapid' => '#e-1BB',
    'unicode' => 
    array (
      0 => 128037,
    ),
    'char_name' => 
    array (
      'title' => 'FRONT-FACING BABY CHICK',
      'desc' => 'Temporary Notes: chick facing you',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59215,
      ),
      'sjis' => 
      array (
        0 => 63988,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 804,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60278,
      ),
      'sjis' => 
      array (
        0 => 62586,
      ),
      'jis' => 
      array (
        0 => 31579,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
        0 => 458,
      ),
      'unicode' => 
      array (
        0 => 58659,
      ),
      'sjis' => 
      array (
        0 => 64451,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040827,
      ),
    ),
  ),
  149 => 
  array (
    'mapid' => '#e-1C8',
    'unicode' => 
    array (
      0 => 128038,
    ),
    'char_name' => 
    array (
      'title' => 'BIRD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59215,
      ),
      'sjis' => 
      array (
        0 => 63988,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 78,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58592,
      ),
      'sjis' => 
      array (
        0 => 63161,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 126,
      ),
      'number_old' => 
      array (
        0 => 456,
      ),
      'unicode' => 
      array (
        0 => 58657,
      ),
      'sjis' => 
      array (
        0 => 64449,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040840,
      ),
    ),
  ),
  150 => 
  array (
    'mapid' => '#e-1DD',
    'unicode' => 
    array (
      0 => 128035,
    ),
    'char_name' => 
    array (
      'title' => 'HATCHING CHICK',
      'desc' => 'Temporary Notes: animated by KDDI',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59215,
      ),
      'sjis' => 
      array (
        0 => 63988,
      ),
      'jis' => 
      array (
        0 => 30267,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 372,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58843,
      ),
      'sjis' => 
      array (
        0 => 62286,
      ),
      'jis' => 
      array (
        0 => 31023,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
        0 => 458,
      ),
      'unicode' => 
      array (
        0 => 58659,
      ),
      'sjis' => 
      array (
        0 => 64451,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040861,
      ),
    ),
  ),
  151 => 
  array (
    'mapid' => '#e-1BC',
    'unicode' => 
    array (
      0 => 128039,
    ),
    'char_name' => 
    array (
      'title' => 'PENGUIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59216,
      ),
      'sjis' => 
      array (
        0 => 63989,
      ),
      'jis' => 
      array (
        0 => 30263,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 252,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58588,
      ),
      'sjis' => 
      array (
        0 => 63157,
      ),
      'jis' => 
      array (
        0 => 30263,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 127,
      ),
      'number_old' => 
      array (
        0 => 85,
      ),
      'unicode' => 
      array (
        0 => 57429,
      ),
      'sjis' => 
      array (
        0 => 63894,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040828,
      ),
    ),
  ),
  152 => 
  array (
    'mapid' => '#e-1D8',
    'unicode' => 
    array (
      0 => 128041,
    ),
    'char_name' => 
    array (
      'title' => 'POODLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 100,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59041,
      ),
      'sjis' => 
      array (
        0 => 63813,
      ),
      'jis' => 
      array (
        0 => 30268,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 74,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58591,
      ),
      'sjis' => 
      array (
        0 => 63160,
      ),
      'jis' => 
      array (
        0 => 30266,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 105,
      ),
      'number_old' => 
      array (
        0 => 82,
      ),
      'unicode' => 
      array (
        0 => 57426,
      ),
      'sjis' => 
      array (
        0 => 63891,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040856,
      ),
    ),
  ),
  153 => 
  array (
    'mapid' => '#e-1BD',
    'unicode' => 
    array (
      0 => 128031,
    ),
    'char_name' => 
    array (
      'title' => 'FISH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59217,
      ),
      'sjis' => 
      array (
        0 => 63990,
      ),
      'jis' => 
      array (
        0 => 31328,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 203,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58522,
      ),
      'sjis' => 
      array (
        0 => 63090,
      ),
      'jis' => 
      array (
        0 => 30035,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 130,
      ),
      'number_old' => 
      array (
        0 => 25,
      ),
      'unicode' => 
      array (
        0 => 57369,
      ),
      'sjis' => 
      array (
        0 => 63833,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040829,
      ),
    ),
  ),
  154 => 
  array (
    'mapid' => '#e-1C7',
    'unicode' => 
    array (
      0 => 128044,
    ),
    'char_name' => 
    array (
      'title' => 'DOLPHIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[イルカ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 713,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60187,
      ),
      'sjis' => 
      array (
        0 => 62428,
      ),
      'jis' => 
      array (
        0 => 31326,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 129,
      ),
      'number_old' => 
      array (
        0 => 455,
      ),
      'unicode' => 
      array (
        0 => 58656,
      ),
      'sjis' => 
      array (
        0 => 64448,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040839,
      ),
    ),
  ),
  155 => 
  array (
    'mapid' => '#e-1C2',
    'unicode' => 
    array (
      0 => 128045,
    ),
    'char_name' => 
    array (
      'title' => 'MOUSE FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ネズミ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 347,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58818,
      ),
      'sjis' => 
      array (
        0 => 63474,
      ),
      'jis' => 
      array (
        0 => 30836,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 107,
      ),
      'number_old' => 
      array (
        0 => 83,
      ),
      'unicode' => 
      array (
        0 => 57427,
      ),
      'sjis' => 
      array (
        0 => 63892,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040834,
      ),
    ),
  ),
  156 => 
  array (
    'mapid' => '#e-1C0',
    'unicode' => 
    array (
      0 => 128047,
    ),
    'char_name' => 
    array (
      'title' => 'TIGER FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[トラ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 345,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58816,
      ),
      'sjis' => 
      array (
        0 => 63472,
      ),
      'jis' => 
      array (
        0 => 30834,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 108,
      ),
      'number_old' => 
      array (
        0 => 80,
      ),
      'unicode' => 
      array (
        0 => 57424,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040832,
      ),
    ),
  ),
  157 => 
  array (
    'mapid' => '#e-1B8',
    'unicode' => 
    array (
      0 => 128049,
    ),
    'char_name' => 
    array (
      'title' => 'CAT FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 101,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59042,
      ),
      'sjis' => 
      array (
        0 => 63814,
      ),
      'jis' => 
      array (
        0 => 30262,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 251,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58587,
      ),
      'sjis' => 
      array (
        0 => 63156,
      ),
      'jis' => 
      array (
        0 => 30262,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 104,
      ),
      'number_old' => 
      array (
        0 => 79,
      ),
      'unicode' => 
      array (
        0 => 57423,
      ),
      'sjis' => 
      array (
        0 => 63888,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040824,
      ),
    ),
  ),
  158 => 
  array (
    'mapid' => '#e-1C3',
    'unicode' => 
    array (
      0 => 128051,
    ),
    'char_name' => 
    array (
      'title' => 'SPOUTING WHALE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[クジラ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 246,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58480,
      ),
      'sjis' => 
      array (
        0 => 63048,
      ),
      'jis' => 
      array (
        0 => 29993,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 128,
      ),
      'number_old' => 
      array (
        0 => 84,
      ),
      'unicode' => 
      array (
        0 => 57428,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040835,
      ),
    ),
  ),
  159 => 
  array (
    'mapid' => '#e-1BE',
    'unicode' => 
    array (
      0 => 128052,
    ),
    'char_name' => 
    array (
      'title' => 'HORSE FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59220,
      ),
      'sjis' => 
      array (
        0 => 63993,
      ),
      'jis' => 
      array (
        0 => 30259,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 248,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58584,
      ),
      'sjis' => 
      array (
        0 => 63153,
      ),
      'jis' => 
      array (
        0 => 30259,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
        0 => 26,
      ),
      'unicode' => 
      array (
        0 => 57370,
      ),
      'sjis' => 
      array (
        0 => 63834,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040830,
      ),
    ),
  ),
  160 => 
  array (
    'mapid' => '#e-1C4',
    'unicode' => 
    array (
      0 => 128053,
    ),
    'char_name' => 
    array (
      'title' => 'MONKEY FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 249,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58585,
      ),
      'sjis' => 
      array (
        0 => 63154,
      ),
      'jis' => 
      array (
        0 => 30260,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 109,
      ),
      'number_old' => 
      array (
        0 => 99,
      ),
      'unicode' => 
      array (
        0 => 57609,
      ),
      'sjis' => 
      array (
        0 => 63305,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040836,
      ),
    ),
  ),
  161 => 
  array (
    'mapid' => '#e-1B7',
    'unicode' => 
    array (
      0 => 128054,
    ),
    'char_name' => 
    array (
      'title' => 'DOG FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 100,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59041,
      ),
      'sjis' => 
      array (
        0 => 63813,
      ),
      'jis' => 
      array (
        0 => 30268,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 134,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58593,
      ),
      'sjis' => 
      array (
        0 => 63162,
      ),
      'jis' => 
      array (
        0 => 30268,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 105,
      ),
      'number_old' => 
      array (
        0 => 82,
      ),
      'unicode' => 
      array (
        0 => 57426,
      ),
      'sjis' => 
      array (
        0 => 63891,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040823,
      ),
    ),
  ),
  162 => 
  array (
    'mapid' => '#e-1BF',
    'unicode' => 
    array (
      0 => 128055,
    ),
    'char_name' => 
    array (
      'title' => 'PIG FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59221,
      ),
      'sjis' => 
      array (
        0 => 63994,
      ),
      'jis' => 
      array (
        0 => 30265,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 254,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58590,
      ),
      'sjis' => 
      array (
        0 => 63159,
      ),
      'jis' => 
      array (
        0 => 30265,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 106,
      ),
      'number_old' => 
      array (
        0 => 101,
      ),
      'unicode' => 
      array (
        0 => 57611,
      ),
      'sjis' => 
      array (
        0 => 63307,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040831,
      ),
    ),
  ),
  163 => 
  array (
    'mapid' => '#e-1C1',
    'unicode' => 
    array (
      0 => 128059,
    ),
    'char_name' => 
    array (
      'title' => 'BEAR FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[クマ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 346,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58817,
      ),
      'sjis' => 
      array (
        0 => 63473,
      ),
      'jis' => 
      array (
        0 => 30835,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 110,
      ),
      'number_old' => 
      array (
        0 => 81,
      ),
      'unicode' => 
      array (
        0 => 57425,
      ),
      'sjis' => 
      array (
        0 => 63890,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040833,
      ),
    ),
  ),
  164 => 
  array (
    'mapid' => '#e-1CA',
    'unicode' => 
    array (
      0 => 128057,
    ),
    'char_name' => 
    array (
      'title' => 'HAMSTER FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ハムスター]',
    ),
    'au' => 
    array (
      'kaomoji' => '[ハムスター]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 114,
      ),
      'number_old' => 
      array (
        0 => 459,
      ),
      'unicode' => 
      array (
        0 => 58660,
      ),
      'sjis' => 
      array (
        0 => 64452,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040842,
      ),
    ),
  ),
  165 => 
  array (
    'mapid' => '#e-1D0',
    'unicode' => 
    array (
      0 => 128058,
    ),
    'char_name' => 
    array (
      'title' => 'WOLF FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 100,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59041,
      ),
      'sjis' => 
      array (
        0 => 63813,
      ),
      'jis' => 
      array (
        0 => 30268,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 134,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58593,
      ),
      'sjis' => 
      array (
        0 => 63162,
      ),
      'jis' => 
      array (
        0 => 30268,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 117,
      ),
      'number_old' => 
      array (
        0 => 465,
      ),
      'unicode' => 
      array (
        0 => 58666,
      ),
      'sjis' => 
      array (
        0 => 64458,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040848,
      ),
    ),
  ),
  166 => 
  array (
    'mapid' => '#e-1D1',
    'unicode' => 
    array (
      0 => 128046,
    ),
    'char_name' => 
    array (
      'title' => 'COW FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[牛]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 719,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60193,
      ),
      'sjis' => 
      array (
        0 => 62434,
      ),
      'jis' => 
      array (
        0 => 31332,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 112,
      ),
      'number_old' => 
      array (
        0 => 466,
      ),
      'unicode' => 
      array (
        0 => 58667,
      ),
      'sjis' => 
      array (
        0 => 64459,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040849,
      ),
    ),
  ),
  167 => 
  array (
    'mapid' => '#e-1D2',
    'unicode' => 
    array (
      0 => 128048,
    ),
    'char_name' => 
    array (
      'title' => 'RABBIT FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ウサギ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 247,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58583,
      ),
      'sjis' => 
      array (
        0 => 63152,
      ),
      'jis' => 
      array (
        0 => 30258,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 111,
      ),
      'number_old' => 
      array (
        0 => 467,
      ),
      'unicode' => 
      array (
        0 => 58668,
      ),
      'sjis' => 
      array (
        0 => 64460,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040850,
      ),
    ),
  ),
  168 => 
  array (
    'mapid' => '#e-1D7',
    'unicode' => 
    array (
      0 => 128056,
    ),
    'char_name' => 
    array (
      'title' => 'FROG FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カエル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 250,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58586,
      ),
      'sjis' => 
      array (
        0 => 63155,
      ),
      'jis' => 
      array (
        0 => 30261,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 115,
      ),
      'number_old' => 
      array (
        0 => 472,
      ),
      'unicode' => 
      array (
        0 => 58673,
      ),
      'sjis' => 
      array (
        0 => 64465,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040855,
      ),
    ),
  ),
  169 => 
  array (
    'mapid' => '#e-1DB',
    'unicode' => 
    array (
      0 => 128062,
    ),
    'char_name' => 
    array (
      'title' => 'PAW PRINTS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 91,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59032,
      ),
      'sjis' => 
      array (
        0 => 63737,
      ),
      'jis' => 
      array (
        0 => 31341,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 276,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58606,
      ),
      'sjis' => 
      array (
        0 => 63175,
      ),
      'jis' => 
      array (
        0 => 30281,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 73,
      ),
      'number_old' => 
      array (
        0 => 477,
      ),
      'unicode' => 
      array (
        0 => 58678,
      ),
      'sjis' => 
      array (
        0 => 64470,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040859,
      ),
    ),
  ),
  170 => 
  array (
    'mapid' => '#e-1DE',
    'unicode' => 
    array (
      0 => 128050,
    ),
    'char_name' => 
    array (
      'title' => 'DRAGON FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[辰]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 749,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60223,
      ),
      'sjis' => 
      array (
        0 => 62531,
      ),
      'jis' => 
      array (
        0 => 31524,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[辰]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040862,
      ),
    ),
  ),
  171 => 
  array (
    'mapid' => '#e-1DF',
    'unicode' => 
    array (
      0 => 128060,
    ),
    'char_name' => 
    array (
      'title' => 'PANDA FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[パンダ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 756,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60230,
      ),
      'sjis' => 
      array (
        0 => 62538,
      ),
      'jis' => 
      array (
        0 => 31531,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[パンダ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040863,
      ),
    ),
  ),
  172 => 
  array (
    'mapid' => '#e-1E0',
    'unicode' => 
    array (
      0 => 128061,
    ),
    'char_name' => 
    array (
      'title' => 'PIG NOSE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59221,
      ),
      'sjis' => 
      array (
        0 => 63994,
      ),
      'jis' => 
      array (
        0 => 30265,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 758,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60232,
      ),
      'sjis' => 
      array (
        0 => 62540,
      ),
      'jis' => 
      array (
        0 => 31533,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 106,
      ),
      'number_old' => 
      array (
        0 => 101,
      ),
      'unicode' => 
      array (
        0 => 57611,
      ),
      'sjis' => 
      array (
        0 => 63307,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040864,
      ),
    ),
  ),
  173 => 
  array (
    'mapid' => '#e-320',
    'unicode' => 
    array (
      0 => 128544,
    ),
    'char_name' => 
    array (
      'title' => 'ANGRY FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 141,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59121,
      ),
      'sjis' => 
      array (
        0 => 63894,
      ),
      'jis' => 
      array (
        0 => 29995,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 258,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58482,
      ),
      'sjis' => 
      array (
        0 => 63050,
      ),
      'jis' => 
      array (
        0 => 29995,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 29,
      ),
      'number_old' => 
      array (
        0 => 89,
      ),
      'unicode' => 
      array (
        0 => 57433,
      ),
      'sjis' => 
      array (
        0 => 63898,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041184,
      ),
    ),
  ),
  174 => 
  array (
    'mapid' => '#e-321',
    'unicode' => 
    array (
      0 => 128553,
    ),
    'char_name' => 
    array (
      'title' => 'WEARY FACE',
      'desc' => 'Old name: ANGUISHED FACE
Temporary Notes: Forms a pair with e-350.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59123,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
        0 => 31095,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 789,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60263,
      ),
      'sjis' => 
      array (
        0 => 62571,
      ),
      'jis' => 
      array (
        0 => 31564,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
        0 => 350,
      ),
      'unicode' => 
      array (
        0 => 58371,
      ),
      'sjis' => 
      array (
        0 => 64323,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041185,
      ),
    ),
  ),
  175 => 
  array (
    'mapid' => '#e-322',
    'unicode' => 
    array (
      0 => 128562,
    ),
    'char_name' => 
    array (
      'title' => 'ASTONISHED FACE',
      'desc' => 'Temporary Notes: Surprise, astonishment',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 144,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59124,
      ),
      'sjis' => 
      array (
        0 => 63897,
      ),
      'jis' => 
      array (
        0 => 30797,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 451,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60106,
      ),
      'sjis' => 
      array (
        0 => 62366,
      ),
      'jis' => 
      array (
        0 => 31102,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 27,
      ),
      'number_old' => 
      array (
        0 => 363,
      ),
      'unicode' => 
      array (
        0 => 58384,
      ),
      'sjis' => 
      array (
        0 => 64336,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041186,
      ),
    ),
  ),
  176 => 
  array (
    'mapid' => '#e-323',
    'unicode' => 
    array (
      0 => 128542,
    ),
    'char_name' => 
    array (
      'title' => 'DISAPPOINTED FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 142,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59122,
      ),
      'sjis' => 
      array (
        0 => 63895,
      ),
      'jis' => 
      array (
        0 => 31092,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 441,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60096,
      ),
      'sjis' => 
      array (
        0 => 62356,
      ),
      'jis' => 
      array (
        0 => 31092,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 18,
      ),
      'number_old' => 
      array (
        0 => 88,
      ),
      'unicode' => 
      array (
        0 => 57432,
      ),
      'sjis' => 
      array (
        0 => 63897,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041187,
      ),
    ),
  ),
  177 => 
  array (
    'mapid' => '#e-324',
    'unicode' => 
    array (
      0 => 128565,
    ),
    'char_name' => 
    array (
      'title' => 'DIZZY FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 144,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59124,
      ),
      'sjis' => 
      array (
        0 => 63897,
      ),
      'jis' => 
      array (
        0 => 30797,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 327,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58798,
      ),
      'sjis' => 
      array (
        0 => 63435,
      ),
      'jis' => 
      array (
        0 => 30797,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 23,
      ),
      'number_old' => 
      array (
        0 => 353,
      ),
      'unicode' => 
      array (
        0 => 58374,
      ),
      'sjis' => 
      array (
        0 => 64326,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041188,
      ),
    ),
  ),
  178 => 
  array (
    'mapid' => '#e-325',
    'unicode' => 
    array (
      0 => 128560,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH OPEN MOUTH AND COLD SWEAT',
      'desc' => 'Old name: EXASPERATED FACE
Temporary Notes: Exasperated, frustrated, impatient (sweating)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59171,
      ),
      'sjis' => 
      array (
        0 => 63944,
      ),
      'jis' => 
      array (
        0 => 30840,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 452,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60107,
      ),
      'sjis' => 
      array (
        0 => 62367,
      ),
      'jis' => 
      array (
        0 => 31265,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 21,
      ),
      'number_old' => 
      array (
        0 => 362,
      ),
      'unicode' => 
      array (
        0 => 58383,
      ),
      'sjis' => 
      array (
        0 => 64335,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041189,
      ),
    ),
  ),
  179 => 
  array (
    'mapid' => '#e-326',
    'unicode' => 
    array (
      0 => 128530,
    ),
    'char_name' => 
    array (
      'title' => 'UNAMUSED FACE',
      'desc' => 'Old name: EXPRESSIONLESS FACE
Temporary Notes: KDDI has side-look animation',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59173,
      ),
      'sjis' => 
      array (
        0 => 63946,
      ),
      'jis' => 
      array (
        0 => 31101,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 450,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60105,
      ),
      'sjis' => 
      array (
        0 => 62365,
      ),
      'jis' => 
      array (
        0 => 31101,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 14,
      ),
      'number_old' => 
      array (
        0 => 361,
      ),
      'unicode' => 
      array (
        0 => 58382,
      ),
      'sjis' => 
      array (
        0 => 64334,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041190,
      ),
    ),
  ),
  180 => 
  array (
    'mapid' => '#e-327',
    'unicode' => 
    array (
      0 => 128525,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH HEART-SHAPED EYES',
      'desc' => 'Old name: FACE WITH HEART-SHAPED EYES
Temporary Notes: Forms a pair with e-34C. used to indicate the state of being in love',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59174,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 349,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58820,
      ),
      'sjis' => 
      array (
        0 => 63476,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 6,
      ),
      'number_old' => 
      array (
        0 => 96,
      ),
      'unicode' => 
      array (
        0 => 57606,
      ),
      'sjis' => 
      array (
        0 => 63302,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041191,
      ),
    ),
  ),
  181 => 
  array (
    'mapid' => '#e-328',
    'unicode' => 
    array (
      0 => 128548,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH LOOK OF TRIUMPH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59219,
      ),
      'sjis' => 
      array (
        0 => 63992,
      ),
      'jis' => 
      array (
        0 => 31589,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 442,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60097,
      ),
      'sjis' => 
      array (
        0 => 62357,
      ),
      'jis' => 
      array (
        0 => 31093,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
        0 => 351,
      ),
      'unicode' => 
      array (
        0 => 58372,
      ),
      'sjis' => 
      array (
        0 => 64324,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041192,
      ),
    ),
  ),
  182 => 
  array (
    'mapid' => '#e-329',
    'unicode' => 
    array (
      0 => 128540,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH STUCK-OUT TONGUE AND WINKING EYE',
      'desc' => 'Old name: WINKING FACE WITH STUCK-OUT TONGUE
* kidding, not serious',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59176,
      ),
      'sjis' => 
      array (
        0 => 63949,
      ),
      'jis' => 
      array (
        0 => 30274,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 264,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58599,
      ),
      'sjis' => 
      array (
        0 => 63168,
      ),
      'jis' => 
      array (
        0 => 30274,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 12,
      ),
      'number_old' => 
      array (
        0 => 95,
      ),
      'unicode' => 
      array (
        0 => 57605,
      ),
      'sjis' => 
      array (
        0 => 63301,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041193,
      ),
    ),
  ),
  183 => 
  array (
    'mapid' => '#e-32A',
    'unicode' => 
    array (
      0 => 128541,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH STUCK-OUT TONGUE AND TIGHTLY-CLOSED EYES',
      'desc' => 'Old name: FACE WITH STUCK-OUT TONGUE
* kidding, not serious
Temporary Notes: with eyelids pulled down for additional effect',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59176,
      ),
      'sjis' => 
      array (
        0 => 63949,
      ),
      'jis' => 
      array (
        0 => 30274,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 264,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58599,
      ),
      'sjis' => 
      array (
        0 => 63168,
      ),
      'jis' => 
      array (
        0 => 30274,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
        0 => 356,
      ),
      'unicode' => 
      array (
        0 => 58377,
      ),
      'sjis' => 
      array (
        0 => 64329,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041194,
      ),
    ),
  ),
  184 => 
  array (
    'mapid' => '#e-32B',
    'unicode' => 
    array (
      0 => 128523,
    ),
    'char_name' => 
    array (
      'title' => 'FACE SAVOURING DELICIOUS FOOD',
      'desc' => 'Old name: FACE SAVORING DELICIOUS FOOD
Temporary Notes: tastes delicious',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59218,
      ),
      'sjis' => 
      array (
        0 => 63991,
      ),
      'jis' => 
      array (
        0 => 31267,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 454,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60109,
      ),
      'sjis' => 
      array (
        0 => 62369,
      ),
      'jis' => 
      array (
        0 => 31267,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 2,
      ),
      'number_old' => 
      array (
        0 => 86,
      ),
      'unicode' => 
      array (
        0 => 57430,
      ),
      'sjis' => 
      array (
        0 => 63895,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041195,
      ),
    ),
  ),
  185 => 
  array (
    'mapid' => '#e-32C',
    'unicode' => 
    array (
      0 => 128536,
    ),
    'char_name' => 
    array (
      'title' => 'FACE THROWING A KISS',
      'desc' => 'Temporary Notes: kiss',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59174,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 456,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60111,
      ),
      'sjis' => 
      array (
        0 => 62371,
      ),
      'jis' => 
      array (
        0 => 31269,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 7,
      ),
      'number_old' => 
      array (
        0 => 371,
      ),
      'unicode' => 
      array (
        0 => 58392,
      ),
      'sjis' => 
      array (
        0 => 64344,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041196,
      ),
    ),
  ),
  186 => 
  array (
    'mapid' => '#e-32D',
    'unicode' => 
    array (
      0 => 128538,
    ),
    'char_name' => 
    array (
      'title' => 'KISSING FACE WITH CLOSED EYES',
      'desc' => 'Old name: FACE KISSING
Temporary Notes: Forms a pair with e-34B. Puckered lips 2 (more forceful kiss, eyes squinting)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59174,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 455,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60110,
      ),
      'sjis' => 
      array (
        0 => 62370,
      ),
      'jis' => 
      array (
        0 => 31268,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 8,
      ),
      'number_old' => 
      array (
        0 => 370,
      ),
      'unicode' => 
      array (
        0 => 58391,
      ),
      'sjis' => 
      array (
        0 => 64343,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041197,
      ),
    ),
  ),
  187 => 
  array (
    'mapid' => '#e-32E',
    'unicode' => 
    array (
      0 => 128567,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH MEDICAL MASK',
      'desc' => 'Old name: FACE WITH MASK
Temporary Notes: Under the weather (wearing a breathing mask)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[風邪ひき]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 448,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60103,
      ),
      'sjis' => 
      array (
        0 => 62363,
      ),
      'jis' => 
      array (
        0 => 31099,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 31,
      ),
      'number_old' => 
      array (
        0 => 359,
      ),
      'unicode' => 
      array (
        0 => 58380,
      ),
      'sjis' => 
      array (
        0 => 64332,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041198,
      ),
    ),
  ),
  188 => 
  array (
    'mapid' => '#e-32F',
    'unicode' => 
    array (
      0 => 128563,
    ),
    'char_name' => 
    array (
      'title' => 'FLUSHED FACE',
      'desc' => 'Temporary Notes: red tinge around eyes',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59178,
      ),
      'sjis' => 
      array (
        0 => 63951,
      ),
      'jis' => 
      array (
        0 => 32309,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 449,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60104,
      ),
      'sjis' => 
      array (
        0 => 62364,
      ),
      'jis' => 
      array (
        0 => 31100,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 9,
      ),
      'number_old' => 
      array (
        0 => 360,
      ),
      'unicode' => 
      array (
        0 => 58381,
      ),
      'sjis' => 
      array (
        0 => 64333,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041199,
      ),
    ),
  ),
  189 => 
  array (
    'mapid' => '#e-330',
    'unicode' => 
    array (
      0 => 128515,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH OPEN MOUTH',
      'desc' => 'Old name: HAPPY FACE WITH OPEN MOUTH
Temporary Notes: May unify with ☺ U+263A WHITE SMILING FACE',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 257,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58481,
      ),
      'sjis' => 
      array (
        0 => 63049,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 3,
      ),
      'number_old' => 
      array (
        0 => 87,
      ),
      'unicode' => 
      array (
        0 => 57431,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041200,
      ),
    ),
  ),
  190 => 
  array (
    'mapid' => '#e-331',
    'unicode' => 
    array (
      0 => 128517,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH OPEN MOUTH AND COLD SWEAT',
      'desc' => 'Old name: HAPPY FACE WITH OPEN MOUTH AND COLD SWEAT
Temporary Notes: with cold sweat (made it!)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59170,
      ),
      'sjis' => 
      array (
        0 => 63943,
      ),
      'jis' => 
      array (
        0 => 32308,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 257,
        1 => 330,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58481,
        1 => 58801,
      ),
      'sjis' => 
      array (
        0 => 63049,
        1 => 63438,
      ),
      'jis' => 
      array (
        0 => 29994,
        1 => 30800,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 1,
        1 => 77,
      ),
      'number_old' => 
      array (
        0 => 368,
        1 => 319,
      ),
      'unicode' => 
      array (
        0 => 58389,
        1 => 58161,
      ),
      'sjis' => 
      array (
        0 => 64341,
        1 => 63953,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041201,
      ),
    ),
  ),
  191 => 
  array (
    'mapid' => '#e-332',
    'unicode' => 
    array (
      0 => 128518,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH OPEN MOUTH AND TIGHTLY-CLOSED EYES',
      'desc' => 'Old name: HAPPY FACE WITH OPEN MOUTH AND CLOSED EYES
Temporary Notes: Happy face 3 for DoCoMo',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59178,
      ),
      'sjis' => 
      array (
        0 => 63951,
      ),
      'jis' => 
      array (
        0 => 32309,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 446,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60101,
      ),
      'sjis' => 
      array (
        0 => 62361,
      ),
      'jis' => 
      array (
        0 => 31097,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 10,
      ),
      'number_old' => 
      array (
        0 => 357,
      ),
      'unicode' => 
      array (
        0 => 58378,
      ),
      'sjis' => 
      array (
        0 => 64330,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041202,
      ),
    ),
  ),
  192 => 
  array (
    'mapid' => '#e-333',
    'unicode' => 
    array (
      0 => 128513,
    ),
    'char_name' => 
    array (
      'title' => 'GRINNING FACE WITH SMILING EYES',
      'desc' => 'Old name: HAPPY FACE WITH GRIN
Temporary Notes: Forms a pair with e-349. loudly laughing face with bare teeth',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59219,
      ),
      'sjis' => 
      array (
        0 => 63992,
      ),
      'jis' => 
      array (
        0 => 31589,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 814,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60288,
      ),
      'sjis' => 
      array (
        0 => 62597,
      ),
      'jis' => 
      array (
        0 => 31589,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
        0 => 351,
      ),
      'unicode' => 
      array (
        0 => 58372,
      ),
      'sjis' => 
      array (
        0 => 64324,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041203,
      ),
    ),
  ),
  193 => 
  array (
    'mapid' => '#e-334',
    'unicode' => 
    array (
      0 => 128514,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH TEARS OF JOY',
      'desc' => 'Old name: HAPPY AND CRYING FACE
Temporary Notes: Forms a pair with e-34A. with tears of joy',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59178,
      ),
      'sjis' => 
      array (
        0 => 63951,
      ),
      'jis' => 
      array (
        0 => 32309,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 786,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60260,
      ),
      'sjis' => 
      array (
        0 => 62568,
      ),
      'jis' => 
      array (
        0 => 31561,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 26,
      ),
      'number_old' => 
      array (
        0 => 365,
      ),
      'unicode' => 
      array (
        0 => 58386,
      ),
      'sjis' => 
      array (
        0 => 64338,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041204,
      ),
    ),
  ),
  194 => 
  array (
    'mapid' => '#e-335',
    'unicode' => 
    array (
      0 => 128522,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH SMILING EYES',
      'desc' => 'Old name: HAPPY FACE WITH WIDE MOUTH AND RAISED EYEBROWS
Temporary Notes: smiling face',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 454,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60109,
      ),
      'sjis' => 
      array (
        0 => 62369,
      ),
      'jis' => 
      array (
        0 => 31267,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 2,
      ),
      'number_old' => 
      array (
        0 => 86,
      ),
      'unicode' => 
      array (
        0 => 57430,
      ),
      'sjis' => 
      array (
        0 => 63895,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041205,
      ),
    ),
  ),
  195 => 
  array (
    'mapid' => '#e-336',
    'unicode' => 
    array (
      0 => 9786,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE SMILING FACE',
      'desc' => 'Temporary Notes: generic smiley',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 68,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58619,
      ),
      'sjis' => 
      array (
        0 => 63188,
      ),
      'jis' => 
      array (
        0 => 30294,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 4,
      ),
      'number_old' => 
      array (
        0 => 367,
      ),
      'unicode' => 
      array (
        0 => 58388,
      ),
      'sjis' => 
      array (
        0 => 64340,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041206,
      ),
    ),
  ),
  196 => 
  array (
    'mapid' => '#e-338',
    'unicode' => 
    array (
      0 => 128516,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING FACE WITH OPEN MOUTH AND SMILING EYES',
      'desc' => 'Old name: HAPPY FACE WITH OPEN MOUTH AND RAISED EYEBROWS
Temporary Notes: with open mouth',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 257,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58481,
      ),
      'sjis' => 
      array (
        0 => 63049,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
        0 => 368,
      ),
      'unicode' => 
      array (
        0 => 58389,
      ),
      'sjis' => 
      array (
        0 => 64341,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041208,
      ),
    ),
  ),
  197 => 
  array (
    'mapid' => '#e-339',
    'unicode' => 
    array (
      0 => 128546,
    ),
    'char_name' => 
    array (
      'title' => 'CRYING FACE',
      'desc' => 'Temporary Notes: Forms a pair with e-34D. 1 or 2 tear drops',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59182,
      ),
      'sjis' => 
      array (
        0 => 63955,
      ),
      'jis' => 
      array (
        0 => 31566,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 791,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60265,
      ),
      'sjis' => 
      array (
        0 => 62573,
      ),
      'jis' => 
      array (
        0 => 31566,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 24,
      ),
      'number_old' => 
      array (
        0 => 366,
      ),
      'unicode' => 
      array (
        0 => 58387,
      ),
      'sjis' => 
      array (
        0 => 64339,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041209,
      ),
    ),
  ),
  198 => 
  array (
    'mapid' => '#e-33A',
    'unicode' => 
    array (
      0 => 128557,
    ),
    'char_name' => 
    array (
      'title' => 'LOUDLY CRYING FACE',
      'desc' => 'Temporary Notes: lots of tears',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59181,
      ),
      'sjis' => 
      array (
        0 => 63954,
      ),
      'jis' => 
      array (
        0 => 29996,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 259,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58483,
      ),
      'sjis' => 
      array (
        0 => 63051,
      ),
      'jis' => 
      array (
        0 => 29996,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 25,
      ),
      'number_old' => 
      array (
        0 => 364,
      ),
      'unicode' => 
      array (
        0 => 58385,
      ),
      'sjis' => 
      array (
        0 => 64337,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041210,
      ),
    ),
  ),
  199 => 
  array (
    'mapid' => '#e-33B',
    'unicode' => 
    array (
      0 => 128552,
    ),
    'char_name' => 
    array (
      'title' => 'FEARFUL FACE',
      'desc' => 'Temporary Notes: Pale in fear',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59223,
      ),
      'sjis' => 
      array (
        0 => 63996,
      ),
      'jis' => 
      array (
        0 => 30839,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 447,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60102,
      ),
      'sjis' => 
      array (
        0 => 62362,
      ),
      'jis' => 
      array (
        0 => 31098,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 22,
      ),
      'number_old' => 
      array (
        0 => 358,
      ),
      'unicode' => 
      array (
        0 => 58379,
      ),
      'sjis' => 
      array (
        0 => 64331,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041211,
      ),
    ),
  ),
  200 => 
  array (
    'mapid' => '#e-33C',
    'unicode' => 
    array (
      0 => 128547,
    ),
    'char_name' => 
    array (
      'title' => 'PERSEVERING FACE',
      'desc' => 'Temporary Notes: failure, disappointment',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59179,
      ),
      'sjis' => 
      array (
        0 => 63952,
      ),
      'jis' => 
      array (
        0 => 31094,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 443,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60098,
      ),
      'sjis' => 
      array (
        0 => 62358,
      ),
      'jis' => 
      array (
        0 => 31094,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 23,
      ),
      'number_old' => 
      array (
        0 => 353,
      ),
      'unicode' => 
      array (
        0 => 58374,
      ),
      'sjis' => 
      array (
        0 => 64326,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041212,
      ),
    ),
  ),
  201 => 
  array (
    'mapid' => '#e-33D',
    'unicode' => 
    array (
      0 => 128545,
    ),
    'char_name' => 
    array (
      'title' => 'POUTING FACE',
      'desc' => 'Temporary Notes: Forms a pair with e-34E.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59172,
      ),
      'sjis' => 
      array (
        0 => 63945,
      ),
      'jis' => 
      array (
        0 => 31554,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 779,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60253,
      ),
      'sjis' => 
      array (
        0 => 62561,
      ),
      'jis' => 
      array (
        0 => 31554,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 30,
      ),
      'number_old' => 
      array (
        0 => 369,
      ),
      'unicode' => 
      array (
        0 => 58390,
      ),
      'sjis' => 
      array (
        0 => 64342,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041213,
      ),
    ),
  ),
  202 => 
  array (
    'mapid' => '#e-33E',
    'unicode' => 
    array (
      0 => 128524,
    ),
    'char_name' => 
    array (
      'title' => 'RELIEVED FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59169,
      ),
      'sjis' => 
      array (
        0 => 63942,
      ),
      'jis' => 
      array (
        0 => 31097,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 446,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60101,
      ),
      'sjis' => 
      array (
        0 => 62361,
      ),
      'jis' => 
      array (
        0 => 31097,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 10,
      ),
      'number_old' => 
      array (
        0 => 357,
      ),
      'unicode' => 
      array (
        0 => 58378,
      ),
      'sjis' => 
      array (
        0 => 64330,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041214,
      ),
    ),
  ),
  203 => 
  array (
    'mapid' => '#e-33F',
    'unicode' => 
    array (
      0 => 128534,
    ),
    'char_name' => 
    array (
      'title' => 'CONFOUNDED FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59123,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
        0 => 31095,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 444,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60099,
      ),
      'sjis' => 
      array (
        0 => 62359,
      ),
      'jis' => 
      array (
        0 => 31095,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 19,
      ),
      'number_old' => 
      array (
        0 => 354,
      ),
      'unicode' => 
      array (
        0 => 58375,
      ),
      'sjis' => 
      array (
        0 => 64327,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041215,
      ),
    ),
  ),
  204 => 
  array (
    'mapid' => '#e-340',
    'unicode' => 
    array (
      0 => 128532,
    ),
    'char_name' => 
    array (
      'title' => 'PENSIVE FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59168,
      ),
      'sjis' => 
      array (
        0 => 63941,
      ),
      'jis' => 
      array (
        0 => 32307,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 441,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60096,
      ),
      'sjis' => 
      array (
        0 => 62356,
      ),
      'jis' => 
      array (
        0 => 31092,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
        0 => 350,
      ),
      'unicode' => 
      array (
        0 => 58371,
      ),
      'sjis' => 
      array (
        0 => 64323,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041216,
      ),
    ),
  ),
  205 => 
  array (
    'mapid' => '#e-341',
    'unicode' => 
    array (
      0 => 128561,
    ),
    'char_name' => 
    array (
      'title' => 'FACE SCREAMING IN FEAR',
      'desc' => 'Temporary Notes: Shocking (like Edvard Munch\'s "The Scream")',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59223,
      ),
      'sjis' => 
      array (
        0 => 63996,
      ),
      'jis' => 
      array (
        0 => 30839,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 350,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58821,
      ),
      'sjis' => 
      array (
        0 => 63477,
      ),
      'jis' => 
      array (
        0 => 30839,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 28,
      ),
      'number_old' => 
      array (
        0 => 97,
      ),
      'unicode' => 
      array (
        0 => 57607,
      ),
      'sjis' => 
      array (
        0 => 63303,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041217,
      ),
    ),
  ),
  206 => 
  array (
    'mapid' => '#e-342',
    'unicode' => 
    array (
      0 => 128554,
    ),
    'char_name' => 
    array (
      'title' => 'SLEEPY FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 157,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59137,
      ),
      'sjis' => 
      array (
        0 => 63910,
      ),
      'jis' => 
      array (
        0 => 29998,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 445,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60100,
      ),
      'sjis' => 
      array (
        0 => 62360,
      ),
      'jis' => 
      array (
        0 => 31096,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 32,
      ),
      'number_old' => 
      array (
        0 => 355,
      ),
      'unicode' => 
      array (
        0 => 58376,
      ),
      'sjis' => 
      array (
        0 => 64328,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041218,
      ),
    ),
  ),
  207 => 
  array (
    'mapid' => '#e-343',
    'unicode' => 
    array (
      0 => 128527,
    ),
    'char_name' => 
    array (
      'title' => 'SMIRKING FACE',
      'desc' => 'Temporary Notes: half smile in some cases',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59180,
      ),
      'sjis' => 
      array (
        0 => 63953,
      ),
      'jis' => 
      array (
        0 => 31091,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 440,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60095,
      ),
      'sjis' => 
      array (
        0 => 62355,
      ),
      'jis' => 
      array (
        0 => 31091,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 15,
      ),
      'number_old' => 
      array (
        0 => 349,
      ),
      'unicode' => 
      array (
        0 => 58370,
      ),
      'sjis' => 
      array (
        0 => 64322,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041219,
      ),
    ),
  ),
  208 => 
  array (
    'mapid' => '#e-344',
    'unicode' => 
    array (
      0 => 128531,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH COLD SWEAT',
      'desc' => 'Temporary Notes: with troubled look',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59171,
      ),
      'sjis' => 
      array (
        0 => 63944,
      ),
      'jis' => 
      array (
        0 => 30840,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 351,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58822,
      ),
      'sjis' => 
      array (
        0 => 63478,
      ),
      'jis' => 
      array (
        0 => 30840,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 16,
      ),
      'number_old' => 
      array (
        0 => 98,
      ),
      'unicode' => 
      array (
        0 => 57608,
      ),
      'sjis' => 
      array (
        0 => 63304,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041220,
      ),
    ),
  ),
  209 => 
  array (
    'mapid' => '#e-345',
    'unicode' => 
    array (
      0 => 128549,
    ),
    'char_name' => 
    array (
      'title' => 'DISAPPOINTED BUT RELIEVED FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59171,
      ),
      'sjis' => 
      array (
        0 => 63944,
      ),
      'jis' => 
      array (
        0 => 30840,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 351,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58822,
      ),
      'sjis' => 
      array (
        0 => 63478,
      ),
      'jis' => 
      array (
        0 => 30840,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 20,
      ),
      'number_old' => 
      array (
        0 => 348,
      ),
      'unicode' => 
      array (
        0 => 58369,
      ),
      'sjis' => 
      array (
        0 => 64321,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041221,
      ),
    ),
  ),
  210 => 
  array (
    'mapid' => '#e-346',
    'unicode' => 
    array (
      0 => 128555,
    ),
    'char_name' => 
    array (
      'title' => 'TIRED FACE',
      'desc' => 'Temporary Notes: Enduring (exhausted) face',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59179,
      ),
      'sjis' => 
      array (
        0 => 63952,
      ),
      'jis' => 
      array (
        0 => 31094,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 260,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58484,
      ),
      'sjis' => 
      array (
        0 => 63052,
      ),
      'jis' => 
      array (
        0 => 29997,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 23,
      ),
      'number_old' => 
      array (
        0 => 353,
      ),
      'unicode' => 
      array (
        0 => 58374,
      ),
      'sjis' => 
      array (
        0 => 64326,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041222,
      ),
    ),
  ),
  211 => 
  array (
    'mapid' => '#e-347',
    'unicode' => 
    array (
      0 => 128521,
    ),
    'char_name' => 
    array (
      'title' => 'WINKING FACE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59177,
      ),
      'sjis' => 
      array (
        0 => 63950,
      ),
      'jis' => 
      array (
        0 => 30837,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 348,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58819,
      ),
      'sjis' => 
      array (
        0 => 63475,
      ),
      'jis' => 
      array (
        0 => 30837,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 5,
      ),
      'number_old' => 
      array (
        0 => 352,
      ),
      'unicode' => 
      array (
        0 => 58373,
      ),
      'sjis' => 
      array (
        0 => 64325,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041223,
      ),
    ),
  ),
  212 => 
  array (
    'mapid' => '#e-348',
    'unicode' => 
    array (
      0 => 128570,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING CAT FACE WITH OPEN MOUTH',
      'desc' => 'Old name: CAT FACE WITH OPEN MOUTH
Temporary Notes: Happy',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59120,
      ),
      'sjis' => 
      array (
        0 => 63893,
      ),
      'jis' => 
      array (
        0 => 29994,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 783,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60257,
      ),
      'sjis' => 
      array (
        0 => 62565,
      ),
      'jis' => 
      array (
        0 => 31558,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 3,
      ),
      'number_old' => 
      array (
        0 => 87,
      ),
      'unicode' => 
      array (
        0 => 57431,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041224,
      ),
    ),
  ),
  213 => 
  array (
    'mapid' => '#e-349',
    'unicode' => 
    array (
      0 => 128568,
    ),
    'char_name' => 
    array (
      'title' => 'GRINNING CAT FACE WITH SMILING EYES',
      'desc' => 'Old name: HAPPY CAT FACE WITH GRIN
Temporary Notes: Forms a pair with e-333. Hee hee hee',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59219,
      ),
      'sjis' => 
      array (
        0 => 63992,
      ),
      'jis' => 
      array (
        0 => 31589,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 813,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60287,
      ),
      'sjis' => 
      array (
        0 => 62596,
      ),
      'jis' => 
      array (
        0 => 31588,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
        0 => 351,
      ),
      'unicode' => 
      array (
        0 => 58372,
      ),
      'sjis' => 
      array (
        0 => 64324,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041225,
      ),
    ),
  ),
  214 => 
  array (
    'mapid' => '#e-34A',
    'unicode' => 
    array (
      0 => 128569,
    ),
    'char_name' => 
    array (
      'title' => 'CAT FACE WITH TEARS OF JOY',
      'desc' => 'Old name: HAPPY AND CRYING CAT FACE
Temporary Notes: Forms a pair with e-334. Tears of joy',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59178,
      ),
      'sjis' => 
      array (
        0 => 63951,
      ),
      'jis' => 
      array (
        0 => 32309,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 785,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60259,
      ),
      'sjis' => 
      array (
        0 => 62567,
      ),
      'jis' => 
      array (
        0 => 31560,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 26,
      ),
      'number_old' => 
      array (
        0 => 365,
      ),
      'unicode' => 
      array (
        0 => 58386,
      ),
      'sjis' => 
      array (
        0 => 64338,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041226,
      ),
    ),
  ),
  215 => 
  array (
    'mapid' => '#e-34B',
    'unicode' => 
    array (
      0 => 128573,
    ),
    'char_name' => 
    array (
      'title' => 'KISSING CAT FACE WITH CLOSED EYES',
      'desc' => 'Old name: CAT FACE KISSING
Temporary Notes: Forms a pair with e-32D. Kissing action.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59174,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 782,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60256,
      ),
      'sjis' => 
      array (
        0 => 62564,
      ),
      'jis' => 
      array (
        0 => 31557,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 7,
      ),
      'number_old' => 
      array (
        0 => 371,
      ),
      'unicode' => 
      array (
        0 => 58392,
      ),
      'sjis' => 
      array (
        0 => 64344,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041227,
      ),
    ),
  ),
  216 => 
  array (
    'mapid' => '#e-34C',
    'unicode' => 
    array (
      0 => 128571,
    ),
    'char_name' => 
    array (
      'title' => 'SMILING CAT FACE WITH HEART-SHAPED EYES',
      'desc' => 'Old name: CAT FACE WITH HEART-SHAPED EYES
Temporary Notes: Forms a pair with e-327. Heart shaped eyes (in love)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59174,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
        0 => 30838,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 787,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60261,
      ),
      'sjis' => 
      array (
        0 => 62569,
      ),
      'jis' => 
      array (
        0 => 31562,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 6,
      ),
      'number_old' => 
      array (
        0 => 96,
      ),
      'unicode' => 
      array (
        0 => 57606,
      ),
      'sjis' => 
      array (
        0 => 63302,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041228,
      ),
    ),
  ),
  217 => 
  array (
    'mapid' => '#e-34D',
    'unicode' => 
    array (
      0 => 128575,
    ),
    'char_name' => 
    array (
      'title' => 'CRYING CAT FACE',
      'desc' => 'Temporary Notes: Forms a pair with e-339. Crying (one or two tears)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59182,
      ),
      'sjis' => 
      array (
        0 => 63955,
      ),
      'jis' => 
      array (
        0 => 31566,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 790,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60264,
      ),
      'sjis' => 
      array (
        0 => 62572,
      ),
      'jis' => 
      array (
        0 => 31565,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 24,
      ),
      'number_old' => 
      array (
        0 => 366,
      ),
      'unicode' => 
      array (
        0 => 58387,
      ),
      'sjis' => 
      array (
        0 => 64339,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041229,
      ),
    ),
  ),
  218 => 
  array (
    'mapid' => '#e-34E',
    'unicode' => 
    array (
      0 => 128574,
    ),
    'char_name' => 
    array (
      'title' => 'POUTING CAT FACE',
      'desc' => 'Temporary Notes: Forms a pair with e-33D.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59172,
      ),
      'sjis' => 
      array (
        0 => 63945,
      ),
      'jis' => 
      array (
        0 => 31554,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 780,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60254,
      ),
      'sjis' => 
      array (
        0 => 62562,
      ),
      'jis' => 
      array (
        0 => 31555,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 30,
      ),
      'number_old' => 
      array (
        0 => 369,
      ),
      'unicode' => 
      array (
        0 => 58390,
      ),
      'sjis' => 
      array (
        0 => 64342,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041230,
      ),
    ),
  ),
  219 => 
  array (
    'mapid' => '#e-34F',
    'unicode' => 
    array (
      0 => 128572,
    ),
    'char_name' => 
    array (
      'title' => 'CAT FACE WITH WRY SMILE',
      'desc' => 'Old name: CAT FACE WITH TIGHTLY-CLOSED LIPS
Temporary Notes: Smart confidence',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59219,
      ),
      'sjis' => 
      array (
        0 => 63992,
      ),
      'jis' => 
      array (
        0 => 31589,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 792,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60266,
      ),
      'sjis' => 
      array (
        0 => 62574,
      ),
      'jis' => 
      array (
        0 => 31567,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
        0 => 351,
      ),
      'unicode' => 
      array (
        0 => 58372,
      ),
      'sjis' => 
      array (
        0 => 64324,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041231,
      ),
    ),
  ),
  220 => 
  array (
    'mapid' => '#e-350',
    'unicode' => 
    array (
      0 => 128576,
    ),
    'char_name' => 
    array (
      'title' => 'WEARY CAT FACE',
      'desc' => 'Old name: ANGUISHED CAT FACE
Temporary Notes: Forms a pair with e-321.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59123,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
        0 => 31095,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 788,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60262,
      ),
      'sjis' => 
      array (
        0 => 62570,
      ),
      'jis' => 
      array (
        0 => 31563,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
        0 => 350,
      ),
      'unicode' => 
      array (
        0 => 58371,
      ),
      'sjis' => 
      array (
        0 => 64323,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041232,
      ),
    ),
  ),
  221 => 
  array (
    'mapid' => '#e-351',
    'unicode' => 
    array (
      0 => 128581,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH NO GOOD GESTURE',
      'desc' => 'Temporary Notes: No good',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59183,
      ),
      'sjis' => 
      array (
        0 => 63956,
      ),
      'jis' => 
      array (
        0 => 32310,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60119,
      ),
      'sjis' => 
      array (
        0 => 62379,
      ),
      'jis' => 
      array (
        0 => 31277,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 71,
      ),
      'number_old' => 
      array (
        0 => 382,
      ),
      'unicode' => 
      array (
        0 => 58403,
      ),
      'sjis' => 
      array (
        0 => 64355,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041233,
      ),
    ),
  ),
  222 => 
  array (
    'mapid' => '#e-352',
    'unicode' => 
    array (
      0 => 128582,
    ),
    'char_name' => 
    array (
      'title' => 'FACE WITH OK GESTURE',
      'desc' => 'Temporary Notes: OK (arms raised, making an "O") . A person or a cat',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 135,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59147,
      ),
      'sjis' => 
      array (
        0 => 63920,
      ),
      'jis' => 
      array (
        0 => 30796,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 465,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60120,
      ),
      'sjis' => 
      array (
        0 => 62380,
      ),
      'jis' => 
      array (
        0 => 31278,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
        0 => 383,
      ),
      'unicode' => 
      array (
        0 => 58404,
      ),
      'sjis' => 
      array (
        0 => 64356,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041234,
      ),
    ),
  ),
  223 => 
  array (
    'mapid' => '#e-353',
    'unicode' => 
    array (
      0 => 128583,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON BOWING DEEPLY',
      'desc' => 'Temporary Notes: Very truly sorry, a cat or person',
    ),
    'docomo' => 
    array (
      'kaomoji' => 'm(_ _)m',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 466,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60121,
      ),
      'sjis' => 
      array (
        0 => 62381,
      ),
      'jis' => 
      array (
        0 => 31279,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 72,
      ),
      'number_old' => 
      array (
        0 => 385,
      ),
      'unicode' => 
      array (
        0 => 58406,
      ),
      'sjis' => 
      array (
        0 => 64358,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041235,
      ),
    ),
  ),
  224 => 
  array (
    'mapid' => '#e-354',
    'unicode' => 
    array (
      0 => 128584,
    ),
    'char_name' => 
    array (
      'title' => 'SEE-NO-EVIL MONKEY',
      'desc' => 'Old name: SEE NO EVIL MONKEY',
    ),
    'docomo' => 
    array (
      'kaomoji' => '(/_＼)',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 766,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60240,
      ),
      'sjis' => 
      array (
        0 => 62548,
      ),
      'jis' => 
      array (
        0 => 31541,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '(/_＼)',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041236,
      ),
    ),
  ),
  225 => 
  array (
    'mapid' => '#e-355',
    'unicode' => 
    array (
      0 => 128586,
    ),
    'char_name' => 
    array (
      'title' => 'SPEAK-NO-EVIL MONKEY',
      'desc' => 'Old name: SPEAK NO EVIL MONKEY',
    ),
    'docomo' => 
    array (
      'kaomoji' => '(・×・)',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 767,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60241,
      ),
      'sjis' => 
      array (
        0 => 62549,
      ),
      'jis' => 
      array (
        0 => 31542,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '(・×・)',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041237,
      ),
    ),
  ),
  226 => 
  array (
    'mapid' => '#e-356',
    'unicode' => 
    array (
      0 => 128585,
    ),
    'char_name' => 
    array (
      'title' => 'HEAR-NO-EVIL MONKEY',
      'desc' => 'Old name: HEAR NO EVIL MONKEY',
    ),
    'docomo' => 
    array (
      'kaomoji' => '|(・×・)|',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 768,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60242,
      ),
      'sjis' => 
      array (
        0 => 62550,
      ),
      'jis' => 
      array (
        0 => 31543,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '|(・×・)|',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041238,
      ),
    ),
  ),
  227 => 
  array (
    'mapid' => '#e-357',
    'unicode' => 
    array (
      0 => 128587,
    ),
    'char_name' => 
    array (
      'title' => 'HAPPY PERSON RAISING ONE HAND',
      'desc' => 'Old name: PERSON RAISING ONE HAND
Temporary Notes: act of raising a hand',
    ),
    'docomo' => 
    array (
      'kaomoji' => '(^-^)/',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 819,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60293,
      ),
      'sjis' => 
      array (
        0 => 62602,
      ),
      'jis' => 
      array (
        0 => 31594,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 53,
      ),
      'number_old' => 
      array (
        0 => 18,
      ),
      'unicode' => 
      array (
        0 => 57362,
      ),
      'sjis' => 
      array (
        0 => 63826,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041239,
      ),
    ),
  ),
  228 => 
  array (
    'mapid' => '#e-358',
    'unicode' => 
    array (
      0 => 128588,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON RAISING BOTH HANDS IN CELEBRATION',
      'desc' => 'Old name: PERSON RAISING BOTH HANDS IN CHEERS
= banzai!
Temporary Notes: banzai, raising both hands',
    ),
    'docomo' => 
    array (
      'kaomoji' => '＼(^o^)／',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 820,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60294,
      ),
      'sjis' => 
      array (
        0 => 62603,
      ),
      'jis' => 
      array (
        0 => 31595,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 68,
      ),
      'number_old' => 
      array (
        0 => 386,
      ),
      'unicode' => 
      array (
        0 => 58407,
      ),
      'sjis' => 
      array (
        0 => 64359,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041240,
      ),
    ),
  ),
  229 => 
  array (
    'mapid' => '#e-359',
    'unicode' => 
    array (
      0 => 128589,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON FROWNING',
      'desc' => 'Temporary Notes: dejected',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59123,
      ),
      'sjis' => 
      array (
        0 => 63896,
      ),
      'jis' => 
      array (
        0 => 31095,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 821,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60295,
      ),
      'sjis' => 
      array (
        0 => 62604,
      ),
      'jis' => 
      array (
        0 => 31596,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
        0 => 350,
      ),
      'unicode' => 
      array (
        0 => 58371,
      ),
      'sjis' => 
      array (
        0 => 64323,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041241,
      ),
    ),
  ),
  230 => 
  array (
    'mapid' => '#e-35A',
    'unicode' => 
    array (
      0 => 128590,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON WITH POUTING FACE',
      'desc' => 'Temporary Notes: cute pouting face',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 141,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59121,
      ),
      'sjis' => 
      array (
        0 => 63894,
      ),
      'jis' => 
      array (
        0 => 29995,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 822,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60296,
      ),
      'sjis' => 
      array (
        0 => 62605,
      ),
      'jis' => 
      array (
        0 => 31597,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 30,
      ),
      'number_old' => 
      array (
        0 => 369,
      ),
      'unicode' => 
      array (
        0 => 58390,
      ),
      'sjis' => 
      array (
        0 => 64342,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041242,
      ),
    ),
  ),
  231 => 
  array (
    'mapid' => '#e-35B',
    'unicode' => 
    array (
      0 => 128591,
    ),
    'char_name' => 
    array (
      'title' => 'PERSON WITH FOLDED HANDS',
      'desc' => '* can indicate sorrow or regret
* can indicate pleading
Temporary Notes: "Sorry" or "Please"',
    ),
    'docomo' => 
    array (
      'kaomoji' => '(>人<)',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 459,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60114,
      ),
      'sjis' => 
      array (
        0 => 62374,
      ),
      'jis' => 
      array (
        0 => 31272,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 59,
      ),
      'number_old' => 
      array (
        0 => 376,
      ),
      'unicode' => 
      array (
        0 => 58397,
      ),
      'sjis' => 
      array (
        0 => 64349,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041243,
      ),
    ),
  ),
  232 => 
  array (
    'mapid' => '#e-4B0',
    'unicode' => 
    array (
      0 => 127968,
    ),
    'char_name' => 
    array (
      'title' => 'HOUSE BUILDING',
      'desc' => 'Temporary Notes: similar to English "house" = "building"',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 38,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58979,
      ),
      'sjis' => 
      array (
        0 => 63684,
      ),
      'jis' => 
      array (
        0 => 30052,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 112,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58539,
      ),
      'sjis' => 
      array (
        0 => 63108,
      ),
      'jis' => 
      array (
        0 => 30052,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 321,
      ),
      'number_old' => 
      array (
        0 => 54,
      ),
      'unicode' => 
      array (
        0 => 57398,
      ),
      'sjis' => 
      array (
        0 => 63862,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041584,
      ),
    ),
  ),
  233 => 
  array (
    'mapid' => '#e-4B1',
    'unicode' => 
    array (
      0 => 127969,
    ),
    'char_name' => 
    array (
      'title' => 'HOUSE WITH GARDEN',
      'desc' => 'Old name: HOUSE WITH YARD
= home, house with yard
Temporary Notes: similar to English "home" = "where one belongs to"',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 38,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58979,
      ),
      'sjis' => 
      array (
        0 => 63684,
      ),
      'jis' => 
      array (
        0 => 30052,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 514,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60169,
      ),
      'sjis' => 
      array (
        0 => 63456,
      ),
      'jis' => 
      array (
        0 => 30818,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 321,
      ),
      'number_old' => 
      array (
        0 => 54,
      ),
      'unicode' => 
      array (
        0 => 57398,
      ),
      'sjis' => 
      array (
        0 => 63862,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041585,
      ),
    ),
  ),
  234 => 
  array (
    'mapid' => '#e-4B2',
    'unicode' => 
    array (
      0 => 127970,
    ),
    'char_name' => 
    array (
      'title' => 'OFFICE BUILDING',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 39,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58980,
      ),
      'sjis' => 
      array (
        0 => 63685,
      ),
      'jis' => 
      array (
        0 => 30054,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 156,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58541,
      ),
      'sjis' => 
      array (
        0 => 63110,
      ),
      'jis' => 
      array (
        0 => 30054,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 322,
      ),
      'number_old' => 
      array (
        0 => 56,
      ),
      'unicode' => 
      array (
        0 => 57400,
      ),
      'sjis' => 
      array (
        0 => 63864,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041586,
      ),
    ),
  ),
  235 => 
  array (
    'mapid' => '#e-4B3',
    'unicode' => 
    array (
      0 => 127971,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE POST OFFICE',
      'desc' => 'x (postal mark - 3012)
Temporary Notes: * U+3012 POSTAL MARK = ARIB-9108',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58981,
      ),
      'sjis' => 
      array (
        0 => 63686,
      ),
      'jis' => 
      array (
        0 => 31026,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 375,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58846,
      ),
      'sjis' => 
      array (
        0 => 62289,
      ),
      'jis' => 
      array (
        0 => 31026,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 325,
      ),
      'number_old' => 
      array (
        0 => 173,
      ),
      'unicode' => 
      array (
        0 => 57683,
      ),
      'sjis' => 
      array (
        0 => 63380,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041587,
      ),
    ),
  ),
  236 => 
  array (
    'mapid' => '#e-4B4',
    'unicode' => 
    array (
      0 => 127973,
    ),
    'char_name' => 
    array (
      'title' => 'HOSPITAL',
      'desc' => 'Temporary Notes: disunified from U+26E8 (ARIB-9109: BLACK CROSS ON SHIELD) because all 3 carriers have a cross on a building while ARIB-9109 is a cross on a shield. (Note: may be controversial in Islamic and Jewish cultures)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 41,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58982,
      ),
      'sjis' => 
      array (
        0 => 63687,
      ),
      'jis' => 
      array (
        0 => 31027,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 376,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58847,
      ),
      'sjis' => 
      array (
        0 => 62290,
      ),
      'jis' => 
      array (
        0 => 31027,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 328,
      ),
      'number_old' => 
      array (
        0 => 175,
      ),
      'unicode' => 
      array (
        0 => 57685,
      ),
      'sjis' => 
      array (
        0 => 63382,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041588,
      ),
    ),
  ),
  237 => 
  array (
    'mapid' => '#e-4B5',
    'unicode' => 
    array (
      0 => 127974,
    ),
    'char_name' => 
    array (
      'title' => 'BANK',
      'desc' => 'Temporary Notes: may contain "BK" or "Bank" letters; related to ⛻ U+26FB = ARIB-9144',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 42,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58983,
      ),
      'sjis' => 
      array (
        0 => 63688,
      ),
      'jis' => 
      array (
        0 => 30051,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 212,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58538,
      ),
      'sjis' => 
      array (
        0 => 63107,
      ),
      'jis' => 
      array (
        0 => 30051,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 326,
      ),
      'number_old' => 
      array (
        0 => 167,
      ),
      'unicode' => 
      array (
        0 => 57677,
      ),
      'sjis' => 
      array (
        0 => 63374,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041589,
      ),
    ),
  ),
  238 => 
  array (
    'mapid' => '#e-4B6',
    'unicode' => 
    array (
      0 => 127975,
    ),
    'char_name' => 
    array (
      'title' => 'AUTOMATED TELLER MACHINE',
      'desc' => 'Old name: ATM
= ATM',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 43,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58984,
      ),
      'sjis' => 
      array (
        0 => 63689,
      ),
      'jis' => 
      array (
        0 => 30044,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 205,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58531,
      ),
      'sjis' => 
      array (
        0 => 63099,
      ),
      'jis' => 
      array (
        0 => 30044,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 327,
      ),
      'number_old' => 
      array (
        0 => 174,
      ),
      'unicode' => 
      array (
        0 => 57684,
      ),
      'sjis' => 
      array (
        0 => 63381,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041590,
      ),
    ),
  ),
  239 => 
  array (
    'mapid' => '#e-4B7',
    'unicode' => 
    array (
      0 => 127976,
    ),
    'char_name' => 
    array (
      'title' => 'HOTEL',
      'desc' => 'Temporary Notes: a building with "H"; related to U+1F157 = ARIB-9129',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 44,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58985,
      ),
      'sjis' => 
      array (
        0 => 63690,
      ),
      'jis' => 
      array (
        0 => 31029,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 378,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60033,
      ),
      'sjis' => 
      array (
        0 => 62292,
      ),
      'jis' => 
      array (
        0 => 31029,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 331,
      ),
      'number_old' => 
      array (
        0 => 178,
      ),
      'unicode' => 
      array (
        0 => 57688,
      ),
      'sjis' => 
      array (
        0 => 63385,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041591,
      ),
    ),
  ),
  240 => 
  array (
    'mapid' => '#e-4B8',
    'unicode' => 
    array (
      0 => 127977,
    ),
    'char_name' => 
    array (
      'title' => 'LOVE HOTEL',
      'desc' => 'Temporary Notes: Note: usually Japanese love hotel',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 44,
        1 => 139,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58985,
        1 => 59119,
      ),
      'sjis' => 
      array (
        0 => 63690,
        1 => 63892,
      ),
      'jis' => 
      array (
        0 => 31029,
        1 => 30001,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 492,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60147,
      ),
      'sjis' => 
      array (
        0 => 62407,
      ),
      'jis' => 
      array (
        0 => 31305,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 332,
      ),
      'number_old' => 
      array (
        0 => 424,
      ),
      'unicode' => 
      array (
        0 => 58625,
      ),
      'sjis' => 
      array (
        0 => 64417,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041592,
      ),
    ),
  ),
  241 => 
  array (
    'mapid' => '#e-4B9',
    'unicode' => 
    array (
      0 => 127978,
    ),
    'char_name' => 
    array (
      'title' => 'CONVENIENCE STORE',
      'desc' => 'Temporary Notes: Convenience Store (stylized "24" to indicate 24 hours)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 45,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58986,
      ),
      'sjis' => 
      array (
        0 => 63691,
      ),
      'jis' => 
      array (
        0 => 30045,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 206,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58532,
      ),
      'sjis' => 
      array (
        0 => 63100,
      ),
      'jis' => 
      array (
        0 => 30045,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 329,
      ),
      'number_old' => 
      array (
        0 => 176,
      ),
      'unicode' => 
      array (
        0 => 57686,
      ),
      'sjis' => 
      array (
        0 => 63383,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041593,
      ),
    ),
  ),
  242 => 
  array (
    'mapid' => '#e-4BA',
    'unicode' => 
    array (
      0 => 127979,
    ),
    'char_name' => 
    array (
      'title' => 'SCHOOL',
      'desc' => 'Temporary Notes: related to U+3246 = ARIB-9110',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59198,
      ),
      'sjis' => 
      array (
        0 => 63971,
      ),
      'jis' => 
      array (
        0 => 31028,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 377,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60032,
      ),
      'sjis' => 
      array (
        0 => 62291,
      ),
      'jis' => 
      array (
        0 => 31028,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 330,
      ),
      'number_old' => 
      array (
        0 => 177,
      ),
      'unicode' => 
      array (
        0 => 57687,
      ),
      'sjis' => 
      array (
        0 => 63384,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041594,
      ),
    ),
  ),
  243 => 
  array (
    'mapid' => '#e-4BB',
    'unicode' => 
    array (
      0 => 9962,
    ),
    'char_name' => 
    array (
      'title' => 'CHURCH',
      'desc' => '= ARIB-9114',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[教会]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 340,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58811,
      ),
      'sjis' => 
      array (
        0 => 63467,
      ),
      'jis' => 
      array (
        0 => 30829,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 335,
      ),
      'number_old' => 
      array (
        0 => 55,
      ),
      'unicode' => 
      array (
        0 => 57399,
      ),
      'sjis' => 
      array (
        0 => 63863,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041595,
      ),
    ),
  ),
  244 => 
  array (
    'mapid' => '#e-4BC',
    'unicode' => 
    array (
      0 => 9970,
    ),
    'char_name' => 
    array (
      'title' => 'FOUNTAIN',
      'desc' => '= ARIB-9125',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[噴水]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 360,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58831,
      ),
      'sjis' => 
      array (
        0 => 62274,
      ),
      'jis' => 
      array (
        0 => 31011,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 343,
      ),
      'number_old' => 
      array (
        0 => 123,
      ),
      'unicode' => 
      array (
        0 => 57633,
      ),
      'sjis' => 
      array (
        0 => 63329,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041596,
      ),
    ),
  ),
  245 => 
  array (
    'mapid' => '#e-4BD',
    'unicode' => 
    array (
      0 => 127980,
    ),
    'char_name' => 
    array (
      'title' => 'DEPARTMENT STORE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[デパート]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 495,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60150,
      ),
      'sjis' => 
      array (
        0 => 62410,
      ),
      'jis' => 
      array (
        0 => 31308,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 333,
      ),
      'number_old' => 
      array (
        0 => 427,
      ),
      'unicode' => 
      array (
        0 => 58628,
      ),
      'sjis' => 
      array (
        0 => 64420,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041597,
      ),
    ),
  ),
  246 => 
  array (
    'mapid' => '#e-4BE',
    'unicode' => 
    array (
      0 => 127983,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE CASTLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[城]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 496,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60151,
      ),
      'sjis' => 
      array (
        0 => 62411,
      ),
      'jis' => 
      array (
        0 => 31309,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 336,
      ),
      'number_old' => 
      array (
        0 => 428,
      ),
      'unicode' => 
      array (
        0 => 58629,
      ),
      'sjis' => 
      array (
        0 => 64421,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041598,
      ),
    ),
  ),
  247 => 
  array (
    'mapid' => '#e-4BF',
    'unicode' => 
    array (
      0 => 127984,
    ),
    'char_name' => 
    array (
      'title' => 'EUROPEAN CASTLE',
      'desc' => 'Old name: WESTERN CASTLE',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[城]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 497,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60152,
      ),
      'sjis' => 
      array (
        0 => 62412,
      ),
      'jis' => 
      array (
        0 => 31310,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 337,
      ),
      'number_old' => 
      array (
        0 => 429,
      ),
      'unicode' => 
      array (
        0 => 58630,
      ),
      'sjis' => 
      array (
        0 => 64422,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041599,
      ),
    ),
  ),
  248 => 
  array (
    'mapid' => '#e-4C0',
    'unicode' => 
    array (
      0 => 127981,
    ),
    'char_name' => 
    array (
      'title' => 'FACTORY',
      'desc' => '= industrial production site
= date of production',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[工場]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 498,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60153,
      ),
      'sjis' => 
      array (
        0 => 62413,
      ),
      'jis' => 
      array (
        0 => 31311,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 340,
      ),
      'number_old' => 
      array (
        0 => 431,
      ),
      'unicode' => 
      array (
        0 => 58632,
      ),
      'sjis' => 
      array (
        0 => 64424,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041600,
      ),
    ),
  ),
  249 => 
  array (
    'mapid' => '#e-4C1',
    'unicode' => 
    array (
      0 => 9875,
    ),
    'char_name' => 
    array (
      'title' => 'ANCHOR',
      'desc' => '= ARIB-9121
Temporary Notes: nautical term, harbor (on maps)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 36,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58977,
      ),
      'sjis' => 
      array (
        0 => 63682,
      ),
      'jis' => 
      array (
        0 => 31030,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 211,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58537,
      ),
      'sjis' => 
      array (
        0 => 63106,
      ),
      'jis' => 
      array (
        0 => 30050,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 210,
      ),
      'number_old' => 
      array (
        0 => 182,
      ),
      'unicode' => 
      array (
        0 => 57858,
      ),
      'sjis' => 
      array (
        0 => 63394,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041601,
      ),
    ),
  ),
  250 => 
  array (
    'mapid' => '#e-4C2',
    'unicode' => 
    array (
      0 => 127982,
    ),
    'char_name' => 
    array (
      'title' => 'IZAKAYA LANTERN',
      'desc' => '= japanese izakaya restaurant
Temporary Notes: Japanese izakaya restaurant for drinking, characteristic red lantern',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59211,
      ),
      'sjis' => 
      array (
        0 => 63984,
      ),
      'jis' => 
      array (
        0 => 31051,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 225,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58557,
      ),
      'sjis' => 
      array (
        0 => 63126,
      ),
      'jis' => 
      array (
        0 => 30070,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 169,
      ),
      'number_old' => 
      array (
        0 => 281,
      ),
      'unicode' => 
      array (
        0 => 58123,
      ),
      'sjis' => 
      array (
        0 => 63915,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041602,
      ),
    ),
  ),
  251 => 
  array (
    'mapid' => '#e-4C3',
    'unicode' => 
    array (
      0 => 128507,
    ),
    'char_name' => 
    array (
      'title' => 'MOUNT FUJI',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-1',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59200,
      ),
      'sjis' => 
      array (
        0 => 63973,
      ),
      'jis' => 
      array (
        0 => 30831,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 342,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58813,
      ),
      'sjis' => 
      array (
        0 => 63469,
      ),
      'jis' => 
      array (
        0 => 30831,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 90,
      ),
      'number_old' => 
      array (
        0 => 59,
      ),
      'unicode' => 
      array (
        0 => 57403,
      ),
      'sjis' => 
      array (
        0 => 63867,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041603,
      ),
    ),
  ),
  252 => 
  array (
    'mapid' => '#e-4C4',
    'unicode' => 
    array (
      0 => 128508,
    ),
    'char_name' => 
    array (
      'title' => 'TOKYO TOWER',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-2',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[東京タワー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 228,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58560,
      ),
      'sjis' => 
      array (
        0 => 63129,
      ),
      'jis' => 
      array (
        0 => 30073,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 338,
      ),
      'number_old' => 
      array (
        0 => 432,
      ),
      'unicode' => 
      array (
        0 => 58633,
      ),
      'sjis' => 
      array (
        0 => 64425,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041604,
      ),
    ),
  ),
  253 => 
  array (
    'mapid' => '#e-4C6',
    'unicode' => 
    array (
      0 => 128509,
    ),
    'char_name' => 
    array (
      'title' => 'STATUE OF LIBERTY',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-3',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[自由の女神]',
    ),
    'au' => 
    array (
      'kaomoji' => '[自由の女神]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 294,
      ),
      'number_old' => 
      array (
        0 => 452,
      ),
      'unicode' => 
      array (
        0 => 58653,
      ),
      'sjis' => 
      array (
        0 => 64445,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041606,
      ),
    ),
  ),
  254 => 
  array (
    'mapid' => '#e-4C7',
    'unicode' => 
    array (
      0 => 128510,
    ),
    'char_name' => 
    array (
      'title' => 'SILHOUETTE OF JAPAN',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-4',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[日本地図]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 214,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58738,
      ),
      'sjis' => 
      array (
        0 => 63375,
      ),
      'jis' => 
      array (
        0 => 30575,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[日本地図]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041607,
      ),
    ),
  ),
  255 => 
  array (
    'mapid' => '#e-4C8',
    'unicode' => 
    array (
      0 => 128511,
    ),
    'char_name' => 
    array (
      'title' => 'MOYAI',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-5
* Japanese stone statue like Moai on Easter Island
Temporary Notes: Japanese stone statue like Moai on Easter Island, famous one in Shibuya, Tokyo',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[モアイ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 794,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60268,
      ),
      'sjis' => 
      array (
        0 => 62576,
      ),
      'jis' => 
      array (
        0 => 31569,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[モアイ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041608,
      ),
    ),
  ),
  256 => 
  array (
    'mapid' => '#e-4CC',
    'unicode' => 
    array (
      0 => 128094,
    ),
    'char_name' => 
    array (
      'title' => 'MANS SHOE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 92,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59033,
      ),
      'sjis' => 
      array (
        0 => 63738,
      ),
      'jis' => 
      array (
        0 => 31342,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 336,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58807,
      ),
      'sjis' => 
      array (
        0 => 63463,
      ),
      'jis' => 
      array (
        0 => 30825,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 219,
      ),
      'number_old' => 
      array (
        0 => 7,
      ),
      'unicode' => 
      array (
        0 => 57351,
      ),
      'sjis' => 
      array (
        0 => 63815,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041612,
      ),
    ),
  ),
  257 => 
  array (
    'mapid' => '#e-4CD',
    'unicode' => 
    array (
      0 => 128095,
    ),
    'char_name' => 
    array (
      'title' => 'ATHLETIC SHOE',
      'desc' => 'Old name: SNEAKER
= runner, sneaker, tennis shoe',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 92,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59033,
      ),
      'sjis' => 
      array (
        0 => 63738,
      ),
      'jis' => 
      array (
        0 => 31342,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 729,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60203,
      ),
      'sjis' => 
      array (
        0 => 62444,
      ),
      'jis' => 
      array (
        0 => 31342,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 219,
      ),
      'number_old' => 
      array (
        0 => 7,
      ),
      'unicode' => 
      array (
        0 => 57351,
      ),
      'sjis' => 
      array (
        0 => 63815,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041613,
      ),
    ),
  ),
  258 => 
  array (
    'mapid' => '#e-4D6',
    'unicode' => 
    array (
      0 => 128096,
    ),
    'char_name' => 
    array (
      'title' => 'HIGH-HEELED SHOE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 55,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58996,
      ),
      'sjis' => 
      array (
        0 => 63701,
      ),
      'jis' => 
      array (
        0 => 30325,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 124,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58650,
      ),
      'sjis' => 
      array (
        0 => 63219,
      ),
      'jis' => 
      array (
        0 => 30325,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 220,
      ),
      'number_old' => 
      array (
        0 => 152,
      ),
      'unicode' => 
      array (
        0 => 57662,
      ),
      'sjis' => 
      array (
        0 => 63358,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041622,
      ),
    ),
  ),
  259 => 
  array (
    'mapid' => '#e-4D7',
    'unicode' => 
    array (
      0 => 128097,
    ),
    'char_name' => 
    array (
      'title' => 'WOMANS SANDAL',
      'desc' => 'Temporary Notes: woman\'s sandal with open toe, slipper',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 55,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58996,
      ),
      'sjis' => 
      array (
        0 => 63701,
      ),
      'jis' => 
      array (
        0 => 30325,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 124,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58650,
      ),
      'sjis' => 
      array (
        0 => 63219,
      ),
      'jis' => 
      array (
        0 => 30325,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 221,
      ),
      'number_old' => 
      array (
        0 => 296,
      ),
      'unicode' => 
      array (
        0 => 58138,
      ),
      'sjis' => 
      array (
        0 => 63930,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041623,
      ),
    ),
  ),
  260 => 
  array (
    'mapid' => '#e-4D8',
    'unicode' => 
    array (
      0 => 128098,
    ),
    'char_name' => 
    array (
      'title' => 'WOMANS BOOTS',
      'desc' => 'Temporary Notes: usually woman\'s boots',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ブーツ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 408,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60063,
      ),
      'sjis' => 
      array (
        0 => 62322,
      ),
      'jis' => 
      array (
        0 => 31059,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 222,
      ),
      'number_old' => 
      array (
        0 => 297,
      ),
      'unicode' => 
      array (
        0 => 58139,
      ),
      'sjis' => 
      array (
        0 => 63931,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041624,
      ),
    ),
  ),
  261 => 
  array (
    'mapid' => '#e-553',
    'unicode' => 
    array (
      0 => 128099,
    ),
    'char_name' => 
    array (
      'title' => 'FOOTPRINTS',
      'desc' => 'Temporary Notes: single or multiple footprints',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 91,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59032,
      ),
      'sjis' => 
      array (
        0 => 63737,
      ),
      'jis' => 
      array (
        0 => 31341,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 728,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60202,
      ),
      'sjis' => 
      array (
        0 => 62443,
      ),
      'jis' => 
      array (
        0 => 31341,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 73,
      ),
      'number_old' => 
      array (
        0 => 477,
      ),
      'unicode' => 
      array (
        0 => 58678,
      ),
      'sjis' => 
      array (
        0 => 64470,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041747,
      ),
    ),
  ),
  262 => 
  array (
    'mapid' => '#e-4CE',
    'unicode' => 
    array (
      0 => 128083,
    ),
    'char_name' => 
    array (
      'title' => 'EYEGLASSES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 93,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59034,
      ),
      'sjis' => 
      array (
        0 => 63739,
      ),
      'jis' => 
      array (
        0 => 30297,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58622,
      ),
      'sjis' => 
      array (
        0 => 63191,
      ),
      'jis' => 
      array (
        0 => 30297,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[メガネ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041614,
      ),
    ),
  ),
  263 => 
  array (
    'mapid' => '#e-4CF',
    'unicode' => 
    array (
      0 => 128085,
    ),
    'char_name' => 
    array (
      'title' => 'T-SHIRT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59150,
      ),
      'sjis' => 
      array (
        0 => 63923,
      ),
      'jis' => 
      array (
        0 => 30824,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 335,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58806,
      ),
      'sjis' => 
      array (
        0 => 63462,
      ),
      'jis' => 
      array (
        0 => 30824,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 214,
      ),
      'number_old' => 
      array (
        0 => 6,
      ),
      'unicode' => 
      array (
        0 => 57350,
      ),
      'sjis' => 
      array (
        0 => 63814,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041615,
      ),
    ),
  ),
  264 => 
  array (
    'mapid' => '#e-4D0',
    'unicode' => 
    array (
      0 => 128086,
    ),
    'char_name' => 
    array (
      'title' => 'JEANS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59153,
      ),
      'sjis' => 
      array (
        0 => 63926,
      ),
      'jis' => 
      array (
        0 => 31580,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 805,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60279,
      ),
      'sjis' => 
      array (
        0 => 62587,
      ),
      'jis' => 
      array (
        0 => 31580,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ジーンズ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041616,
      ),
    ),
  ),
  265 => 
  array (
    'mapid' => '#e-4D1',
    'unicode' => 
    array (
      0 => 128081,
    ),
    'char_name' => 
    array (
      'title' => 'CROWN',
      'desc' => 'Temporary Notes: Not the same as ♕ U+2655 WHITE CHESS KING',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59162,
      ),
      'sjis' => 
      array (
        0 => 63935,
      ),
      'jis' => 
      array (
        0 => 30843,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 354,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58825,
      ),
      'sjis' => 
      array (
        0 => 63481,
      ),
      'jis' => 
      array (
        0 => 30843,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
        0 => 104,
      ),
      'unicode' => 
      array (
        0 => 57614,
      ),
      'sjis' => 
      array (
        0 => 63310,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041617,
      ),
    ),
  ),
  266 => 
  array (
    'mapid' => '#e-4D3',
    'unicode' => 
    array (
      0 => 128084,
    ),
    'char_name' => 
    array (
      'title' => 'NECKTIE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ネクタイ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 396,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60051,
      ),
      'sjis' => 
      array (
        0 => 62310,
      ),
      'jis' => 
      array (
        0 => 31047,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 218,
      ),
      'number_old' => 
      array (
        0 => 272,
      ),
      'unicode' => 
      array (
        0 => 58114,
      ),
      'sjis' => 
      array (
        0 => 63906,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041619,
      ),
    ),
  ),
  267 => 
  array (
    'mapid' => '#e-4D4',
    'unicode' => 
    array (
      0 => 128082,
    ),
    'char_name' => 
    array (
      'title' => 'WOMANS HAT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[帽子]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 407,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60062,
      ),
      'sjis' => 
      array (
        0 => 62321,
      ),
      'jis' => 
      array (
        0 => 31058,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 225,
      ),
      'number_old' => 
      array (
        0 => 294,
      ),
      'unicode' => 
      array (
        0 => 58136,
      ),
      'sjis' => 
      array (
        0 => 63928,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041620,
      ),
    ),
  ),
  268 => 
  array (
    'mapid' => '#e-4D5',
    'unicode' => 
    array (
      0 => 128087,
    ),
    'char_name' => 
    array (
      'title' => 'DRESS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ドレス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 793,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60267,
      ),
      'sjis' => 
      array (
        0 => 62575,
      ),
      'jis' => 
      array (
        0 => 31568,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 215,
      ),
      'number_old' => 
      array (
        0 => 295,
      ),
      'unicode' => 
      array (
        0 => 58137,
      ),
      'sjis' => 
      array (
        0 => 63929,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041621,
      ),
    ),
  ),
  269 => 
  array (
    'mapid' => '#e-4D9',
    'unicode' => 
    array (
      0 => 128088,
    ),
    'char_name' => 
    array (
      'title' => 'KIMONO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[着物]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 412,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60067,
      ),
      'sjis' => 
      array (
        0 => 62326,
      ),
      'jis' => 
      array (
        0 => 31063,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 216,
      ),
      'number_old' => 
      array (
        0 => 303,
      ),
      'unicode' => 
      array (
        0 => 58145,
      ),
      'sjis' => 
      array (
        0 => 63937,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041625,
      ),
    ),
  ),
  270 => 
  array (
    'mapid' => '#e-4DA',
    'unicode' => 
    array (
      0 => 128089,
    ),
    'char_name' => 
    array (
      'title' => 'BIKINI',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ビキニ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 413,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60068,
      ),
      'sjis' => 
      array (
        0 => 62327,
      ),
      'jis' => 
      array (
        0 => 31064,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 217,
      ),
      'number_old' => 
      array (
        0 => 304,
      ),
      'unicode' => 
      array (
        0 => 58146,
      ),
      'sjis' => 
      array (
        0 => 63938,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041626,
      ),
    ),
  ),
  271 => 
  array (
    'mapid' => '#e-4DB',
    'unicode' => 
    array (
      0 => 128090,
    ),
    'char_name' => 
    array (
      'title' => 'WOMANS CLOTHES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59150,
      ),
      'sjis' => 
      array (
        0 => 63923,
      ),
      'jis' => 
      array (
        0 => 30824,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 301,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58637,
      ),
      'sjis' => 
      array (
        0 => 63206,
      ),
      'jis' => 
      array (
        0 => 30312,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 214,
      ),
      'number_old' => 
      array (
        0 => 6,
      ),
      'unicode' => 
      array (
        0 => 57350,
      ),
      'sjis' => 
      array (
        0 => 63814,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041627,
      ),
    ),
  ),
  272 => 
  array (
    'mapid' => '#e-4DC',
    'unicode' => 
    array (
      0 => 128091,
    ),
    'char_name' => 
    array (
      'title' => 'PURSE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59151,
      ),
      'sjis' => 
      array (
        0 => 63924,
      ),
      'jis' => 
      array (
        0 => 30303,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 290,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58628,
      ),
      'sjis' => 
      array (
        0 => 63197,
      ),
      'jis' => 
      array (
        0 => 30303,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[財布]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041628,
      ),
    ),
  ),
  273 => 
  array (
    'mapid' => '#e-4F0',
    'unicode' => 
    array (
      0 => 128092,
    ),
    'char_name' => 
    array (
      'title' => 'HANDBAG',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 69,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59010,
      ),
      'sjis' => 
      array (
        0 => 63715,
      ),
      'jis' => 
      array (
        0 => 30037,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 83,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58524,
      ),
      'sjis' => 
      array (
        0 => 63092,
      ),
      'jis' => 
      array (
        0 => 30037,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 226,
      ),
      'number_old' => 
      array (
        0 => 305,
      ),
      'unicode' => 
      array (
        0 => 58147,
      ),
      'sjis' => 
      array (
        0 => 63939,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041648,
      ),
    ),
  ),
  274 => 
  array (
    'mapid' => '#e-4F1',
    'unicode' => 
    array (
      0 => 128093,
    ),
    'char_name' => 
    array (
      'title' => 'POUCH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 168,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59053,
      ),
      'sjis' => 
      array (
        0 => 63825,
      ),
      'jis' => 
      array (
        0 => 32299,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[ふくろ]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ふくろ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041649,
      ),
    ),
  ),
  275 => 
  array (
    'mapid' => '#e-4DD',
    'unicode' => 
    array (
      0 => 128176,
    ),
    'char_name' => 
    array (
      'title' => 'MONEY BAG',
      'desc' => '* glyph may show any currency symbol instead of a dollar sign
Temporary Notes: a bag with a dollar or yen sign',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59157,
      ),
      'sjis' => 
      array (
        0 => 63930,
      ),
      'jis' => 
      array (
        0 => 30242,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 233,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58567,
      ),
      'sjis' => 
      array (
        0 => 63136,
      ),
      'jis' => 
      array (
        0 => 30242,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 235,
      ),
      'number_old' => 
      array (
        0 => 137,
      ),
      'unicode' => 
      array (
        0 => 57647,
      ),
      'sjis' => 
      array (
        0 => 63343,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041629,
      ),
    ),
  ),
  276 => 
  array (
    'mapid' => '#e-4DE',
    'unicode' => 
    array (
      0 => 128177,
    ),
    'char_name' => 
    array (
      'title' => 'CURRENCY EXCHANGE',
      'desc' => 'Temporary Notes: $ and ¥ signs, exchange rate',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[$￥]',
    ),
    'au' => 
    array (
      'kaomoji' => '[$￥]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 433,
      ),
      'number_old' => 
      array (
        0 => 163,
      ),
      'unicode' => 
      array (
        0 => 57673,
      ),
      'sjis' => 
      array (
        0 => 63370,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041630,
      ),
    ),
  ),
  277 => 
  array (
    'mapid' => '#e-4DF',
    'unicode' => 
    array (
      0 => 128185,
    ),
    'char_name' => 
    array (
      'title' => 'CHART WITH UPWARDS TREND AND YEN SIGN',
      'desc' => 'Old name: CHART WITH UPWARDS TREND AND YEN SYMBOL
Temporary Notes: stock market, stock prices',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[株価]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 373,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58844,
      ),
      'sjis' => 
      array (
        0 => 62287,
      ),
      'jis' => 
      array (
        0 => 31024,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 432,
      ),
      'number_old' => 
      array (
        0 => 164,
      ),
      'unicode' => 
      array (
        0 => 57674,
      ),
      'sjis' => 
      array (
        0 => 63371,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041631,
      ),
    ),
  ),
  278 => 
  array (
    'mapid' => '#e-4E0',
    'unicode' => 
    array (
      0 => 128178,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY DOLLAR SIGN',
      'desc' => 'Temporary Notes: disunified from $ U+0024 DOLLAR SIGN',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59157,
      ),
      'sjis' => 
      array (
        0 => 63930,
      ),
      'jis' => 
      array (
        0 => 30242,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 14,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58745,
      ),
      'sjis' => 
      array (
        0 => 63382,
      ),
      'jis' => 
      array (
        0 => 30582,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 235,
      ),
      'number_old' => 
      array (
        0 => 137,
      ),
      'unicode' => 
      array (
        0 => 57647,
      ),
      'sjis' => 
      array (
        0 => 63343,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041632,
      ),
    ),
  ),
  279 => 
  array (
    'mapid' => '#e-4E1',
    'unicode' => 
    array (
      0 => 128179,
    ),
    'char_name' => 
    array (
      'title' => 'CREDIT CARD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カード]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 87,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58748,
      ),
      'sjis' => 
      array (
        0 => 63385,
      ),
      'jis' => 
      array (
        0 => 30585,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[カード]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041633,
      ),
    ),
  ),
  280 => 
  array (
    'mapid' => '#e-4E2',
    'unicode' => 
    array (
      0 => 128180,
    ),
    'char_name' => 
    array (
      'title' => 'BANKNOTE WITH YEN SIGN',
      'desc' => 'Temporary Notes: a check, a sign indicating "not free"',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 113,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59094,
      ),
      'sjis' => 
      array (
        0 => 63866,
      ),
      'jis' => 
      array (
        0 => 30586,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 109,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58749,
      ),
      'sjis' => 
      array (
        0 => 63386,
      ),
      'jis' => 
      array (
        0 => 30586,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '￥',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041634,
      ),
    ),
  ),
  281 => 
  array (
    'mapid' => '#e-4E3',
    'unicode' => 
    array (
      0 => 128181,
    ),
    'char_name' => 
    array (
      'title' => 'BANKNOTE WITH DOLLAR SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59157,
      ),
      'sjis' => 
      array (
        0 => 63930,
      ),
      'jis' => 
      array (
        0 => 30242,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 139,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58757,
      ),
      'sjis' => 
      array (
        0 => 63394,
      ),
      'jis' => 
      array (
        0 => 30756,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 235,
      ),
      'number_old' => 
      array (
        0 => 137,
      ),
      'unicode' => 
      array (
        0 => 57647,
      ),
      'sjis' => 
      array (
        0 => 63343,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041635,
      ),
    ),
  ),
  282 => 
  array (
    'mapid' => '#e-4E4',
    'unicode' => 
    array (
      0 => 128184,
    ),
    'char_name' => 
    array (
      'title' => 'MONEY WITH WINGS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[飛んでいくお金]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 777,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60251,
      ),
      'sjis' => 
      array (
        0 => 62559,
      ),
      'jis' => 
      array (
        0 => 31552,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[飛んでいくお金]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041636,
      ),
    ),
  ),
  283 => 
  array (
    'mapid' => '#e-4ED',
    'unicode' => 
    array (
      0 => 127464,
      1 => 127475,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS CN',
      'desc' => 'Temporary Notes: China',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[中国]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 703,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60177,
      ),
      'sjis' => 
      array (
        0 => 62418,
      ),
      'jis' => 
      array (
        0 => 31316,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 430,
      ),
      'number_old' => 
      array (
        0 => 442,
      ),
      'unicode' => 
      array (
        0 => 58643,
      ),
      'sjis' => 
      array (
        0 => 64435,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041645,
      ),
    ),
  ),
  284 => 
  array (
    'mapid' => '#e-4E8',
    'unicode' => 
    array (
      0 => 127465,
      1 => 127466,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS DE',
      'desc' => 'Temporary Notes: Germany',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ドイツ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 700,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60174,
      ),
      'sjis' => 
      array (
        0 => 62415,
      ),
      'jis' => 
      array (
        0 => 31313,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 425,
      ),
      'number_old' => 
      array (
        0 => 437,
      ),
      'unicode' => 
      array (
        0 => 58638,
      ),
      'sjis' => 
      array (
        0 => 64430,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041640,
      ),
    ),
  ),
  285 => 
  array (
    'mapid' => '#e-4EB',
    'unicode' => 
    array (
      0 => 127466,
      1 => 127480,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS ES',
      'desc' => 'Temporary Notes: Spain',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[スペイン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 366,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58837,
      ),
      'sjis' => 
      array (
        0 => 62280,
      ),
      'jis' => 
      array (
        0 => 31017,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 428,
      ),
      'number_old' => 
      array (
        0 => 440,
      ),
      'unicode' => 
      array (
        0 => 58641,
      ),
      'sjis' => 
      array (
        0 => 64433,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041643,
      ),
    ),
  ),
  286 => 
  array (
    'mapid' => '#e-4E7',
    'unicode' => 
    array (
      0 => 127467,
      1 => 127479,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS FR',
      'desc' => 'Temporary Notes: France',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フランス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 499,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60154,
      ),
      'sjis' => 
      array (
        0 => 62414,
      ),
      'jis' => 
      array (
        0 => 31312,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 424,
      ),
      'number_old' => 
      array (
        0 => 436,
      ),
      'unicode' => 
      array (
        0 => 58637,
      ),
      'sjis' => 
      array (
        0 => 64429,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041639,
      ),
    ),
  ),
  287 => 
  array (
    'mapid' => '#e-4EA',
    'unicode' => 
    array (
      0 => 127468,
      1 => 127463,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS GB',
      'desc' => 'Temporary Notes: U.K.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[イギリス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 702,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60176,
      ),
      'sjis' => 
      array (
        0 => 62417,
      ),
      'jis' => 
      array (
        0 => 31315,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 427,
      ),
      'number_old' => 
      array (
        0 => 439,
      ),
      'unicode' => 
      array (
        0 => 58640,
      ),
      'sjis' => 
      array (
        0 => 64432,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041642,
      ),
    ),
  ),
  288 => 
  array (
    'mapid' => '#e-4E9',
    'unicode' => 
    array (
      0 => 127470,
      1 => 127481,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS IT',
      'desc' => 'Temporary Notes: Italy',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[イタリア]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 701,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60175,
      ),
      'sjis' => 
      array (
        0 => 62416,
      ),
      'jis' => 
      array (
        0 => 31314,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 426,
      ),
      'number_old' => 
      array (
        0 => 438,
      ),
      'unicode' => 
      array (
        0 => 58639,
      ),
      'sjis' => 
      array (
        0 => 64431,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041641,
      ),
    ),
  ),
  289 => 
  array (
    'mapid' => '#e-4E5',
    'unicode' => 
    array (
      0 => 127471,
      1 => 127477,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS JP',
      'desc' => 'Temporary Notes: Japan, also a national holiday (in red)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[日の丸]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58572,
      ),
      'sjis' => 
      array (
        0 => 63141,
      ),
      'jis' => 
      array (
        0 => 30247,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 422,
      ),
      'number_old' => 
      array (
        0 => 434,
      ),
      'unicode' => 
      array (
        0 => 58635,
      ),
      'sjis' => 
      array (
        0 => 64427,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041637,
      ),
    ),
  ),
  290 => 
  array (
    'mapid' => '#e-4EE',
    'unicode' => 
    array (
      0 => 127472,
      1 => 127479,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS KR',
      'desc' => 'Temporary Notes: South Korea',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[韓国]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 704,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60178,
      ),
      'sjis' => 
      array (
        0 => 62419,
      ),
      'jis' => 
      array (
        0 => 31317,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 431,
      ),
      'number_old' => 
      array (
        0 => 443,
      ),
      'unicode' => 
      array (
        0 => 58644,
      ),
      'sjis' => 
      array (
        0 => 64436,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041646,
      ),
    ),
  ),
  291 => 
  array (
    'mapid' => '#e-4EC',
    'unicode' => 
    array (
      0 => 127479,
      1 => 127482,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS RU',
      'desc' => 'Temporary Notes: Russia',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ロシア]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 367,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58838,
      ),
      'sjis' => 
      array (
        0 => 62281,
      ),
      'jis' => 
      array (
        0 => 31018,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 429,
      ),
      'number_old' => 
      array (
        0 => 441,
      ),
      'unicode' => 
      array (
        0 => 58642,
      ),
      'sjis' => 
      array (
        0 => 64434,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041644,
      ),
    ),
  ),
  292 => 
  array (
    'mapid' => '#e-4E6',
    'unicode' => 
    array (
      0 => 127482,
      1 => 127480,
    ),
    'char_name' => 
    array (
      'title' => 'REGIONAL INDICATOR SYMBOL LETTERS US',
      'desc' => 'Temporary Notes: U.S.A.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[USA]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 90,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58739,
      ),
      'sjis' => 
      array (
        0 => 63376,
      ),
      'jis' => 
      array (
        0 => 30576,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 423,
      ),
      'number_old' => 
      array (
        0 => 435,
      ),
      'unicode' => 
      array (
        0 => 58636,
      ),
      'sjis' => 
      array (
        0 => 64428,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041638,
      ),
    ),
  ),
  293 => 
  array (
    'mapid' => '#e-4F6',
    'unicode' => 
    array (
      0 => 128293,
    ),
    'char_name' => 
    array (
      'title' => 'FIRE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[炎]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 269,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58491,
      ),
      'sjis' => 
      array (
        0 => 63059,
      ),
      'jis' => 
      array (
        0 => 30004,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
        0 => 119,
      ),
      'unicode' => 
      array (
        0 => 57629,
      ),
      'sjis' => 
      array (
        0 => 63325,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041654,
      ),
    ),
  ),
  294 => 
  array (
    'mapid' => '#e-4FB',
    'unicode' => 
    array (
      0 => 128294,
    ),
    'char_name' => 
    array (
      'title' => 'ELECTRIC TORCH',
      'desc' => 'Old name: FLASHLIGHT
= flashlight',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 151,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59131,
      ),
      'sjis' => 
      array (
        0 => 63904,
      ),
      'jis' => 
      array (
        0 => 29999,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 130,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58755,
      ),
      'sjis' => 
      array (
        0 => 63392,
      ),
      'jis' => 
      array (
        0 => 30754,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[懐中電灯]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041659,
      ),
    ),
  ),
  295 => 
  array (
    'mapid' => '#e-4C9',
    'unicode' => 
    array (
      0 => 128295,
    ),
    'char_name' => 
    array (
      'title' => 'WRENCH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59160,
      ),
      'sjis' => 
      array (
        0 => 63933,
      ),
      'jis' => 
      array (
        0 => 30758,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 152,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58759,
      ),
      'sjis' => 
      array (
        0 => 63396,
      ),
      'jis' => 
      array (
        0 => 30758,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[レンチ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041609,
      ),
    ),
  ),
  296 => 
  array (
    'mapid' => '#e-4CA',
    'unicode' => 
    array (
      0 => 128296,
    ),
    'char_name' => 
    array (
      'title' => 'HAMMER',
      'desc' => 'Temporary Notes: mallet',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ハンマー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 356,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58827,
      ),
      'sjis' => 
      array (
        0 => 63483,
      ),
      'jis' => 
      array (
        0 => 30845,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 147,
      ),
      'number_old' => 
      array (
        0 => 112,
      ),
      'unicode' => 
      array (
        0 => 57622,
      ),
      'sjis' => 
      array (
        0 => 63318,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041610,
      ),
    ),
  ),
  297 => 
  array (
    'mapid' => '#e-4CB',
    'unicode' => 
    array (
      0 => 128297,
    ),
    'char_name' => 
    array (
      'title' => 'NUT AND BOLT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ネジ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 123,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58753,
      ),
      'sjis' => 
      array (
        0 => 63390,
      ),
      'jis' => 
      array (
        0 => 30590,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ネジ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041611,
      ),
    ),
  ),
  298 => 
  array (
    'mapid' => '#e-4FA',
    'unicode' => 
    array (
      0 => 128298,
    ),
    'char_name' => 
    array (
      'title' => 'HOCHO',
      'desc' => 'Old name: KNIFE
= Japanese kitchen knife',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[包丁]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 114,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58751,
      ),
      'sjis' => 
      array (
        0 => 63388,
      ),
      'jis' => 
      array (
        0 => 30588,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[包丁]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041658,
      ),
    ),
  ),
  299 => 
  array (
    'mapid' => '#e-4F5',
    'unicode' => 
    array (
      0 => 128299,
    ),
    'char_name' => 
    array (
      'title' => 'PISTOL',
      'desc' => 'Temporary Notes: action genre',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ピストル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 296,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58634,
      ),
      'sjis' => 
      array (
        0 => 63203,
      ),
      'jis' => 
      array (
        0 => 30309,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 146,
      ),
      'number_old' => 
      array (
        0 => 109,
      ),
      'unicode' => 
      array (
        0 => 57619,
      ),
      'sjis' => 
      array (
        0 => 63315,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041653,
      ),
    ),
  ),
  300 => 
  array (
    'mapid' => '#e-4F7',
    'unicode' => 
    array (
      0 => 128302,
    ),
    'char_name' => 
    array (
      'title' => 'CRYSTAL BALL',
      'desc' => 'Temporary Notes: fortune telling, zodiacs',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[占い]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 392,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60047,
      ),
      'sjis' => 
      array (
        0 => 62306,
      ),
      'jis' => 
      array (
        0 => 31043,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 404,
      ),
      'number_old' => 
      array (
        0 => 242,
      ),
      'unicode' => 
      array (
        0 => 57918,
      ),
      'sjis' => 
      array (
        0 => 63454,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041655,
      ),
    ),
  ),
  301 => 
  array (
    'mapid' => '#e-4F8',
    'unicode' => 
    array (
      0 => 128303,
    ),
    'char_name' => 
    array (
      'title' => 'SIX POINTED STAR WITH MIDDLE DOT',
      'desc' => 'Temporary Notes: zodiacs, fortune telling',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[占い]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 392,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60047,
      ),
      'sjis' => 
      array (
        0 => 62306,
      ),
      'jis' => 
      array (
        0 => 31043,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 404,
      ),
      'number_old' => 
      array (
        0 => 242,
      ),
      'unicode' => 
      array (
        0 => 57918,
      ),
      'sjis' => 
      array (
        0 => 63454,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041656,
      ),
    ),
  ),
  302 => 
  array (
    'mapid' => '#e-044',
    'unicode' => 
    array (
      0 => 128304,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE SYMBOL FOR BEGINNER',
      'desc' => 'Temporary Notes: (In Japan) Known as the "wakaba" mark - young/green-yellow leaf. Originally referred to a newly licensed driver. Now it refers to any neophyte.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[若葉マーク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 179,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58496,
      ),
      'sjis' => 
      array (
        0 => 63064,
      ),
      'jis' => 
      array (
        0 => 30009,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 351,
      ),
      'number_old' => 
      array (
        0 => 189,
      ),
      'unicode' => 
      array (
        0 => 57865,
      ),
      'sjis' => 
      array (
        0 => 63401,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040452,
      ),
    ),
  ),
  303 => 
  array (
    'mapid' => '#e-4D2',
    'unicode' => 
    array (
      0 => 128305,
    ),
    'char_name' => 
    array (
      'title' => 'TRIDENT EMBLEM',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59162,
      ),
      'sjis' => 
      array (
        0 => 63935,
      ),
      'jis' => 
      array (
        0 => 30843,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 354,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58825,
      ),
      'sjis' => 
      array (
        0 => 63481,
      ),
      'jis' => 
      array (
        0 => 30843,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 457,
      ),
      'number_old' => 
      array (
        0 => 49,
      ),
      'unicode' => 
      array (
        0 => 57393,
      ),
      'sjis' => 
      array (
        0 => 63857,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041618,
      ),
    ),
  ),
  304 => 
  array (
    'mapid' => '#e-509',
    'unicode' => 
    array (
      0 => 128137,
    ),
    'char_name' => 
    array (
      'title' => 'SYRINGE',
      'desc' => 'Temporary Notes: with blood',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[注射]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 304,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58640,
      ),
      'sjis' => 
      array (
        0 => 63209,
      ),
      'jis' => 
      array (
        0 => 30315,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 268,
      ),
      'number_old' => 
      array (
        0 => 149,
      ),
      'unicode' => 
      array (
        0 => 57659,
      ),
      'sjis' => 
      array (
        0 => 63355,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041673,
      ),
    ),
  ),
  305 => 
  array (
    'mapid' => '#e-50A',
    'unicode' => 
    array (
      0 => 128138,
    ),
    'char_name' => 
    array (
      'title' => 'PILL',
      'desc' => 'Temporary Notes: The carrier Emoji shows a capsule but the name is simply "medicine". So a more generic name is given. Also used for cold medicine.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[薬]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 403,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60058,
      ),
      'sjis' => 
      array (
        0 => 62317,
      ),
      'jis' => 
      array (
        0 => 31054,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 267,
      ),
      'number_old' => 
      array (
        0 => 285,
      ),
      'unicode' => 
      array (
        0 => 58127,
      ),
      'sjis' => 
      array (
        0 => 63919,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041674,
      ),
    ),
  ),
  306 => 
  array (
    'mapid' => '#e-50B',
    'unicode' => 
    array (
      0 => 127344,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED LATIN CAPITAL LETTER A',
      'desc' => '= blood type A',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[A]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 724,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60198,
      ),
      'sjis' => 
      array (
        0 => 62439,
      ),
      'jis' => 
      array (
        0 => 31337,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 418,
      ),
      'number_old' => 
      array (
        0 => 473,
      ),
      'unicode' => 
      array (
        0 => 58674,
      ),
      'sjis' => 
      array (
        0 => 64466,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041675,
      ),
    ),
  ),
  307 => 
  array (
    'mapid' => '#e-50C',
    'unicode' => 
    array (
      0 => 127345,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED LATIN CAPITAL LETTER B',
      'desc' => '= blood type B',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[B]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 725,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60199,
      ),
      'sjis' => 
      array (
        0 => 62440,
      ),
      'jis' => 
      array (
        0 => 31338,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 419,
      ),
      'number_old' => 
      array (
        0 => 474,
      ),
      'unicode' => 
      array (
        0 => 58675,
      ),
      'sjis' => 
      array (
        0 => 64467,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041676,
      ),
    ),
  ),
  308 => 
  array (
    'mapid' => '#e-50D',
    'unicode' => 
    array (
      0 => 127374,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED AB',
      'desc' => '= blood type AB',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[AB]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 727,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60201,
      ),
      'sjis' => 
      array (
        0 => 62442,
      ),
      'jis' => 
      array (
        0 => 31340,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 420,
      ),
      'number_old' => 
      array (
        0 => 475,
      ),
      'unicode' => 
      array (
        0 => 58676,
      ),
      'sjis' => 
      array (
        0 => 64468,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041677,
      ),
    ),
  ),
  309 => 
  array (
    'mapid' => '#e-50E',
    'unicode' => 
    array (
      0 => 127358,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED LATIN CAPITAL LETTER O',
      'desc' => '= blood type O',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[O]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 726,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60200,
      ),
      'sjis' => 
      array (
        0 => 62441,
      ),
      'jis' => 
      array (
        0 => 31339,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 421,
      ),
      'number_old' => 
      array (
        0 => 476,
      ),
      'unicode' => 
      array (
        0 => 58677,
      ),
      'sjis' => 
      array (
        0 => 64469,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041678,
      ),
    ),
  ),
  310 => 
  array (
    'mapid' => '#e-50F',
    'unicode' => 
    array (
      0 => 127872,
    ),
    'char_name' => 
    array (
      'title' => 'RIBBON',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 71,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59012,
      ),
      'sjis' => 
      array (
        0 => 63717,
      ),
      'jis' => 
      array (
        0 => 30782,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 312,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58783,
      ),
      'sjis' => 
      array (
        0 => 63420,
      ),
      'jis' => 
      array (
        0 => 30782,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 223,
      ),
      'number_old' => 
      array (
        0 => 290,
      ),
      'unicode' => 
      array (
        0 => 58132,
      ),
      'sjis' => 
      array (
        0 => 63924,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041679,
      ),
    ),
  ),
  311 => 
  array (
    'mapid' => '#e-510',
    'unicode' => 
    array (
      0 => 127873,
    ),
    'char_name' => 
    array (
      'title' => 'WRAPPED PRESENT',
      'desc' => 'x (package - 1F4E6)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 72,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59013,
      ),
      'sjis' => 
      array (
        0 => 63718,
      ),
      'jis' => 
      array (
        0 => 30250,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 144,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58575,
      ),
      'sjis' => 
      array (
        0 => 63144,
      ),
      'jis' => 
      array (
        0 => 30250,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
        0 => 108,
      ),
      'unicode' => 
      array (
        0 => 57618,
      ),
      'sjis' => 
      array (
        0 => 63314,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041680,
      ),
    ),
  ),
  312 => 
  array (
    'mapid' => '#e-511',
    'unicode' => 
    array (
      0 => 127874,
    ),
    'char_name' => 
    array (
      'title' => 'BIRTHDAY CAKE',
      'desc' => 'Temporary Notes: birthday',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 73,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59014,
      ),
      'sjis' => 
      array (
        0 => 63719,
      ),
      'jis' => 
      array (
        0 => 30783,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 313,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58784,
      ),
      'sjis' => 
      array (
        0 => 63421,
      ),
      'jis' => 
      array (
        0 => 30783,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
        0 => 345,
      ),
      'unicode' => 
      array (
        0 => 58187,
      ),
      'sjis' => 
      array (
        0 => 63979,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041681,
      ),
    ),
  ),
  313 => 
  array (
    'mapid' => '#e-512',
    'unicode' => 
    array (
      0 => 127876,
    ),
    'char_name' => 
    array (
      'title' => 'CHRISTMAS TREE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 103,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59044,
      ),
      'sjis' => 
      array (
        0 => 63816,
      ),
      'jis' => 
      array (
        0 => 30244,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 234,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58569,
      ),
      'sjis' => 
      array (
        0 => 63138,
      ),
      'jis' => 
      array (
        0 => 30244,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 320,
      ),
      'number_old' => 
      array (
        0 => 51,
      ),
      'unicode' => 
      array (
        0 => 57395,
      ),
      'sjis' => 
      array (
        0 => 63859,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041682,
      ),
    ),
  ),
  314 => 
  array (
    'mapid' => '#e-513',
    'unicode' => 
    array (
      0 => 127877,
    ),
    'char_name' => 
    array (
      'title' => 'FATHER CHRISTMAS',
      'desc' => 'Old name: SANTA CLAUS
= Santa Claus',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サンタ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 489,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60144,
      ),
      'sjis' => 
      array (
        0 => 62404,
      ),
      'jis' => 
      array (
        0 => 31302,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 319,
      ),
      'number_old' => 
      array (
        0 => 419,
      ),
      'unicode' => 
      array (
        0 => 58440,
      ),
      'sjis' => 
      array (
        0 => 64393,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041683,
      ),
    ),
  ),
  315 => 
  array (
    'mapid' => '#e-514',
    'unicode' => 
    array (
      0 => 127884,
    ),
    'char_name' => 
    array (
      'title' => 'CROSSED FLAGS',
      'desc' => '* Japanese national holiday',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[祝日]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 370,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58841,
      ),
      'sjis' => 
      array (
        0 => 62284,
      ),
      'jis' => 
      array (
        0 => 31021,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 80,
      ),
      'number_old' => 
      array (
        0 => 157,
      ),
      'unicode' => 
      array (
        0 => 57667,
      ),
      'sjis' => 
      array (
        0 => 63364,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041684,
      ),
    ),
  ),
  316 => 
  array (
    'mapid' => '#e-515',
    'unicode' => 
    array (
      0 => 127878,
    ),
    'char_name' => 
    array (
      'title' => 'FIREWORKS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花火]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 357,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58828,
      ),
      'sjis' => 
      array (
        0 => 63484,
      ),
      'jis' => 
      array (
        0 => 30846,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 314,
      ),
      'number_old' => 
      array (
        0 => 113,
      ),
      'unicode' => 
      array (
        0 => 57623,
      ),
      'sjis' => 
      array (
        0 => 63319,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041685,
      ),
    ),
  ),
  317 => 
  array (
    'mapid' => '#e-516',
    'unicode' => 
    array (
      0 => 127880,
    ),
    'char_name' => 
    array (
      'title' => 'BALLOON',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[風船]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 404,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60059,
      ),
      'sjis' => 
      array (
        0 => 62318,
      ),
      'jis' => 
      array (
        0 => 31055,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 145,
      ),
      'number_old' => 
      array (
        0 => 286,
      ),
      'unicode' => 
      array (
        0 => 58128,
      ),
      'sjis' => 
      array (
        0 => 63920,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041686,
      ),
    ),
  ),
  318 => 
  array (
    'mapid' => '#e-517',
    'unicode' => 
    array (
      0 => 127881,
    ),
    'char_name' => 
    array (
      'title' => 'PARTY POPPER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[クラッカー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 405,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60060,
      ),
      'sjis' => 
      array (
        0 => 62319,
      ),
      'jis' => 
      array (
        0 => 31056,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 138,
      ),
      'number_old' => 
      array (
        0 => 288,
      ),
      'unicode' => 
      array (
        0 => 58130,
      ),
      'sjis' => 
      array (
        0 => 63922,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041687,
      ),
    ),
  ),
  319 => 
  array (
    'mapid' => '#e-518',
    'unicode' => 
    array (
      0 => 127885,
    ),
    'char_name' => 
    array (
      'title' => 'PINE DECORATION',
      'desc' => '* Japanese new year\'s door decoration
Temporary Notes: (門松)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[門松]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 476,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60131,
      ),
      'sjis' => 
      array (
        0 => 62391,
      ),
      'jis' => 
      array (
        0 => 31289,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 308,
      ),
      'number_old' => 
      array (
        0 => 401,
      ),
      'unicode' => 
      array (
        0 => 58422,
      ),
      'sjis' => 
      array (
        0 => 64374,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041688,
      ),
    ),
  ),
  320 => 
  array (
    'mapid' => '#e-519',
    'unicode' => 
    array (
      0 => 127886,
    ),
    'char_name' => 
    array (
      'title' => 'JAPANESE DOLLS',
      'desc' => 'Old name: GIRLS DOLL FESTIVAL
* Japanese Hinamatsuri or girls\' doll festival
Temporary Notes: 雛祭り: Japanese Hinamatsuri',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ひな祭り]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 477,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60132,
      ),
      'sjis' => 
      array (
        0 => 62392,
      ),
      'jis' => 
      array (
        0 => 31290,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 310,
      ),
      'number_old' => 
      array (
        0 => 403,
      ),
      'unicode' => 
      array (
        0 => 58424,
      ),
      'sjis' => 
      array (
        0 => 64376,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041689,
      ),
    ),
  ),
  321 => 
  array (
    'mapid' => '#e-51A',
    'unicode' => 
    array (
      0 => 127891,
    ),
    'char_name' => 
    array (
      'title' => 'GRADUATION CAP',
      'desc' => '* graduation ceremony',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[卒業式]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 478,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60133,
      ),
      'sjis' => 
      array (
        0 => 62393,
      ),
      'jis' => 
      array (
        0 => 31291,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 311,
      ),
      'number_old' => 
      array (
        0 => 404,
      ),
      'unicode' => 
      array (
        0 => 58425,
      ),
      'sjis' => 
      array (
        0 => 64377,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041690,
      ),
    ),
  ),
  322 => 
  array (
    'mapid' => '#e-51B',
    'unicode' => 
    array (
      0 => 127890,
    ),
    'char_name' => 
    array (
      'title' => 'SCHOOL SATCHEL',
      'desc' => '* Japanese school entrance ceremony',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ランドセル]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 479,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60134,
      ),
      'sjis' => 
      array (
        0 => 62394,
      ),
      'jis' => 
      array (
        0 => 31292,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 312,
      ),
      'number_old' => 
      array (
        0 => 405,
      ),
      'unicode' => 
      array (
        0 => 58426,
      ),
      'sjis' => 
      array (
        0 => 64378,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041691,
      ),
    ),
  ),
  323 => 
  array (
    'mapid' => '#e-51C',
    'unicode' => 
    array (
      0 => 127887,
    ),
    'char_name' => 
    array (
      'title' => 'CARP STREAMER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[こいのぼり]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 480,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60135,
      ),
      'sjis' => 
      array (
        0 => 62395,
      ),
      'jis' => 
      array (
        0 => 31293,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 313,
      ),
      'number_old' => 
      array (
        0 => 406,
      ),
      'unicode' => 
      array (
        0 => 58427,
      ),
      'sjis' => 
      array (
        0 => 64379,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041692,
      ),
    ),
  ),
  324 => 
  array (
    'mapid' => '#e-51D',
    'unicode' => 
    array (
      0 => 127879,
    ),
    'char_name' => 
    array (
      'title' => 'FIREWORK SPARKLER',
      'desc' => '* long, stick-like firework that looks like a burning incense stick
Temporary Notes: "Senkoo Hanabi" in Japanese',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[線香花火]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 484,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60139,
      ),
      'sjis' => 
      array (
        0 => 62399,
      ),
      'jis' => 
      array (
        0 => 31297,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 315,
      ),
      'number_old' => 
      array (
        0 => 411,
      ),
      'unicode' => 
      array (
        0 => 58432,
      ),
      'sjis' => 
      array (
        0 => 64385,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041693,
      ),
    ),
  ),
  325 => 
  array (
    'mapid' => '#e-51E',
    'unicode' => 
    array (
      0 => 127888,
    ),
    'char_name' => 
    array (
      'title' => 'WIND CHIME',
      'desc' => 'Temporary Notes: Wind chime, wind bell (風鈴)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[風鈴]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 486,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60141,
      ),
      'sjis' => 
      array (
        0 => 62401,
      ),
      'jis' => 
      array (
        0 => 31299,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 316,
      ),
      'number_old' => 
      array (
        0 => 413,
      ),
      'unicode' => 
      array (
        0 => 58434,
      ),
      'sjis' => 
      array (
        0 => 64387,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041694,
      ),
    ),
  ),
  326 => 
  array (
    'mapid' => '#e-51F',
    'unicode' => 
    array (
      0 => 127875,
    ),
    'char_name' => 
    array (
      'title' => 'JACK-O-LANTERN',
      'desc' => 'Old name: JACK O LANTERN
= Hallowe\'en',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ハロウィン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 487,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60142,
      ),
      'sjis' => 
      array (
        0 => 62402,
      ),
      'jis' => 
      array (
        0 => 31300,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 318,
      ),
      'number_old' => 
      array (
        0 => 416,
      ),
      'unicode' => 
      array (
        0 => 58437,
      ),
      'sjis' => 
      array (
        0 => 64390,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041695,
      ),
    ),
  ),
  327 => 
  array (
    'mapid' => '#e-520',
    'unicode' => 
    array (
      0 => 127882,
    ),
    'char_name' => 
    array (
      'title' => 'CONFETTI BALL',
      'desc' => '= congratulations
Temporary Notes: Ornamental bag or decorative ball that opens up. Sometimes used to express "Congratulations!"',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[オメデトウ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 230,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58479,
      ),
      'sjis' => 
      array (
        0 => 63047,
      ),
      'jis' => 
      array (
        0 => 29992,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[オメデトウ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041696,
      ),
    ),
  ),
  328 => 
  array (
    'mapid' => '#e-521',
    'unicode' => 
    array (
      0 => 127883,
    ),
    'char_name' => 
    array (
      'title' => 'TANABATA TREE',
      'desc' => '= tanabata tree with wishing papers
Temporary Notes: (七夕笹飾り)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[七夕]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 747,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60221,
      ),
      'sjis' => 
      array (
        0 => 62529,
      ),
      'jis' => 
      array (
        0 => 31522,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[七夕]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041697,
      ),
    ),
  ),
  329 => 
  array (
    'mapid' => '#e-017',
    'unicode' => 
    array (
      0 => 127889,
    ),
    'char_name' => 
    array (
      'title' => 'MOON VIEWING CEREMONY',
      'desc' => '* Japanese Otsukimi harvest celebration
Temporary Notes: Moon viewing (お月見)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[お月見]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 488,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60143,
      ),
      'sjis' => 
      array (
        0 => 62403,
      ),
      'jis' => 
      array (
        0 => 31301,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 317,
      ),
      'number_old' => 
      array (
        0 => 417,
      ),
      'unicode' => 
      array (
        0 => 58438,
      ),
      'sjis' => 
      array (
        0 => 64391,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040407,
      ),
    ),
  ),
  330 => 
  array (
    'mapid' => '#e-522',
    'unicode' => 
    array (
      0 => 128223,
    ),
    'char_name' => 
    array (
      'title' => 'PAGER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 29,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58970,
      ),
      'sjis' => 
      array (
        0 => 63675,
      ),
      'jis' => 
      array (
        0 => 30778,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 308,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58779,
      ),
      'sjis' => 
      array (
        0 => 63416,
      ),
      'jis' => 
      array (
        0 => 30778,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ポケベル]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041698,
      ),
    ),
  ),
  331 => 
  array (
    'mapid' => '#e-523',
    'unicode' => 
    array (
      0 => 9742,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK TELEPHONE',
      'desc' => '= ARIB-9391',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 74,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59015,
      ),
      'sjis' => 
      array (
        0 => 63720,
      ),
      'jis' => 
      array (
        0 => 30773,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 85,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58774,
      ),
      'sjis' => 
      array (
        0 => 63411,
      ),
      'jis' => 
      array (
        0 => 30773,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 245,
      ),
      'number_old' => 
      array (
        0 => 9,
      ),
      'unicode' => 
      array (
        0 => 57353,
      ),
      'sjis' => 
      array (
        0 => 63817,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041699,
      ),
    ),
  ),
  332 => 
  array (
    'mapid' => '#e-524',
    'unicode' => 
    array (
      0 => 128222,
    ),
    'char_name' => 
    array (
      'title' => 'TELEPHONE RECEIVER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 74,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59015,
      ),
      'sjis' => 
      array (
        0 => 63720,
      ),
      'jis' => 
      array (
        0 => 30773,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 155,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58654,
      ),
      'sjis' => 
      array (
        0 => 63223,
      ),
      'jis' => 
      array (
        0 => 30329,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 245,
      ),
      'number_old' => 
      array (
        0 => 9,
      ),
      'unicode' => 
      array (
        0 => 57353,
      ),
      'sjis' => 
      array (
        0 => 63817,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041700,
      ),
    ),
  ),
  333 => 
  array (
    'mapid' => '#e-525',
    'unicode' => 
    array (
      0 => 128241,
    ),
    'char_name' => 
    array (
      'title' => 'MOBILE PHONE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 75,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59016,
      ),
      'sjis' => 
      array (
        0 => 63721,
      ),
      'jis' => 
      array (
        0 => 30759,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 161,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58760,
      ),
      'sjis' => 
      array (
        0 => 63397,
      ),
      'jis' => 
      array (
        0 => 30759,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 244,
      ),
      'number_old' => 
      array (
        0 => 10,
      ),
      'unicode' => 
      array (
        0 => 57354,
      ),
      'sjis' => 
      array (
        0 => 63818,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041701,
      ),
    ),
  ),
  334 => 
  array (
    'mapid' => '#e-526',
    'unicode' => 
    array (
      0 => 128242,
    ),
    'char_name' => 
    array (
      'title' => 'MOBILE PHONE WITH RIGHTWARDS ARROW AT LEFT',
      'desc' => 'Old name: PHONE WITH ARROW
* making a phone call',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 105,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59086,
      ),
      'sjis' => 
      array (
        0 => 63858,
      ),
      'jis' => 
      array (
        0 => 30817,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 513,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60168,
      ),
      'sjis' => 
      array (
        0 => 63455,
      ),
      'jis' => 
      array (
        0 => 30817,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 243,
      ),
      'number_old' => 
      array (
        0 => 94,
      ),
      'unicode' => 
      array (
        0 => 57604,
      ),
      'sjis' => 
      array (
        0 => 63300,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041702,
      ),
    ),
  ),
  335 => 
  array (
    'mapid' => '#e-527',
    'unicode' => 
    array (
      0 => 128221,
    ),
    'char_name' => 
    array (
      'title' => 'MEMO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59017,
      ),
      'sjis' => 
      array (
        0 => 63722,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 395,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60050,
      ),
      'sjis' => 
      array (
        0 => 62309,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041703,
      ),
    ),
  ),
  336 => 
  array (
    'mapid' => '#e-528',
    'unicode' => 
    array (
      0 => 128224,
    ),
    'char_name' => 
    array (
      'title' => 'FAX MACHINE',
      'desc' => 'Old name: FAX',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 107,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59088,
      ),
      'sjis' => 
      array (
        0 => 63860,
      ),
      'jis' => 
      array (
        0 => 30331,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 166,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58656,
      ),
      'sjis' => 
      array (
        0 => 63225,
      ),
      'jis' => 
      array (
        0 => 30331,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 246,
      ),
      'number_old' => 
      array (
        0 => 11,
      ),
      'unicode' => 
      array (
        0 => 57355,
      ),
      'sjis' => 
      array (
        0 => 63819,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041704,
      ),
    ),
  ),
  337 => 
  array (
    'mapid' => '#e-529',
    'unicode' => 
    array (
      0 => 9993,
    ),
    'char_name' => 
    array (
      'title' => 'ENVELOPE',
      'desc' => 'Temporary Notes: mail',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 110,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59091,
      ),
      'sjis' => 
      array (
        0 => 63863,
      ),
      'jis' => 
      array (
        0 => 30332,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 108,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58657,
      ),
      'sjis' => 
      array (
        0 => 63226,
      ),
      'jis' => 
      array (
        0 => 30332,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 242,
      ),
      'number_old' => 
      array (
        0 => 93,
      ),
      'unicode' => 
      array (
        0 => 57603,
      ),
      'sjis' => 
      array (
        0 => 63299,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041705,
      ),
    ),
  ),
  338 => 
  array (
    'mapid' => '#e-52A',
    'unicode' => 
    array (
      0 => 128232,
    ),
    'char_name' => 
    array (
      'title' => 'INCOMING ENVELOPE',
      'desc' => 'x (envelope - 2709)
Temporary Notes: Mail (with cartoon movement marks). Might be allocated in the U+27xx Dingbats block with U+2709 ENVELOPE.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 106,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59087,
      ),
      'sjis' => 
      array (
        0 => 63859,
      ),
      'jis' => 
      array (
        0 => 31559,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 151,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58769,
      ),
      'sjis' => 
      array (
        0 => 63406,
      ),
      'jis' => 
      array (
        0 => 30768,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 242,
      ),
      'number_old' => 
      array (
        0 => 93,
      ),
      'unicode' => 
      array (
        0 => 57603,
      ),
      'sjis' => 
      array (
        0 => 63299,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041706,
      ),
    ),
  ),
  339 => 
  array (
    'mapid' => '#e-52B',
    'unicode' => 
    array (
      0 => 128233,
    ),
    'char_name' => 
    array (
      'title' => 'ENVELOPE WITH DOWNWARDS ARROW ABOVE',
      'desc' => 'Old name: ENVELOPE WITH ARROW
* sending mail
Temporary Notes: Might be allocated in the U+27xx Dingbats block with U+2709 ENVELOPE.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 106,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59087,
      ),
      'sjis' => 
      array (
        0 => 63859,
      ),
      'jis' => 
      array (
        0 => 31559,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 784,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60258,
      ),
      'sjis' => 
      array (
        0 => 62566,
      ),
      'jis' => 
      array (
        0 => 31559,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 242,
      ),
      'number_old' => 
      array (
        0 => 93,
      ),
      'unicode' => 
      array (
        0 => 57603,
      ),
      'sjis' => 
      array (
        0 => 63299,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041707,
      ),
    ),
  ),
  340 => 
  array (
    'mapid' => '#e-52C',
    'unicode' => 
    array (
      0 => 128234,
    ),
    'char_name' => 
    array (
      'title' => 'CLOSED MAILBOX WITH LOWERED FLAG',
      'desc' => '= letter box, mail reception
= empty mailbox',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58981,
      ),
      'sjis' => 
      array (
        0 => 63686,
      ),
      'jis' => 
      array (
        0 => 31026,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 129,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58651,
      ),
      'sjis' => 
      array (
        0 => 63220,
      ),
      'jis' => 
      array (
        0 => 30326,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 323,
      ),
      'number_old' => 
      array (
        0 => 91,
      ),
      'unicode' => 
      array (
        0 => 57601,
      ),
      'sjis' => 
      array (
        0 => 63297,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041708,
      ),
    ),
  ),
  341 => 
  array (
    'mapid' => '#e-52D',
    'unicode' => 
    array (
      0 => 128235,
    ),
    'char_name' => 
    array (
      'title' => 'CLOSED MAILBOX WITH RAISED FLAG',
      'desc' => '= mailbox containing mail',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58981,
      ),
      'sjis' => 
      array (
        0 => 63686,
      ),
      'jis' => 
      array (
        0 => 31026,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 515,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60170,
      ),
      'sjis' => 
      array (
        0 => 63457,
      ),
      'jis' => 
      array (
        0 => 30819,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 323,
      ),
      'number_old' => 
      array (
        0 => 91,
      ),
      'unicode' => 
      array (
        0 => 57601,
      ),
      'sjis' => 
      array (
        0 => 63297,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041709,
      ),
    ),
  ),
  342 => 
  array (
    'mapid' => '#e-52E',
    'unicode' => 
    array (
      0 => 128238,
    ),
    'char_name' => 
    array (
      'title' => 'POSTBOX',
      'desc' => '= mailbox for sending mail',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58981,
      ),
      'sjis' => 
      array (
        0 => 63686,
      ),
      'jis' => 
      array (
        0 => 31026,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 129,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58651,
      ),
      'sjis' => 
      array (
        0 => 63220,
      ),
      'jis' => 
      array (
        0 => 30326,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 324,
      ),
      'number_old' => 
      array (
        0 => 92,
      ),
      'unicode' => 
      array (
        0 => 57602,
      ),
      'sjis' => 
      array (
        0 => 63298,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041710,
      ),
    ),
  ),
  343 => 
  array (
    'mapid' => '#e-822',
    'unicode' => 
    array (
      0 => 128240,
    ),
    'char_name' => 
    array (
      'title' => 'NEWSPAPER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[新聞]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 171,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58763,
      ),
      'sjis' => 
      array (
        0 => 63400,
      ),
      'jis' => 
      array (
        0 => 30762,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[新聞]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042466,
      ),
    ),
  ),
  344 => 
  array (
    'mapid' => '#e-52F',
    'unicode' => 
    array (
      0 => 128226,
    ),
    'char_name' => 
    array (
      'title' => 'PUBLIC ADDRESS LOUDSPEAKER',
      'desc' => 'Temporary Notes: used for sound volume, notification',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[スピーカ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58641,
      ),
      'sjis' => 
      array (
        0 => 63210,
      ),
      'jis' => 
      array (
        0 => 30316,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 150,
      ),
      'number_old' => 
      array (
        0 => 156,
      ),
      'unicode' => 
      array (
        0 => 57666,
      ),
      'sjis' => 
      array (
        0 => 63363,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041711,
      ),
    ),
  ),
  345 => 
  array (
    'mapid' => '#e-530',
    'unicode' => 
    array (
      0 => 128227,
    ),
    'char_name' => 
    array (
      'title' => 'CHEERING MEGAPHONE',
      'desc' => 'Temporary Notes: also used for a general megaphone',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[メガホン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58641,
      ),
      'sjis' => 
      array (
        0 => 63210,
      ),
      'jis' => 
      array (
        0 => 30316,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 151,
      ),
      'number_old' => 
      array (
        0 => 293,
      ),
      'unicode' => 
      array (
        0 => 58135,
      ),
      'sjis' => 
      array (
        0 => 63927,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041712,
      ),
    ),
  ),
  346 => 
  array (
    'mapid' => '#e-531',
    'unicode' => 
    array (
      0 => 128225,
    ),
    'char_name' => 
    array (
      'title' => 'SATELLITE ANTENNA',
      'desc' => '= position indicator, news',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[アンテナ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 210,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58536,
      ),
      'sjis' => 
      array (
        0 => 63105,
      ),
      'jis' => 
      array (
        0 => 30049,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 249,
      ),
      'number_old' => 
      array (
        0 => 165,
      ),
      'unicode' => 
      array (
        0 => 57675,
      ),
      'sjis' => 
      array (
        0 => 63372,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041713,
      ),
    ),
  ),
  347 => 
  array (
    'mapid' => '#e-533',
    'unicode' => 
    array (
      0 => 128228,
    ),
    'char_name' => 
    array (
      'title' => 'OUTBOX TRAY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[送信BOX]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 153,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58770,
      ),
      'sjis' => 
      array (
        0 => 63407,
      ),
      'jis' => 
      array (
        0 => 30769,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[送信BOX]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041715,
      ),
    ),
  ),
  348 => 
  array (
    'mapid' => '#e-534',
    'unicode' => 
    array (
      0 => 128229,
    ),
    'char_name' => 
    array (
      'title' => 'INBOX TRAY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[受信BOX]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 154,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58771,
      ),
      'sjis' => 
      array (
        0 => 63408,
      ),
      'jis' => 
      array (
        0 => 30770,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[受信BOX]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041716,
      ),
    ),
  ),
  349 => 
  array (
    'mapid' => '#e-535',
    'unicode' => 
    array (
      0 => 128230,
    ),
    'char_name' => 
    array (
      'title' => 'PACKAGE',
      'desc' => 'x (wrapped present - 1F381)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 72,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59013,
      ),
      'sjis' => 
      array (
        0 => 63718,
      ),
      'jis' => 
      array (
        0 => 30250,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 165,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58655,
      ),
      'sjis' => 
      array (
        0 => 63224,
      ),
      'jis' => 
      array (
        0 => 30330,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
        0 => 108,
      ),
      'unicode' => 
      array (
        0 => 57618,
      ),
      'sjis' => 
      array (
        0 => 63314,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041717,
      ),
    ),
  ),
  350 => 
  array (
    'mapid' => '#e-B92',
    'unicode' => 
    array (
      0 => 128231,
    ),
    'char_name' => 
    array (
      'title' => 'E-MAIL SYMBOL',
      'desc' => '* glyph may show an @-sign instead of an E
Temporary Notes: Email (Envelope with "E")',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 110,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59091,
      ),
      'sjis' => 
      array (
        0 => 63863,
      ),
      'jis' => 
      array (
        0 => 30332,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 799,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60273,
      ),
      'sjis' => 
      array (
        0 => 62581,
      ),
      'jis' => 
      array (
        0 => 31574,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 242,
      ),
      'number_old' => 
      array (
        0 => 93,
      ),
      'unicode' => 
      array (
        0 => 57603,
      ),
      'sjis' => 
      array (
        0 => 63299,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043346,
      ),
    ),
  ),
  351 => 
  array (
    'mapid' => '#e-B7C',
    'unicode' => 
    array (
      0 => 128288,
    ),
    'char_name' => 
    array (
      'title' => 'INPUT SYMBOL FOR LATIN CAPITAL LETTERS',
      'desc' => 'Old name: LATIN CAPITAL LETTERS INPUT SYMBOL
Temporary Notes: Letters (ABCD, uppercase)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ABCD]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 502,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60157,
      ),
      'sjis' => 
      array (
        0 => 63444,
      ),
      'jis' => 
      array (
        0 => 30806,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ABCD]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043324,
      ),
    ),
  ),
  352 => 
  array (
    'mapid' => '#e-B7D',
    'unicode' => 
    array (
      0 => 128289,
    ),
    'char_name' => 
    array (
      'title' => 'INPUT SYMBOL FOR LATIN SMALL LETTERS',
      'desc' => 'Old name: LATIN SMALL LETTERS INPUT SYMBOL
Temporary Notes: Letters (abcd, lowercase)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[abcd]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 503,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60158,
      ),
      'sjis' => 
      array (
        0 => 63445,
      ),
      'jis' => 
      array (
        0 => 30807,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[abcd]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043325,
      ),
    ),
  ),
  353 => 
  array (
    'mapid' => '#e-B7E',
    'unicode' => 
    array (
      0 => 128290,
    ),
    'char_name' => 
    array (
      'title' => 'INPUT SYMBOL FOR NUMBERS',
      'desc' => 'Old name: NUMBERS INPUT SYMBOL
Temporary Notes: Numbers (1234)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[1234]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 504,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60159,
      ),
      'sjis' => 
      array (
        0 => 63446,
      ),
      'jis' => 
      array (
        0 => 30808,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[1234]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043326,
      ),
    ),
  ),
  354 => 
  array (
    'mapid' => '#e-B7F',
    'unicode' => 
    array (
      0 => 128291,
    ),
    'char_name' => 
    array (
      'title' => 'INPUT SYMBOL FOR SYMBOLS',
      'desc' => 'Old name: SYMBOLS INPUT SYMBOL
Temporary Notes: Symbols (〒, ♪, @, %)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[記号]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 505,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60160,
      ),
      'sjis' => 
      array (
        0 => 63447,
      ),
      'jis' => 
      array (
        0 => 30809,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[記号]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043327,
      ),
    ),
  ),
  355 => 
  array (
    'mapid' => '#e-B80',
    'unicode' => 
    array (
      0 => 128292,
    ),
    'char_name' => 
    array (
      'title' => 'INPUT SYMBOL FOR LATIN LETTERS',
      'desc' => 'Old name: LATIN LETTERS INPUT SYMBOL
= English input (ABC)
Temporary Notes: English (ABC)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ABC]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 771,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60245,
      ),
      'sjis' => 
      array (
        0 => 62553,
      ),
      'jis' => 
      array (
        0 => 31546,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ABC]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043328,
      ),
    ),
  ),
  356 => 
  array (
    'mapid' => '#e-536',
    'unicode' => 
    array (
      0 => 10002,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK NIB',
      'desc' => 'Temporary Notes: editing, Docomo has WHITE NIB.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 169,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59054,
      ),
      'sjis' => 
      array (
        0 => 63826,
      ),
      'jis' => 
      array (
        0 => 30812,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 508,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60163,
      ),
      'sjis' => 
      array (
        0 => 63450,
      ),
      'jis' => 
      array (
        0 => 30812,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ペン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041718,
      ),
    ),
  ),
  357 => 
  array (
    'mapid' => '#e-537',
    'unicode' => 
    array (
      0 => 128186,
    ),
    'char_name' => 
    array (
      'title' => 'SEAT',
      'desc' => 'Design Note: the glyph should look more like SoftBank #264',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 171,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59058,
      ),
      'sjis' => 
      array (
        0 => 63830,
      ),
      'jis' => 
      array (
        0 => 32087,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[いす]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 264,
      ),
      'number_old' => 
      array (
        0 => 121,
      ),
      'unicode' => 
      array (
        0 => 57631,
      ),
      'sjis' => 
      array (
        0 => 63327,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041719,
      ),
    ),
  ),
  358 => 
  array (
    'mapid' => '#e-538',
    'unicode' => 
    array (
      0 => 128187,
    ),
    'char_name' => 
    array (
      'title' => 'PERSONAL COMPUTER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59158,
      ),
      'sjis' => 
      array (
        0 => 63931,
      ),
      'jis' => 
      array (
        0 => 30826,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 337,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58808,
      ),
      'sjis' => 
      array (
        0 => 63464,
      ),
      'jis' => 
      array (
        0 => 30826,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 241,
      ),
      'number_old' => 
      array (
        0 => 12,
      ),
      'unicode' => 
      array (
        0 => 57356,
      ),
      'sjis' => 
      array (
        0 => 63820,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041720,
      ),
    ),
  ),
  359 => 
  array (
    'mapid' => '#e-539',
    'unicode' => 
    array (
      0 => 9999,
    ),
    'char_name' => 
    array (
      'title' => 'PENCIL',
      'desc' => 'Temporary Notes: Note: pencil directions are varied among Japanese carriers, could be solid or white',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59161,
      ),
      'sjis' => 
      array (
        0 => 63934,
      ),
      'jis' => 
      array (
        0 => 30042,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 149,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58529,
      ),
      'sjis' => 
      array (
        0 => 63097,
      ),
      'jis' => 
      array (
        0 => 30042,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041721,
      ),
    ),
  ),
  360 => 
  array (
    'mapid' => '#e-53A',
    'unicode' => 
    array (
      0 => 128206,
    ),
    'char_name' => 
    array (
      'title' => 'PAPERCLIP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59184,
      ),
      'sjis' => 
      array (
        0 => 63957,
      ),
      'jis' => 
      array (
        0 => 30041,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58528,
      ),
      'sjis' => 
      array (
        0 => 63096,
      ),
      'jis' => 
      array (
        0 => 30041,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[クリップ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041722,
      ),
    ),
  ),
  361 => 
  array (
    'mapid' => '#e-53B',
    'unicode' => 
    array (
      0 => 128188,
    ),
    'char_name' => 
    array (
      'title' => 'BRIEFCASE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 69,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59010,
      ),
      'sjis' => 
      array (
        0 => 63715,
      ),
      'jis' => 
      array (
        0 => 30037,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 359,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58830,
      ),
      'sjis' => 
      array (
        0 => 62273,
      ),
      'jis' => 
      array (
        0 => 31010,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 227,
      ),
      'number_old' => 
      array (
        0 => 120,
      ),
      'unicode' => 
      array (
        0 => 57630,
      ),
      'sjis' => 
      array (
        0 => 63326,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041723,
      ),
    ),
  ),
  362 => 
  array (
    'mapid' => '#e-53C',
    'unicode' => 
    array (
      0 => 128189,
    ),
    'char_name' => 
    array (
      'title' => 'MINIDISC',
      'desc' => 'Old name: MINI DISC
Temporary Notes: MD mini disc',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[MD]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 126,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58754,
      ),
      'sjis' => 
      array (
        0 => 63391,
      ),
      'jis' => 
      array (
        0 => 30753,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 256,
      ),
      'number_old' => 
      array (
        0 => 292,
      ),
      'unicode' => 
      array (
        0 => 58134,
      ),
      'sjis' => 
      array (
        0 => 63926,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041724,
      ),
    ),
  ),
  363 => 
  array (
    'mapid' => '#e-53D',
    'unicode' => 
    array (
      0 => 128190,
    ),
    'char_name' => 
    array (
      'title' => 'FLOPPY DISK',
      'desc' => '= flexible disk cartridge, floppy disc, floppy, diskette',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フロッピー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 59,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58722,
      ),
      'sjis' => 
      array (
        0 => 63358,
      ),
      'jis' => 
      array (
        0 => 30559,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 256,
      ),
      'number_old' => 
      array (
        0 => 292,
      ),
      'unicode' => 
      array (
        0 => 58134,
      ),
      'sjis' => 
      array (
        0 => 63926,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041725,
      ),
    ),
  ),
  364 => 
  array (
    'mapid' => '#e-81D',
    'unicode' => 
    array (
      0 => 128191,
    ),
    'char_name' => 
    array (
      'title' => 'OPTICAL DISC',
      'desc' => 'Old name: OPTICAL DISK',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 79,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59020,
      ),
      'sjis' => 
      array (
        0 => 63725,
      ),
      'jis' => 
      array (
        0 => 30311,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 300,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58636,
      ),
      'sjis' => 
      array (
        0 => 63205,
      ),
      'jis' => 
      array (
        0 => 30311,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 253,
      ),
      'number_old' => 
      array (
        0 => 128,
      ),
      'unicode' => 
      array (
        0 => 57638,
      ),
      'sjis' => 
      array (
        0 => 63334,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042461,
      ),
    ),
  ),
  365 => 
  array (
    'mapid' => '#e-81E',
    'unicode' => 
    array (
      0 => 128192,
    ),
    'char_name' => 
    array (
      'title' => 'DVD',
      'desc' => '= digital video/versatile disc',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 79,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59020,
      ),
      'sjis' => 
      array (
        0 => 63725,
      ),
      'jis' => 
      array (
        0 => 30311,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 300,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58636,
      ),
      'sjis' => 
      array (
        0 => 63205,
      ),
      'jis' => 
      array (
        0 => 30311,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 254,
      ),
      'number_old' => 
      array (
        0 => 129,
      ),
      'unicode' => 
      array (
        0 => 57639,
      ),
      'sjis' => 
      array (
        0 => 63335,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042462,
      ),
    ),
  ),
  366 => 
  array (
    'mapid' => '#e-53E',
    'unicode' => 
    array (
      0 => 9986,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK SCISSORS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 56,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58997,
      ),
      'sjis' => 
      array (
        0 => 63702,
      ),
      'jis' => 
      array (
        0 => 30321,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 104,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58646,
      ),
      'sjis' => 
      array (
        0 => 63215,
      ),
      'jis' => 
      array (
        0 => 30321,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 238,
      ),
      'number_old' => 
      array (
        0 => 289,
      ),
      'unicode' => 
      array (
        0 => 58131,
      ),
      'sjis' => 
      array (
        0 => 63923,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041726,
      ),
    ),
  ),
  367 => 
  array (
    'mapid' => '#e-53F',
    'unicode' => 
    array (
      0 => 128205,
    ),
    'char_name' => 
    array (
      'title' => 'ROUND PUSHPIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[画びょう]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 49,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58720,
      ),
      'sjis' => 
      array (
        0 => 63356,
      ),
      'jis' => 
      array (
        0 => 30557,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[画びょう]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041727,
      ),
    ),
  ),
  368 => 
  array (
    'mapid' => '#e-540',
    'unicode' => 
    array (
      0 => 128195,
    ),
    'char_name' => 
    array (
      'title' => 'PAGE WITH CURL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59017,
      ),
      'sjis' => 
      array (
        0 => 63722,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 56,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58721,
      ),
      'sjis' => 
      array (
        0 => 63357,
      ),
      'jis' => 
      array (
        0 => 30558,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041728,
      ),
    ),
  ),
  369 => 
  array (
    'mapid' => '#e-541',
    'unicode' => 
    array (
      0 => 128196,
    ),
    'char_name' => 
    array (
      'title' => 'PAGE FACING UP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59017,
      ),
      'sjis' => 
      array (
        0 => 63722,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 103,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58729,
      ),
      'sjis' => 
      array (
        0 => 63366,
      ),
      'jis' => 
      array (
        0 => 30566,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041729,
      ),
    ),
  ),
  370 => 
  array (
    'mapid' => '#e-542',
    'unicode' => 
    array (
      0 => 128197,
    ),
    'char_name' => 
    array (
      'title' => 'CALENDAR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カレンダー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 67,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58723,
      ),
      'sjis' => 
      array (
        0 => 63360,
      ),
      'jis' => 
      array (
        0 => 30560,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[カレンダー]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041730,
      ),
    ),
  ),
  371 => 
  array (
    'mapid' => '#e-543',
    'unicode' => 
    array (
      0 => 128193,
    ),
    'char_name' => 
    array (
      'title' => 'FILE FOLDER',
      'desc' => 'Temporary Notes: closed folder',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フォルダ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 79,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58767,
      ),
      'sjis' => 
      array (
        0 => 63404,
      ),
      'jis' => 
      array (
        0 => 30766,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[フォルダ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041731,
      ),
    ),
  ),
  372 => 
  array (
    'mapid' => '#e-544',
    'unicode' => 
    array (
      0 => 128194,
    ),
    'char_name' => 
    array (
      'title' => 'OPEN FILE FOLDER',
      'desc' => 'Temporary Notes: open folder',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フォルダ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 84,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58768,
      ),
      'sjis' => 
      array (
        0 => 63405,
      ),
      'jis' => 
      array (
        0 => 30767,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[フォルダ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041732,
      ),
    ),
  ),
  373 => 
  array (
    'mapid' => '#e-545',
    'unicode' => 
    array (
      0 => 128211,
    ),
    'char_name' => 
    array (
      'title' => 'NOTEBOOK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 121,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58731,
      ),
      'sjis' => 
      array (
        0 => 63368,
      ),
      'jis' => 
      array (
        0 => 30568,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041733,
      ),
    ),
  ),
  374 => 
  array (
    'mapid' => '#e-546',
    'unicode' => 
    array (
      0 => 128214,
    ),
    'char_name' => 
    array (
      'title' => 'OPEN BOOK',
      'desc' => '= read operator\'s manual
* similar to ISO/IEC 7000-0790 "Read operator\'s manual"
Temporary Notes: open book, open notebook',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 122,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58527,
      ),
      'sjis' => 
      array (
        0 => 63095,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041734,
      ),
    ),
  ),
  375 => 
  array (
    'mapid' => '#e-547',
    'unicode' => 
    array (
      0 => 128212,
    ),
    'char_name' => 
    array (
      'title' => 'NOTEBOOK WITH DECORATIVE COVER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 91,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58525,
      ),
      'sjis' => 
      array (
        0 => 63093,
      ),
      'jis' => 
      array (
        0 => 30038,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041735,
      ),
    ),
  ),
  376 => 
  array (
    'mapid' => '#e-502',
    'unicode' => 
    array (
      0 => 128213,
    ),
    'char_name' => 
    array (
      'title' => 'CLOSED BOOK',
      'desc' => 'Old name: VERTICAL CLOSED BOOK
Temporary Notes: vertical closed book',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 102,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58728,
      ),
      'sjis' => 
      array (
        0 => 63365,
      ),
      'jis' => 
      array (
        0 => 30565,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041666,
      ),
    ),
  ),
  377 => 
  array (
    'mapid' => '#e-4FF',
    'unicode' => 
    array (
      0 => 128215,
    ),
    'char_name' => 
    array (
      'title' => 'GREEN BOOK',
      'desc' => 'Old name: BOOK-1
Temporary Notes: green colored book (closed)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 97,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58725,
      ),
      'sjis' => 
      array (
        0 => 63362,
      ),
      'jis' => 
      array (
        0 => 30562,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041663,
      ),
    ),
  ),
  378 => 
  array (
    'mapid' => '#e-500',
    'unicode' => 
    array (
      0 => 128216,
    ),
    'char_name' => 
    array (
      'title' => 'BLUE BOOK',
      'desc' => 'Old name: BOOK-2
Temporary Notes: blue colored book (closed)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 100,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58726,
      ),
      'sjis' => 
      array (
        0 => 63363,
      ),
      'jis' => 
      array (
        0 => 30563,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041664,
      ),
    ),
  ),
  379 => 
  array (
    'mapid' => '#e-501',
    'unicode' => 
    array (
      0 => 128217,
    ),
    'char_name' => 
    array (
      'title' => 'ORANGE BOOK',
      'desc' => 'Old name: BOOK-3
Temporary Notes: orange colored book (closed)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 101,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58727,
      ),
      'sjis' => 
      array (
        0 => 63364,
      ),
      'jis' => 
      array (
        0 => 30564,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041665,
      ),
    ),
  ),
  380 => 
  array (
    'mapid' => '#e-503',
    'unicode' => 
    array (
      0 => 128218,
    ),
    'char_name' => 
    array (
      'title' => 'BOOKS',
      'desc' => 'Temporary Notes: multiple, a stack of books',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 147,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58735,
      ),
      'sjis' => 
      array (
        0 => 63372,
      ),
      'jis' => 
      array (
        0 => 30572,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041667,
      ),
    ),
  ),
  381 => 
  array (
    'mapid' => '#e-504',
    'unicode' => 
    array (
      0 => 128219,
    ),
    'char_name' => 
    array (
      'title' => 'NAME BADGE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[名札]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 145,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58653,
      ),
      'sjis' => 
      array (
        0 => 63222,
      ),
      'jis' => 
      array (
        0 => 30328,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[名札]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041668,
      ),
    ),
  ),
  382 => 
  array (
    'mapid' => '#e-4FD',
    'unicode' => 
    array (
      0 => 128220,
    ),
    'char_name' => 
    array (
      'title' => 'SCROLL',
      'desc' => 'Temporary Notes: scroll a window on a computer',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 166,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59146,
      ),
      'sjis' => 
      array (
        0 => 63919,
      ),
      'jis' => 
      array (
        0 => 31348,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58719,
      ),
      'sjis' => 
      array (
        0 => 63355,
      ),
      'jis' => 
      array (
        0 => 30556,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[スクロール]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041661,
      ),
    ),
  ),
  383 => 
  array (
    'mapid' => '#e-548',
    'unicode' => 
    array (
      0 => 128203,
    ),
    'char_name' => 
    array (
      'title' => 'CLIPBOARD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59017,
      ),
      'sjis' => 
      array (
        0 => 63722,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 92,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58724,
      ),
      'sjis' => 
      array (
        0 => 63361,
      ),
      'jis' => 
      array (
        0 => 30561,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041736,
      ),
    ),
  ),
  384 => 
  array (
    'mapid' => '#e-549',
    'unicode' => 
    array (
      0 => 128198,
    ),
    'char_name' => 
    array (
      'title' => 'TEAR-OFF CALENDAR',
      'desc' => 'Old name: TEAR OFF CALENDAR',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カレンダー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 105,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58730,
      ),
      'sjis' => 
      array (
        0 => 63367,
      ),
      'jis' => 
      array (
        0 => 30567,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[カレンダー]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041737,
      ),
    ),
  ),
  385 => 
  array (
    'mapid' => '#e-54A',
    'unicode' => 
    array (
      0 => 128202,
    ),
    'char_name' => 
    array (
      'title' => 'BAR CHART',
      'desc' => 'Temporary Notes: bar graph',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[グラフ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 127,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58740,
      ),
      'sjis' => 
      array (
        0 => 63377,
      ),
      'jis' => 
      array (
        0 => 30577,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 432,
      ),
      'number_old' => 
      array (
        0 => 164,
      ),
      'unicode' => 
      array (
        0 => 57674,
      ),
      'sjis' => 
      array (
        0 => 63371,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041738,
      ),
    ),
  ),
  386 => 
  array (
    'mapid' => '#e-54B',
    'unicode' => 
    array (
      0 => 128200,
    ),
    'char_name' => 
    array (
      'title' => 'CHART WITH UPWARDS TREND',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[グラフ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 128,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58741,
      ),
      'sjis' => 
      array (
        0 => 63378,
      ),
      'jis' => 
      array (
        0 => 30578,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 432,
      ),
      'number_old' => 
      array (
        0 => 164,
      ),
      'unicode' => 
      array (
        0 => 57674,
      ),
      'sjis' => 
      array (
        0 => 63371,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041739,
      ),
    ),
  ),
  387 => 
  array (
    'mapid' => '#e-54C',
    'unicode' => 
    array (
      0 => 128201,
    ),
    'char_name' => 
    array (
      'title' => 'CHART WITH DOWNWARDS TREND',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[グラフ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 159,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58742,
      ),
      'sjis' => 
      array (
        0 => 63379,
      ),
      'jis' => 
      array (
        0 => 30579,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[グラフ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041740,
      ),
    ),
  ),
  388 => 
  array (
    'mapid' => '#e-54D',
    'unicode' => 
    array (
      0 => 128199,
    ),
    'char_name' => 
    array (
      'title' => 'CARD INDEX',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 131,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58732,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
        0 => 30569,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041741,
      ),
    ),
  ),
  389 => 
  array (
    'mapid' => '#e-54E',
    'unicode' => 
    array (
      0 => 128204,
    ),
    'char_name' => 
    array (
      'title' => 'PUSHPIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[画びょう]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58733,
      ),
      'sjis' => 
      array (
        0 => 63370,
      ),
      'jis' => 
      array (
        0 => 30570,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[画びょう]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041742,
      ),
    ),
  ),
  390 => 
  array (
    'mapid' => '#e-54F',
    'unicode' => 
    array (
      0 => 128210,
    ),
    'char_name' => 
    array (
      'title' => 'LEDGER',
      'desc' => 'Temporary Notes: real estate original record book, financial books,',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59011,
      ),
      'sjis' => 
      array (
        0 => 63716,
      ),
      'jis' => 
      array (
        0 => 30040,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 142,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58734,
      ),
      'sjis' => 
      array (
        0 => 63371,
      ),
      'jis' => 
      array (
        0 => 30571,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 236,
      ),
      'number_old' => 
      array (
        0 => 162,
      ),
      'unicode' => 
      array (
        0 => 57672,
      ),
      'sjis' => 
      array (
        0 => 63369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041743,
      ),
    ),
  ),
  391 => 
  array (
    'mapid' => '#e-550',
    'unicode' => 
    array (
      0 => 128207,
    ),
    'char_name' => 
    array (
      'title' => 'STRAIGHT RULER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[定規]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 157,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58736,
      ),
      'sjis' => 
      array (
        0 => 63373,
      ),
      'jis' => 
      array (
        0 => 30573,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[定規]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041744,
      ),
    ),
  ),
  392 => 
  array (
    'mapid' => '#e-551',
    'unicode' => 
    array (
      0 => 128208,
    ),
    'char_name' => 
    array (
      'title' => 'TRIANGULAR RULER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[三角定規]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 158,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58530,
      ),
      'sjis' => 
      array (
        0 => 63098,
      ),
      'jis' => 
      array (
        0 => 30043,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[三角定規]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041745,
      ),
    ),
  ),
  393 => 
  array (
    'mapid' => '#e-552',
    'unicode' => 
    array (
      0 => 128209,
    ),
    'char_name' => 
    array (
      'title' => 'BOOKMARK TABS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59017,
      ),
      'sjis' => 
      array (
        0 => 63722,
      ),
      'jis' => 
      array (
        0 => 31046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 516,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60171,
      ),
      'sjis' => 
      array (
        0 => 63458,
      ),
      'jis' => 
      array (
        0 => 30820,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 237,
      ),
      'number_old' => 
      array (
        0 => 271,
      ),
      'unicode' => 
      array (
        0 => 58113,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041746,
      ),
    ),
  ),
  394 => 
  array (
    'mapid' => '#e-7D0',
    'unicode' => 
    array (
      0 => 127933,
    ),
    'char_name' => 
    array (
      'title' => 'RUNNING SHIRT WITH SASH',
      'desc' => 'Temporary Notes: any sports; a sash across a running shirt to identify runner\'s number and team',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 21,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58962,
      ),
      'sjis' => 
      array (
        0 => 63667,
      ),
      'jis' => 
      array (
        0 => 32289,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '〓',
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042384,
      ),
    ),
  ),
  395 => 
  array (
    'mapid' => '#e-7D1',
    'unicode' => 
    array (
      0 => 9918,
    ),
    'char_name' => 
    array (
      'title' => 'BASEBALL',
      'desc' => '= ARIB-9316',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 22,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58963,
      ),
      'sjis' => 
      array (
        0 => 63668,
      ),
      'jis' => 
      array (
        0 => 30067,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 45,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58554,
      ),
      'sjis' => 
      array (
        0 => 63123,
      ),
      'jis' => 
      array (
        0 => 30067,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 153,
      ),
      'number_old' => 
      array (
        0 => 22,
      ),
      'unicode' => 
      array (
        0 => 57366,
      ),
      'sjis' => 
      array (
        0 => 63830,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042385,
      ),
    ),
  ),
  396 => 
  array (
    'mapid' => '#e-7D2',
    'unicode' => 
    array (
      0 => 9971,
    ),
    'char_name' => 
    array (
      'title' => 'FLAG IN HOLE',
      'desc' => '= ARIB-9126
Temporary Notes: Unified with U+26F3 = ARIB-9126. Golf (DoCoMo is golf club, others are the green and flag).',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 23,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58964,
      ),
      'sjis' => 
      array (
        0 => 63669,
      ),
      'jis' => 
      array (
        0 => 30776,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 306,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58777,
      ),
      'sjis' => 
      array (
        0 => 63414,
      ),
      'jis' => 
      array (
        0 => 30776,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 156,
      ),
      'number_old' => 
      array (
        0 => 20,
      ),
      'unicode' => 
      array (
        0 => 57364,
      ),
      'sjis' => 
      array (
        0 => 63828,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042386,
      ),
    ),
  ),
  397 => 
  array (
    'mapid' => '#e-7D3',
    'unicode' => 
    array (
      0 => 127934,
    ),
    'char_name' => 
    array (
      'title' => 'TENNIS RACQUET AND BALL',
      'desc' => 'Old name: TENNIS
= tennis
Temporary Notes: racket and ball, or player',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 24,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58965,
      ),
      'sjis' => 
      array (
        0 => 63670,
      ),
      'jis' => 
      array (
        0 => 30064,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 220,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58551,
      ),
      'sjis' => 
      array (
        0 => 63120,
      ),
      'jis' => 
      array (
        0 => 30064,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 154,
      ),
      'number_old' => 
      array (
        0 => 21,
      ),
      'unicode' => 
      array (
        0 => 57365,
      ),
      'sjis' => 
      array (
        0 => 63829,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042387,
      ),
    ),
  ),
  398 => 
  array (
    'mapid' => '#e-7D4',
    'unicode' => 
    array (
      0 => 9917,
    ),
    'char_name' => 
    array (
      'title' => 'SOCCER BALL',
      'desc' => 'Temporary Notes: soccer ball, or player',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 25,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58966,
      ),
      'sjis' => 
      array (
        0 => 63671,
      ),
      'jis' => 
      array (
        0 => 30063,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 219,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58550,
      ),
      'sjis' => 
      array (
        0 => 63119,
      ),
      'jis' => 
      array (
        0 => 30063,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 152,
      ),
      'number_old' => 
      array (
        0 => 24,
      ),
      'unicode' => 
      array (
        0 => 57368,
      ),
      'sjis' => 
      array (
        0 => 63832,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042388,
      ),
    ),
  ),
  399 => 
  array (
    'mapid' => '#e-7D5',
    'unicode' => 
    array (
      0 => 127935,
    ),
    'char_name' => 
    array (
      'title' => 'SKI AND SKI BOOT',
      'desc' => 'Old name: SKIING
= skiing
x (skier - 26F7)
Temporary Notes: ski and boots, or ski and poles. disunified from U+26F7 (ARIB-9138: SKIER) because U+26F7 is a person on a ski while all 3 carriers have a boot on a ski.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 26,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58967,
      ),
      'sjis' => 
      array (
        0 => 63672,
      ),
      'jis' => 
      array (
        0 => 31072,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 421,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60076,
      ),
      'sjis' => 
      array (
        0 => 62336,
      ),
      'jis' => 
      array (
        0 => 31072,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 157,
      ),
      'number_old' => 
      array (
        0 => 19,
      ),
      'unicode' => 
      array (
        0 => 57363,
      ),
      'sjis' => 
      array (
        0 => 63827,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042389,
      ),
    ),
  ),
  400 => 
  array (
    'mapid' => '#e-7D6',
    'unicode' => 
    array (
      0 => 127936,
    ),
    'char_name' => 
    array (
      'title' => 'BASKETBALL AND HOOP',
      'desc' => 'Old name: BASKETBALL
= basketball
Temporary Notes: ball and hoop',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 27,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58968,
      ),
      'sjis' => 
      array (
        0 => 63673,
      ),
      'jis' => 
      array (
        0 => 30777,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 307,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58778,
      ),
      'sjis' => 
      array (
        0 => 63415,
      ),
      'jis' => 
      array (
        0 => 30777,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 155,
      ),
      'number_old' => 
      array (
        0 => 389,
      ),
      'unicode' => 
      array (
        0 => 58410,
      ),
      'sjis' => 
      array (
        0 => 64362,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042390,
      ),
    ),
  ),
  401 => 
  array (
    'mapid' => '#e-7D7',
    'unicode' => 
    array (
      0 => 127937,
    ),
    'char_name' => 
    array (
      'title' => 'CHEQUERED FLAG',
      'desc' => 'Old name: CHECKERED FLAG
= motor sports
Temporary Notes: motor sports, goal',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 28,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58969,
      ),
      'sjis' => 
      array (
        0 => 63674,
      ),
      'jis' => 
      array (
        0 => 30066,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 222,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58553,
      ),
      'sjis' => 
      array (
        0 => 63122,
      ),
      'jis' => 
      array (
        0 => 30066,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 163,
      ),
      'number_old' => 
      array (
        0 => 140,
      ),
      'unicode' => 
      array (
        0 => 57650,
      ),
      'sjis' => 
      array (
        0 => 63346,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042391,
      ),
    ),
  ),
  402 => 
  array (
    'mapid' => '#e-7D8',
    'unicode' => 
    array (
      0 => 127938,
    ),
    'char_name' => 
    array (
      'title' => 'SNOWBOARDER',
      'desc' => 'Temporary Notes: snow boarding',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59154,
      ),
      'sjis' => 
      array (
        0 => 63927,
      ),
      'jis' => 
      array (
        0 => 30065,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 221,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58552,
      ),
      'sjis' => 
      array (
        0 => 63121,
      ),
      'jis' => 
      array (
        0 => 30065,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[スノボ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042392,
      ),
    ),
  ),
  403 => 
  array (
    'mapid' => '#e-7D9',
    'unicode' => 
    array (
      0 => 127939,
    ),
    'char_name' => 
    array (
      'title' => 'RUNNER',
      'desc' => '= running, marathon, track and fields',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59187,
      ),
      'sjis' => 
      array (
        0 => 63960,
      ),
      'jis' => 
      array (
        0 => 29988,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 218,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58475,
      ),
      'sjis' => 
      array (
        0 => 63043,
      ),
      'jis' => 
      array (
        0 => 29988,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 75,
      ),
      'number_old' => 
      array (
        0 => 111,
      ),
      'unicode' => 
      array (
        0 => 57621,
      ),
      'sjis' => 
      array (
        0 => 63317,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042393,
      ),
    ),
  ),
  404 => 
  array (
    'mapid' => '#e-7DA',
    'unicode' => 
    array (
      0 => 127940,
    ),
    'char_name' => 
    array (
      'title' => 'SURFER',
      'desc' => '= surfing',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59154,
      ),
      'sjis' => 
      array (
        0 => 63927,
      ),
      'jis' => 
      array (
        0 => 30065,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 751,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60225,
      ),
      'sjis' => 
      array (
        0 => 62533,
      ),
      'jis' => 
      array (
        0 => 31526,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 161,
      ),
      'number_old' => 
      array (
        0 => 23,
      ),
      'unicode' => 
      array (
        0 => 57367,
      ),
      'sjis' => 
      array (
        0 => 63831,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042394,
      ),
    ),
  ),
  405 => 
  array (
    'mapid' => '#e-7DB',
    'unicode' => 
    array (
      0 => 127942,
    ),
    'char_name' => 
    array (
      'title' => 'TROPHY',
      'desc' => 'Temporary Notes: a gold cup',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[トロフィー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 364,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58835,
      ),
      'sjis' => 
      array (
        0 => 62278,
      ),
      'jis' => 
      array (
        0 => 31015,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 139,
      ),
      'number_old' => 
      array (
        0 => 139,
      ),
      'unicode' => 
      array (
        0 => 57649,
      ),
      'sjis' => 
      array (
        0 => 63345,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042395,
      ),
    ),
  ),
  406 => 
  array (
    'mapid' => '#e-7DD',
    'unicode' => 
    array (
      0 => 127944,
    ),
    'char_name' => 
    array (
      'title' => 'AMERICAN FOOTBALL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フットボール]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 96,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58555,
      ),
      'sjis' => 
      array (
        0 => 63124,
      ),
      'jis' => 
      array (
        0 => 30068,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 158,
      ),
      'number_old' => 
      array (
        0 => 390,
      ),
      'unicode' => 
      array (
        0 => 58411,
      ),
      'sjis' => 
      array (
        0 => 64363,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042397,
      ),
    ),
  ),
  407 => 
  array (
    'mapid' => '#e-7DE',
    'unicode' => 
    array (
      0 => 127946,
    ),
    'char_name' => 
    array (
      'title' => 'SWIMMER',
      'desc' => 'Temporary Notes: swimming',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[水泳]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 471,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60126,
      ),
      'sjis' => 
      array (
        0 => 62386,
      ),
      'jis' => 
      array (
        0 => 31284,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 160,
      ),
      'number_old' => 
      array (
        0 => 392,
      ),
      'unicode' => 
      array (
        0 => 58413,
      ),
      'sjis' => 
      array (
        0 => 64365,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042398,
      ),
    ),
  ),
  408 => 
  array (
    'mapid' => '#e-7DF',
    'unicode' => 
    array (
      0 => 128643,
    ),
    'char_name' => 
    array (
      'title' => 'RAILWAY CAR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 30,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58971,
      ),
      'sjis' => 
      array (
        0 => 63676,
      ),
      'jis' => 
      array (
        0 => 30062,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 172,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58549,
      ),
      'sjis' => 
      array (
        0 => 63118,
      ),
      'jis' => 
      array (
        0 => 30062,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 205,
      ),
      'number_old' => 
      array (
        0 => 30,
      ),
      'unicode' => 
      array (
        0 => 57374,
      ),
      'sjis' => 
      array (
        0 => 63838,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042399,
      ),
    ),
  ),
  409 => 
  array (
    'mapid' => '#e-7E0',
    'unicode' => 
    array (
      0 => 128647,
    ),
    'char_name' => 
    array (
      'title' => 'METRO',
      'desc' => '= subway, underground train
Temporary Notes: (DoCoMo\'s is an "M" for metro)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 31,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58972,
      ),
      'sjis' => 
      array (
        0 => 63677,
      ),
      'jis' => 
      array (
        0 => 30830,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 341,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58812,
      ),
      'sjis' => 
      array (
        0 => 63468,
      ),
      'jis' => 
      array (
        0 => 30830,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 206,
      ),
      'number_old' => 
      array (
        0 => 399,
      ),
      'unicode' => 
      array (
        0 => 58420,
      ),
      'sjis' => 
      array (
        0 => 64372,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042400,
      ),
    ),
  ),
  410 => 
  array (
    'mapid' => '#e-7E1',
    'unicode' => 
    array (
      0 => 9410,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCLED LATIN CAPITAL LETTER M',
      'desc' => 'Temporary Notes: Disunified from SUBWAY symbols from KDDI and Softbank. Was originally proposed as a new "METRO SIGN" symbol but then unified with Ⓜ U+24C2 CIRCLED LATIN CAPITAL LETTER M because several variants of a stylized "M" are found for different Metro systems, including a circled M. (Project issue 92.)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 31,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58972,
      ),
      'sjis' => 
      array (
        0 => 63677,
      ),
      'jis' => 
      array (
        0 => 30830,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 341,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58812,
      ),
      'sjis' => 
      array (
        0 => 63468,
      ),
      'jis' => 
      array (
        0 => 30830,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 206,
      ),
      'number_old' => 
      array (
        0 => 399,
      ),
      'unicode' => 
      array (
        0 => 58420,
      ),
      'sjis' => 
      array (
        0 => 64372,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042401,
      ),
    ),
  ),
  411 => 
  array (
    'mapid' => '#e-7E2',
    'unicode' => 
    array (
      0 => 128644,
    ),
    'char_name' => 
    array (
      'title' => 'HIGH-SPEED TRAIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 32,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58973,
      ),
      'sjis' => 
      array (
        0 => 63678,
      ),
      'jis' => 
      array (
        0 => 30057,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 217,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58544,
      ),
      'sjis' => 
      array (
        0 => 63113,
      ),
      'jis' => 
      array (
        0 => 30057,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 209,
      ),
      'number_old' => 
      array (
        0 => 400,
      ),
      'unicode' => 
      array (
        0 => 58421,
      ),
      'sjis' => 
      array (
        0 => 64373,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042402,
      ),
    ),
  ),
  412 => 
  array (
    'mapid' => '#e-7E3',
    'unicode' => 
    array (
      0 => 128645,
    ),
    'char_name' => 
    array (
      'title' => 'HIGH-SPEED TRAIN WITH BULLET NOSE',
      'desc' => 'Temporary Notes: front facing for SoftBank, used in different phone sets; old-style Japanese high-speed train; Wikipedia/Shinkansen: "The first Shinkansen trains, the 0 series [...]. The last of these trains, with their classic bullet-nosed appearance, were retired on 30 November 2008."',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 32,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58973,
      ),
      'sjis' => 
      array (
        0 => 63678,
      ),
      'jis' => 
      array (
        0 => 30057,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 217,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58544,
      ),
      'sjis' => 
      array (
        0 => 63113,
      ),
      'jis' => 
      array (
        0 => 30057,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 208,
      ),
      'number_old' => 
      array (
        0 => 31,
      ),
      'unicode' => 
      array (
        0 => 57375,
      ),
      'sjis' => 
      array (
        0 => 63839,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042403,
      ),
    ),
  ),
  413 => 
  array (
    'mapid' => '#e-7E4',
    'unicode' => 
    array (
      0 => 128663,
    ),
    'char_name' => 
    array (
      'title' => 'AUTOMOBILE',
      'desc' => 'Old name: AUTOMOBILE-1
Temporary Notes: sedan',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 33,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58974,
      ),
      'sjis' => 
      array (
        0 => 63679,
      ),
      'jis' => 
      array (
        0 => 30058,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58545,
      ),
      'sjis' => 
      array (
        0 => 63114,
      ),
      'jis' => 
      array (
        0 => 30058,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 197,
      ),
      'number_old' => 
      array (
        0 => 27,
      ),
      'unicode' => 
      array (
        0 => 57371,
      ),
      'sjis' => 
      array (
        0 => 63835,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042404,
      ),
    ),
  ),
  414 => 
  array (
    'mapid' => '#e-7E5',
    'unicode' => 
    array (
      0 => 128665,
    ),
    'char_name' => 
    array (
      'title' => 'RECREATIONAL VEHICLE',
      'desc' => 'Temporary Notes: wagon',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 34,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58975,
      ),
      'sjis' => 
      array (
        0 => 63680,
      ),
      'jis' => 
      array (
        0 => 32290,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58545,
      ),
      'sjis' => 
      array (
        0 => 63114,
      ),
      'jis' => 
      array (
        0 => 30058,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 198,
      ),
      'number_old' => 
      array (
        0 => 393,
      ),
      'unicode' => 
      array (
        0 => 58414,
      ),
      'sjis' => 
      array (
        0 => 64366,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042405,
      ),
    ),
  ),
  415 => 
  array (
    'mapid' => '#e-7E6',
    'unicode' => 
    array (
      0 => 128652,
    ),
    'char_name' => 
    array (
      'title' => 'BUS',
      'desc' => 'Old name: BUS-2',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58976,
      ),
      'sjis' => 
      array (
        0 => 63681,
      ),
      'jis' => 
      array (
        0 => 30056,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 216,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58543,
      ),
      'sjis' => 
      array (
        0 => 63112,
      ),
      'jis' => 
      array (
        0 => 30056,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 199,
      ),
      'number_old' => 
      array (
        0 => 179,
      ),
      'unicode' => 
      array (
        0 => 57689,
      ),
      'sjis' => 
      array (
        0 => 63386,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042406,
      ),
    ),
  ),
  416 => 
  array (
    'mapid' => '#e-7E7',
    'unicode' => 
    array (
      0 => 128655,
    ),
    'char_name' => 
    array (
      'title' => 'BUS STOP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[バス停]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 209,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58535,
      ),
      'sjis' => 
      array (
        0 => 63104,
      ),
      'jis' => 
      array (
        0 => 30048,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 347,
      ),
      'number_old' => 
      array (
        0 => 170,
      ),
      'unicode' => 
      array (
        0 => 57680,
      ),
      'sjis' => 
      array (
        0 => 63377,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042407,
      ),
    ),
  ),
  417 => 
  array (
    'mapid' => '#e-7E8',
    'unicode' => 
    array (
      0 => 128674,
    ),
    'char_name' => 
    array (
      'title' => 'SHIP',
      'desc' => 'x (ferry - 26F4)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 36,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58977,
      ),
      'sjis' => 
      array (
        0 => 63682,
      ),
      'jis' => 
      array (
        0 => 31030,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 379,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60034,
      ),
      'sjis' => 
      array (
        0 => 62293,
      ),
      'jis' => 
      array (
        0 => 31030,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 210,
      ),
      'number_old' => 
      array (
        0 => 182,
      ),
      'unicode' => 
      array (
        0 => 57858,
      ),
      'sjis' => 
      array (
        0 => 63394,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042408,
      ),
    ),
  ),
  418 => 
  array (
    'mapid' => '#e-7E9',
    'unicode' => 
    array (
      0 => 9992,
    ),
    'char_name' => 
    array (
      'title' => 'AIRPLANE',
      'desc' => '= ARIB-9122',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 37,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58978,
      ),
      'sjis' => 
      array (
        0 => 63683,
      ),
      'jis' => 
      array (
        0 => 30060,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 168,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58547,
      ),
      'sjis' => 
      array (
        0 => 63116,
      ),
      'jis' => 
      array (
        0 => 30060,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 212,
      ),
      'number_old' => 
      array (
        0 => 29,
      ),
      'unicode' => 
      array (
        0 => 57373,
      ),
      'sjis' => 
      array (
        0 => 63837,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042409,
      ),
    ),
  ),
  419 => 
  array (
    'mapid' => '#e-7EA',
    'unicode' => 
    array (
      0 => 9973,
    ),
    'char_name' => 
    array (
      'title' => 'SAILBOAT',
      'desc' => '= ARIB-9128',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 102,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59043,
      ),
      'sjis' => 
      array (
        0 => 63815,
      ),
      'jis' => 
      array (
        0 => 30061,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 169,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58548,
      ),
      'sjis' => 
      array (
        0 => 63117,
      ),
      'jis' => 
      array (
        0 => 30061,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 211,
      ),
      'number_old' => 
      array (
        0 => 28,
      ),
      'unicode' => 
      array (
        0 => 57372,
      ),
      'sjis' => 
      array (
        0 => 63836,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042410,
      ),
    ),
  ),
  420 => 
  array (
    'mapid' => '#e-7EC',
    'unicode' => 
    array (
      0 => 128649,
    ),
    'char_name' => 
    array (
      'title' => 'STATION',
      'desc' => '= train, subway station',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[駅]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 795,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60269,
      ),
      'sjis' => 
      array (
        0 => 62577,
      ),
      'jis' => 
      array (
        0 => 31570,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 207,
      ),
      'number_old' => 
      array (
        0 => 57,
      ),
      'unicode' => 
      array (
        0 => 57401,
      ),
      'sjis' => 
      array (
        0 => 63865,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042412,
      ),
    ),
  ),
  421 => 
  array (
    'mapid' => '#e-7ED',
    'unicode' => 
    array (
      0 => 128640,
    ),
    'char_name' => 
    array (
      'title' => 'ROCKET',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ロケット]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 353,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58824,
      ),
      'sjis' => 
      array (
        0 => 63480,
      ),
      'jis' => 
      array (
        0 => 30842,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 213,
      ),
      'number_old' => 
      array (
        0 => 103,
      ),
      'unicode' => 
      array (
        0 => 57613,
      ),
      'sjis' => 
      array (
        0 => 63309,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042413,
      ),
    ),
  ),
  422 => 
  array (
    'mapid' => '#e-7EE',
    'unicode' => 
    array (
      0 => 128676,
    ),
    'char_name' => 
    array (
      'title' => 'SPEEDBOAT',
      'desc' => 'Temporary Notes: motorboat racing',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 102,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59043,
      ),
      'sjis' => 
      array (
        0 => 63815,
      ),
      'jis' => 
      array (
        0 => 30061,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 169,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58548,
      ),
      'sjis' => 
      array (
        0 => 63117,
      ),
      'jis' => 
      array (
        0 => 30061,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 162,
      ),
      'number_old' => 
      array (
        0 => 143,
      ),
      'unicode' => 
      array (
        0 => 57653,
      ),
      'sjis' => 
      array (
        0 => 63349,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042414,
      ),
    ),
  ),
  423 => 
  array (
    'mapid' => '#e-7EF',
    'unicode' => 
    array (
      0 => 128661,
    ),
    'char_name' => 
    array (
      'title' => 'TAXI',
      'desc' => 'Old name: TAXI-1
Temporary Notes: a car with light sign on the roof',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 33,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58974,
      ),
      'sjis' => 
      array (
        0 => 63679,
      ),
      'jis' => 
      array (
        0 => 30058,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58545,
      ),
      'sjis' => 
      array (
        0 => 63114,
      ),
      'jis' => 
      array (
        0 => 30058,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 204,
      ),
      'number_old' => 
      array (
        0 => 180,
      ),
      'unicode' => 
      array (
        0 => 57690,
      ),
      'sjis' => 
      array (
        0 => 63387,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042415,
      ),
    ),
  ),
  424 => 
  array (
    'mapid' => '#e-7F1',
    'unicode' => 
    array (
      0 => 128666,
    ),
    'char_name' => 
    array (
      'title' => 'DELIVERY TRUCK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[トラック]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58546,
      ),
      'sjis' => 
      array (
        0 => 63115,
      ),
      'jis' => 
      array (
        0 => 30059,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 200,
      ),
      'number_old' => 
      array (
        0 => 394,
      ),
      'unicode' => 
      array (
        0 => 58415,
      ),
      'sjis' => 
      array (
        0 => 64367,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042417,
      ),
    ),
  ),
  425 => 
  array (
    'mapid' => '#e-7F2',
    'unicode' => 
    array (
      0 => 128658,
    ),
    'char_name' => 
    array (
      'title' => 'FIRE ENGINE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[消防車]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 472,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60127,
      ),
      'sjis' => 
      array (
        0 => 62387,
      ),
      'jis' => 
      array (
        0 => 31285,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 203,
      ),
      'number_old' => 
      array (
        0 => 395,
      ),
      'unicode' => 
      array (
        0 => 58416,
      ),
      'sjis' => 
      array (
        0 => 64368,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042418,
      ),
    ),
  ),
  426 => 
  array (
    'mapid' => '#e-7F3',
    'unicode' => 
    array (
      0 => 128657,
    ),
    'char_name' => 
    array (
      'title' => 'AMBULANCE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[救急車]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 473,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60128,
      ),
      'sjis' => 
      array (
        0 => 62388,
      ),
      'jis' => 
      array (
        0 => 31286,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 202,
      ),
      'number_old' => 
      array (
        0 => 396,
      ),
      'unicode' => 
      array (
        0 => 58417,
      ),
      'sjis' => 
      array (
        0 => 64369,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042419,
      ),
    ),
  ),
  427 => 
  array (
    'mapid' => '#e-7F4',
    'unicode' => 
    array (
      0 => 128659,
    ),
    'char_name' => 
    array (
      'title' => 'POLICE CAR',
      'desc' => 'Old name: POLICE CAR-1',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[パトカー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 474,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60129,
      ),
      'sjis' => 
      array (
        0 => 62389,
      ),
      'jis' => 
      array (
        0 => 31287,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 201,
      ),
      'number_old' => 
      array (
        0 => 397,
      ),
      'unicode' => 
      array (
        0 => 58418,
      ),
      'sjis' => 
      array (
        0 => 64370,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042420,
      ),
    ),
  ),
  428 => 
  array (
    'mapid' => '#e-7F5',
    'unicode' => 
    array (
      0 => 9981,
    ),
    'char_name' => 
    array (
      'title' => 'FUEL PUMP',
      'desc' => '= ARIB-9146',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58987,
      ),
      'sjis' => 
      array (
        0 => 63692,
      ),
      'jis' => 
      array (
        0 => 30574,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 213,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58737,
      ),
      'sjis' => 
      array (
        0 => 63374,
      ),
      'jis' => 
      array (
        0 => 30574,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 346,
      ),
      'number_old' => 
      array (
        0 => 58,
      ),
      'unicode' => 
      array (
        0 => 57402,
      ),
      'sjis' => 
      array (
        0 => 63866,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042421,
      ),
    ),
  ),
  429 => 
  array (
    'mapid' => '#e-7F6',
    'unicode' => 
    array (
      0 => 127359,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED LATIN CAPITAL LETTER P',
      'desc' => '= ARIB-9016
Temporary Notes: "P" sign',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 47,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58988,
      ),
      'sjis' => 
      array (
        0 => 63693,
      ),
      'jis' => 
      array (
        0 => 30047,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 208,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58534,
      ),
      'sjis' => 
      array (
        0 => 63102,
      ),
      'jis' => 
      array (
        0 => 30047,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 352,
      ),
      'number_old' => 
      array (
        0 => 169,
      ),
      'unicode' => 
      array (
        0 => 57679,
      ),
      'sjis' => 
      array (
        0 => 63376,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042422,
      ),
    ),
  ),
  430 => 
  array (
    'mapid' => '#e-7F7',
    'unicode' => 
    array (
      0 => 128677,
    ),
    'char_name' => 
    array (
      'title' => 'HORIZONTAL TRAFFIC LIGHT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 48,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58989,
      ),
      'sjis' => 
      array (
        0 => 63694,
      ),
      'jis' => 
      array (
        0 => 29987,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 99,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58474,
      ),
      'sjis' => 
      array (
        0 => 63042,
      ),
      'jis' => 
      array (
        0 => 29987,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 348,
      ),
      'number_old' => 
      array (
        0 => 168,
      ),
      'unicode' => 
      array (
        0 => 57678,
      ),
      'sjis' => 
      array (
        0 => 63375,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042423,
      ),
    ),
  ),
  431 => 
  array (
    'mapid' => '#e-7F8',
    'unicode' => 
    array (
      0 => 128679,
    ),
    'char_name' => 
    array (
      'title' => 'CONSTRUCTION SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[工事中]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 368,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58839,
      ),
      'sjis' => 
      array (
        0 => 62282,
      ),
      'jis' => 
      array (
        0 => 31019,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 350,
      ),
      'number_old' => 
      array (
        0 => 145,
      ),
      'unicode' => 
      array (
        0 => 57655,
      ),
      'sjis' => 
      array (
        0 => 63351,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042424,
      ),
    ),
  ),
  432 => 
  array (
    'mapid' => '#e-7F9',
    'unicode' => 
    array (
      0 => 128680,
    ),
    'char_name' => 
    array (
      'title' => 'POLICE CARS REVOLVING LIGHT',
      'desc' => '= rotating beacon',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[パトカー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 801,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60275,
      ),
      'sjis' => 
      array (
        0 => 62583,
      ),
      'jis' => 
      array (
        0 => 31576,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 201,
      ),
      'number_old' => 
      array (
        0 => 397,
      ),
      'unicode' => 
      array (
        0 => 58418,
      ),
      'sjis' => 
      array (
        0 => 64370,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042425,
      ),
    ),
  ),
  433 => 
  array (
    'mapid' => '#e-7FA',
    'unicode' => 
    array (
      0 => 9832,
    ),
    'char_name' => 
    array (
      'title' => 'HOT SPRINGS',
      'desc' => '= ARIB-9117
Temporary Notes: onsen',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 147,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59127,
      ),
      'sjis' => 
      array (
        0 => 63900,
      ),
      'jis' => 
      array (
        0 => 30069,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 224,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58556,
      ),
      'sjis' => 
      array (
        0 => 63125,
      ),
      'jis' => 
      array (
        0 => 30069,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 345,
      ),
      'number_old' => 
      array (
        0 => 125,
      ),
      'unicode' => 
      array (
        0 => 57635,
      ),
      'sjis' => 
      array (
        0 => 63331,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042426,
      ),
    ),
  ),
  434 => 
  array (
    'mapid' => '#e-7FB',
    'unicode' => 
    array (
      0 => 9978,
    ),
    'char_name' => 
    array (
      'title' => 'TENT',
      'desc' => '= ARIB-9141
Temporary Notes: camp',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[キャンプ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 361,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58832,
      ),
      'sjis' => 
      array (
        0 => 62275,
      ),
      'jis' => 
      array (
        0 => 31012,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 344,
      ),
      'number_old' => 
      array (
        0 => 124,
      ),
      'unicode' => 
      array (
        0 => 57634,
      ),
      'sjis' => 
      array (
        0 => 63330,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042427,
      ),
    ),
  ),
  435 => 
  array (
    'mapid' => '#e-7FC',
    'unicode' => 
    array (
      0 => 127904,
    ),
    'char_name' => 
    array (
      'title' => 'CAROUSEL HORSE',
      'desc' => '= amusement park',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 60,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59001,
      ),
      'sjis' => 
      array (
        0 => 63706,
      ),
      'jis' => 
      array (
        0 => 32291,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '〓',
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042428,
      ),
    ),
  ),
  436 => 
  array (
    'mapid' => '#e-7FD',
    'unicode' => 
    array (
      0 => 127905,
    ),
    'char_name' => 
    array (
      'title' => 'FERRIS WHEEL',
      'desc' => '= amusement park',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[観覧車]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 223,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58477,
      ),
      'sjis' => 
      array (
        0 => 63045,
      ),
      'jis' => 
      array (
        0 => 29990,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 341,
      ),
      'number_old' => 
      array (
        0 => 126,
      ),
      'unicode' => 
      array (
        0 => 57636,
      ),
      'sjis' => 
      array (
        0 => 63332,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042429,
      ),
    ),
  ),
  437 => 
  array (
    'mapid' => '#e-7FE',
    'unicode' => 
    array (
      0 => 127906,
    ),
    'char_name' => 
    array (
      'title' => 'ROLLER COASTER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ジェットコースター]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 475,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60130,
      ),
      'sjis' => 
      array (
        0 => 62390,
      ),
      'jis' => 
      array (
        0 => 31288,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 342,
      ),
      'number_old' => 
      array (
        0 => 398,
      ),
      'unicode' => 
      array (
        0 => 58419,
      ),
      'sjis' => 
      array (
        0 => 64371,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042430,
      ),
    ),
  ),
  438 => 
  array (
    'mapid' => '#e-7FF',
    'unicode' => 
    array (
      0 => 127907,
    ),
    'char_name' => 
    array (
      'title' => 'FISHING POLE AND FISH',
      'desc' => 'Old name: FISHING
= fishing',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59217,
      ),
      'sjis' => 
      array (
        0 => 63990,
      ),
      'jis' => 
      array (
        0 => 31328,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 752,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60226,
      ),
      'sjis' => 
      array (
        0 => 62534,
      ),
      'jis' => 
      array (
        0 => 31527,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 130,
      ),
      'number_old' => 
      array (
        0 => 25,
      ),
      'unicode' => 
      array (
        0 => 57369,
      ),
      'sjis' => 
      array (
        0 => 63833,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042431,
      ),
    ),
  ),
  439 => 
  array (
    'mapid' => '#e-800',
    'unicode' => 
    array (
      0 => 127908,
    ),
    'char_name' => 
    array (
      'title' => 'MICROPHONE',
      'desc' => '= karaoke',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 57,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58998,
      ),
      'sjis' => 
      array (
        0 => 63703,
      ),
      'jis' => 
      array (
        0 => 30302,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 289,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58627,
      ),
      'sjis' => 
      array (
        0 => 63196,
      ),
      'jis' => 
      array (
        0 => 30302,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 251,
      ),
      'number_old' => 
      array (
        0 => 60,
      ),
      'unicode' => 
      array (
        0 => 57404,
      ),
      'sjis' => 
      array (
        0 => 63868,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042432,
      ),
    ),
  ),
  440 => 
  array (
    'mapid' => '#e-801',
    'unicode' => 
    array (
      0 => 127909,
    ),
    'char_name' => 
    array (
      'title' => 'MOVIE CAMERA',
      'desc' => '= film, movies
Temporary Notes: movie projector, video camera',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 58,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58999,
      ),
      'sjis' => 
      array (
        0 => 63704,
      ),
      'jis' => 
      array (
        0 => 30322,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 110,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58647,
      ),
      'sjis' => 
      array (
        0 => 63216,
      ),
      'jis' => 
      array (
        0 => 30322,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 260,
      ),
      'number_old' => 
      array (
        0 => 61,
      ),
      'unicode' => 
      array (
        0 => 57405,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042433,
      ),
    ),
  ),
  441 => 
  array (
    'mapid' => '#e-802',
    'unicode' => 
    array (
      0 => 127910,
    ),
    'char_name' => 
    array (
      'title' => 'CINEMA',
      'desc' => '= movie theater, movie projector',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 58,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58999,
      ),
      'sjis' => 
      array (
        0 => 63704,
      ),
      'jis' => 
      array (
        0 => 30322,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 110,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58647,
      ),
      'sjis' => 
      array (
        0 => 63216,
      ),
      'jis' => 
      array (
        0 => 30322,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 356,
      ),
      'number_old' => 
      array (
        0 => 430,
      ),
      'unicode' => 
      array (
        0 => 58631,
      ),
      'sjis' => 
      array (
        0 => 64423,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042434,
      ),
    ),
  ),
  442 => 
  array (
    'mapid' => '#e-803',
    'unicode' => 
    array (
      0 => 127911,
    ),
    'char_name' => 
    array (
      'title' => 'HEADPHONE',
      'desc' => '= music',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 61,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59002,
      ),
      'sjis' => 
      array (
        0 => 63707,
      ),
      'jis' => 
      array (
        0 => 30307,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 294,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58632,
      ),
      'sjis' => 
      array (
        0 => 63201,
      ),
      'jis' => 
      array (
        0 => 30307,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 252,
      ),
      'number_old' => 
      array (
        0 => 280,
      ),
      'unicode' => 
      array (
        0 => 58122,
      ),
      'sjis' => 
      array (
        0 => 63914,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042435,
      ),
    ),
  ),
  443 => 
  array (
    'mapid' => '#e-804',
    'unicode' => 
    array (
      0 => 127912,
    ),
    'char_name' => 
    array (
      'title' => 'ARTIST PALETTE',
      'desc' => 'Old name: ART
= art',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 62,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59003,
      ),
      'sjis' => 
      array (
        0 => 63708,
      ),
      'jis' => 
      array (
        0 => 30779,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 309,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58780,
      ),
      'sjis' => 
      array (
        0 => 63417,
      ),
      'jis' => 
      array (
        0 => 30779,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 263,
      ),
      'number_old' => 
      array (
        0 => 425,
      ),
      'unicode' => 
      array (
        0 => 58626,
      ),
      'sjis' => 
      array (
        0 => 64418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042436,
      ),
    ),
  ),
  444 => 
  array (
    'mapid' => '#e-805',
    'unicode' => 
    array (
      0 => 127913,
    ),
    'char_name' => 
    array (
      'title' => 'TOP HAT',
      'desc' => '= drama, performing arts, theater',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 63,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59004,
      ),
      'sjis' => 
      array (
        0 => 63709,
      ),
      'jis' => 
      array (
        0 => 31307,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 494,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60149,
      ),
      'sjis' => 
      array (
        0 => 62409,
      ),
      'jis' => 
      array (
        0 => 31307,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 224,
      ),
      'number_old' => 
      array (
        0 => 426,
      ),
      'unicode' => 
      array (
        0 => 58627,
      ),
      'sjis' => 
      array (
        0 => 64419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042437,
      ),
    ),
  ),
  445 => 
  array (
    'mapid' => '#e-806',
    'unicode' => 
    array (
      0 => 127914,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCUS TENT',
      'desc' => 'Old name: EVENT
= event',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 64,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59005,
      ),
      'sjis' => 
      array (
        0 => 63710,
      ),
      'jis' => 
      array (
        0 => 30781,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 311,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58782,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
        0 => 30781,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[イベント]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042438,
      ),
    ),
  ),
  446 => 
  array (
    'mapid' => '#e-807',
    'unicode' => 
    array (
      0 => 127915,
    ),
    'char_name' => 
    array (
      'title' => 'TICKET',
      'desc' => '* indicates an event',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 65,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59006,
      ),
      'sjis' => 
      array (
        0 => 63711,
      ),
      'jis' => 
      array (
        0 => 30039,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 106,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58526,
      ),
      'sjis' => 
      array (
        0 => 63094,
      ),
      'jis' => 
      array (
        0 => 30039,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 262,
      ),
      'number_old' => 
      array (
        0 => 127,
      ),
      'unicode' => 
      array (
        0 => 57637,
      ),
      'sjis' => 
      array (
        0 => 63333,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042439,
      ),
    ),
  ),
  447 => 
  array (
    'mapid' => '#e-808',
    'unicode' => 
    array (
      0 => 127916,
    ),
    'char_name' => 
    array (
      'title' => 'CLAPPER BOARD',
      'desc' => 'Old name: MOVIE SHOOTING CLAPBOARD',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 167,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59052,
      ),
      'sjis' => 
      array (
        0 => 63824,
      ),
      'jis' => 
      array (
        0 => 30071,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 226,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58558,
      ),
      'sjis' => 
      array (
        0 => 63127,
      ),
      'jis' => 
      array (
        0 => 30071,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 261,
      ),
      'number_old' => 
      array (
        0 => 306,
      ),
      'unicode' => 
      array (
        0 => 58148,
      ),
      'sjis' => 
      array (
        0 => 63940,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042440,
      ),
    ),
  ),
  448 => 
  array (
    'mapid' => '#e-809',
    'unicode' => 
    array (
      0 => 127917,
    ),
    'char_name' => 
    array (
      'title' => 'PERFORMING ARTS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[演劇]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 310,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58781,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
        0 => 30780,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 224,
      ),
      'number_old' => 
      array (
        0 => 426,
      ),
      'unicode' => 
      array (
        0 => 58627,
      ),
      'sjis' => 
      array (
        0 => 64419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042441,
      ),
    ),
  ),
  449 => 
  array (
    'mapid' => '#e-80A',
    'unicode' => 
    array (
      0 => 127918,
    ),
    'char_name' => 
    array (
      'title' => 'VIDEO GAME',
      'desc' => '= video game controller',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 78,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59019,
      ),
      'sjis' => 
      array (
        0 => 63724,
      ),
      'jis' => 
      array (
        0 => 30241,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 232,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58566,
      ),
      'sjis' => 
      array (
        0 => 63135,
      ),
      'jis' => 
      array (
        0 => 30241,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ゲーム]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042442,
      ),
    ),
  ),
  450 => 
  array (
    'mapid' => '#e-80B',
    'unicode' => 
    array (
      0 => 126980,
    ),
    'char_name' => 
    array (
      'title' => 'MAHJONG TILE RED DRAGON',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[麻雀]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 362,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58833,
      ),
      'sjis' => 
      array (
        0 => 62276,
      ),
      'jis' => 
      array (
        0 => 31013,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 164,
      ),
      'number_old' => 
      array (
        0 => 135,
      ),
      'unicode' => 
      array (
        0 => 57645,
      ),
      'sjis' => 
      array (
        0 => 63341,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042443,
      ),
    ),
  ),
  451 => 
  array (
    'mapid' => '#e-80C',
    'unicode' => 
    array (
      0 => 127919,
    ),
    'char_name' => 
    array (
      'title' => 'DIRECT HIT',
      'desc' => '= archery target, hitting the target
x (bullseye - 25CE)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[的中]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 231,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58565,
      ),
      'sjis' => 
      array (
        0 => 63134,
      ),
      'jis' => 
      array (
        0 => 30078,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 141,
      ),
      'number_old' => 
      array (
        0 => 138,
      ),
      'unicode' => 
      array (
        0 => 57648,
      ),
      'sjis' => 
      array (
        0 => 63344,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042444,
      ),
    ),
  ),
  452 => 
  array (
    'mapid' => '#e-80D',
    'unicode' => 
    array (
      0 => 127920,
    ),
    'char_name' => 
    array (
      'title' => 'SLOT MACHINE',
      'desc' => 'Temporary Notes: 777',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[777]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 229,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58478,
      ),
      'sjis' => 
      array (
        0 => 63046,
      ),
      'jis' => 
      array (
        0 => 29991,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 434,
      ),
      'number_old' => 
      array (
        0 => 141,
      ),
      'unicode' => 
      array (
        0 => 57651,
      ),
      'sjis' => 
      array (
        0 => 63347,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042445,
      ),
    ),
  ),
  453 => 
  array (
    'mapid' => '#e-80E',
    'unicode' => 
    array (
      0 => 127921,
    ),
    'char_name' => 
    array (
      'title' => 'BILLIARDS',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ビリヤード]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 470,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60125,
      ),
      'sjis' => 
      array (
        0 => 62385,
      ),
      'jis' => 
      array (
        0 => 31283,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 159,
      ),
      'number_old' => 
      array (
        0 => 391,
      ),
      'unicode' => 
      array (
        0 => 58412,
      ),
      'sjis' => 
      array (
        0 => 64364,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042446,
      ),
    ),
  ),
  454 => 
  array (
    'mapid' => '#e-80F',
    'unicode' => 
    array (
      0 => 127922,
    ),
    'char_name' => 
    array (
      'title' => 'GAME DIE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サイコロ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 170,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58568,
      ),
      'sjis' => 
      array (
        0 => 63137,
      ),
      'jis' => 
      array (
        0 => 30243,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[サイコロ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042447,
      ),
    ),
  ),
  455 => 
  array (
    'mapid' => '#e-810',
    'unicode' => 
    array (
      0 => 127923,
    ),
    'char_name' => 
    array (
      'title' => 'BOWLING',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ボーリング]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 753,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60227,
      ),
      'sjis' => 
      array (
        0 => 62535,
      ),
      'jis' => 
      array (
        0 => 31528,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ボーリング]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042448,
      ),
    ),
  ),
  456 => 
  array (
    'mapid' => '#e-811',
    'unicode' => 
    array (
      0 => 127924,
    ),
    'char_name' => 
    array (
      'title' => 'FLOWER PLAYING CARDS',
      'desc' => '= flower cards
Temporary Notes: (花札)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花札]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 796,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60270,
      ),
      'sjis' => 
      array (
        0 => 62578,
      ),
      'jis' => 
      array (
        0 => 31571,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[花札]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042449,
      ),
    ),
  ),
  457 => 
  array (
    'mapid' => '#e-812',
    'unicode' => 
    array (
      0 => 127183,
    ),
    'char_name' => 
    array (
      'title' => 'PLAYING CARD BLACK JOKER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ジョーカー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 797,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60271,
      ),
      'sjis' => 
      array (
        0 => 62579,
      ),
      'jis' => 
      array (
        0 => 31572,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ジョーカー]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042450,
      ),
    ),
  ),
  458 => 
  array (
    'mapid' => '#e-813',
    'unicode' => 
    array (
      0 => 127925,
    ),
    'char_name' => 
    array (
      'title' => 'MUSICAL NOTE',
      'desc' => '= music, being in good mood
x (eighth note - 266A)
Temporary Notes: Disunified from U+266A due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 146,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59126,
      ),
      'sjis' => 
      array (
        0 => 63899,
      ),
      'jis' => 
      array (
        0 => 30832,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 343,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58814,
      ),
      'sjis' => 
      array (
        0 => 63470,
      ),
      'jis' => 
      array (
        0 => 30832,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 46,
      ),
      'number_old' => 
      array (
        0 => 62,
      ),
      'unicode' => 
      array (
        0 => 57406,
      ),
      'sjis' => 
      array (
        0 => 63870,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042451,
      ),
    ),
  ),
  459 => 
  array (
    'mapid' => '#e-814',
    'unicode' => 
    array (
      0 => 127926,
    ),
    'char_name' => 
    array (
      'title' => 'MULTIPLE MUSICAL NOTES',
      'desc' => '= dancing notes, mood, melody
x (beamed eighth notes - 266B)
Temporary Notes: disunified from ♫ U+266B',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 155,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59135,
      ),
      'sjis' => 
      array (
        0 => 63908,
      ),
      'jis' => 
      array (
        0 => 30304,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 291,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58629,
      ),
      'sjis' => 
      array (
        0 => 63198,
      ),
      'jis' => 
      array (
        0 => 30304,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 47,
      ),
      'number_old' => 
      array (
        0 => 308,
      ),
      'unicode' => 
      array (
        0 => 58150,
      ),
      'sjis' => 
      array (
        0 => 63942,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042452,
      ),
    ),
  ),
  460 => 
  array (
    'mapid' => '#e-815',
    'unicode' => 
    array (
      0 => 127927,
    ),
    'char_name' => 
    array (
      'title' => 'SAXOPHONE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サックス]',
    ),
    'au' => 
    array (
      'kaomoji' => '[サックス]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 259,
      ),
      'number_old' => 
      array (
        0 => 64,
      ),
      'unicode' => 
      array (
        0 => 57408,
      ),
      'sjis' => 
      array (
        0 => 63873,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042453,
      ),
    ),
  ),
  461 => 
  array (
    'mapid' => '#e-816',
    'unicode' => 
    array (
      0 => 127928,
    ),
    'char_name' => 
    array (
      'title' => 'GUITAR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ギター]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 292,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58630,
      ),
      'sjis' => 
      array (
        0 => 63199,
      ),
      'jis' => 
      array (
        0 => 30305,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 257,
      ),
      'number_old' => 
      array (
        0 => 65,
      ),
      'unicode' => 
      array (
        0 => 57409,
      ),
      'sjis' => 
      array (
        0 => 63874,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042454,
      ),
    ),
  ),
  462 => 
  array (
    'mapid' => '#e-817',
    'unicode' => 
    array (
      0 => 127929,
    ),
    'char_name' => 
    array (
      'title' => 'MUSICAL KEYBOARD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ピアノ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 750,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60224,
      ),
      'sjis' => 
      array (
        0 => 62532,
      ),
      'jis' => 
      array (
        0 => 31525,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ピアノ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042455,
      ),
    ),
  ),
  463 => 
  array (
    'mapid' => '#e-818',
    'unicode' => 
    array (
      0 => 127930,
    ),
    'char_name' => 
    array (
      'title' => 'TRUMPET',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[トランペット]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 469,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60124,
      ),
      'sjis' => 
      array (
        0 => 62384,
      ),
      'jis' => 
      array (
        0 => 31282,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 258,
      ),
      'number_old' => 
      array (
        0 => 66,
      ),
      'unicode' => 
      array (
        0 => 57410,
      ),
      'sjis' => 
      array (
        0 => 63875,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042456,
      ),
    ),
  ),
  464 => 
  array (
    'mapid' => '#e-819',
    'unicode' => 
    array (
      0 => 127931,
    ),
    'char_name' => 
    array (
      'title' => 'VIOLIN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[バイオリン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 293,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58631,
      ),
      'sjis' => 
      array (
        0 => 63200,
      ),
      'jis' => 
      array (
        0 => 30306,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[バイオリン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042457,
      ),
    ),
  ),
  465 => 
  array (
    'mapid' => '#e-81A',
    'unicode' => 
    array (
      0 => 127932,
    ),
    'char_name' => 
    array (
      'title' => 'MUSICAL SCORE',
      'desc' => 'x (musical symbol g clef - 1D11E)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 155,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59135,
      ),
      'sjis' => 
      array (
        0 => 63908,
      ),
      'jis' => 
      array (
        0 => 30304,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 453,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60108,
      ),
      'sjis' => 
      array (
        0 => 62368,
      ),
      'jis' => 
      array (
        0 => 31266,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 47,
      ),
      'number_old' => 
      array (
        0 => 308,
      ),
      'unicode' => 
      array (
        0 => 58150,
      ),
      'sjis' => 
      array (
        0 => 63942,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042458,
      ),
    ),
  ),
  466 => 
  array (
    'mapid' => '#e-81B',
    'unicode' => 
    array (
      0 => 12349,
    ),
    'char_name' => 
    array (
      'title' => 'PART ALTERNATION MARK',
      'desc' => 'Temporary Notes: Unified with U+303D. Part of JIS X 0213 set. indicator for the 1st vocal part of a song',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[歌記号]',
    ),
    'au' => 
    array (
      'kaomoji' => '[歌記号]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 458,
      ),
      'number_old' => 
      array (
        0 => 134,
      ),
      'unicode' => 
      array (
        0 => 57644,
      ),
      'sjis' => 
      array (
        0 => 63340,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042459,
      ),
    ),
  ),
  467 => 
  array (
    'mapid' => '#e-4EF',
    'unicode' => 
    array (
      0 => 128247,
    ),
    'char_name' => 
    array (
      'title' => 'CAMERA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 68,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59009,
      ),
      'sjis' => 
      array (
        0 => 63714,
      ),
      'jis' => 
      array (
        0 => 30320,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 94,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58645,
      ),
      'sjis' => 
      array (
        0 => 63214,
      ),
      'jis' => 
      array (
        0 => 30320,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 247,
      ),
      'number_old' => 
      array (
        0 => 8,
      ),
      'unicode' => 
      array (
        0 => 57352,
      ),
      'sjis' => 
      array (
        0 => 63816,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041647,
      ),
    ),
  ),
  468 => 
  array (
    'mapid' => '#e-4F9',
    'unicode' => 
    array (
      0 => 128249,
    ),
    'char_name' => 
    array (
      'title' => 'VIDEO CAMERA',
      'desc' => 'Temporary Notes: handycam, videocam',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 58,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58999,
      ),
      'sjis' => 
      array (
        0 => 63704,
      ),
      'jis' => 
      array (
        0 => 30322,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 111,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58750,
      ),
      'sjis' => 
      array (
        0 => 63387,
      ),
      'jis' => 
      array (
        0 => 30587,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 260,
      ),
      'number_old' => 
      array (
        0 => 61,
      ),
      'unicode' => 
      array (
        0 => 57405,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041657,
      ),
    ),
  ),
  469 => 
  array (
    'mapid' => '#e-81C',
    'unicode' => 
    array (
      0 => 128250,
    ),
    'char_name' => 
    array (
      'title' => 'TELEVISION',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 77,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59018,
      ),
      'sjis' => 
      array (
        0 => 63723,
      ),
      'jis' => 
      array (
        0 => 30301,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 288,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58626,
      ),
      'sjis' => 
      array (
        0 => 63195,
      ),
      'jis' => 
      array (
        0 => 30301,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 240,
      ),
      'number_old' => 
      array (
        0 => 132,
      ),
      'unicode' => 
      array (
        0 => 57642,
      ),
      'sjis' => 
      array (
        0 => 63338,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042460,
      ),
    ),
  ),
  470 => 
  array (
    'mapid' => '#e-81F',
    'unicode' => 
    array (
      0 => 128251,
    ),
    'char_name' => 
    array (
      'title' => 'RADIO',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ラジオ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 338,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58809,
      ),
      'sjis' => 
      array (
        0 => 63465,
      ),
      'jis' => 
      array (
        0 => 30827,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 248,
      ),
      'number_old' => 
      array (
        0 => 130,
      ),
      'unicode' => 
      array (
        0 => 57640,
      ),
      'sjis' => 
      array (
        0 => 63336,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042463,
      ),
    ),
  ),
  471 => 
  array (
    'mapid' => '#e-820',
    'unicode' => 
    array (
      0 => 128252,
    ),
    'char_name' => 
    array (
      'title' => 'VIDEOCASSETTE',
      'desc' => 'Old name: VIDEO CASSETTE TAPE',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ビデオ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 115,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58752,
      ),
      'sjis' => 
      array (
        0 => 63389,
      ),
      'jis' => 
      array (
        0 => 30589,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 255,
      ),
      'number_old' => 
      array (
        0 => 131,
      ),
      'unicode' => 
      array (
        0 => 57641,
      ),
      'sjis' => 
      array (
        0 => 63337,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042464,
      ),
    ),
  ),
  472 => 
  array (
    'mapid' => '#e-823',
    'unicode' => 
    array (
      0 => 128139,
    ),
    'char_name' => 
    array (
      'title' => 'KISS MARK',
      'desc' => '= lips',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 149,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59129,
      ),
      'sjis' => 
      array (
        0 => 63902,
      ),
      'jis' => 
      array (
        0 => 30278,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 273,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58603,
      ),
      'sjis' => 
      array (
        0 => 63172,
      ),
      'jis' => 
      array (
        0 => 30278,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 63,
      ),
      'number_old' => 
      array (
        0 => 3,
      ),
      'unicode' => 
      array (
        0 => 57347,
      ),
      'sjis' => 
      array (
        0 => 63811,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042467,
      ),
    ),
  ),
  473 => 
  array (
    'mapid' => '#e-824',
    'unicode' => 
    array (
      0 => 128140,
    ),
    'char_name' => 
    array (
      'title' => 'LOVE LETTER',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59159,
      ),
      'sjis' => 
      array (
        0 => 63932,
      ),
      'jis' => 
      array (
        0 => 31581,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 806,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60280,
      ),
      'sjis' => 
      array (
        0 => 62588,
      ),
      'jis' => 
      array (
        0 => 31581,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 242,
        1 => 36,
      ),
      'number_old' => 
      array (
        0 => 93,
        1 => 310,
      ),
      'unicode' => 
      array (
        0 => 57603,
        1 => 58152,
      ),
      'sjis' => 
      array (
        0 => 63299,
        1 => 63944,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042468,
      ),
    ),
  ),
  474 => 
  array (
    'mapid' => '#e-825',
    'unicode' => 
    array (
      0 => 128141,
    ),
    'char_name' => 
    array (
      'title' => 'RING',
      'desc' => '= jewelry',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59163,
      ),
      'sjis' => 
      array (
        0 => 63936,
      ),
      'jis' => 
      array (
        0 => 30319,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 72,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58644,
      ),
      'sjis' => 
      array (
        0 => 63213,
      ),
      'jis' => 
      array (
        0 => 30319,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 229,
      ),
      'number_old' => 
      array (
        0 => 52,
      ),
      'unicode' => 
      array (
        0 => 57396,
      ),
      'sjis' => 
      array (
        0 => 63860,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042469,
      ),
    ),
  ),
  475 => 
  array (
    'mapid' => '#e-826',
    'unicode' => 
    array (
      0 => 128142,
    ),
    'char_name' => 
    array (
      'title' => 'GEM STONE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59163,
      ),
      'sjis' => 
      array (
        0 => 63936,
      ),
      'jis' => 
      array (
        0 => 30319,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 72,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58644,
      ),
      'sjis' => 
      array (
        0 => 63213,
      ),
      'jis' => 
      array (
        0 => 30319,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 230,
      ),
      'number_old' => 
      array (
        0 => 53,
      ),
      'unicode' => 
      array (
        0 => 57397,
      ),
      'sjis' => 
      array (
        0 => 63861,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042470,
      ),
    ),
  ),
  476 => 
  array (
    'mapid' => '#e-827',
    'unicode' => 
    array (
      0 => 128143,
    ),
    'char_name' => 
    array (
      'title' => 'KISS',
      'desc' => '= two people kissing',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 149,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59129,
      ),
      'sjis' => 
      array (
        0 => 63902,
      ),
      'jis' => 
      array (
        0 => 30278,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 355,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58826,
      ),
      'sjis' => 
      array (
        0 => 63482,
      ),
      'jis' => 
      array (
        0 => 30844,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 277,
      ),
      'number_old' => 
      array (
        0 => 107,
      ),
      'unicode' => 
      array (
        0 => 57617,
      ),
      'sjis' => 
      array (
        0 => 63313,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042471,
      ),
    ),
  ),
  477 => 
  array (
    'mapid' => '#e-828',
    'unicode' => 
    array (
      0 => 128144,
    ),
    'char_name' => 
    array (
      'title' => 'BOUQUET',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花束]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 398,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60053,
      ),
      'sjis' => 
      array (
        0 => 62312,
      ),
      'jis' => 
      array (
        0 => 31049,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 98,
      ),
      'number_old' => 
      array (
        0 => 276,
      ),
      'unicode' => 
      array (
        0 => 58118,
      ),
      'sjis' => 
      array (
        0 => 63910,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042472,
      ),
    ),
  ),
  478 => 
  array (
    'mapid' => '#e-829',
    'unicode' => 
    array (
      0 => 128145,
    ),
    'char_name' => 
    array (
      'title' => 'COUPLE WITH HEART',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59117,
      ),
      'sjis' => 
      array (
        0 => 63890,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 467,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60122,
      ),
      'sjis' => 
      array (
        0 => 62382,
      ),
      'jis' => 
      array (
        0 => 31280,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 278,
      ),
      'number_old' => 
      array (
        0 => 384,
      ),
      'unicode' => 
      array (
        0 => 58405,
      ),
      'sjis' => 
      array (
        0 => 64357,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042473,
      ),
    ),
  ),
  479 => 
  array (
    'mapid' => '#e-82A',
    'unicode' => 
    array (
      0 => 128146,
    ),
    'char_name' => 
    array (
      'title' => 'WEDDING',
      'desc' => '= wedding chapel',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[結婚式]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 340,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58811,
      ),
      'sjis' => 
      array (
        0 => 63467,
      ),
      'jis' => 
      array (
        0 => 30829,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 334,
      ),
      'number_old' => 
      array (
        0 => 408,
      ),
      'unicode' => 
      array (
        0 => 58429,
      ),
      'sjis' => 
      array (
        0 => 64381,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042474,
      ),
    ),
  ),
  480 => 
  array (
    'mapid' => '#e-B25',
    'unicode' => 
    array (
      0 => 128286,
    ),
    'char_name' => 
    array (
      'title' => 'NO ONE UNDER EIGHTEEN SYMBOL',
      'desc' => 'Temporary Notes: under 18 not permitted',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[18禁]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 380,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60035,
      ),
      'sjis' => 
      array (
        0 => 62294,
      ),
      'jis' => 
      array (
        0 => 31031,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 456,
      ),
      'number_old' => 
      array (
        0 => 187,
      ),
      'unicode' => 
      array (
        0 => 57863,
      ),
      'sjis' => 
      array (
        0 => 63399,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043237,
      ),
    ),
  ),
  481 => 
  array (
    'mapid' => '#e-B29',
    'unicode' => 
    array (
      0 => 169,
    ),
    'char_name' => 
    array (
      'title' => 'COPYRIGHT SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59185,
      ),
      'sjis' => 
      array (
        0 => 63958,
      ),
      'jis' => 
      array (
        0 => 30549,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 81,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58712,
      ),
      'sjis' => 
      array (
        0 => 63348,
      ),
      'jis' => 
      array (
        0 => 30549,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 469,
      ),
      'number_old' => 
      array (
        0 => 258,
      ),
      'unicode' => 
      array (
        0 => 57934,
      ),
      'sjis' => 
      array (
        0 => 63470,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043241,
      ),
    ),
  ),
  482 => 
  array (
    'mapid' => '#e-B2D',
    'unicode' => 
    array (
      0 => 174,
    ),
    'char_name' => 
    array (
      'title' => 'REGISTERED SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59190,
      ),
      'sjis' => 
      array (
        0 => 63963,
      ),
      'jis' => 
      array (
        0 => 30550,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 82,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58713,
      ),
      'sjis' => 
      array (
        0 => 63349,
      ),
      'jis' => 
      array (
        0 => 30550,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 470,
      ),
      'number_old' => 
      array (
        0 => 259,
      ),
      'unicode' => 
      array (
        0 => 57935,
      ),
      'sjis' => 
      array (
        0 => 63471,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043245,
      ),
    ),
  ),
  483 => 
  array (
    'mapid' => '#e-B2A',
    'unicode' => 
    array (
      0 => 8482,
    ),
    'char_name' => 
    array (
      'title' => 'TRADE MARK SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59186,
      ),
      'sjis' => 
      array (
        0 => 63959,
      ),
      'jis' => 
      array (
        0 => 30539,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 54,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58702,
      ),
      'sjis' => 
      array (
        0 => 63338,
      ),
      'jis' => 
      array (
        0 => 30539,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 471,
      ),
      'number_old' => 
      array (
        0 => 478,
      ),
      'unicode' => 
      array (
        0 => 58679,
      ),
      'sjis' => 
      array (
        0 => 64471,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043242,
      ),
    ),
  ),
  484 => 
  array (
    'mapid' => '#e-B47',
    'unicode' => 
    array (
      0 => 8505,
    ),
    'char_name' => 
    array (
      'title' => 'INFORMATION SOURCE',
      'desc' => 'Temporary Notes: "i" = information',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ｉ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 11,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58675,
      ),
      'sjis' => 
      array (
        0 => 63311,
      ),
      'jis' => 
      array (
        0 => 30512,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ｉ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043271,
      ),
    ),
  ),
  485 => 
  array (
    'mapid' => '#e-82C',
    'unicode' => 
    array (
      0 => 35,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'HASH KEY',
      'desc' => 'Temporary Notes: pound key, number sign. Unify with ASCII # (U+0023) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 123,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59104,
      ),
      'sjis' => 
      array (
        0 => 63877,
      ),
      'jis' => 
      array (
        0 => 31593,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 818,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60292,
      ),
      'sjis' => 
      array (
        0 => 62601,
      ),
      'jis' => 
      array (
        0 => 31593,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 403,
      ),
      'number_old' => 
      array (
        0 => 196,
      ),
      'unicode' => 
      array (
        0 => 57872,
      ),
      'sjis' => 
      array (
        0 => 63408,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042476,
      ),
    ),
  ),
  486 => 
  array (
    'mapid' => '#e-82E',
    'unicode' => 
    array (
      0 => 49,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 1',
      'desc' => 'Temporary Notes: Unify with ASCII 1 (U+0031) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 125,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59106,
      ),
      'sjis' => 
      array (
        0 => 63879,
      ),
      'jis' => 
      array (
        0 => 30333,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 180,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58658,
      ),
      'sjis' => 
      array (
        0 => 63227,
      ),
      'jis' => 
      array (
        0 => 30333,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 393,
      ),
      'number_old' => 
      array (
        0 => 208,
      ),
      'unicode' => 
      array (
        0 => 57884,
      ),
      'sjis' => 
      array (
        0 => 63420,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042478,
      ),
    ),
  ),
  487 => 
  array (
    'mapid' => '#e-82F',
    'unicode' => 
    array (
      0 => 50,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 2',
      'desc' => 'Temporary Notes: Unify with ASCII 2 (U+0032) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 126,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59107,
      ),
      'sjis' => 
      array (
        0 => 63880,
      ),
      'jis' => 
      array (
        0 => 30334,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 181,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58659,
      ),
      'sjis' => 
      array (
        0 => 63228,
      ),
      'jis' => 
      array (
        0 => 30334,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 394,
      ),
      'number_old' => 
      array (
        0 => 209,
      ),
      'unicode' => 
      array (
        0 => 57885,
      ),
      'sjis' => 
      array (
        0 => 63421,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042479,
      ),
    ),
  ),
  488 => 
  array (
    'mapid' => '#e-830',
    'unicode' => 
    array (
      0 => 51,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 3',
      'desc' => 'Temporary Notes: Unify with ASCII 3 (U+0033) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 127,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59108,
      ),
      'sjis' => 
      array (
        0 => 63881,
      ),
      'jis' => 
      array (
        0 => 30497,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 182,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58660,
      ),
      'sjis' => 
      array (
        0 => 63296,
      ),
      'jis' => 
      array (
        0 => 30497,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 395,
      ),
      'number_old' => 
      array (
        0 => 210,
      ),
      'unicode' => 
      array (
        0 => 57886,
      ),
      'sjis' => 
      array (
        0 => 63422,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042480,
      ),
    ),
  ),
  489 => 
  array (
    'mapid' => '#e-831',
    'unicode' => 
    array (
      0 => 52,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 4',
      'desc' => 'Temporary Notes: Unify with ASCII 4 (U+0034) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 128,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59109,
      ),
      'sjis' => 
      array (
        0 => 63882,
      ),
      'jis' => 
      array (
        0 => 30498,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 183,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58661,
      ),
      'sjis' => 
      array (
        0 => 63297,
      ),
      'jis' => 
      array (
        0 => 30498,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 396,
      ),
      'number_old' => 
      array (
        0 => 211,
      ),
      'unicode' => 
      array (
        0 => 57887,
      ),
      'sjis' => 
      array (
        0 => 63423,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042481,
      ),
    ),
  ),
  490 => 
  array (
    'mapid' => '#e-832',
    'unicode' => 
    array (
      0 => 53,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 5',
      'desc' => 'Temporary Notes: Unify with ASCII 5 (U+0035) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 129,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59110,
      ),
      'sjis' => 
      array (
        0 => 63883,
      ),
      'jis' => 
      array (
        0 => 30499,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 184,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58662,
      ),
      'sjis' => 
      array (
        0 => 63298,
      ),
      'jis' => 
      array (
        0 => 30499,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 397,
      ),
      'number_old' => 
      array (
        0 => 212,
      ),
      'unicode' => 
      array (
        0 => 57888,
      ),
      'sjis' => 
      array (
        0 => 63424,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042482,
      ),
    ),
  ),
  491 => 
  array (
    'mapid' => '#e-833',
    'unicode' => 
    array (
      0 => 54,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 6',
      'desc' => 'Temporary Notes: Unify with ASCII 6 (U+0036) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 130,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59111,
      ),
      'sjis' => 
      array (
        0 => 63884,
      ),
      'jis' => 
      array (
        0 => 30500,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 185,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58663,
      ),
      'sjis' => 
      array (
        0 => 63299,
      ),
      'jis' => 
      array (
        0 => 30500,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 398,
      ),
      'number_old' => 
      array (
        0 => 213,
      ),
      'unicode' => 
      array (
        0 => 57889,
      ),
      'sjis' => 
      array (
        0 => 63425,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042483,
      ),
    ),
  ),
  492 => 
  array (
    'mapid' => '#e-834',
    'unicode' => 
    array (
      0 => 55,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 7',
      'desc' => 'Temporary Notes: Unify with ASCII 7 (U+0037) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 131,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59112,
      ),
      'sjis' => 
      array (
        0 => 63885,
      ),
      'jis' => 
      array (
        0 => 30501,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 186,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58664,
      ),
      'sjis' => 
      array (
        0 => 63300,
      ),
      'jis' => 
      array (
        0 => 30501,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 399,
      ),
      'number_old' => 
      array (
        0 => 214,
      ),
      'unicode' => 
      array (
        0 => 57890,
      ),
      'sjis' => 
      array (
        0 => 63426,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042484,
      ),
    ),
  ),
  493 => 
  array (
    'mapid' => '#e-835',
    'unicode' => 
    array (
      0 => 56,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 8',
      'desc' => 'Temporary Notes: Unify with ASCII 8 (U+0038) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 132,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59113,
      ),
      'sjis' => 
      array (
        0 => 63886,
      ),
      'jis' => 
      array (
        0 => 30502,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 187,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58665,
      ),
      'sjis' => 
      array (
        0 => 63301,
      ),
      'jis' => 
      array (
        0 => 30502,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 400,
      ),
      'number_old' => 
      array (
        0 => 215,
      ),
      'unicode' => 
      array (
        0 => 57891,
      ),
      'sjis' => 
      array (
        0 => 63427,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042485,
      ),
    ),
  ),
  494 => 
  array (
    'mapid' => '#e-836',
    'unicode' => 
    array (
      0 => 57,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 9',
      'desc' => 'Temporary Notes: Unify with ASCII 9 (U+0039) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 133,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59114,
      ),
      'sjis' => 
      array (
        0 => 63887,
      ),
      'jis' => 
      array (
        0 => 30503,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 188,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58666,
      ),
      'sjis' => 
      array (
        0 => 63302,
      ),
      'jis' => 
      array (
        0 => 30503,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 401,
      ),
      'number_old' => 
      array (
        0 => 216,
      ),
      'unicode' => 
      array (
        0 => 57892,
      ),
      'sjis' => 
      array (
        0 => 63428,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042486,
      ),
    ),
  ),
  495 => 
  array (
    'mapid' => '#e-837',
    'unicode' => 
    array (
      0 => 48,
      1 => 8419,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP 0',
      'desc' => 'Temporary Notes: Unify with ASCII 0 (U+0030) + (U+20E3)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 134,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59115,
      ),
      'sjis' => 
      array (
        0 => 63888,
      ),
      'jis' => 
      array (
        0 => 30795,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 325,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58796,
      ),
      'sjis' => 
      array (
        0 => 63433,
      ),
      'jis' => 
      array (
        0 => 30795,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 402,
      ),
      'number_old' => 
      array (
        0 => 217,
      ),
      'unicode' => 
      array (
        0 => 57893,
      ),
      'sjis' => 
      array (
        0 => 63429,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042487,
      ),
    ),
  ),
  496 => 
  array (
    'mapid' => '#e-83B',
    'unicode' => 
    array (
      0 => 128287,
    ),
    'char_name' => 
    array (
      'title' => 'KEYCAP TEN',
      'desc' => 'x (combining enclosing keycap - 20E3)
Design Note: Should look like digits 10 enclosed by a keycap like  ⃣ U+20E3 COMBINING ENCLOSING KEYCAP.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[10]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 189,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58667,
      ),
      'sjis' => 
      array (
        0 => 63303,
      ),
      'jis' => 
      array (
        0 => 30504,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[10]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042491,
      ),
    ),
  ),
  497 => 
  array (
    'mapid' => '#e-838',
    'unicode' => 
    array (
      0 => 128246,
    ),
    'char_name' => 
    array (
      'title' => 'ANTENNA WITH BARS',
      'desc' => '= cellular reception
Temporary Notes: (good reception)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[バリ3]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 381,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60036,
      ),
      'sjis' => 
      array (
        0 => 62295,
      ),
      'jis' => 
      array (
        0 => 31032,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 465,
      ),
      'number_old' => 
      array (
        0 => 191,
      ),
      'unicode' => 
      array (
        0 => 57867,
      ),
      'sjis' => 
      array (
        0 => 63403,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042488,
      ),
    ),
  ),
  498 => 
  array (
    'mapid' => '#e-839',
    'unicode' => 
    array (
      0 => 128243,
    ),
    'char_name' => 
    array (
      'title' => 'VIBRATION MODE',
      'desc' => 'Temporary Notes: manner mode (in Japan)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[マナーモード]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 393,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60048,
      ),
      'sjis' => 
      array (
        0 => 62307,
      ),
      'jis' => 
      array (
        0 => 31044,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 466,
      ),
      'number_old' => 
      array (
        0 => 260,
      ),
      'unicode' => 
      array (
        0 => 57936,
      ),
      'sjis' => 
      array (
        0 => 63472,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042489,
      ),
    ),
  ),
  499 => 
  array (
    'mapid' => '#e-83A',
    'unicode' => 
    array (
      0 => 128244,
    ),
    'char_name' => 
    array (
      'title' => 'MOBILE PHONE OFF',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ケータイOFF]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 394,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60049,
      ),
      'sjis' => 
      array (
        0 => 62308,
      ),
      'jis' => 
      array (
        0 => 31045,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 467,
      ),
      'number_old' => 
      array (
        0 => 261,
      ),
      'unicode' => 
      array (
        0 => 57937,
      ),
      'sjis' => 
      array (
        0 => 63473,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042490,
      ),
    ),
  ),
  500 => 
  array (
    'mapid' => '#e-960',
    'unicode' => 
    array (
      0 => 127828,
    ),
    'char_name' => 
    array (
      'title' => 'HAMBURGER',
      'desc' => '= fast food place',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 54,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58995,
      ),
      'sjis' => 
      array (
        0 => 63700,
      ),
      'jis' => 
      array (
        0 => 30257,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 245,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58582,
      ),
      'sjis' => 
      array (
        0 => 63151,
      ),
      'jis' => 
      array (
        0 => 30257,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 180,
      ),
      'number_old' => 
      array (
        0 => 122,
      ),
      'unicode' => 
      array (
        0 => 57632,
      ),
      'sjis' => 
      array (
        0 => 63328,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042784,
      ),
    ),
  ),
  501 => 
  array (
    'mapid' => '#e-961',
    'unicode' => 
    array (
      0 => 127833,
    ),
    'char_name' => 
    array (
      'title' => 'RICE BALL',
      'desc' => 'Temporary Notes: onigiri',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59209,
      ),
      'sjis' => 
      array (
        0 => 63982,
      ),
      'jis' => 
      array (
        0 => 30256,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 244,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58581,
      ),
      'sjis' => 
      array (
        0 => 63150,
      ),
      'jis' => 
      array (
        0 => 30256,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 177,
      ),
      'number_old' => 
      array (
        0 => 336,
      ),
      'unicode' => 
      array (
        0 => 58178,
      ),
      'sjis' => 
      array (
        0 => 63970,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042785,
      ),
    ),
  ),
  502 => 
  array (
    'mapid' => '#e-962',
    'unicode' => 
    array (
      0 => 127856,
    ),
    'char_name' => 
    array (
      'title' => 'SHORTCAKE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59210,
      ),
      'sjis' => 
      array (
        0 => 63983,
      ),
      'jis' => 
      array (
        0 => 30251,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 239,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58576,
      ),
      'sjis' => 
      array (
        0 => 63145,
      ),
      'jis' => 
      array (
        0 => 30251,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 172,
      ),
      'number_old' => 
      array (
        0 => 70,
      ),
      'unicode' => 
      array (
        0 => 57414,
      ),
      'sjis' => 
      array (
        0 => 63879,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042786,
      ),
    ),
  ),
  503 => 
  array (
    'mapid' => '#e-963',
    'unicode' => 
    array (
      0 => 127836,
    ),
    'char_name' => 
    array (
      'title' => 'STEAMING BOWL',
      'desc' => '= ramen noodles',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59212,
      ),
      'sjis' => 
      array (
        0 => 63985,
      ),
      'jis' => 
      array (
        0 => 30803,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 333,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58804,
      ),
      'sjis' => 
      array (
        0 => 63441,
      ),
      'jis' => 
      array (
        0 => 30803,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 183,
      ),
      'number_old' => 
      array (
        0 => 334,
      ),
      'unicode' => 
      array (
        0 => 58176,
      ),
      'sjis' => 
      array (
        0 => 63968,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042787,
      ),
    ),
  ),
  504 => 
  array (
    'mapid' => '#e-964',
    'unicode' => 
    array (
      0 => 127838,
    ),
    'char_name' => 
    array (
      'title' => 'BREAD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59213,
      ),
      'sjis' => 
      array (
        0 => 63986,
      ),
      'jis' => 
      array (
        0 => 31075,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 424,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60079,
      ),
      'sjis' => 
      array (
        0 => 62339,
      ),
      'jis' => 
      array (
        0 => 31075,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 179,
      ),
      'number_old' => 
      array (
        0 => 327,
      ),
      'unicode' => 
      array (
        0 => 58169,
      ),
      'sjis' => 
      array (
        0 => 63961,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042788,
      ),
    ),
  ),
  505 => 
  array (
    'mapid' => '#e-965',
    'unicode' => 
    array (
      0 => 127859,
    ),
    'char_name' => 
    array (
      'title' => 'COOKING',
      'desc' => '= frying pan, cooking utensil',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フライパン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 240,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58577,
      ),
      'sjis' => 
      array (
        0 => 63146,
      ),
      'jis' => 
      array (
        0 => 30252,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 189,
      ),
      'number_old' => 
      array (
        0 => 161,
      ),
      'unicode' => 
      array (
        0 => 57671,
      ),
      'sjis' => 
      array (
        0 => 63368,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042789,
      ),
    ),
  ),
  506 => 
  array (
    'mapid' => '#e-966',
    'unicode' => 
    array (
      0 => 127846,
    ),
    'char_name' => 
    array (
      'title' => 'SOFT ICE CREAM',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ソフトクリーム]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 425,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60080,
      ),
      'sjis' => 
      array (
        0 => 62340,
      ),
      'jis' => 
      array (
        0 => 31076,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 173,
      ),
      'number_old' => 
      array (
        0 => 328,
      ),
      'unicode' => 
      array (
        0 => 58170,
      ),
      'sjis' => 
      array (
        0 => 63962,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042790,
      ),
    ),
  ),
  507 => 
  array (
    'mapid' => '#e-967',
    'unicode' => 
    array (
      0 => 127839,
    ),
    'char_name' => 
    array (
      'title' => 'FRENCH FRIES',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ポテト]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 426,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60081,
      ),
      'sjis' => 
      array (
        0 => 62341,
      ),
      'jis' => 
      array (
        0 => 31077,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 188,
      ),
      'number_old' => 
      array (
        0 => 329,
      ),
      'unicode' => 
      array (
        0 => 58171,
      ),
      'sjis' => 
      array (
        0 => 63963,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042791,
      ),
    ),
  ),
  508 => 
  array (
    'mapid' => '#e-968',
    'unicode' => 
    array (
      0 => 127841,
    ),
    'char_name' => 
    array (
      'title' => 'DANGO',
      'desc' => 'Old name: DUMPLING
= mochi balls on skewer',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[だんご]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 427,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60082,
      ),
      'sjis' => 
      array (
        0 => 62342,
      ),
      'jis' => 
      array (
        0 => 31078,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 174,
      ),
      'number_old' => 
      array (
        0 => 330,
      ),
      'unicode' => 
      array (
        0 => 58172,
      ),
      'sjis' => 
      array (
        0 => 63964,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042792,
      ),
    ),
  ),
  509 => 
  array (
    'mapid' => '#e-969',
    'unicode' => 
    array (
      0 => 127832,
    ),
    'char_name' => 
    array (
      'title' => 'RICE CRACKER',
      'desc' => 'Temporary Notes: Japanese rice cracker (senbei)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[せんべい]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 428,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60083,
      ),
      'sjis' => 
      array (
        0 => 62343,
      ),
      'jis' => 
      array (
        0 => 31079,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 175,
      ),
      'number_old' => 
      array (
        0 => 331,
      ),
      'unicode' => 
      array (
        0 => 58173,
      ),
      'sjis' => 
      array (
        0 => 63965,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042793,
      ),
    ),
  ),
  510 => 
  array (
    'mapid' => '#e-96A',
    'unicode' => 
    array (
      0 => 127834,
    ),
    'char_name' => 
    array (
      'title' => 'COOKED RICE',
      'desc' => '= bowl of rice',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59212,
      ),
      'sjis' => 
      array (
        0 => 63985,
      ),
      'jis' => 
      array (
        0 => 30803,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 429,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60084,
      ),
      'sjis' => 
      array (
        0 => 62344,
      ),
      'jis' => 
      array (
        0 => 31080,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 178,
      ),
      'number_old' => 
      array (
        0 => 332,
      ),
      'unicode' => 
      array (
        0 => 58174,
      ),
      'sjis' => 
      array (
        0 => 63966,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042794,
      ),
    ),
  ),
  511 => 
  array (
    'mapid' => '#e-96B',
    'unicode' => 
    array (
      0 => 127837,
    ),
    'char_name' => 
    array (
      'title' => 'SPAGHETTI',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[パスタ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 430,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60085,
      ),
      'sjis' => 
      array (
        0 => 62345,
      ),
      'jis' => 
      array (
        0 => 31081,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 182,
      ),
      'number_old' => 
      array (
        0 => 333,
      ),
      'unicode' => 
      array (
        0 => 58175,
      ),
      'sjis' => 
      array (
        0 => 63967,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042795,
      ),
    ),
  ),
  512 => 
  array (
    'mapid' => '#e-96C',
    'unicode' => 
    array (
      0 => 127835,
    ),
    'char_name' => 
    array (
      'title' => 'CURRY AND RICE',
      'desc' => '= Japanese style curry',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カレー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 431,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60086,
      ),
      'sjis' => 
      array (
        0 => 62346,
      ),
      'jis' => 
      array (
        0 => 31082,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 181,
      ),
      'number_old' => 
      array (
        0 => 335,
      ),
      'unicode' => 
      array (
        0 => 58177,
      ),
      'sjis' => 
      array (
        0 => 63969,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042796,
      ),
    ),
  ),
  513 => 
  array (
    'mapid' => '#e-96D',
    'unicode' => 
    array (
      0 => 127842,
    ),
    'char_name' => 
    array (
      'title' => 'ODEN',
      'desc' => 'Old name: SEAFOOD CASSEROLE
= seafood on skewer
Temporary Notes: seafood hotchpotch, oden',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[おでん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 432,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60087,
      ),
      'sjis' => 
      array (
        0 => 62347,
      ),
      'jis' => 
      array (
        0 => 31083,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 187,
      ),
      'number_old' => 
      array (
        0 => 337,
      ),
      'unicode' => 
      array (
        0 => 58179,
      ),
      'sjis' => 
      array (
        0 => 63971,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042797,
      ),
    ),
  ),
  514 => 
  array (
    'mapid' => '#e-96E',
    'unicode' => 
    array (
      0 => 127843,
    ),
    'char_name' => 
    array (
      'title' => 'SUSHI',
      'desc' => 'Temporary Notes: nigiri sushi',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[すし]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 433,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60088,
      ),
      'sjis' => 
      array (
        0 => 62348,
      ),
      'jis' => 
      array (
        0 => 31084,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 184,
      ),
      'number_old' => 
      array (
        0 => 338,
      ),
      'unicode' => 
      array (
        0 => 58180,
      ),
      'sjis' => 
      array (
        0 => 63972,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042798,
      ),
    ),
  ),
  515 => 
  array (
    'mapid' => '#e-96F',
    'unicode' => 
    array (
      0 => 127857,
    ),
    'char_name' => 
    array (
      'title' => 'BENTO BOX',
      'desc' => 'Old name: LUNCHBOX
Temporary Notes: obento',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[弁当]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 438,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60093,
      ),
      'sjis' => 
      array (
        0 => 62353,
      ),
      'jis' => 
      array (
        0 => 31089,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 185,
      ),
      'number_old' => 
      array (
        0 => 346,
      ),
      'unicode' => 
      array (
        0 => 58188,
      ),
      'sjis' => 
      array (
        0 => 63980,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042799,
      ),
    ),
  ),
  516 => 
  array (
    'mapid' => '#e-970',
    'unicode' => 
    array (
      0 => 127858,
    ),
    'char_name' => 
    array (
      'title' => 'POT OF FOOD',
      'desc' => 'Temporary Notes: hot pot, nabe',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[鍋]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 439,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60094,
      ),
      'sjis' => 
      array (
        0 => 62354,
      ),
      'jis' => 
      array (
        0 => 31090,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 186,
      ),
      'number_old' => 
      array (
        0 => 347,
      ),
      'unicode' => 
      array (
        0 => 58189,
      ),
      'sjis' => 
      array (
        0 => 63981,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042800,
      ),
    ),
  ),
  517 => 
  array (
    'mapid' => '#e-971',
    'unicode' => 
    array (
      0 => 127847,
    ),
    'char_name' => 
    array (
      'title' => 'SHAVED ICE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[カキ氷]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 483,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60138,
      ),
      'sjis' => 
      array (
        0 => 62398,
      ),
      'jis' => 
      array (
        0 => 31296,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
        0 => 410,
      ),
      'unicode' => 
      array (
        0 => 58431,
      ),
      'sjis' => 
      array (
        0 => 64384,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042801,
      ),
    ),
  ),
  518 => 
  array (
    'mapid' => '#e-972',
    'unicode' => 
    array (
      0 => 127830,
    ),
    'char_name' => 
    array (
      'title' => 'MEAT ON BONE',
      'desc' => 'Temporary Notes: food',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[肉]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 160,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58564,
      ),
      'sjis' => 
      array (
        0 => 63133,
      ),
      'jis' => 
      array (
        0 => 30077,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[肉]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042802,
      ),
    ),
  ),
  519 => 
  array (
    'mapid' => '#e-973',
    'unicode' => 
    array (
      0 => 127845,
    ),
    'char_name' => 
    array (
      'title' => 'FISH CAKE WITH SWIRL DESIGN',
      'desc' => 'Temporary Notes: topping for ramen noodles',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 6,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58947,
      ),
      'sjis' => 
      array (
        0 => 63652,
      ),
      'jis' => 
      array (
        0 => 29986,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 275,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58605,
      ),
      'sjis' => 
      array (
        0 => 63174,
      ),
      'jis' => 
      array (
        0 => 30280,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[なると]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042803,
      ),
    ),
  ),
  520 => 
  array (
    'mapid' => '#e-974',
    'unicode' => 
    array (
      0 => 127840,
    ),
    'char_name' => 
    array (
      'title' => 'ROASTED SWEET POTATO',
      'desc' => 'Temporary Notes: 焼き芋: Japanese yakiimo',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[やきいも]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 744,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60218,
      ),
      'sjis' => 
      array (
        0 => 62459,
      ),
      'jis' => 
      array (
        0 => 31357,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[やきいも]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042804,
      ),
    ),
  ),
  521 => 
  array (
    'mapid' => '#e-975',
    'unicode' => 
    array (
      0 => 127829,
    ),
    'char_name' => 
    array (
      'title' => 'SLICE OF PIZZA',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ピザ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 745,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60219,
      ),
      'sjis' => 
      array (
        0 => 62460,
      ),
      'jis' => 
      array (
        0 => 31358,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ピザ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042805,
      ),
    ),
  ),
  522 => 
  array (
    'mapid' => '#e-976',
    'unicode' => 
    array (
      0 => 127831,
    ),
    'char_name' => 
    array (
      'title' => 'POULTRY LEG',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[チキン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 746,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60220,
      ),
      'sjis' => 
      array (
        0 => 62528,
      ),
      'jis' => 
      array (
        0 => 31521,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[チキン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042806,
      ),
    ),
  ),
  523 => 
  array (
    'mapid' => '#e-977',
    'unicode' => 
    array (
      0 => 127848,
    ),
    'char_name' => 
    array (
      'title' => 'ICE CREAM',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[アイスクリーム]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 760,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60234,
      ),
      'sjis' => 
      array (
        0 => 62542,
      ),
      'jis' => 
      array (
        0 => 31535,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[アイスクリーム]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042807,
      ),
    ),
  ),
  524 => 
  array (
    'mapid' => '#e-978',
    'unicode' => 
    array (
      0 => 127849,
    ),
    'char_name' => 
    array (
      'title' => 'DOUGHNUT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ドーナツ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 761,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60235,
      ),
      'sjis' => 
      array (
        0 => 62543,
      ),
      'jis' => 
      array (
        0 => 31536,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ドーナツ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042808,
      ),
    ),
  ),
  525 => 
  array (
    'mapid' => '#e-979',
    'unicode' => 
    array (
      0 => 127850,
    ),
    'char_name' => 
    array (
      'title' => 'COOKIE',
      'desc' => '= biscuit',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[クッキー]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 762,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60236,
      ),
      'sjis' => 
      array (
        0 => 62544,
      ),
      'jis' => 
      array (
        0 => 31537,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[クッキー]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042809,
      ),
    ),
  ),
  526 => 
  array (
    'mapid' => '#e-97A',
    'unicode' => 
    array (
      0 => 127851,
    ),
    'char_name' => 
    array (
      'title' => 'CHOCOLATE BAR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[チョコ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 763,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60237,
      ),
      'sjis' => 
      array (
        0 => 62545,
      ),
      'jis' => 
      array (
        0 => 31538,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[チョコ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042810,
      ),
    ),
  ),
  527 => 
  array (
    'mapid' => '#e-97B',
    'unicode' => 
    array (
      0 => 127852,
    ),
    'char_name' => 
    array (
      'title' => 'CANDY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[キャンディ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 764,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60238,
      ),
      'sjis' => 
      array (
        0 => 62546,
      ),
      'jis' => 
      array (
        0 => 31539,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[キャンディ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042811,
      ),
    ),
  ),
  528 => 
  array (
    'mapid' => '#e-97C',
    'unicode' => 
    array (
      0 => 127853,
    ),
    'char_name' => 
    array (
      'title' => 'LOLLIPOP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[キャンディ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 765,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60239,
      ),
      'sjis' => 
      array (
        0 => 62547,
      ),
      'jis' => 
      array (
        0 => 31540,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[キャンディ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042812,
      ),
    ),
  ),
  529 => 
  array (
    'mapid' => '#e-97D',
    'unicode' => 
    array (
      0 => 127854,
    ),
    'char_name' => 
    array (
      'title' => 'CUSTARD',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[プリン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 772,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60246,
      ),
      'sjis' => 
      array (
        0 => 62554,
      ),
      'jis' => 
      array (
        0 => 31547,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[プリン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042813,
      ),
    ),
  ),
  530 => 
  array (
    'mapid' => '#e-97E',
    'unicode' => 
    array (
      0 => 127855,
    ),
    'char_name' => 
    array (
      'title' => 'HONEY POT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ハチミツ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 775,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60249,
      ),
      'sjis' => 
      array (
        0 => 62557,
      ),
      'jis' => 
      array (
        0 => 31550,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ハチミツ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042814,
      ),
    ),
  ),
  531 => 
  array (
    'mapid' => '#e-97F',
    'unicode' => 
    array (
      0 => 127844,
    ),
    'char_name' => 
    array (
      'title' => 'FRIED SHRIMP',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[エビフライ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 798,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60272,
      ),
      'sjis' => 
      array (
        0 => 62580,
      ),
      'jis' => 
      array (
        0 => 31573,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[エビフライ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042815,
      ),
    ),
  ),
  532 => 
  array (
    'mapid' => '#e-980',
    'unicode' => 
    array (
      0 => 127860,
    ),
    'char_name' => 
    array (
      'title' => 'FORK AND KNIFE',
      'desc' => '= restaurant, meal
* glyph may show a fork and spoon
* glyph may show a crossed fork and knife
* glyph may show a fork and knife with a plate',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 50,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58991,
      ),
      'sjis' => 
      array (
        0 => 63696,
      ),
      'jis' => 
      array (
        0 => 30053,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 146,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58540,
      ),
      'sjis' => 
      array (
        0 => 63109,
      ),
      'jis' => 
      array (
        0 => 30053,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 165,
      ),
      'number_old' => 
      array (
        0 => 67,
      ),
      'unicode' => 
      array (
        0 => 57411,
      ),
      'sjis' => 
      array (
        0 => 63876,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042816,
      ),
    ),
  ),
  533 => 
  array (
    'mapid' => '#e-981',
    'unicode' => 
    array (
      0 => 9749,
    ),
    'char_name' => 
    array (
      'title' => 'HOT BEVERAGE',
      'desc' => 'Temporary Notes: café, coffee',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 51,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58992,
      ),
      'sjis' => 
      array (
        0 => 63697,
      ),
      'jis' => 
      array (
        0 => 30774,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 93,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58775,
      ),
      'sjis' => 
      array (
        0 => 63412,
      ),
      'jis' => 
      array (
        0 => 30774,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 171,
      ),
      'number_old' => 
      array (
        0 => 69,
      ),
      'unicode' => 
      array (
        0 => 57413,
      ),
      'sjis' => 
      array (
        0 => 63878,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042817,
      ),
    ),
  ),
  534 => 
  array (
    'mapid' => '#e-982',
    'unicode' => 
    array (
      0 => 127864,
    ),
    'char_name' => 
    array (
      'title' => 'COCKTAIL GLASS',
      'desc' => 'Temporary Notes: martini, bar',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 52,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58993,
      ),
      'sjis' => 
      array (
        0 => 63698,
      ),
      'jis' => 
      array (
        0 => 30075,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 52,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58562,
      ),
      'sjis' => 
      array (
        0 => 63131,
      ),
      'jis' => 
      array (
        0 => 30075,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 168,
      ),
      'number_old' => 
      array (
        0 => 68,
      ),
      'unicode' => 
      array (
        0 => 57412,
      ),
      'sjis' => 
      array (
        0 => 63877,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042818,
      ),
    ),
  ),
  535 => 
  array (
    'mapid' => '#e-983',
    'unicode' => 
    array (
      0 => 127866,
    ),
    'char_name' => 
    array (
      'title' => 'BEER MUG',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 53,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58994,
      ),
      'sjis' => 
      array (
        0 => 63699,
      ),
      'jis' => 
      array (
        0 => 30076,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 65,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58563,
      ),
      'sjis' => 
      array (
        0 => 63132,
      ),
      'jis' => 
      array (
        0 => 30076,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 166,
      ),
      'number_old' => 
      array (
        0 => 71,
      ),
      'unicode' => 
      array (
        0 => 57415,
      ),
      'sjis' => 
      array (
        0 => 63880,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042819,
      ),
    ),
  ),
  536 => 
  array (
    'mapid' => '#e-984',
    'unicode' => 
    array (
      0 => 127861,
    ),
    'char_name' => 
    array (
      'title' => 'TEACUP WITHOUT HANDLE',
      'desc' => 'x (hot beverage - 2615)
x (cup on black square - 26FE)
Design Note: Make it look like a hot tea cup without a handle used typically in China, Japan, and Korea',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59166,
      ),
      'sjis' => 
      array (
        0 => 63939,
      ),
      'jis' => 
      array (
        0 => 31074,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 423,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60078,
      ),
      'sjis' => 
      array (
        0 => 62338,
      ),
      'jis' => 
      array (
        0 => 31074,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 170,
      ),
      'number_old' => 
      array (
        0 => 326,
      ),
      'unicode' => 
      array (
        0 => 58168,
      ),
      'sjis' => 
      array (
        0 => 63960,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042820,
      ),
    ),
  ),
  537 => 
  array (
    'mapid' => '#e-985',
    'unicode' => 
    array (
      0 => 127862,
    ),
    'char_name' => 
    array (
      'title' => 'SAKE BOTTLE AND CUP',
      'desc' => 'Temporary Notes: sake',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59211,
      ),
      'sjis' => 
      array (
        0 => 63984,
      ),
      'jis' => 
      array (
        0 => 31051,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 400,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60055,
      ),
      'sjis' => 
      array (
        0 => 62314,
      ),
      'jis' => 
      array (
        0 => 31051,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 169,
      ),
      'number_old' => 
      array (
        0 => 281,
      ),
      'unicode' => 
      array (
        0 => 58123,
      ),
      'sjis' => 
      array (
        0 => 63915,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042821,
      ),
    ),
  ),
  538 => 
  array (
    'mapid' => '#e-986',
    'unicode' => 
    array (
      0 => 127863,
    ),
    'char_name' => 
    array (
      'title' => 'WINE GLASS',
      'desc' => 'Temporary Notes: wine',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59222,
      ),
      'sjis' => 
      array (
        0 => 63995,
      ),
      'jis' => 
      array (
        0 => 30074,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 12,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58561,
      ),
      'sjis' => 
      array (
        0 => 63130,
      ),
      'jis' => 
      array (
        0 => 30074,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 168,
      ),
      'number_old' => 
      array (
        0 => 68,
      ),
      'unicode' => 
      array (
        0 => 57412,
      ),
      'sjis' => 
      array (
        0 => 63877,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042822,
      ),
    ),
  ),
  539 => 
  array (
    'mapid' => '#e-987',
    'unicode' => 
    array (
      0 => 127867,
    ),
    'char_name' => 
    array (
      'title' => 'CLINKING BEER MUGS',
      'desc' => '= cheers',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 53,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58994,
      ),
      'sjis' => 
      array (
        0 => 63699,
      ),
      'jis' => 
      array (
        0 => 30076,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 401,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60056,
      ),
      'sjis' => 
      array (
        0 => 62315,
      ),
      'jis' => 
      array (
        0 => 31052,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 167,
      ),
      'number_old' => 
      array (
        0 => 282,
      ),
      'unicode' => 
      array (
        0 => 58124,
      ),
      'sjis' => 
      array (
        0 => 63916,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042823,
      ),
    ),
  ),
  540 => 
  array (
    'mapid' => '#e-988',
    'unicode' => 
    array (
      0 => 127865,
    ),
    'char_name' => 
    array (
      'title' => 'TROPICAL DRINK',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 52,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58993,
      ),
      'sjis' => 
      array (
        0 => 63698,
      ),
      'jis' => 
      array (
        0 => 30075,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 748,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60222,
      ),
      'sjis' => 
      array (
        0 => 62530,
      ),
      'jis' => 
      array (
        0 => 31523,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 168,
      ),
      'number_old' => 
      array (
        0 => 68,
      ),
      'unicode' => 
      array (
        0 => 57412,
      ),
      'sjis' => 
      array (
        0 => 63877,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042824,
      ),
    ),
  ),
  541 => 
  array (
    'mapid' => '#e-AF0',
    'unicode' => 
    array (
      0 => 8599,
    ),
    'char_name' => 
    array (
      'title' => 'NORTH EAST ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 59,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59000,
      ),
      'sjis' => 
      array (
        0 => 63705,
      ),
      'jis' => 
      array (
        0 => 30546,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 70,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58709,
      ),
      'sjis' => 
      array (
        0 => 63345,
      ),
      'jis' => 
      array (
        0 => 30546,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 377,
      ),
      'number_old' => 
      array (
        0 => 234,
      ),
      'unicode' => 
      array (
        0 => 57910,
      ),
      'sjis' => 
      array (
        0 => 63446,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043184,
      ),
    ),
  ),
  542 => 
  array (
    'mapid' => '#e-AF1',
    'unicode' => 
    array (
      0 => 8600,
    ),
    'char_name' => 
    array (
      'title' => 'SOUTH EAST ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 89,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59030,
      ),
      'sjis' => 
      array (
        0 => 63735,
      ),
      'jis' => 
      array (
        0 => 30538,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 43,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58701,
      ),
      'sjis' => 
      array (
        0 => 63337,
      ),
      'jis' => 
      array (
        0 => 30538,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 379,
      ),
      'number_old' => 
      array (
        0 => 236,
      ),
      'unicode' => 
      array (
        0 => 57912,
      ),
      'sjis' => 
      array (
        0 => 63448,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043185,
      ),
    ),
  ),
  543 => 
  array (
    'mapid' => '#e-AF2',
    'unicode' => 
    array (
      0 => 8598,
    ),
    'char_name' => 
    array (
      'title' => 'NORTH WEST ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 90,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59031,
      ),
      'sjis' => 
      array (
        0 => 63736,
      ),
      'jis' => 
      array (
        0 => 30537,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 42,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58700,
      ),
      'sjis' => 
      array (
        0 => 63336,
      ),
      'jis' => 
      array (
        0 => 30537,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 378,
      ),
      'number_old' => 
      array (
        0 => 235,
      ),
      'unicode' => 
      array (
        0 => 57911,
      ),
      'sjis' => 
      array (
        0 => 63447,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043186,
      ),
    ),
  ),
  544 => 
  array (
    'mapid' => '#e-AF3',
    'unicode' => 
    array (
      0 => 8601,
    ),
    'char_name' => 
    array (
      'title' => 'SOUTH WEST ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 104,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59045,
      ),
      'sjis' => 
      array (
        0 => 63817,
      ),
      'jis' => 
      array (
        0 => 30547,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 71,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58710,
      ),
      'sjis' => 
      array (
        0 => 63346,
      ),
      'jis' => 
      array (
        0 => 30547,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 380,
      ),
      'number_old' => 
      array (
        0 => 237,
      ),
      'unicode' => 
      array (
        0 => 57913,
      ),
      'sjis' => 
      array (
        0 => 63449,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043187,
      ),
    ),
  ),
  545 => 
  array (
    'mapid' => '#e-AF4',
    'unicode' => 
    array (
      0 => 10548,
    ),
    'char_name' => 
    array (
      'title' => 'ARROW POINTING RIGHTWARDS THEN CURVING UPWARDS',
      'desc' => 'Temporary Notes: From the left curving upward ("Good")',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 145,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59125,
      ),
      'sjis' => 
      array (
        0 => 63898,
      ),
      'jis' => 
      array (
        0 => 31344,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 731,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60205,
      ),
      'sjis' => 
      array (
        0 => 62446,
      ),
      'jis' => 
      array (
        0 => 31344,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 377,
      ),
      'number_old' => 
      array (
        0 => 234,
      ),
      'unicode' => 
      array (
        0 => 57910,
      ),
      'sjis' => 
      array (
        0 => 63446,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043188,
      ),
    ),
  ),
  546 => 
  array (
    'mapid' => '#e-AF5',
    'unicode' => 
    array (
      0 => 10549,
    ),
    'char_name' => 
    array (
      'title' => 'ARROW POINTING RIGHTWARDS THEN CURVING DOWNWARDS',
      'desc' => 'Temporary Notes: disunified from ↷ U+21B7. From the left curving downward ("Bad")',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 156,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59136,
      ),
      'sjis' => 
      array (
        0 => 63909,
      ),
      'jis' => 
      array (
        0 => 31345,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 732,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60206,
      ),
      'sjis' => 
      array (
        0 => 62447,
      ),
      'jis' => 
      array (
        0 => 31345,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 379,
      ),
      'number_old' => 
      array (
        0 => 236,
      ),
      'unicode' => 
      array (
        0 => 57912,
      ),
      'sjis' => 
      array (
        0 => 63448,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043189,
      ),
    ),
  ),
  547 => 
  array (
    'mapid' => '#e-AF6',
    'unicode' => 
    array (
      0 => 8596,
    ),
    'char_name' => 
    array (
      'title' => 'LEFT RIGHT ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59196,
      ),
      'sjis' => 
      array (
        0 => 63969,
      ),
      'jis' => 
      array (
        0 => 31583,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 808,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60282,
      ),
      'sjis' => 
      array (
        0 => 62590,
      ),
      'jis' => 
      array (
        0 => 31583,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '⇔',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043190,
      ),
    ),
  ),
  548 => 
  array (
    'mapid' => '#e-AF7',
    'unicode' => 
    array (
      0 => 8597,
    ),
    'char_name' => 
    array (
      'title' => 'UP DOWN ARROW',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59197,
      ),
      'sjis' => 
      array (
        0 => 63970,
      ),
      'jis' => 
      array (
        0 => 31584,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 809,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60283,
      ),
      'sjis' => 
      array (
        0 => 62592,
      ),
      'jis' => 
      array (
        0 => 31584,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '↑↓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043191,
      ),
    ),
  ),
  549 => 
  array (
    'mapid' => '#e-AF8',
    'unicode' => 
    array (
      0 => 11014,
    ),
    'char_name' => 
    array (
      'title' => 'UPWARDS BLACK ARROW',
      'desc' => '= ARIB-9203
Temporary Notes: disunified from U+2191 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[↑]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 29,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58687,
      ),
      'sjis' => 
      array (
        0 => 63323,
      ),
      'jis' => 
      array (
        0 => 30524,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 381,
      ),
      'number_old' => 
      array (
        0 => 230,
      ),
      'unicode' => 
      array (
        0 => 57906,
      ),
      'sjis' => 
      array (
        0 => 63442,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043192,
      ),
    ),
  ),
  550 => 
  array (
    'mapid' => '#e-AF9',
    'unicode' => 
    array (
      0 => 11015,
    ),
    'char_name' => 
    array (
      'title' => 'DOWNWARDS BLACK ARROW',
      'desc' => '= ARIB-9204
Temporary Notes: disunified from U+2193 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[↓]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 30,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58688,
      ),
      'sjis' => 
      array (
        0 => 63324,
      ),
      'jis' => 
      array (
        0 => 30525,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 382,
      ),
      'number_old' => 
      array (
        0 => 231,
      ),
      'unicode' => 
      array (
        0 => 57907,
      ),
      'sjis' => 
      array (
        0 => 63443,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043193,
      ),
    ),
  ),
  551 => 
  array (
    'mapid' => '#e-AFA',
    'unicode' => 
    array (
      0 => 10145,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK RIGHTWARDS ARROW',
      'desc' => '= ARIB-9201
Temporary Notes: disunified from U+2192 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[→]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 63,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58706,
      ),
      'sjis' => 
      array (
        0 => 63342,
      ),
      'jis' => 
      array (
        0 => 30543,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 383,
      ),
      'number_old' => 
      array (
        0 => 232,
      ),
      'unicode' => 
      array (
        0 => 57908,
      ),
      'sjis' => 
      array (
        0 => 63444,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043194,
      ),
    ),
  ),
  552 => 
  array (
    'mapid' => '#e-AFB',
    'unicode' => 
    array (
      0 => 11013,
    ),
    'char_name' => 
    array (
      'title' => 'LEFTWARDS BLACK ARROW',
      'desc' => '= ARIB-9202
Temporary Notes: disunified from U+2190 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[←]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 64,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58707,
      ),
      'sjis' => 
      array (
        0 => 63343,
      ),
      'jis' => 
      array (
        0 => 30544,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 384,
      ),
      'number_old' => 
      array (
        0 => 233,
      ),
      'unicode' => 
      array (
        0 => 57909,
      ),
      'sjis' => 
      array (
        0 => 63445,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043195,
      ),
    ),
  ),
  553 => 
  array (
    'mapid' => '#e-AFC',
    'unicode' => 
    array (
      0 => 9654,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK RIGHT-POINTING TRIANGLE',
      'desc' => '= ARIB-9248
Temporary Notes: Play',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[>]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 6,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58670,
      ),
      'sjis' => 
      array (
        0 => 63306,
      ),
      'jis' => 
      array (
        0 => 30507,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 385,
      ),
      'number_old' => 
      array (
        0 => 238,
      ),
      'unicode' => 
      array (
        0 => 57914,
      ),
      'sjis' => 
      array (
        0 => 63450,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043196,
      ),
    ),
  ),
  554 => 
  array (
    'mapid' => '#e-AFD',
    'unicode' => 
    array (
      0 => 9664,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK LEFT-POINTING TRIANGLE',
      'desc' => '= ARIB-9249
Temporary Notes: Reverse',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[<]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 5,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58669,
      ),
      'sjis' => 
      array (
        0 => 63305,
      ),
      'jis' => 
      array (
        0 => 30506,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 386,
      ),
      'number_old' => 
      array (
        0 => 239,
      ),
      'unicode' => 
      array (
        0 => 57915,
      ),
      'sjis' => 
      array (
        0 => 63451,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043197,
      ),
    ),
  ),
  555 => 
  array (
    'mapid' => '#e-AFE',
    'unicode' => 
    array (
      0 => 9193,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK RIGHT-POINTING DOUBLE TRIANGLE',
      'desc' => '= fast forward',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[>>]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 8,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58672,
      ),
      'sjis' => 
      array (
        0 => 63308,
      ),
      'jis' => 
      array (
        0 => 30509,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 387,
      ),
      'number_old' => 
      array (
        0 => 240,
      ),
      'unicode' => 
      array (
        0 => 57916,
      ),
      'sjis' => 
      array (
        0 => 63452,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043198,
      ),
    ),
  ),
  556 => 
  array (
    'mapid' => '#e-AFF',
    'unicode' => 
    array (
      0 => 9194,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK LEFT-POINTING DOUBLE TRIANGLE',
      'desc' => '= fast rewind',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[<<]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 7,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58671,
      ),
      'sjis' => 
      array (
        0 => 63307,
      ),
      'jis' => 
      array (
        0 => 30508,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 388,
      ),
      'number_old' => 
      array (
        0 => 241,
      ),
      'unicode' => 
      array (
        0 => 57917,
      ),
      'sjis' => 
      array (
        0 => 63453,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043199,
      ),
    ),
  ),
  557 => 
  array (
    'mapid' => '#e-B03',
    'unicode' => 
    array (
      0 => 9195,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK UP-POINTING DOUBLE TRIANGLE',
      'desc' => 'Temporary Notes: Fast forward (up)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▲',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58693,
      ),
      'sjis' => 
      array (
        0 => 63329,
      ),
      'jis' => 
      array (
        0 => 30530,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▲',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043203,
      ),
    ),
  ),
  558 => 
  array (
    'mapid' => '#e-B02',
    'unicode' => 
    array (
      0 => 9196,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK DOWN-POINTING DOUBLE TRIANGLE',
      'desc' => 'Temporary Notes: Fast forward (down)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▼',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 34,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58692,
      ),
      'sjis' => 
      array (
        0 => 63328,
      ),
      'jis' => 
      array (
        0 => 30529,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▼',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043202,
      ),
    ),
  ),
  559 => 
  array (
    'mapid' => '#e-B78',
    'unicode' => 
    array (
      0 => 128314,
    ),
    'char_name' => 
    array (
      'title' => 'UP-POINTING RED TRIANGLE',
      'desc' => 'Old name: UP-POINTING TRIANGLE-1
Temporary Notes: Triangle (pointing up). disunified from U+25B2 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▲',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 88,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58714,
      ),
      'sjis' => 
      array (
        0 => 63350,
      ),
      'jis' => 
      array (
        0 => 30551,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▲',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043320,
      ),
    ),
  ),
  560 => 
  array (
    'mapid' => '#e-B79',
    'unicode' => 
    array (
      0 => 128315,
    ),
    'char_name' => 
    array (
      'title' => 'DOWN-POINTING RED TRIANGLE',
      'desc' => 'Old name: DOWN-POINTING TRIANGLE-1
Temporary Notes: Triangle (pointing down). disunified from U+25BC due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▼',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 89,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58715,
      ),
      'sjis' => 
      array (
        0 => 63351,
      ),
      'jis' => 
      array (
        0 => 30552,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▼',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043321,
      ),
    ),
  ),
  561 => 
  array (
    'mapid' => '#e-B01',
    'unicode' => 
    array (
      0 => 128316,
    ),
    'char_name' => 
    array (
      'title' => 'UP-POINTING SMALL RED TRIANGLE',
      'desc' => 'Old name: UP-POINTING SMALL TRIANGLE-1
= play arrow up
Temporary Notes: disunified from U+25B2 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▲',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 33,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58691,
      ),
      'sjis' => 
      array (
        0 => 63327,
      ),
      'jis' => 
      array (
        0 => 30528,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▲',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043201,
      ),
    ),
  ),
  562 => 
  array (
    'mapid' => '#e-B00',
    'unicode' => 
    array (
      0 => 128317,
    ),
    'char_name' => 
    array (
      'title' => 'DOWN-POINTING SMALL RED TRIANGLE',
      'desc' => 'Old name: DOWN-POINTING SMALL TRIANGLE-1
= play arrow down
Temporary Notes: disunified from U+25BC due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '▼',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 32,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58690,
      ),
      'sjis' => 
      array (
        0 => 63326,
      ),
      'jis' => 
      array (
        0 => 30527,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '▼',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043200,
      ),
    ),
  ),
  563 => 
  array (
    'mapid' => '#e-B44',
    'unicode' => 
    array (
      0 => 11093,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY LARGE CIRCLE',
      'desc' => '= ARIB-9032
* forms a pair with CROSS MARK
* also used to mean good, correct or approved
x (white circle - 25CB)
x (large circle - 25EF)
x (heavy circle - 2B58)
Temporary Notes: good; OK, approved; O in tic tac toe; disunified from ○ U+25CB WHITE CIRCLE because of Shift-JIS source separation',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 99,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59040,
      ),
      'sjis' => 
      array (
        0 => 63812,
      ),
      'jis' => 
      array (
        0 => 32292,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 422,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60077,
      ),
      'sjis' => 
      array (
        0 => 62337,
      ),
      'jis' => 
      array (
        0 => 31073,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 371,
      ),
      'number_old' => 
      array (
        0 => 320,
      ),
      'unicode' => 
      array (
        0 => 58162,
      ),
      'sjis' => 
      array (
        0 => 63954,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043268,
      ),
    ),
  ),
  564 => 
  array (
    'mapid' => '#e-B45',
    'unicode' => 
    array (
      0 => 10060,
    ),
    'char_name' => 
    array (
      'title' => 'CROSS MARK',
      'desc' => '* forms a pair with 2B55 heavy large circle
Temporary Notes: bad; NO GOOD, not approved; X in tic tac toe. disunified from ✕ U+2715',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[×]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 61,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58704,
      ),
      'sjis' => 
      array (
        0 => 63340,
      ),
      'jis' => 
      array (
        0 => 30541,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 372,
      ),
      'number_old' => 
      array (
        0 => 321,
      ),
      'unicode' => 
      array (
        0 => 58163,
      ),
      'sjis' => 
      array (
        0 => 63955,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043269,
      ),
    ),
  ),
  565 => 
  array (
    'mapid' => '#e-B46',
    'unicode' => 
    array (
      0 => 10062,
    ),
    'char_name' => 
    array (
      'title' => 'NEGATIVE SQUARED CROSS MARK',
      'desc' => 'Temporary Notes: Another X (orange background)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[×]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 62,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58705,
      ),
      'sjis' => 
      array (
        0 => 63341,
      ),
      'jis' => 
      array (
        0 => 30542,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 372,
      ),
      'number_old' => 
      array (
        0 => 321,
      ),
      'unicode' => 
      array (
        0 => 58163,
      ),
      'sjis' => 
      array (
        0 => 63955,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043270,
      ),
    ),
  ),
  566 => 
  array (
    'mapid' => '#e-B04',
    'unicode' => 
    array (
      0 => 10071,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY EXCLAMATION MARK SYMBOL',
      'desc' => '= ARIB-9003',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 158,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59138,
      ),
      'sjis' => 
      array (
        0 => 63911,
      ),
      'jis' => 
      array (
        0 => 30011,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 2,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58498,
      ),
      'sjis' => 
      array (
        0 => 63066,
      ),
      'jis' => 
      array (
        0 => 30011,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 42,
      ),
      'number_old' => 
      array (
        0 => 33,
      ),
      'unicode' => 
      array (
        0 => 57377,
      ),
      'sjis' => 
      array (
        0 => 63841,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043204,
      ),
    ),
  ),
  567 => 
  array (
    'mapid' => '#e-B05',
    'unicode' => 
    array (
      0 => 8265,
    ),
    'char_name' => 
    array (
      'title' => 'EXCLAMATION QUESTION MARK',
      'desc' => '= ARIB-9379',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 159,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59139,
      ),
      'sjis' => 
      array (
        0 => 63912,
      ),
      'jis' => 
      array (
        0 => 31346,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 733,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60207,
      ),
      'sjis' => 
      array (
        0 => 62448,
      ),
      'jis' => 
      array (
        0 => 31346,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '！？',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043205,
      ),
    ),
  ),
  568 => 
  array (
    'mapid' => '#e-B06',
    'unicode' => 
    array (
      0 => 8252,
    ),
    'char_name' => 
    array (
      'title' => 'DOUBLE EXCLAMATION MARK',
      'desc' => '= ARIB-9378',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 160,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59140,
      ),
      'sjis' => 
      array (
        0 => 63913,
      ),
      'jis' => 
      array (
        0 => 31347,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 734,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60208,
      ),
      'sjis' => 
      array (
        0 => 62449,
      ),
      'jis' => 
      array (
        0 => 31347,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '！！',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043206,
      ),
    ),
  ),
  569 => 
  array (
    'mapid' => '#e-B09',
    'unicode' => 
    array (
      0 => 10067,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK QUESTION MARK ORNAMENT',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[？]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 3,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58499,
      ),
      'sjis' => 
      array (
        0 => 63067,
      ),
      'jis' => 
      array (
        0 => 30012,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 44,
      ),
      'number_old' => 
      array (
        0 => 32,
      ),
      'unicode' => 
      array (
        0 => 57376,
      ),
      'sjis' => 
      array (
        0 => 63840,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043209,
      ),
    ),
  ),
  570 => 
  array (
    'mapid' => '#e-B0A',
    'unicode' => 
    array (
      0 => 10068,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE QUESTION MARK ORNAMENT',
      'desc' => 'Temporary Notes: moving question mark',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[？]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 3,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58499,
      ),
      'sjis' => 
      array (
        0 => 63067,
      ),
      'jis' => 
      array (
        0 => 30012,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 45,
      ),
      'number_old' => 
      array (
        0 => 324,
      ),
      'unicode' => 
      array (
        0 => 58166,
      ),
      'sjis' => 
      array (
        0 => 63958,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043210,
      ),
    ),
  ),
  571 => 
  array (
    'mapid' => '#e-B0B',
    'unicode' => 
    array (
      0 => 10069,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE EXCLAMATION MARK ORNAMENT',
      'desc' => 'x (heavy exclamation mark ornament - 2762)
x (heavy exclamation mark symbol - 2757)
Temporary Notes: moving exclamation mark',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 158,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59138,
      ),
      'sjis' => 
      array (
        0 => 63911,
      ),
      'jis' => 
      array (
        0 => 30011,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 2,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58498,
      ),
      'sjis' => 
      array (
        0 => 63066,
      ),
      'jis' => 
      array (
        0 => 30011,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 43,
      ),
      'number_old' => 
      array (
        0 => 325,
      ),
      'unicode' => 
      array (
        0 => 58167,
      ),
      'sjis' => 
      array (
        0 => 63959,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043211,
      ),
    ),
  ),
  572 => 
  array (
    'mapid' => '#e-B07',
    'unicode' => 
    array (
      0 => 12336,
    ),
    'char_name' => 
    array (
      'title' => 'WAVY DASH',
      'desc' => 'Temporary Notes: a wavy line, used as a wavy length mark',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 165,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59145,
      ),
      'sjis' => 
      array (
        0 => 63918,
      ),
      'jis' => 
      array (
        0 => 32298,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '〓',
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043207,
      ),
    ),
  ),
  573 => 
  array (
    'mapid' => '#e-B08',
    'unicode' => 
    array (
      0 => 10160,
    ),
    'char_name' => 
    array (
      'title' => 'CURLY LOOP',
      'desc' => 'Old name: LOOPED LENGTH MARK
= kururi
Temporary Notes: a line with a loop; new compatibility character, see e-B07=U+3030',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 166,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59146,
      ),
      'sjis' => 
      array (
        0 => 63919,
      ),
      'jis' => 
      array (
        0 => 31348,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 735,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60209,
      ),
      'sjis' => 
      array (
        0 => 62450,
      ),
      'jis' => 
      array (
        0 => 31348,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '～',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043208,
      ),
    ),
  ),
  574 => 
  array (
    'mapid' => '#e-82B',
    'unicode' => 
    array (
      0 => 10175,
    ),
    'char_name' => 
    array (
      'title' => 'DOUBLE CURLY LOOP',
      'desc' => 'Old name: EMOJI COMPATIBILITY SYMBOL-16
x (bamum letter phase-e nggurae - 16986)
Temporary Notes: Original name: FREE DIAL. Two loops. Occurs widely in print in Japan. Originally proposed for U+23xx.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 122,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59103,
      ),
      'sjis' => 
      array (
        0 => 63876,
      ),
      'jis' => 
      array (
        0 => 32093,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[フリーダイヤル]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 468,
      ),
      'number_old' => 
      array (
        0 => 197,
      ),
      'unicode' => 
      array (
        0 => 57873,
      ),
      'sjis' => 
      array (
        0 => 63409,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042475,
      ),
    ),
  ),
  575 => 
  array (
    'mapid' => '#e-B0C',
    'unicode' => 
    array (
      0 => 10084,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY BLACK HEART',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 51,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58773,
      ),
      'sjis' => 
      array (
        0 => 63410,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 33,
      ),
      'number_old' => 
      array (
        0 => 34,
      ),
      'unicode' => 
      array (
        0 => 57378,
      ),
      'sjis' => 
      array (
        0 => 63842,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043212,
      ),
    ),
  ),
  576 => 
  array (
    'mapid' => '#e-B0D',
    'unicode' => 
    array (
      0 => 128147,
    ),
    'char_name' => 
    array (
      'title' => 'BEATING HEART',
      'desc' => 'Temporary Notes: pulsating heart',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59117,
      ),
      'sjis' => 
      array (
        0 => 63890,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 803,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60277,
      ),
      'sjis' => 
      array (
        0 => 62585,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
        0 => 309,
      ),
      'unicode' => 
      array (
        0 => 58151,
      ),
      'sjis' => 
      array (
        0 => 63943,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043213,
      ),
    ),
  ),
  577 => 
  array (
    'mapid' => '#e-B0E',
    'unicode' => 
    array (
      0 => 128148,
    ),
    'char_name' => 
    array (
      'title' => 'BROKEN HEART',
      'desc' => 'Temporary Notes: breaking or broken heart',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 138,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59118,
      ),
      'sjis' => 
      array (
        0 => 63891,
      ),
      'jis' => 
      array (
        0 => 30000,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 265,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58487,
      ),
      'sjis' => 
      array (
        0 => 63055,
      ),
      'jis' => 
      array (
        0 => 30000,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 34,
      ),
      'number_old' => 
      array (
        0 => 35,
      ),
      'unicode' => 
      array (
        0 => 57379,
      ),
      'sjis' => 
      array (
        0 => 63843,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043214,
      ),
    ),
  ),
  578 => 
  array (
    'mapid' => '#e-B0F',
    'unicode' => 
    array (
      0 => 128149,
    ),
    'char_name' => 
    array (
      'title' => 'TWO HEARTS',
      'desc' => 'Temporary Notes: two hearts',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 139,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59119,
      ),
      'sjis' => 
      array (
        0 => 63892,
      ),
      'jis' => 
      array (
        0 => 30001,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 266,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58488,
      ),
      'sjis' => 
      array (
        0 => 63056,
      ),
      'jis' => 
      array (
        0 => 30001,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
        0 => 309,
      ),
      'unicode' => 
      array (
        0 => 58151,
      ),
      'sjis' => 
      array (
        0 => 63943,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043215,
      ),
    ),
  ),
  579 => 
  array (
    'mapid' => '#e-B10',
    'unicode' => 
    array (
      0 => 128150,
    ),
    'char_name' => 
    array (
      'title' => 'SPARKLING HEART',
      'desc' => 'Temporary Notes: sparkling heart',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 415,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60070,
      ),
      'sjis' => 
      array (
        0 => 62329,
      ),
      'jis' => 
      array (
        0 => 31066,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
        0 => 309,
      ),
      'unicode' => 
      array (
        0 => 58151,
      ),
      'sjis' => 
      array (
        0 => 63943,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043216,
      ),
    ),
  ),
  580 => 
  array (
    'mapid' => '#e-B11',
    'unicode' => 
    array (
      0 => 128151,
    ),
    'char_name' => 
    array (
      'title' => 'GROWING HEART',
      'desc' => 'Temporary Notes: heart growing bigger',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59117,
      ),
      'sjis' => 
      array (
        0 => 63890,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 803,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60277,
      ),
      'sjis' => 
      array (
        0 => 62585,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 36,
      ),
      'number_old' => 
      array (
        0 => 310,
      ),
      'unicode' => 
      array (
        0 => 58152,
      ),
      'sjis' => 
      array (
        0 => 63944,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043217,
      ),
    ),
  ),
  581 => 
  array (
    'mapid' => '#e-B12',
    'unicode' => 
    array (
      0 => 128152,
    ),
    'char_name' => 
    array (
      'title' => 'HEART WITH ARROW',
      'desc' => 'Temporary Notes: heart with an arrow through it',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 272,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58602,
      ),
      'sjis' => 
      array (
        0 => 63171,
      ),
      'jis' => 
      array (
        0 => 30277,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 37,
      ),
      'number_old' => 
      array (
        0 => 311,
      ),
      'unicode' => 
      array (
        0 => 58153,
      ),
      'sjis' => 
      array (
        0 => 63945,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043218,
      ),
    ),
  ),
  582 => 
  array (
    'mapid' => '#e-B13',
    'unicode' => 
    array (
      0 => 128153,
    ),
    'char_name' => 
    array (
      'title' => 'BLUE HEART',
      'desc' => 'Old name: HEART-1
Temporary Notes: Heart with blue color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 416,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60071,
      ),
      'sjis' => 
      array (
        0 => 62330,
      ),
      'jis' => 
      array (
        0 => 31067,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 38,
      ),
      'number_old' => 
      array (
        0 => 312,
      ),
      'unicode' => 
      array (
        0 => 58154,
      ),
      'sjis' => 
      array (
        0 => 63946,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043219,
      ),
    ),
  ),
  583 => 
  array (
    'mapid' => '#e-B14',
    'unicode' => 
    array (
      0 => 128154,
    ),
    'char_name' => 
    array (
      'title' => 'GREEN HEART',
      'desc' => 'Old name: HEART-2
Temporary Notes: Heart with green color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 417,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60072,
      ),
      'sjis' => 
      array (
        0 => 62331,
      ),
      'jis' => 
      array (
        0 => 31068,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 39,
      ),
      'number_old' => 
      array (
        0 => 313,
      ),
      'unicode' => 
      array (
        0 => 58155,
      ),
      'sjis' => 
      array (
        0 => 63947,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043220,
      ),
    ),
  ),
  584 => 
  array (
    'mapid' => '#e-B15',
    'unicode' => 
    array (
      0 => 128155,
    ),
    'char_name' => 
    array (
      'title' => 'YELLOW HEART',
      'desc' => 'Old name: HEART-3
Temporary Notes: Heart with yellow color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 418,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60073,
      ),
      'sjis' => 
      array (
        0 => 62332,
      ),
      'jis' => 
      array (
        0 => 31069,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
        0 => 314,
      ),
      'unicode' => 
      array (
        0 => 58156,
      ),
      'sjis' => 
      array (
        0 => 63948,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043221,
      ),
    ),
  ),
  585 => 
  array (
    'mapid' => '#e-B16',
    'unicode' => 
    array (
      0 => 128156,
    ),
    'char_name' => 
    array (
      'title' => 'PURPLE HEART',
      'desc' => 'Old name: HEART-4
Temporary Notes: Heart with purple color',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 419,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60074,
      ),
      'sjis' => 
      array (
        0 => 62333,
      ),
      'jis' => 
      array (
        0 => 31070,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 41,
      ),
      'number_old' => 
      array (
        0 => 315,
      ),
      'unicode' => 
      array (
        0 => 58157,
      ),
      'sjis' => 
      array (
        0 => 63949,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043222,
      ),
    ),
  ),
  586 => 
  array (
    'mapid' => '#e-B17',
    'unicode' => 
    array (
      0 => 128157,
    ),
    'char_name' => 
    array (
      'title' => 'HEART WITH RIBBON',
      'desc' => 'Temporary Notes: Valentine\'s (heart with ribbon, or candy with heart)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 136,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59116,
      ),
      'sjis' => 
      array (
        0 => 63889,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 770,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60244,
      ),
      'sjis' => 
      array (
        0 => 62552,
      ),
      'jis' => 
      array (
        0 => 31545,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 309,
      ),
      'number_old' => 
      array (
        0 => 402,
      ),
      'unicode' => 
      array (
        0 => 58423,
      ),
      'sjis' => 
      array (
        0 => 64375,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043223,
      ),
    ),
  ),
  587 => 
  array (
    'mapid' => '#e-B18',
    'unicode' => 
    array (
      0 => 128158,
    ),
    'char_name' => 
    array (
      'title' => 'REVOLVING HEARTS',
      'desc' => 'Temporary Notes: cute',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 137,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59117,
      ),
      'sjis' => 
      array (
        0 => 63890,
      ),
      'jis' => 
      array (
        0 => 31578,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 328,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58799,
      ),
      'sjis' => 
      array (
        0 => 63436,
      ),
      'jis' => 
      array (
        0 => 30798,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 35,
      ),
      'number_old' => 
      array (
        0 => 309,
      ),
      'unicode' => 
      array (
        0 => 58151,
      ),
      'sjis' => 
      array (
        0 => 63943,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043224,
      ),
    ),
  ),
  588 => 
  array (
    'mapid' => '#e-B19',
    'unicode' => 
    array (
      0 => 128159,
    ),
    'char_name' => 
    array (
      'title' => 'HEART DECORATION',
      'desc' => 'Temporary Notes: Note: Softbank ruled lines, sometimes mapped to cute heart mark in other carriers',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59128,
      ),
      'sjis' => 
      array (
        0 => 63901,
      ),
      'jis' => 
      array (
        0 => 32297,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 51,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58773,
      ),
      'sjis' => 
      array (
        0 => 63410,
      ),
      'jis' => 
      array (
        0 => 30772,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 460,
      ),
      'number_old' => 
      array (
        0 => 184,
      ),
      'unicode' => 
      array (
        0 => 57860,
      ),
      'sjis' => 
      array (
        0 => 63396,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043225,
      ),
    ),
  ),
  589 => 
  array (
    'mapid' => '#e-B1A',
    'unicode' => 
    array (
      0 => 9829,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK HEART SUIT',
      'desc' => '= ARIB-9373',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 80,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59021,
      ),
      'sjis' => 
      array (
        0 => 63726,
      ),
      'jis' => 
      array (
        0 => 31065,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 414,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60069,
      ),
      'sjis' => 
      array (
        0 => 62328,
      ),
      'jis' => 
      array (
        0 => 31065,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 373,
      ),
      'number_old' => 
      array (
        0 => 192,
      ),
      'unicode' => 
      array (
        0 => 57868,
      ),
      'sjis' => 
      array (
        0 => 63404,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043226,
      ),
    ),
  ),
  590 => 
  array (
    'mapid' => '#e-B1B',
    'unicode' => 
    array (
      0 => 9824,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK SPADE SUIT',
      'desc' => '= ARIB-9375',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 81,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59022,
      ),
      'sjis' => 
      array (
        0 => 63727,
      ),
      'jis' => 
      array (
        0 => 30784,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 314,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58785,
      ),
      'sjis' => 
      array (
        0 => 63422,
      ),
      'jis' => 
      array (
        0 => 30784,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 375,
      ),
      'number_old' => 
      array (
        0 => 194,
      ),
      'unicode' => 
      array (
        0 => 57870,
      ),
      'sjis' => 
      array (
        0 => 63406,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043227,
      ),
    ),
  ),
  591 => 
  array (
    'mapid' => '#e-B1C',
    'unicode' => 
    array (
      0 => 9830,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK DIAMOND SUIT',
      'desc' => '= ARIB-9372',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 82,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59023,
      ),
      'sjis' => 
      array (
        0 => 63728,
      ),
      'jis' => 
      array (
        0 => 30785,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 315,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58786,
      ),
      'sjis' => 
      array (
        0 => 63423,
      ),
      'jis' => 
      array (
        0 => 30785,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 374,
      ),
      'number_old' => 
      array (
        0 => 193,
      ),
      'unicode' => 
      array (
        0 => 57869,
      ),
      'sjis' => 
      array (
        0 => 63405,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043228,
      ),
    ),
  ),
  592 => 
  array (
    'mapid' => '#e-B1D',
    'unicode' => 
    array (
      0 => 9827,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK CLUB SUIT',
      'desc' => '= ARIB-9374',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 83,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59024,
      ),
      'sjis' => 
      array (
        0 => 63729,
      ),
      'jis' => 
      array (
        0 => 30786,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 316,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58787,
      ),
      'sjis' => 
      array (
        0 => 63424,
      ),
      'jis' => 
      array (
        0 => 30786,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 376,
      ),
      'number_old' => 
      array (
        0 => 195,
      ),
      'unicode' => 
      array (
        0 => 57871,
      ),
      'sjis' => 
      array (
        0 => 63407,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043229,
      ),
    ),
  ),
  593 => 
  array (
    'mapid' => '#e-B1E',
    'unicode' => 
    array (
      0 => 128684,
    ),
    'char_name' => 
    array (
      'title' => 'SMOKING SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 66,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59007,
      ),
      'sjis' => 
      array (
        0 => 63712,
      ),
      'jis' => 
      array (
        0 => 30006,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 176,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58493,
      ),
      'sjis' => 
      array (
        0 => 63061,
      ),
      'jis' => 
      array (
        0 => 30006,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 265,
      ),
      'number_old' => 
      array (
        0 => 284,
      ),
      'unicode' => 
      array (
        0 => 58126,
      ),
      'sjis' => 
      array (
        0 => 63918,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043230,
      ),
    ),
  ),
  594 => 
  array (
    'mapid' => '#e-B1F',
    'unicode' => 
    array (
      0 => 128685,
    ),
    'char_name' => 
    array (
      'title' => 'NO SMOKING SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 67,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59008,
      ),
      'sjis' => 
      array (
        0 => 63713,
      ),
      'jis' => 
      array (
        0 => 30007,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 177,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58494,
      ),
      'sjis' => 
      array (
        0 => 63062,
      ),
      'jis' => 
      array (
        0 => 30007,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 266,
      ),
      'number_old' => 
      array (
        0 => 188,
      ),
      'unicode' => 
      array (
        0 => 57864,
      ),
      'sjis' => 
      array (
        0 => 63400,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043231,
      ),
    ),
  ),
  595 => 
  array (
    'mapid' => '#e-B20',
    'unicode' => 
    array (
      0 => 9855,
    ),
    'char_name' => 
    array (
      'title' => 'WHEELCHAIR SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 94,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59035,
      ),
      'sjis' => 
      array (
        0 => 63740,
      ),
      'jis' => 
      array (
        0 => 30008,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 178,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58495,
      ),
      'sjis' => 
      array (
        0 => 63063,
      ),
      'jis' => 
      array (
        0 => 30008,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 355,
      ),
      'number_old' => 
      array (
        0 => 190,
      ),
      'unicode' => 
      array (
        0 => 57866,
      ),
      'sjis' => 
      array (
        0 => 63402,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043232,
      ),
    ),
  ),
  596 => 
  array (
    'mapid' => '#e-B22',
    'unicode' => 
    array (
      0 => 128681,
    ),
    'char_name' => 
    array (
      'title' => 'TRIANGULAR FLAG ON POST',
      'desc' => '= location information
Temporary Notes: Location information, a flag',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 121,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59102,
      ),
      'sjis' => 
      array (
        0 => 63875,
      ),
      'jis' => 
      array (
        0 => 31343,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 730,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60204,
      ),
      'sjis' => 
      array (
        0 => 62445,
      ),
      'jis' => 
      array (
        0 => 31343,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[旗]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043234,
      ),
    ),
  ),
  597 => 
  array (
    'mapid' => '#e-B23',
    'unicode' => 
    array (
      0 => 9888,
    ),
    'char_name' => 
    array (
      'title' => 'WARNING SIGN',
      'desc' => 'Temporary Notes: Unified with U+26A0. Danger / Caution / Warning',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59191,
      ),
      'sjis' => 
      array (
        0 => 63964,
      ),
      'jis' => 
      array (
        0 => 30010,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 1,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58497,
      ),
      'sjis' => 
      array (
        0 => 63065,
      ),
      'jis' => 
      array (
        0 => 30010,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 349,
      ),
      'number_old' => 
      array (
        0 => 262,
      ),
      'unicode' => 
      array (
        0 => 57938,
      ),
      'sjis' => 
      array (
        0 => 63474,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043235,
      ),
    ),
  ),
  598 => 
  array (
    'mapid' => '#e-B26',
    'unicode' => 
    array (
      0 => 9940,
    ),
    'char_name' => 
    array (
      'title' => 'NO ENTRY',
      'desc' => '= ARIB-9011
Temporary Notes: No entrance, no trespassing',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59183,
      ),
      'sjis' => 
      array (
        0 => 63956,
      ),
      'jis' => 
      array (
        0 => 32310,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 98,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58500,
      ),
      'sjis' => 
      array (
        0 => 63068,
      ),
      'jis' => 
      array (
        0 => 30013,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 350,
      ),
      'number_old' => 
      array (
        0 => 145,
      ),
      'unicode' => 
      array (
        0 => 57655,
      ),
      'sjis' => 
      array (
        0 => 63351,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043238,
      ),
    ),
  ),
  599 => 
  array (
    'mapid' => '#e-B2C',
    'unicode' => 
    array (
      0 => 9851,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK UNIVERSAL RECYCLING SYMBOL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59189,
      ),
      'sjis' => 
      array (
        0 => 63962,
      ),
      'jis' => 
      array (
        0 => 31582,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 807,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60281,
      ),
      'sjis' => 
      array (
        0 => 62589,
      ),
      'jis' => 
      array (
        0 => 31582,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '↑↓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043244,
      ),
    ),
  ),
  600 => 
  array (
    'mapid' => '#e-7EB',
    'unicode' => 
    array (
      0 => 128690,
    ),
    'char_name' => 
    array (
      'title' => 'BICYCLE',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59165,
      ),
      'sjis' => 
      array (
        0 => 63938,
      ),
      'jis' => 
      array (
        0 => 30055,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 215,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58542,
      ),
      'sjis' => 
      array (
        0 => 63111,
      ),
      'jis' => 
      array (
        0 => 30055,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 196,
      ),
      'number_old' => 
      array (
        0 => 144,
      ),
      'unicode' => 
      array (
        0 => 57654,
      ),
      'sjis' => 
      array (
        0 => 63350,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042411,
      ),
    ),
  ),
  601 => 
  array (
    'mapid' => '#e-7F0',
    'unicode' => 
    array (
      0 => 128694,
    ),
    'char_name' => 
    array (
      'title' => 'PEDESTRIAN',
      'desc' => '= walking',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59187,
      ),
      'sjis' => 
      array (
        0 => 63960,
      ),
      'jis' => 
      array (
        0 => 29988,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 800,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60274,
      ),
      'sjis' => 
      array (
        0 => 62582,
      ),
      'jis' => 
      array (
        0 => 31575,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 74,
      ),
      'number_old' => 
      array (
        0 => 181,
      ),
      'unicode' => 
      array (
        0 => 57857,
      ),
      'sjis' => 
      array (
        0 => 63393,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042416,
      ),
    ),
  ),
  602 => 
  array (
    'mapid' => '#e-B33',
    'unicode' => 
    array (
      0 => 128697,
    ),
    'char_name' => 
    array (
      'title' => 'MENS SYMBOL',
      'desc' => '= man symbol
= men\'s restroom',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[♂]',
    ),
    'au' => 
    array (
      'kaomoji' => '[♂]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 357,
      ),
      'number_old' => 
      array (
        0 => 146,
      ),
      'unicode' => 
      array (
        0 => 57656,
      ),
      'sjis' => 
      array (
        0 => 63352,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043251,
      ),
    ),
  ),
  603 => 
  array (
    'mapid' => '#e-B34',
    'unicode' => 
    array (
      0 => 128698,
    ),
    'char_name' => 
    array (
      'title' => 'WOMENS SYMBOL',
      'desc' => '= woman symbol
= women\'s restroom',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[♀]',
    ),
    'au' => 
    array (
      'kaomoji' => '[♀]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 358,
      ),
      'number_old' => 
      array (
        0 => 147,
      ),
      'unicode' => 
      array (
        0 => 57657,
      ),
      'sjis' => 
      array (
        0 => 63353,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043252,
      ),
    ),
  ),
  604 => 
  array (
    'mapid' => '#e-505',
    'unicode' => 
    array (
      0 => 128704,
    ),
    'char_name' => 
    array (
      'title' => 'BATH',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 147,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59127,
      ),
      'sjis' => 
      array (
        0 => 63900,
      ),
      'jis' => 
      array (
        0 => 30069,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 369,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58840,
      ),
      'sjis' => 
      array (
        0 => 62283,
      ),
      'jis' => 
      array (
        0 => 31020,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 274,
      ),
      'number_old' => 
      array (
        0 => 153,
      ),
      'unicode' => 
      array (
        0 => 57663,
      ),
      'sjis' => 
      array (
        0 => 63360,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041669,
      ),
    ),
  ),
  605 => 
  array (
    'mapid' => '#e-506',
    'unicode' => 
    array (
      0 => 128699,
    ),
    'char_name' => 
    array (
      'title' => 'RESTROOM',
      'desc' => '= man and woman symbol with divider',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 49,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58990,
      ),
      'sjis' => 
      array (
        0 => 63695,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 207,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58533,
      ),
      'sjis' => 
      array (
        0 => 63101,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 353,
      ),
      'number_old' => 
      array (
        0 => 171,
      ),
      'unicode' => 
      array (
        0 => 57681,
      ),
      'sjis' => 
      array (
        0 => 63378,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041670,
      ),
    ),
  ),
  606 => 
  array (
    'mapid' => '#e-507',
    'unicode' => 
    array (
      0 => 128701,
    ),
    'char_name' => 
    array (
      'title' => 'TOILET',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 49,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58990,
      ),
      'sjis' => 
      array (
        0 => 63695,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 207,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58533,
      ),
      'sjis' => 
      array (
        0 => 63101,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 269,
      ),
      'number_old' => 
      array (
        0 => 154,
      ),
      'unicode' => 
      array (
        0 => 57664,
      ),
      'sjis' => 
      array (
        0 => 63361,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041671,
      ),
    ),
  ),
  607 => 
  array (
    'mapid' => '#e-508',
    'unicode' => 
    array (
      0 => 128702,
    ),
    'char_name' => 
    array (
      'title' => 'WATER CLOSET',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 49,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58990,
      ),
      'sjis' => 
      array (
        0 => 63695,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 207,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58533,
      ),
      'sjis' => 
      array (
        0 => 63101,
      ),
      'jis' => 
      array (
        0 => 30046,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 354,
      ),
      'number_old' => 
      array (
        0 => 279,
      ),
      'unicode' => 
      array (
        0 => 58121,
      ),
      'sjis' => 
      array (
        0 => 63913,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041672,
      ),
    ),
  ),
  608 => 
  array (
    'mapid' => '#e-B35',
    'unicode' => 
    array (
      0 => 128700,
    ),
    'char_name' => 
    array (
      'title' => 'BABY SYMBOL',
      'desc' => '= baby on board, baby changing station
Temporary Notes: used as a sign for a baby; Crawling Baby',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[赤ちゃん]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 710,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60184,
      ),
      'sjis' => 
      array (
        0 => 62425,
      ),
      'jis' => 
      array (
        0 => 31323,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 359,
      ),
      'number_old' => 
      array (
        0 => 148,
      ),
      'unicode' => 
      array (
        0 => 57658,
      ),
      'sjis' => 
      array (
        0 => 63354,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043253,
      ),
    ),
  ),
  609 => 
  array (
    'mapid' => '#e-4F3',
    'unicode' => 
    array (
      0 => 128682,
    ),
    'char_name' => 
    array (
      'title' => 'DOOR',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59156,
      ),
      'sjis' => 
      array (
        0 => 63929,
      ),
      'jis' => 
      array (
        0 => 32306,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[ドア]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ドア]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041651,
      ),
    ),
  ),
  610 => 
  array (
    'mapid' => '#e-B48',
    'unicode' => 
    array (
      0 => 128683,
    ),
    'char_name' => 
    array (
      'title' => 'NO ENTRY SIGN',
      'desc' => 'Old name: NO ENTRY SIGN
x (combining enclosing circle backslash - 20E0)
x (no entry - 26D4)
Temporary Notes: Prohibited (circle with diagonal slash); Do not enter',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59192,
      ),
      'sjis' => 
      array (
        0 => 63965,
      ),
      'jis' => 
      array (
        0 => 32311,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 31,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58689,
      ),
      'sjis' => 
      array (
        0 => 63325,
      ),
      'jis' => 
      array (
        0 => 30526,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[禁止]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043272,
      ),
    ),
  ),
  611 => 
  array (
    'mapid' => '#e-B49',
    'unicode' => 
    array (
      0 => 10004,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY CHECK MARK',
      'desc' => 'Temporary Notes: Check mark (blue)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 73,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58711,
      ),
      'sjis' => 
      array (
        0 => 63347,
      ),
      'jis' => 
      array (
        0 => 30548,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043273,
      ),
    ),
  ),
  612 => 
  array (
    'mapid' => '#e-B84',
    'unicode' => 
    array (
      0 => 127377,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CL',
      'desc' => 'Old name: CLEAR SIGN
= clear
Temporary Notes: Clear ("CL" stamp)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 118,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59099,
      ),
      'sjis' => 
      array (
        0 => 63872,
      ),
      'jis' => 
      array (
        0 => 30794,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 324,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58795,
      ),
      'sjis' => 
      array (
        0 => 63432,
      ),
      'jis' => 
      array (
        0 => 30794,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[CL]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043332,
      ),
    ),
  ),
  613 => 
  array (
    'mapid' => '#e-B38',
    'unicode' => 
    array (
      0 => 127378,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED COOL',
      'desc' => 'Old name: COOL SIGN
Temporary Notes: cool!; hip',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[COOL]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 382,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60037,
      ),
      'sjis' => 
      array (
        0 => 62296,
      ),
      'jis' => 
      array (
        0 => 31033,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 439,
      ),
      'number_old' => 
      array (
        0 => 200,
      ),
      'unicode' => 
      array (
        0 => 57876,
      ),
      'sjis' => 
      array (
        0 => 63412,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043256,
      ),
    ),
  ),
  614 => 
  array (
    'mapid' => '#e-B21',
    'unicode' => 
    array (
      0 => 127379,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED FREE',
      'desc' => 'Old name: FREE SIGN
= free postage
Temporary Notes: a letter sign Free of Charge',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 114,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59095,
      ),
      'sjis' => 
      array (
        0 => 63867,
      ),
      'jis' => 
      array (
        0 => 30581,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 299,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58744,
      ),
      'sjis' => 
      array (
        0 => 63381,
      ),
      'jis' => 
      array (
        0 => 30581,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[FREE]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043233,
      ),
    ),
  ),
  615 => 
  array (
    'mapid' => '#e-B81',
    'unicode' => 
    array (
      0 => 127380,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED ID',
      'desc' => 'Old name: IDENTIFICATION SIGN
= identification, ID
Temporary Notes: ID ("ID" stamp)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 115,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59096,
      ),
      'sjis' => 
      array (
        0 => 63868,
      ),
      'jis' => 
      array (
        0 => 31036,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 385,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60040,
      ),
      'sjis' => 
      array (
        0 => 62299,
      ),
      'jis' => 
      array (
        0 => 31036,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 449,
      ),
      'number_old' => 
      array (
        0 => 221,
      ),
      'unicode' => 
      array (
        0 => 57897,
      ),
      'sjis' => 
      array (
        0 => 63433,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043329,
      ),
    ),
  ),
  616 => 
  array (
    'mapid' => '#e-B36',
    'unicode' => 
    array (
      0 => 127381,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED NEW',
      'desc' => 'Old name: NEW SIGN
Temporary Notes: a stamp, seal, sign',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 120,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59101,
      ),
      'sjis' => 
      array (
        0 => 63874,
      ),
      'jis' => 
      array (
        0 => 30823,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 334,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58805,
      ),
      'sjis' => 
      array (
        0 => 63461,
      ),
      'jis' => 
      array (
        0 => 30823,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 437,
      ),
      'number_old' => 
      array (
        0 => 198,
      ),
      'unicode' => 
      array (
        0 => 57874,
      ),
      'sjis' => 
      array (
        0 => 63410,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043254,
      ),
    ),
  ),
  617 => 
  array (
    'mapid' => '#e-B28',
    'unicode' => 
    array (
      0 => 127382,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED NG',
      'desc' => 'Old name: NO GOOD SIGN
= no good
Temporary Notes: no good, NG',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59183,
      ),
      'sjis' => 
      array (
        0 => 63956,
      ),
      'jis' => 
      array (
        0 => 32310,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[NG]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[NG]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043240,
      ),
    ),
  ),
  618 => 
  array (
    'mapid' => '#e-B27',
    'unicode' => 
    array (
      0 => 127383,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED OK',
      'desc' => 'Old name: OK SIGN
Temporary Notes: a stamp, seal, button for approval',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 135,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59147,
      ),
      'sjis' => 
      array (
        0 => 63920,
      ),
      'jis' => 
      array (
        0 => 30796,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 326,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58797,
      ),
      'sjis' => 
      array (
        0 => 63434,
      ),
      'jis' => 
      array (
        0 => 30796,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 435,
      ),
      'number_old' => 
      array (
        0 => 257,
      ),
      'unicode' => 
      array (
        0 => 57933,
      ),
      'sjis' => 
      array (
        0 => 63469,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043239,
      ),
    ),
  ),
  619 => 
  array (
    'mapid' => '#e-B4F',
    'unicode' => 
    array (
      0 => 127384,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED SOS',
      'desc' => 'Old name: SOS SIGN
= search, hunt for missing person',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[SOS]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 270,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58600,
      ),
      'sjis' => 
      array (
        0 => 63169,
      ),
      'jis' => 
      array (
        0 => 30275,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[SOS]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043279,
      ),
    ),
  ),
  620 => 
  array (
    'mapid' => '#e-B37',
    'unicode' => 
    array (
      0 => 127385,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED UP WITH EXCLAMATION MARK',
      'desc' => 'Old name: UP SIGN
= new information, update
Temporary Notes: site renewed, updated, new information',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[UP!]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 303,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58639,
      ),
      'sjis' => 
      array (
        0 => 63208,
      ),
      'jis' => 
      array (
        0 => 30314,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 438,
      ),
      'number_old' => 
      array (
        0 => 199,
      ),
      'unicode' => 
      array (
        0 => 57875,
      ),
      'sjis' => 
      array (
        0 => 63411,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043255,
      ),
    ),
  ),
  621 => 
  array (
    'mapid' => '#e-B32',
    'unicode' => 
    array (
      0 => 127386,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED VS',
      'desc' => 'Old name: VS SIGN
= versus',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[VS]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 363,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58834,
      ),
      'sjis' => 
      array (
        0 => 62277,
      ),
      'jis' => 
      array (
        0 => 31014,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 441,
      ),
      'number_old' => 
      array (
        0 => 136,
      ),
      'unicode' => 
      array (
        0 => 57646,
      ),
      'sjis' => 
      array (
        0 => 63342,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043250,
      ),
    ),
  ),
  622 => 
  array (
    'mapid' => '#e-B24',
    'unicode' => 
    array (
      0 => 127489,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED KATAKANA KOKO',
      'desc' => '= here sign
# <square> 30B3 30B3
Temporary Notes: KATAKANA LETTERS KOKO; destination, here',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ココ]',
    ),
    'au' => 
    array (
      'kaomoji' => '[ココ]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 440,
      ),
      'number_old' => 
      array (
        0 => 183,
      ),
      'unicode' => 
      array (
        0 => 57859,
      ),
      'sjis' => 
      array (
        0 => 63395,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043236,
      ),
    ),
  ),
  623 => 
  array (
    'mapid' => '#e-B3F',
    'unicode' => 
    array (
      0 => 127490,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED KATAKANA SA',
      'desc' => '= service sign
x (circled katakana sa - 32DA)
# <square> 30B5
Temporary Notes: サ: KATAKANA LETTER SA; service charge; for free, on the house;',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[サービス]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 384,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60039,
      ),
      'sjis' => 
      array (
        0 => 62298,
      ),
      'jis' => 
      array (
        0 => 31035,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 446,
      ),
      'number_old' => 
      array (
        0 => 220,
      ),
      'unicode' => 
      array (
        0 => 57896,
      ),
      'sjis' => 
      array (
        0 => 63432,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043263,
      ),
    ),
  ),
  624 => 
  array (
    'mapid' => '#e-B2E',
    'unicode' => 
    array (
      0 => 127538,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-7981',
      'desc' => '= prohibited sign
# <square> 7981
Temporary Notes: 禁: IDEOGRAPH PROHIBITION',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59192,
      ),
      'sjis' => 
      array (
        0 => 63965,
      ),
      'jis' => 
      array (
        0 => 32311,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[禁]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[禁]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043246,
      ),
    ),
  ),
  625 => 
  array (
    'mapid' => '#e-B2F',
    'unicode' => 
    array (
      0 => 127539,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-7A7A',
      'desc' => '= empty sign
# <square> 7A7A
Temporary Notes: 空: IDEOGRAPH EMPTY; Vacant, seats available',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59193,
      ),
      'sjis' => 
      array (
        0 => 63966,
      ),
      'jis' => 
      array (
        0 => 31038,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 387,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60042,
      ),
      'sjis' => 
      array (
        0 => 62301,
      ),
      'jis' => 
      array (
        0 => 31038,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 443,
      ),
      'number_old' => 
      array (
        0 => 223,
      ),
      'unicode' => 
      array (
        0 => 57899,
      ),
      'sjis' => 
      array (
        0 => 63435,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043247,
      ),
    ),
  ),
  626 => 
  array (
    'mapid' => '#e-B30',
    'unicode' => 
    array (
      0 => 127540,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-5408',
      'desc' => '= passed sign
# <square> 5408
Temporary Notes: 合: IDEOGRAPH MATCH; approved, passed as in an examination',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59194,
      ),
      'sjis' => 
      array (
        0 => 63967,
      ),
      'jis' => 
      array (
        0 => 32312,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[合]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[合]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043248,
      ),
    ),
  ),
  627 => 
  array (
    'mapid' => '#e-B31',
    'unicode' => 
    array (
      0 => 127541,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-6E80',
      'desc' => '= full sign
# <square> 6E80
Temporary Notes: 満: IDEOGRAPH FULL; fully occupied, full tank, etc.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59195,
      ),
      'sjis' => 
      array (
        0 => 63968,
      ),
      'jis' => 
      array (
        0 => 31037,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 386,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60041,
      ),
      'sjis' => 
      array (
        0 => 62300,
      ),
      'jis' => 
      array (
        0 => 31037,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 442,
      ),
      'number_old' => 
      array (
        0 => 222,
      ),
      'unicode' => 
      array (
        0 => 57898,
      ),
      'sjis' => 
      array (
        0 => 63434,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043249,
      ),
    ),
  ),
  628 => 
  array (
    'mapid' => '#e-B39',
    'unicode' => 
    array (
      0 => 127542,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-6709',
      'desc' => '= existence sign
x (circled ideograph have - 3292)
# <square> 6709
Temporary Notes: 有: IDEOGRAPH EXISTENCE; available, in stock; charges apply',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[有]',
    ),
    'au' => 
    array (
      'kaomoji' => '[有]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 450,
      ),
      'number_old' => 
      array (
        0 => 201,
      ),
      'unicode' => 
      array (
        0 => 57877,
      ),
      'sjis' => 
      array (
        0 => 63413,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043257,
      ),
    ),
  ),
  629 => 
  array (
    'mapid' => '#e-B3A',
    'unicode' => 
    array (
      0 => 127514,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-7121',
      'desc' => '= ARIB-9069
= non-existence sign
# <square> 7121
Temporary Notes: 無: IDEOGRAPH NON-EXISTENCE; out of stock, unavailable; free',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[無]',
    ),
    'au' => 
    array (
      'kaomoji' => '[無]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 451,
      ),
      'number_old' => 
      array (
        0 => 202,
      ),
      'unicode' => 
      array (
        0 => 57878,
      ),
      'sjis' => 
      array (
        0 => 63414,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043258,
      ),
    ),
  ),
  630 => 
  array (
    'mapid' => '#e-B3B',
    'unicode' => 
    array (
      0 => 127543,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-6708',
      'desc' => '= monthly sign
x (circled ideograph moon - 328A)
# <square> 6708
Temporary Notes: 月: IDEOGRAPH MOON; monthly charge, monthly rate; month',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[月]',
    ),
    'au' => 
    array (
      'kaomoji' => '[月]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 452,
      ),
      'number_old' => 
      array (
        0 => 203,
      ),
      'unicode' => 
      array (
        0 => 57879,
      ),
      'sjis' => 
      array (
        0 => 63415,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043259,
      ),
    ),
  ),
  631 => 
  array (
    'mapid' => '#e-B3C',
    'unicode' => 
    array (
      0 => 127544,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-7533',
      'desc' => '= application sign
# <square> 7533
Temporary Notes: 申: IDEOGRAPH SAYING "application needed, apply here"',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[申]',
    ),
    'au' => 
    array (
      'kaomoji' => '[申]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 453,
      ),
      'number_old' => 
      array (
        0 => 204,
      ),
      'unicode' => 
      array (
        0 => 57880,
      ),
      'sjis' => 
      array (
        0 => 63416,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043260,
      ),
    ),
  ),
  632 => 
  array (
    'mapid' => '#e-B3E',
    'unicode' => 
    array (
      0 => 127545,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-5272',
      'desc' => '= discount sign
# <square> 5272
Temporary Notes: 割: IDEOGRAPH DIVIDE;',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[割]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 383,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60038,
      ),
      'sjis' => 
      array (
        0 => 62297,
      ),
      'jis' => 
      array (
        0 => 31034,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 445,
      ),
      'number_old' => 
      array (
        0 => 219,
      ),
      'unicode' => 
      array (
        0 => 57895,
      ),
      'sjis' => 
      array (
        0 => 63431,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043262,
      ),
    ),
  ),
  633 => 
  array (
    'mapid' => '#e-B40',
    'unicode' => 
    array (
      0 => 127535,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-6307',
      'desc' => '= ARIB-9336
= reserved sign
"reserved" in trains, theaters, etc.
# <square> 6307
Temporary Notes: 指: IDEOGRAPH POINTING; reserved, designated 指定',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[指]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 388,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60043,
      ),
      'sjis' => 
      array (
        0 => 62302,
      ),
      'jis' => 
      array (
        0 => 31039,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 447,
      ),
      'number_old' => 
      array (
        0 => 224,
      ),
      'unicode' => 
      array (
        0 => 57900,
      ),
      'sjis' => 
      array (
        0 => 63436,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043264,
      ),
    ),
  ),
  634 => 
  array (
    'mapid' => '#e-B41',
    'unicode' => 
    array (
      0 => 127546,
    ),
    'char_name' => 
    array (
      'title' => 'SQUARED CJK UNIFIED IDEOGRAPH-55B6',
      'desc' => '= in business sign
# <square> 55B6
Temporary Notes: 営: IDEOGRAPH BUSINESS; open for business 営業中; business hours 営業時間; branch office 営業所',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[営]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 389,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60044,
      ),
      'sjis' => 
      array (
        0 => 62303,
      ),
      'jis' => 
      array (
        0 => 31040,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 448,
      ),
      'number_old' => 
      array (
        0 => 225,
      ),
      'unicode' => 
      array (
        0 => 57901,
      ),
      'sjis' => 
      array (
        0 => 63437,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043265,
      ),
    ),
  ),
  635 => 
  array (
    'mapid' => '#e-B2B',
    'unicode' => 
    array (
      0 => 12953,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCLED IDEOGRAPH SECRET',
      'desc' => '= ARIB-9083
Temporary Notes: 秘: IDEOGRAPH SECRET (TOP SECRET SIGN)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59188,
      ),
      'sjis' => 
      array (
        0 => 63961,
      ),
      'jis' => 
      array (
        0 => 30284,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 279,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58609,
      ),
      'sjis' => 
      array (
        0 => 63178,
      ),
      'jis' => 
      array (
        0 => 30284,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 455,
      ),
      'number_old' => 
      array (
        0 => 291,
      ),
      'unicode' => 
      array (
        0 => 58133,
      ),
      'sjis' => 
      array (
        0 => 63925,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043243,
      ),
    ),
  ),
  636 => 
  array (
    'mapid' => '#e-B43',
    'unicode' => 
    array (
      0 => 12951,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCLED IDEOGRAPH CONGRATULATION',
      'desc' => 'Temporary Notes: 祝: IDEOGRAPH CELEBRATION; celebration sign; congratulations; related to ㈷ U+3237 PARENTHESIZED IDEOGRAPH CONGRATULATION (= ARIB-9308)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[祝]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 402,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60057,
      ),
      'sjis' => 
      array (
        0 => 62316,
      ),
      'jis' => 
      array (
        0 => 31053,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 454,
      ),
      'number_old' => 
      array (
        0 => 283,
      ),
      'unicode' => 
      array (
        0 => 58125,
      ),
      'sjis' => 
      array (
        0 => 63917,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043267,
      ),
    ),
  ),
  637 => 
  array (
    'mapid' => '#e-B3D',
    'unicode' => 
    array (
      0 => 127568,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCLED IDEOGRAPH ADVANTAGE',
      'desc' => '= advantage sign
# <circle> 5F97
Temporary Notes: 得: IDEOGRAPH ADVANTAGE; good bargain; special tax break on public bonds',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[得]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 285,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58615,
      ),
      'sjis' => 
      array (
        0 => 63184,
      ),
      'jis' => 
      array (
        0 => 30290,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 444,
      ),
      'number_old' => 
      array (
        0 => 218,
      ),
      'unicode' => 
      array (
        0 => 57894,
      ),
      'sjis' => 
      array (
        0 => 63430,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043261,
      ),
    ),
  ),
  638 => 
  array (
    'mapid' => '#e-B50',
    'unicode' => 
    array (
      0 => 127569,
    ),
    'char_name' => 
    array (
      'title' => 'CIRCLED IDEOGRAPH ACCEPT',
      'desc' => '= accept sign
# <circle> 53EF
Temporary Notes: Han character 可; accepted, acceptable',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[可]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 506,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60161,
      ),
      'sjis' => 
      array (
        0 => 63448,
      ),
      'jis' => 
      array (
        0 => 30810,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[可]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043280,
      ),
    ),
  ),
  639 => 
  array (
    'mapid' => '#e-B51',
    'unicode' => 
    array (
      0 => 10133,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY PLUS SIGN',
      'desc' => 'Temporary Notes: Not unified with CIRCLED PLUS',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[＋]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 26,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58684,
      ),
      'sjis' => 
      array (
        0 => 63320,
      ),
      'jis' => 
      array (
        0 => 30521,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[＋]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043281,
      ),
    ),
  ),
  640 => 
  array (
    'mapid' => '#e-B52',
    'unicode' => 
    array (
      0 => 10134,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY MINUS SIGN',
      'desc' => 'Temporary Notes: Not unified with CIRCLED MINUS',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[－]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 27,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58685,
      ),
      'sjis' => 
      array (
        0 => 63321,
      ),
      'jis' => 
      array (
        0 => 30522,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[－]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043282,
      ),
    ),
  ),
  641 => 
  array (
    'mapid' => '#e-B53',
    'unicode' => 
    array (
      0 => 10006,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY MULTIPLICATION X',
      'desc' => 'Temporary Notes: Unified with U+2716 in the Dingbats block',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[×]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 55,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58703,
      ),
      'sjis' => 
      array (
        0 => 63339,
      ),
      'jis' => 
      array (
        0 => 30540,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 372,
      ),
      'number_old' => 
      array (
        0 => 321,
      ),
      'unicode' => 
      array (
        0 => 58163,
      ),
      'sjis' => 
      array (
        0 => 63955,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043283,
      ),
    ),
  ),
  642 => 
  array (
    'mapid' => '#e-B54',
    'unicode' => 
    array (
      0 => 10135,
    ),
    'char_name' => 
    array (
      'title' => 'HEAVY DIVISION SIGN',
      'desc' => 'Temporary Notes: disunified from ÷ U+00F7',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[÷]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 66,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58708,
      ),
      'sjis' => 
      array (
        0 => 63344,
      ),
      'jis' => 
      array (
        0 => 30545,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[÷]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043284,
      ),
    ),
  ),
  643 => 
  array (
    'mapid' => '#e-B55',
    'unicode' => 
    array (
      0 => 128160,
    ),
    'char_name' => 
    array (
      'title' => 'DIAMOND SHAPE WITH A DOT INSIDE',
      'desc' => '= kawaii, cute
Temporary Notes: Cute (pink diamond shaped thing)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59128,
      ),
      'sjis' => 
      array (
        0 => 63901,
      ),
      'jis' => 
      array (
        0 => 32297,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '〓',
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043285,
      ),
    ),
  ),
  644 => 
  array (
    'mapid' => '#e-B56',
    'unicode' => 
    array (
      0 => 128161,
    ),
    'char_name' => 
    array (
      'title' => 'ELECTRIC LIGHT BULB',
      'desc' => '= idea',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 151,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59131,
      ),
      'sjis' => 
      array (
        0 => 63904,
      ),
      'jis' => 
      array (
        0 => 29999,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 77,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58486,
      ),
      'sjis' => 
      array (
        0 => 63054,
      ),
      'jis' => 
      array (
        0 => 29999,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 144,
      ),
      'number_old' => 
      array (
        0 => 105,
      ),
      'unicode' => 
      array (
        0 => 57615,
      ),
      'sjis' => 
      array (
        0 => 63311,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043286,
      ),
    ),
  ),
  645 => 
  array (
    'mapid' => '#e-B57',
    'unicode' => 
    array (
      0 => 128162,
    ),
    'char_name' => 
    array (
      'title' => 'ANGER SYMBOL',
      'desc' => 'Old name: ANGER SIGN
Temporary Notes: Angry (comic book style symbol where a punch lands)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 152,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59132,
      ),
      'sjis' => 
      array (
        0 => 63905,
      ),
      'jis' => 
      array (
        0 => 30272,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 262,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58597,
      ),
      'sjis' => 
      array (
        0 => 63166,
      ),
      'jis' => 
      array (
        0 => 30272,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 79,
      ),
      'number_old' => 
      array (
        0 => 322,
      ),
      'unicode' => 
      array (
        0 => 58164,
      ),
      'sjis' => 
      array (
        0 => 63956,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043287,
      ),
    ),
  ),
  646 => 
  array (
    'mapid' => '#e-B58',
    'unicode' => 
    array (
      0 => 128163,
    ),
    'char_name' => 
    array (
      'title' => 'BOMB',
      'desc' => 'Temporary Notes: Bomb (about to blow up)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 154,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59134,
      ),
      'sjis' => 
      array (
        0 => 63907,
      ),
      'jis' => 
      array (
        0 => 30003,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 268,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58490,
      ),
      'sjis' => 
      array (
        0 => 63058,
      ),
      'jis' => 
      array (
        0 => 30003,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 149,
      ),
      'number_old' => 
      array (
        0 => 287,
      ),
      'unicode' => 
      array (
        0 => 58129,
      ),
      'sjis' => 
      array (
        0 => 63921,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043288,
      ),
    ),
  ),
  647 => 
  array (
    'mapid' => '#e-B59',
    'unicode' => 
    array (
      0 => 128164,
    ),
    'char_name' => 
    array (
      'title' => 'SLEEPING SYMBOL',
      'desc' => 'Old name: SLEEPING SIGN
Temporary Notes: Sleepy ("zzz")',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 157,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59137,
      ),
      'sjis' => 
      array (
        0 => 63910,
      ),
      'jis' => 
      array (
        0 => 29998,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 261,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58485,
      ),
      'sjis' => 
      array (
        0 => 63053,
      ),
      'jis' => 
      array (
        0 => 29998,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 78,
      ),
      'number_old' => 
      array (
        0 => 150,
      ),
      'unicode' => 
      array (
        0 => 57660,
      ),
      'sjis' => 
      array (
        0 => 63356,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043289,
      ),
    ),
  ),
  648 => 
  array (
    'mapid' => '#e-B5A',
    'unicode' => 
    array (
      0 => 128165,
    ),
    'char_name' => 
    array (
      'title' => 'COLLISION SYMBOL',
      'desc' => 'Temporary Notes: Bump (collision)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 161,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59141,
      ),
      'sjis' => 
      array (
        0 => 63914,
      ),
      'jis' => 
      array (
        0 => 30799,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 329,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58800,
      ),
      'sjis' => 
      array (
        0 => 63437,
      ),
      'jis' => 
      array (
        0 => 30799,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ドンッ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043290,
      ),
    ),
  ),
  649 => 
  array (
    'mapid' => '#e-B5B',
    'unicode' => 
    array (
      0 => 128166,
    ),
    'char_name' => 
    array (
      'title' => 'SPLASHING SWEAT SYMBOL',
      'desc' => 'Old name: SPLASHING SWEAT
Temporary Notes: Sweat',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 162,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59142,
      ),
      'sjis' => 
      array (
        0 => 63915,
      ),
      'jis' => 
      array (
        0 => 30800,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 330,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58801,
      ),
      'sjis' => 
      array (
        0 => 63438,
      ),
      'jis' => 
      array (
        0 => 30800,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 77,
      ),
      'number_old' => 
      array (
        0 => 319,
      ),
      'unicode' => 
      array (
        0 => 58161,
      ),
      'sjis' => 
      array (
        0 => 63953,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043291,
      ),
    ),
  ),
  650 => 
  array (
    'mapid' => '#e-B5C',
    'unicode' => 
    array (
      0 => 128167,
    ),
    'char_name' => 
    array (
      'title' => 'DROPLET',
      'desc' => 'Old name: DROP OF WATER, DRIP
* represents a drop of sweat or drop of water
Temporary Notes: sweat drip; tear drop',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 163,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59143,
      ),
      'sjis' => 
      array (
        0 => 63916,
      ),
      'jis' => 
      array (
        0 => 30273,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 263,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58598,
      ),
      'sjis' => 
      array (
        0 => 63167,
      ),
      'jis' => 
      array (
        0 => 30273,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 77,
      ),
      'number_old' => 
      array (
        0 => 319,
      ),
      'unicode' => 
      array (
        0 => 58161,
      ),
      'sjis' => 
      array (
        0 => 63953,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043292,
      ),
    ),
  ),
  651 => 
  array (
    'mapid' => '#e-B5D',
    'unicode' => 
    array (
      0 => 128168,
    ),
    'char_name' => 
    array (
      'title' => 'DASH SYMBOL',
      'desc' => '= running dash
Temporary Notes: Dash (running dash … the cloud of dust left behind)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 164,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59144,
      ),
      'sjis' => 
      array (
        0 => 63917,
      ),
      'jis' => 
      array (
        0 => 30287,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 282,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58612,
      ),
      'sjis' => 
      array (
        0 => 63181,
      ),
      'jis' => 
      array (
        0 => 30287,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
        0 => 318,
      ),
      'unicode' => 
      array (
        0 => 58160,
      ),
      'sjis' => 
      array (
        0 => 63952,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043293,
      ),
    ),
  ),
  652 => 
  array (
    'mapid' => '#e-4F4',
    'unicode' => 
    array (
      0 => 128169,
    ),
    'char_name' => 
    array (
      'title' => 'PILE OF POO',
      'desc' => 'Old name: DUNG
= dog dirt',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ウンチ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 283,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58613,
      ),
      'sjis' => 
      array (
        0 => 63182,
      ),
      'jis' => 
      array (
        0 => 30288,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 302,
      ),
      'number_old' => 
      array (
        0 => 90,
      ),
      'unicode' => 
      array (
        0 => 57434,
      ),
      'sjis' => 
      array (
        0 => 63899,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041652,
      ),
    ),
  ),
  653 => 
  array (
    'mapid' => '#e-B5E',
    'unicode' => 
    array (
      0 => 128170,
    ),
    'char_name' => 
    array (
      'title' => 'FLEXED BICEPS',
      'desc' => '= strong, muscled',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[力こぶ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 271,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58601,
      ),
      'sjis' => 
      array (
        0 => 63170,
      ),
      'jis' => 
      array (
        0 => 30276,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 62,
      ),
      'number_old' => 
      array (
        0 => 166,
      ),
      'unicode' => 
      array (
        0 => 57676,
      ),
      'sjis' => 
      array (
        0 => 63373,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043294,
      ),
    ),
  ),
  654 => 
  array (
    'mapid' => '#e-B5F',
    'unicode' => 
    array (
      0 => 128171,
    ),
    'char_name' => 
    array (
      'title' => 'DIZZY SYMBOL',
      'desc' => '= circling stars',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[クラクラ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 778,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60252,
      ),
      'sjis' => 
      array (
        0 => 62560,
      ),
      'jis' => 
      array (
        0 => 31553,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 19,
      ),
      'number_old' => 
      array (
        0 => 354,
      ),
      'unicode' => 
      array (
        0 => 58375,
      ),
      'sjis' => 
      array (
        0 => 64327,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043295,
      ),
    ),
  ),
  655 => 
  array (
    'mapid' => '#e-532',
    'unicode' => 
    array (
      0 => 128172,
    ),
    'char_name' => 
    array (
      'title' => 'SPEECH BALLOON',
      'desc' => '= comic book conversation bubble',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[フキダシ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 86,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58621,
      ),
      'sjis' => 
      array (
        0 => 63190,
      ),
      'jis' => 
      array (
        0 => 30296,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[フキダシ]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041714,
      ),
    ),
  ),
  656 => 
  array (
    'mapid' => '#e-B60',
    'unicode' => 
    array (
      0 => 10024,
    ),
    'char_name' => 
    array (
      'title' => 'SPARKLES',
      'desc' => 'Temporary Notes: sparkling new',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 150,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59130,
      ),
      'sjis' => 
      array (
        0 => 63903,
      ),
      'jis' => 
      array (
        0 => 31071,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 420,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60075,
      ),
      'sjis' => 
      array (
        0 => 62334,
      ),
      'jis' => 
      array (
        0 => 31071,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 48,
      ),
      'number_old' => 
      array (
        0 => 316,
      ),
      'unicode' => 
      array (
        0 => 58158,
      ),
      'sjis' => 
      array (
        0 => 63950,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043296,
      ),
    ),
  ),
  657 => 
  array (
    'mapid' => '#e-B61',
    'unicode' => 
    array (
      0 => 10036,
    ),
    'char_name' => 
    array (
      'title' => 'EIGHT POINTED BLACK STAR',
      'desc' => 'Temporary Notes: Yellow glitter, spark',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59128,
      ),
      'sjis' => 
      array (
        0 => 63901,
      ),
      'jis' => 
      array (
        0 => 32297,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 267,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58489,
      ),
      'sjis' => 
      array (
        0 => 63057,
      ),
      'jis' => 
      array (
        0 => 30002,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 461,
      ),
      'number_old' => 
      array (
        0 => 185,
      ),
      'unicode' => 
      array (
        0 => 57861,
      ),
      'sjis' => 
      array (
        0 => 63397,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043297,
      ),
    ),
  ),
  658 => 
  array (
    'mapid' => '#e-B62',
    'unicode' => 
    array (
      0 => 10035,
    ),
    'char_name' => 
    array (
      'title' => 'EIGHT SPOKED ASTERISK',
      'desc' => 'Temporary Notes: Green/blue glitter, star',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 148,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59128,
      ),
      'sjis' => 
      array (
        0 => 63901,
      ),
      'jis' => 
      array (
        0 => 32297,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 28,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58686,
      ),
      'sjis' => 
      array (
        0 => 63322,
      ),
      'jis' => 
      array (
        0 => 30523,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 462,
      ),
      'number_old' => 
      array (
        0 => 186,
      ),
      'unicode' => 
      array (
        0 => 57862,
      ),
      'sjis' => 
      array (
        0 => 63398,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043298,
      ),
    ),
  ),
  659 => 
  array (
    'mapid' => '#e-B65',
    'unicode' => 
    array (
      0 => 9898,
    ),
    'char_name' => 
    array (
      'title' => 'MEDIUM WHITE CIRCLE',
      'desc' => 'Temporary Notes: Small circle (red)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 23,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58682,
      ),
      'sjis' => 
      array (
        0 => 63318,
      ),
      'jis' => 
      array (
        0 => 30519,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 459,
      ),
      'number_old' => 
      array (
        0 => 205,
      ),
      'unicode' => 
      array (
        0 => 57881,
      ),
      'sjis' => 
      array (
        0 => 63417,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043301,
      ),
    ),
  ),
  660 => 
  array (
    'mapid' => '#e-B66',
    'unicode' => 
    array (
      0 => 9899,
    ),
    'char_name' => 
    array (
      'title' => 'MEDIUM BLACK CIRCLE',
      'desc' => 'Temporary Notes: Small circle (blue)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 24,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58683,
      ),
      'sjis' => 
      array (
        0 => 63319,
      ),
      'jis' => 
      array (
        0 => 30520,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 459,
      ),
      'number_old' => 
      array (
        0 => 205,
      ),
      'unicode' => 
      array (
        0 => 57881,
      ),
      'sjis' => 
      array (
        0 => 63417,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043302,
      ),
    ),
  ),
  661 => 
  array (
    'mapid' => '#e-B63',
    'unicode' => 
    array (
      0 => 128308,
    ),
    'char_name' => 
    array (
      'title' => 'LARGE RED CIRCLE',
      'desc' => 'Old name: LARGE CIRCLE-1
x (large circle - 25EF)
x (black large circle - 2B24)
Temporary Notes: Large circle (red). Disunified from ○ U+25CB and ◯ U+25EF due to source separation rule (Shift_JIS). Disunified from ARIB-9104=U+2B58 HEAVY CIRCLE because of different semantics. Not "WHITE LARGE CIRCLE" because the counterpart to ⬤ U+2B24 BLACK LARGE CIRCLE is ◯ LARGE CIRCLE.
Design Note: Same basic shape as for ⬤ U+2B24 BLACK LARGE CIRCLE.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 40,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58698,
      ),
      'sjis' => 
      array (
        0 => 63334,
      ),
      'jis' => 
      array (
        0 => 30535,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 459,
      ),
      'number_old' => 
      array (
        0 => 205,
      ),
      'unicode' => 
      array (
        0 => 57881,
      ),
      'sjis' => 
      array (
        0 => 63417,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043299,
      ),
    ),
  ),
  662 => 
  array (
    'mapid' => '#e-B64',
    'unicode' => 
    array (
      0 => 128309,
    ),
    'char_name' => 
    array (
      'title' => 'LARGE BLUE CIRCLE',
      'desc' => 'Old name: LARGE CIRCLE-2
x (large circle - 25EF)
x (heavy large circle - 2B55)
Temporary Notes: Large circle (blue). disunified from U+25CF due to source separation rule (Shift_JIS).
Design Note: Same basic shape as for ⬤ U+2B24 BLACK LARGE CIRCLE.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 41,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58699,
      ),
      'sjis' => 
      array (
        0 => 63335,
      ),
      'jis' => 
      array (
        0 => 30536,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043300,
      ),
    ),
  ),
  663 => 
  array (
    'mapid' => '#e-BA3',
    'unicode' => 
    array (
      0 => 128306,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK SQUARE BUTTON',
      'desc' => 'Old name: BLACK ROUNDED SQUARE
Design Note: Same shapes for e-BA3 and e-B67.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 41,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58699,
      ),
      'sjis' => 
      array (
        0 => 63335,
      ),
      'jis' => 
      array (
        0 => 30536,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043300,
      ),
    ),
  ),
  664 => 
  array (
    'mapid' => '#e-B67',
    'unicode' => 
    array (
      0 => 128307,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE SQUARE BUTTON',
      'desc' => 'Old name: WHITE ROUNDED SQUARE
Design Note: Same shapes for e-BA3 and e-B67.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 95,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59036,
      ),
      'sjis' => 
      array (
        0 => 63808,
      ),
      'jis' => 
      array (
        0 => 30791,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 41,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58699,
      ),
      'sjis' => 
      array (
        0 => 63335,
      ),
      'jis' => 
      array (
        0 => 30536,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043303,
      ),
    ),
  ),
  665 => 
  array (
    'mapid' => '#e-B68',
    'unicode' => 
    array (
      0 => 11088,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE MEDIUM STAR',
      'desc' => 'Temporary Notes: disunified from ★ U+2605 BLACK STAR and ☆ U+2606 WHITE STAR due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[☆]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 69,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58507,
      ),
      'sjis' => 
      array (
        0 => 63075,
      ),
      'jis' => 
      array (
        0 => 30020,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 49,
      ),
      'number_old' => 
      array (
        0 => 317,
      ),
      'unicode' => 
      array (
        0 => 58159,
      ),
      'sjis' => 
      array (
        0 => 63951,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043304,
      ),
    ),
  ),
  666 => 
  array (
    'mapid' => '#e-B6B',
    'unicode' => 
    array (
      0 => 11036,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE LARGE SQUARE',
      'desc' => 'Temporary Notes: Extra large square (orange). disunified from U+25A1 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 38,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58696,
      ),
      'sjis' => 
      array (
        0 => 63332,
      ),
      'jis' => 
      array (
        0 => 30533,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043307,
      ),
    ),
  ),
  667 => 
  array (
    'mapid' => '#e-B6C',
    'unicode' => 
    array (
      0 => 11035,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK LARGE SQUARE',
      'desc' => '= ARIB-9064
Temporary Notes: Extra large square (green). disunified from U+25A0 due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 39,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58697,
      ),
      'sjis' => 
      array (
        0 => 63333,
      ),
      'jis' => 
      array (
        0 => 30534,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043308,
      ),
    ),
  ),
  668 => 
  array (
    'mapid' => '#e-B6D',
    'unicode' => 
    array (
      0 => 9643,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE SMALL SQUARE',
      'desc' => 'Temporary Notes: Small square (orange)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 9,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58673,
      ),
      'sjis' => 
      array (
        0 => 63309,
      ),
      'jis' => 
      array (
        0 => 30510,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043309,
      ),
    ),
  ),
  669 => 
  array (
    'mapid' => '#e-B6E',
    'unicode' => 
    array (
      0 => 9642,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK SMALL SQUARE',
      'desc' => 'Temporary Notes: Small square (green)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 10,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58674,
      ),
      'sjis' => 
      array (
        0 => 63310,
      ),
      'jis' => 
      array (
        0 => 30511,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043310,
      ),
    ),
  ),
  670 => 
  array (
    'mapid' => '#e-B6F',
    'unicode' => 
    array (
      0 => 9725,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE MEDIUM SMALL SQUARE',
      'desc' => 'Temporary Notes: Medium square (orange)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 17,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58676,
      ),
      'sjis' => 
      array (
        0 => 63312,
      ),
      'jis' => 
      array (
        0 => 30513,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043311,
      ),
    ),
  ),
  671 => 
  array (
    'mapid' => '#e-B70',
    'unicode' => 
    array (
      0 => 9726,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK MEDIUM SMALL SQUARE',
      'desc' => 'Temporary Notes: Medium square (green)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 18,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58677,
      ),
      'sjis' => 
      array (
        0 => 63313,
      ),
      'jis' => 
      array (
        0 => 30514,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043312,
      ),
    ),
  ),
  672 => 
  array (
    'mapid' => '#e-B71',
    'unicode' => 
    array (
      0 => 9723,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE MEDIUM SQUARE',
      'desc' => 'Temporary Notes: Large square (orange)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 21,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58680,
      ),
      'sjis' => 
      array (
        0 => 63316,
      ),
      'jis' => 
      array (
        0 => 30517,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043313,
      ),
    ),
  ),
  673 => 
  array (
    'mapid' => '#e-B72',
    'unicode' => 
    array (
      0 => 9724,
    ),
    'char_name' => 
    array (
      'title' => 'BLACK MEDIUM SQUARE',
      'desc' => 'Temporary Notes: Large square (green)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '■',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 22,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58681,
      ),
      'sjis' => 
      array (
        0 => 63317,
      ),
      'jis' => 
      array (
        0 => 30518,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
        0 => 206,
      ),
      'unicode' => 
      array (
        0 => 57882,
      ),
      'sjis' => 
      array (
        0 => 63418,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043314,
      ),
    ),
  ),
  674 => 
  array (
    'mapid' => '#e-B73',
    'unicode' => 
    array (
      0 => 128310,
    ),
    'char_name' => 
    array (
      'title' => 'LARGE ORANGE DIAMOND',
      'desc' => 'Old name: LARGE DIAMOND-1
Temporary Notes: Large diamond (orange). disunified from ◇ U+25C7 WHITE DIAMOND due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '◆',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 36,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58694,
      ),
      'sjis' => 
      array (
        0 => 63330,
      ),
      'jis' => 
      array (
        0 => 30531,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043315,
      ),
    ),
  ),
  675 => 
  array (
    'mapid' => '#e-B74',
    'unicode' => 
    array (
      0 => 128311,
    ),
    'char_name' => 
    array (
      'title' => 'LARGE BLUE DIAMOND',
      'desc' => 'Old name: LARGE DIAMOND-2
Temporary Notes: Large diamond (blue). disunified from ◆ U+25C6 BLACK DIAMOND due to source separation rule (Shift_JIS).',
    ),
    'docomo' => 
    array (
      'kaomoji' => '◆',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 37,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58695,
      ),
      'sjis' => 
      array (
        0 => 63331,
      ),
      'jis' => 
      array (
        0 => 30532,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043316,
      ),
    ),
  ),
  676 => 
  array (
    'mapid' => '#e-B75',
    'unicode' => 
    array (
      0 => 128312,
    ),
    'char_name' => 
    array (
      'title' => 'SMALL ORANGE DIAMOND',
      'desc' => 'Old name: SMALL DIAMOND-1
Temporary Notes: Small diamond (orange).
Design Note: Same basic shape as ⬩ U+2B29 BLACK SMALL DIAMOND',
    ),
    'docomo' => 
    array (
      'kaomoji' => '◆',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 19,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58678,
      ),
      'sjis' => 
      array (
        0 => 63314,
      ),
      'jis' => 
      array (
        0 => 30515,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043317,
      ),
    ),
  ),
  677 => 
  array (
    'mapid' => '#e-B76',
    'unicode' => 
    array (
      0 => 128313,
    ),
    'char_name' => 
    array (
      'title' => 'SMALL BLUE DIAMOND',
      'desc' => 'Old name: SMALL DIAMOND-2
Temporary Notes: Small diamond (blue).
Design Note: Same basic shape as ⬩ U+2B29 BLACK SMALL DIAMOND',
    ),
    'docomo' => 
    array (
      'kaomoji' => '◆',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 20,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58679,
      ),
      'sjis' => 
      array (
        0 => 63315,
      ),
      'jis' => 
      array (
        0 => 30516,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 464,
      ),
      'number_old' => 
      array (
        0 => 207,
      ),
      'unicode' => 
      array (
        0 => 57883,
      ),
      'sjis' => 
      array (
        0 => 63419,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043318,
      ),
    ),
  ),
  678 => 
  array (
    'mapid' => '#e-B77',
    'unicode' => 
    array (
      0 => 10055,
    ),
    'char_name' => 
    array (
      'title' => 'SPARKLE',
      'desc' => 'Temporary Notes: Spark',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 150,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59130,
      ),
      'sjis' => 
      array (
        0 => 63903,
      ),
      'jis' => 
      array (
        0 => 31071,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 76,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58476,
      ),
      'sjis' => 
      array (
        0 => 63044,
      ),
      'jis' => 
      array (
        0 => 29989,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 48,
      ),
      'number_old' => 
      array (
        0 => 316,
      ),
      'unicode' => 
      array (
        0 => 58158,
      ),
      'sjis' => 
      array (
        0 => 63950,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043319,
      ),
    ),
  ),
  679 => 
  array (
    'mapid' => '#e-B7A',
    'unicode' => 
    array (
      0 => 128174,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE FLOWER',
      'desc' => '= brilliant homework
Temporary Notes: ❀ U+2740 WHITE FLORETTE?; Symbol that a teacher writes on homework for "brilliant!" (花丸)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[花丸]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 278,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58608,
      ),
      'sjis' => 
      array (
        0 => 63177,
      ),
      'jis' => 
      array (
        0 => 30283,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[花丸]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043322,
      ),
    ),
  ),
  680 => 
  array (
    'mapid' => '#e-B7B',
    'unicode' => 
    array (
      0 => 128175,
    ),
    'char_name' => 
    array (
      'title' => 'HUNDRED POINTS SYMBOL',
      'desc' => '= perfect score
Temporary Notes: 100 (perfect score), e.g. school exam',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[100点]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 280,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58610,
      ),
      'sjis' => 
      array (
        0 => 63179,
      ),
      'jis' => 
      array (
        0 => 30285,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[100点]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043323,
      ),
    ),
  ),
  681 => 
  array (
    'mapid' => '#e-B83',
    'unicode' => 
    array (
      0 => 8617,
    ),
    'char_name' => 
    array (
      'title' => 'LEFTWARDS ARROW WITH HOOK',
      'desc' => 'Temporary Notes: Continue (the [enter] key arrow)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 117,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59098,
      ),
      'sjis' => 
      array (
        0 => 63870,
      ),
      'jis' => 
      array (
        0 => 30554,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 118,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58717,
      ),
      'sjis' => 
      array (
        0 => 63353,
      ),
      'jis' => 
      array (
        0 => 30554,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '←┘',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043331,
      ),
    ),
  ),
  682 => 
  array (
    'mapid' => '#e-B88',
    'unicode' => 
    array (
      0 => 8618,
    ),
    'char_name' => 
    array (
      'title' => 'RIGHTWARDS ARROW WITH HOOK',
      'desc' => 'Temporary Notes: Enter arrow (backwards)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '└→',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 117,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58716,
      ),
      'sjis' => 
      array (
        0 => 63352,
      ),
      'jis' => 
      array (
        0 => 30553,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '└→',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043336,
      ),
    ),
  ),
  683 => 
  array (
    'mapid' => '#e-B91',
    'unicode' => 
    array (
      0 => 128259,
    ),
    'char_name' => 
    array (
      'title' => 'CLOCKWISE DOWNWARDS AND UPWARDS OPEN CIRCLE ARROWS',
      'desc' => 'Old name: DOUBLE CLOCKWISE OPEN CIRCLE ARROWS
= reload',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59189,
      ),
      'sjis' => 
      array (
        0 => 63962,
      ),
      'jis' => 
      array (
        0 => 31582,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 518,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60173,
      ),
      'sjis' => 
      array (
        0 => 63460,
      ),
      'jis' => 
      array (
        0 => 30822,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '↑↓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043345,
      ),
    ),
  ),
  684 => 
  array (
    'mapid' => '#e-821',
    'unicode' => 
    array (
      0 => 128266,
    ),
    'char_name' => 
    array (
      'title' => 'SPEAKER WITH THREE SOUND WAVES',
      'desc' => '= sound',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[スピーカ]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 13,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58641,
      ),
      'sjis' => 
      array (
        0 => 63210,
      ),
      'jis' => 
      array (
        0 => 30316,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 250,
      ),
      'number_old' => 
      array (
        0 => 155,
      ),
      'unicode' => 
      array (
        0 => 57665,
      ),
      'sjis' => 
      array (
        0 => 63362,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1042465,
      ),
    ),
  ),
  685 => 
  array (
    'mapid' => '#e-4FC',
    'unicode' => 
    array (
      0 => 128267,
    ),
    'char_name' => 
    array (
      'title' => 'BATTERY',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[電池]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 135,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58756,
      ),
      'sjis' => 
      array (
        0 => 63393,
      ),
      'jis' => 
      array (
        0 => 30755,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[電池]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041660,
      ),
    ),
  ),
  686 => 
  array (
    'mapid' => '#e-4FE',
    'unicode' => 
    array (
      0 => 128268,
    ),
    'char_name' => 
    array (
      'title' => 'ELECTRIC PLUG',
      'desc' => 'Temporary Notes: wall outlet',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[コンセント]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 162,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58761,
      ),
      'sjis' => 
      array (
        0 => 63398,
      ),
      'jis' => 
      array (
        0 => 30760,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[コンセント]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041662,
      ),
    ),
  ),
  687 => 
  array (
    'mapid' => '#e-B85',
    'unicode' => 
    array (
      0 => 128269,
    ),
    'char_name' => 
    array (
      'title' => 'LEFT-POINTING MAGNIFYING GLASS',
      'desc' => '= search',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 119,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59100,
      ),
      'sjis' => 
      array (
        0 => 63873,
      ),
      'jis' => 
      array (
        0 => 30323,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 119,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58648,
      ),
      'sjis' => 
      array (
        0 => 63217,
      ),
      'jis' => 
      array (
        0 => 30323,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
        0 => 110,
      ),
      'unicode' => 
      array (
        0 => 57620,
      ),
      'sjis' => 
      array (
        0 => 63316,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043333,
      ),
    ),
  ),
  688 => 
  array (
    'mapid' => '#e-B8D',
    'unicode' => 
    array (
      0 => 128270,
    ),
    'char_name' => 
    array (
      'title' => 'RIGHT-POINTING MAGNIFYING GLASS',
      'desc' => '= get more details',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 119,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59100,
      ),
      'sjis' => 
      array (
        0 => 63873,
      ),
      'jis' => 
      array (
        0 => 30323,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 510,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60165,
      ),
      'sjis' => 
      array (
        0 => 63452,
      ),
      'jis' => 
      array (
        0 => 30814,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 143,
      ),
      'number_old' => 
      array (
        0 => 110,
      ),
      'unicode' => 
      array (
        0 => 57620,
      ),
      'sjis' => 
      array (
        0 => 63316,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043341,
      ),
    ),
  ),
  689 => 
  array (
    'mapid' => '#e-B86',
    'unicode' => 
    array (
      0 => 128274,
    ),
    'char_name' => 
    array (
      'title' => 'LOCK',
      'desc' => '= padlock in locked position
Temporary Notes: Lock (closed padlock)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59097,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 138,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58652,
      ),
      'sjis' => 
      array (
        0 => 63221,
      ),
      'jis' => 
      array (
        0 => 30327,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 233,
      ),
      'number_old' => 
      array (
        0 => 158,
      ),
      'unicode' => 
      array (
        0 => 57668,
      ),
      'sjis' => 
      array (
        0 => 63365,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043334,
      ),
    ),
  ),
  690 => 
  array (
    'mapid' => '#e-B87',
    'unicode' => 
    array (
      0 => 128275,
    ),
    'char_name' => 
    array (
      'title' => 'OPEN LOCK',
      'desc' => 'Temporary Notes: Lock (open padlock)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59097,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 138,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58652,
      ),
      'sjis' => 
      array (
        0 => 63221,
      ),
      'jis' => 
      array (
        0 => 30327,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 234,
      ),
      'number_old' => 
      array (
        0 => 159,
      ),
      'unicode' => 
      array (
        0 => 57669,
      ),
      'sjis' => 
      array (
        0 => 63366,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043335,
      ),
    ),
  ),
  691 => 
  array (
    'mapid' => '#e-B90',
    'unicode' => 
    array (
      0 => 128271,
    ),
    'char_name' => 
    array (
      'title' => 'LOCK WITH INK PEN',
      'desc' => '= privacy
Temporary Notes: (padlock with ink pen)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59097,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 517,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60172,
      ),
      'sjis' => 
      array (
        0 => 63459,
      ),
      'jis' => 
      array (
        0 => 30821,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 233,
      ),
      'number_old' => 
      array (
        0 => 158,
      ),
      'unicode' => 
      array (
        0 => 57668,
      ),
      'sjis' => 
      array (
        0 => 63365,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043344,
      ),
    ),
  ),
  692 => 
  array (
    'mapid' => '#e-B8A',
    'unicode' => 
    array (
      0 => 128272,
    ),
    'char_name' => 
    array (
      'title' => 'CLOSED LOCK WITH KEY',
      'desc' => '= secure
Temporary Notes: (lock with certificate)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59097,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 501,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60156,
      ),
      'sjis' => 
      array (
        0 => 63443,
      ),
      'jis' => 
      array (
        0 => 30805,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 233,
      ),
      'number_old' => 
      array (
        0 => 158,
      ),
      'unicode' => 
      array (
        0 => 57668,
      ),
      'sjis' => 
      array (
        0 => 63365,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043338,
      ),
    ),
  ),
  693 => 
  array (
    'mapid' => '#e-B82',
    'unicode' => 
    array (
      0 => 128273,
    ),
    'char_name' => 
    array (
      'title' => 'KEY',
      'desc' => 'Temporary Notes: Password (key). Not unified with ARIB-9071=U+26BF SQUARED KEY because no carrier shows this key in an enclosing square.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 116,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59097,
      ),
      'sjis' => 
      array (
        0 => 63869,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 120,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58649,
      ),
      'sjis' => 
      array (
        0 => 63218,
      ),
      'jis' => 
      array (
        0 => 30324,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 232,
      ),
      'number_old' => 
      array (
        0 => 63,
      ),
      'unicode' => 
      array (
        0 => 57407,
      ),
      'sjis' => 
      array (
        0 => 63872,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043330,
      ),
    ),
  ),
  694 => 
  array (
    'mapid' => '#e-4F2',
    'unicode' => 
    array (
      0 => 128276,
    ),
    'char_name' => 
    array (
      'title' => 'BELL',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59155,
      ),
      'sjis' => 
      array (
        0 => 63928,
      ),
      'jis' => 
      array (
        0 => 30317,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 48,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58642,
      ),
      'sjis' => 
      array (
        0 => 63211,
      ),
      'jis' => 
      array (
        0 => 30317,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 142,
      ),
      'number_old' => 
      array (
        0 => 307,
      ),
      'unicode' => 
      array (
        0 => 58149,
      ),
      'sjis' => 
      array (
        0 => 63941,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1041650,
      ),
    ),
  ),
  695 => 
  array (
    'mapid' => '#e-B8B',
    'unicode' => 
    array (
      0 => 9745,
    ),
    'char_name' => 
    array (
      'title' => 'BALLOT BOX WITH CHECK',
      'desc' => 'Temporary Notes: Checked checkbox',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 507,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60162,
      ),
      'sjis' => 
      array (
        0 => 63449,
      ),
      'jis' => 
      array (
        0 => 30811,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043339,
      ),
    ),
  ),
  696 => 
  array (
    'mapid' => '#e-B8C',
    'unicode' => 
    array (
      0 => 128280,
    ),
    'char_name' => 
    array (
      'title' => 'RADIO BUTTON',
      'desc' => 'Temporary Notes: Selected radio button',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ラジオボタン]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 509,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60164,
      ),
      'sjis' => 
      array (
        0 => 63451,
      ),
      'jis' => 
      array (
        0 => 30813,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ラジオボタン]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043340,
      ),
    ),
  ),
  697 => 
  array (
    'mapid' => '#e-B8F',
    'unicode' => 
    array (
      0 => 128278,
    ),
    'char_name' => 
    array (
      'title' => 'BOOKMARK',
      'desc' => 'Temporary Notes: Bookmark list ("お気に入り")',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[ブックマーク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 512,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60167,
      ),
      'sjis' => 
      array (
        0 => 63454,
      ),
      'jis' => 
      array (
        0 => 30816,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ブックマーク]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043343,
      ),
    ),
  ),
  698 => 
  array (
    'mapid' => '#e-B4B',
    'unicode' => 
    array (
      0 => 128279,
    ),
    'char_name' => 
    array (
      'title' => 'LINK SYMBOL',
      'desc' => 'Temporary Notes: Disunified from ♾ U+267E PERMANENT PAPER SIGN; Link with a twist',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[リンク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 164,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58762,
      ),
      'sjis' => 
      array (
        0 => 63399,
      ),
      'jis' => 
      array (
        0 => 30761,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[リンク]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043275,
      ),
    ),
  ),
  699 => 
  array (
    'mapid' => '#e-B8E',
    'unicode' => 
    array (
      0 => 128281,
    ),
    'char_name' => 
    array (
      'title' => 'BACK WITH LEFTWARDS ARROW ABOVE',
      'desc' => 'Old name: BACK WITH LEFT ARROW ABOVE
Temporary Notes: Back (left arrow with "BACK")',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[←BACK]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 511,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60166,
      ),
      'sjis' => 
      array (
        0 => 63453,
      ),
      'jis' => 
      array (
        0 => 30815,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 384,
      ),
      'number_old' => 
      array (
        0 => 233,
      ),
      'unicode' => 
      array (
        0 => 57909,
      ),
      'sjis' => 
      array (
        0 => 63445,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043342,
      ),
    ),
  ),
  700 => 
  array (
    'mapid' => '#e-01A',
    'unicode' => 
    array (
      0 => 128282,
    ),
    'char_name' => 
    array (
      'title' => 'END WITH LEFTWARDS ARROW ABOVE',
      'desc' => 'Old name: END WITH LEFT ARROW ABOVE',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 175,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59065,
      ),
      'sjis' => 
      array (
        0 => 63837,
      ),
      'jis' => 
      array (
        0 => 32303,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[end]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[end]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040410,
      ),
    ),
  ),
  701 => 
  array (
    'mapid' => '#e-019',
    'unicode' => 
    array (
      0 => 128283,
    ),
    'char_name' => 
    array (
      'title' => 'ON WITH EXCLAMATION MARK WITH LEFT RIGHT ARROW ABOVE',
      'desc' => 'Old name: ON WITH DOUBLE POINTING ARROW ABOVE',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 174,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59064,
      ),
      'sjis' => 
      array (
        0 => 63836,
      ),
      'jis' => 
      array (
        0 => 32302,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[ON]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[ON]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040409,
      ),
    ),
  ),
  702 => 
  array (
    'mapid' => '#e-018',
    'unicode' => 
    array (
      0 => 128284,
    ),
    'char_name' => 
    array (
      'title' => 'SOON WITH RIGHTWARDS ARROW ABOVE',
      'desc' => 'Old name: SOON WITH RIGHT ARROW ABOVE
Temporary Notes: soon',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 173,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59063,
      ),
      'sjis' => 
      array (
        0 => 63835,
      ),
      'jis' => 
      array (
        0 => 32301,
      ),
    ),
    'au' => 
    array (
      'kaomoji' => '[SOON]',
    ),
    'softbank' => 
    array (
      'kaomoji' => '[SOON]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1040408,
      ),
    ),
  ),
  703 => 
  array (
    'mapid' => '#e-B42',
    'unicode' => 
    array (
      0 => 128285,
    ),
    'char_name' => 
    array (
      'title' => 'TOP WITH UPWARDS ARROW ABOVE',
      'desc' => 'Old name: TOP WITH UP-POINTING TRIANGLE SIGN
= top of page',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[TOP]',
    ),
    'au' => 
    array (
      'kaomoji' => '[TOP]',
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 436,
      ),
      'number_old' => 
      array (
        0 => 256,
      ),
      'unicode' => 
      array (
        0 => 57932,
      ),
      'sjis' => 
      array (
        0 => 63468,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043266,
      ),
    ),
  ),
  704 => 
  array (
    'mapid' => '#e-B4C',
    'unicode' => 
    array (
      0 => 8195,
    ),
    'char_name' => 
    array (
      'title' => 'EM SPACE',
      'desc' => 'Temporary Notes: Note: KDDI\'s Full blank (mapped to EM SPACE)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '〓',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 173,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58764,
      ),
      'sjis' => 
      array (
        0 => 63401,
      ),
      'jis' => 
      array (
        0 => 30763,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043276,
      ),
    ),
  ),
  705 => 
  array (
    'mapid' => '#e-B4D',
    'unicode' => 
    array (
      0 => 8194,
    ),
    'char_name' => 
    array (
      'title' => 'EN SPACE',
      'desc' => 'Temporary Notes: Note: KDDI\'s Half blank (mapped to EN SPACE)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '〓',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 174,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58765,
      ),
      'sjis' => 
      array (
        0 => 63402,
      ),
      'jis' => 
      array (
        0 => 30764,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043277,
      ),
    ),
  ),
  706 => 
  array (
    'mapid' => '#e-B4E',
    'unicode' => 
    array (
      0 => 8197,
    ),
    'char_name' => 
    array (
      'title' => 'FOUR-PER-EM SPACE',
      'desc' => 'Temporary Notes: Note: KDDI\'s Quarter blank (mapped to FOUR-PER-EM SQUARE)',
    ),
    'docomo' => 
    array (
      'kaomoji' => '〓',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 175,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58766,
      ),
      'sjis' => 
      array (
        0 => 63403,
      ),
      'jis' => 
      array (
        0 => 30765,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '〓',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043278,
      ),
    ),
  ),
  707 => 
  array (
    'mapid' => '#e-B4A',
    'unicode' => 
    array (
      0 => 9989,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE HEAVY CHECK MARK',
      'desc' => 'x (heavy check mark - 2714)
Temporary Notes: Check mark (red); not unified with ✓ U+2713
Design Note: Should look like a hollow version (that is, without fill) of ✔ U+2714 HEAVY CHECK MARK.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 132,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58718,
      ),
      'sjis' => 
      array (
        0 => 63354,
      ),
      'jis' => 
      array (
        0 => 30555,
      ),
    ),
    'softbank' => 
    array (
      'kaomoji' => '[チェックマーク]',
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043274,
      ),
    ),
  ),
  708 => 
  array (
    'mapid' => '#e-B93',
    'unicode' => 
    array (
      0 => 9994,
    ),
    'char_name' => 
    array (
      'title' => 'RAISED FIST',
      'desc' => '= rock in Rock, Paper, Scissors game
x (raised hand - 270B)
x (victory hand - 270C)
Design Note: Harmonize design with ✌ U+270C VICTORY HAND Dingbat.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 86,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59027,
      ),
      'sjis' => 
      array (
        0 => 63732,
      ),
      'jis' => 
      array (
        0 => 31592,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 817,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60291,
      ),
      'sjis' => 
      array (
        0 => 62600,
      ),
      'jis' => 
      array (
        0 => 31592,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 51,
      ),
      'number_old' => 
      array (
        0 => 16,
      ),
      'unicode' => 
      array (
        0 => 57360,
      ),
      'sjis' => 
      array (
        0 => 63824,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043347,
      ),
    ),
  ),
  709 => 
  array (
    'mapid' => '#e-B95',
    'unicode' => 
    array (
      0 => 9995,
    ),
    'char_name' => 
    array (
      'title' => 'RAISED HAND',
      'desc' => '= paper in Rock, Paper, Scissors game
x (raised fist - 270A)
x (victory hand - 270C)
Design Note: Harmonize design with ✌ U+270C VICTORY HAND Dingbat.',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 88,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59029,
      ),
      'sjis' => 
      array (
        0 => 63734,
      ),
      'jis' => 
      array (
        0 => 30790,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 320,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58791,
      ),
      'sjis' => 
      array (
        0 => 63428,
      ),
      'jis' => 
      array (
        0 => 30790,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 53,
      ),
      'number_old' => 
      array (
        0 => 18,
      ),
      'unicode' => 
      array (
        0 => 57362,
      ),
      'sjis' => 
      array (
        0 => 63826,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043349,
      ),
    ),
  ),
  710 => 
  array (
    'mapid' => '#e-B94',
    'unicode' => 
    array (
      0 => 9996,
    ),
    'char_name' => 
    array (
      'title' => 'VICTORY HAND',
      'desc' => '= scissors in Rock, Paper, Scissors game
* commonly used as "Victory" sign
x (raised fist - 270A)
x (raised hand - 270B)',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 87,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59028,
      ),
      'sjis' => 
      array (
        0 => 63733,
      ),
      'jis' => 
      array (
        0 => 30789,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 319,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58790,
      ),
      'sjis' => 
      array (
        0 => 63427,
      ),
      'jis' => 
      array (
        0 => 30789,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 52,
      ),
      'number_old' => 
      array (
        0 => 17,
      ),
      'unicode' => 
      array (
        0 => 57361,
      ),
      'sjis' => 
      array (
        0 => 63825,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043348,
      ),
    ),
  ),
  711 => 
  array (
    'mapid' => '#e-B96',
    'unicode' => 
    array (
      0 => 128074,
    ),
    'char_name' => 
    array (
      'title' => 'FISTED HAND SIGN',
      'desc' => 'Old name: FISTED HAND
= punch',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 153,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59133,
      ),
      'sjis' => 
      array (
        0 => 63906,
      ),
      'jis' => 
      array (
        0 => 30286,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 281,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58611,
      ),
      'sjis' => 
      array (
        0 => 63180,
      ),
      'jis' => 
      array (
        0 => 30286,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 55,
      ),
      'number_old' => 
      array (
        0 => 13,
      ),
      'unicode' => 
      array (
        0 => 57357,
      ),
      'sjis' => 
      array (
        0 => 63821,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043350,
      ),
    ),
  ),
  712 => 
  array (
    'mapid' => '#e-B97',
    'unicode' => 
    array (
      0 => 128077,
    ),
    'char_name' => 
    array (
      'title' => 'THUMBS UP SIGN',
      'desc' => '',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59175,
      ),
      'sjis' => 
      array (
        0 => 63948,
      ),
      'jis' => 
      array (
        0 => 30292,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 287,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58617,
      ),
      'sjis' => 
      array (
        0 => 63186,
      ),
      'jis' => 
      array (
        0 => 30292,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 54,
      ),
      'number_old' => 
      array (
        0 => 14,
      ),
      'unicode' => 
      array (
        0 => 57358,
      ),
      'sjis' => 
      array (
        0 => 63822,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043351,
      ),
    ),
  ),
  713 => 
  array (
    'mapid' => '#e-B98',
    'unicode' => 
    array (
      0 => 9757,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE UP POINTING INDEX',
      'desc' => 'Temporary Notes: No. 1',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[人差し指]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 284,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58614,
      ),
      'sjis' => 
      array (
        0 => 63183,
      ),
      'jis' => 
      array (
        0 => 30289,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 56,
      ),
      'number_old' => 
      array (
        0 => 15,
      ),
      'unicode' => 
      array (
        0 => 57359,
      ),
      'sjis' => 
      array (
        0 => 63823,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043352,
      ),
    ),
  ),
  714 => 
  array (
    'mapid' => '#e-B99',
    'unicode' => 
    array (
      0 => 128070,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE UP POINTING BACKHAND INDEX',
      'desc' => 'Temporary Notes: Up
Design Note: Similar to ☝ U+261D WHITE UP POINTING INDEX but showing the back of the hand instead of the palm side.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[↑]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 390,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60045,
      ),
      'sjis' => 
      array (
        0 => 62304,
      ),
      'jis' => 
      array (
        0 => 31041,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 389,
      ),
      'number_old' => 
      array (
        0 => 226,
      ),
      'unicode' => 
      array (
        0 => 57902,
      ),
      'sjis' => 
      array (
        0 => 63438,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043353,
      ),
    ),
  ),
  715 => 
  array (
    'mapid' => '#e-B9A',
    'unicode' => 
    array (
      0 => 128071,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE DOWN POINTING BACKHAND INDEX',
      'desc' => 'Temporary Notes: Down
Design Note: Similar to ☟ U+261F WHITE DOWN POINTING INDEX but showing the back of the hand instead of the palm side.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[↓]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 391,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60046,
      ),
      'sjis' => 
      array (
        0 => 62305,
      ),
      'jis' => 
      array (
        0 => 31042,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 390,
      ),
      'number_old' => 
      array (
        0 => 227,
      ),
      'unicode' => 
      array (
        0 => 57903,
      ),
      'sjis' => 
      array (
        0 => 63439,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043354,
      ),
    ),
  ),
  716 => 
  array (
    'mapid' => '#e-B9B',
    'unicode' => 
    array (
      0 => 128072,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE LEFT POINTING BACKHAND INDEX',
      'desc' => 'Temporary Notes: Left
Design Note: Similar to ☜ U+261C WHITE LEFT POINTING INDEX but showing the back of the hand instead of the palm side.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[←]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 140,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58623,
      ),
      'sjis' => 
      array (
        0 => 63192,
      ),
      'jis' => 
      array (
        0 => 30298,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 391,
      ),
      'number_old' => 
      array (
        0 => 228,
      ),
      'unicode' => 
      array (
        0 => 57904,
      ),
      'sjis' => 
      array (
        0 => 63440,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043355,
      ),
    ),
  ),
  717 => 
  array (
    'mapid' => '#e-B9C',
    'unicode' => 
    array (
      0 => 128073,
    ),
    'char_name' => 
    array (
      'title' => 'WHITE RIGHT POINTING BACKHAND INDEX',
      'desc' => 'Temporary Notes: Right
Design Note: Similar to ☞ U+261E WHITE RIGHT POINTING INDEX but showing the back of the hand instead of the palm side.',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[→]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 141,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 58624,
      ),
      'sjis' => 
      array (
        0 => 63193,
      ),
      'jis' => 
      array (
        0 => 30299,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 392,
      ),
      'number_old' => 
      array (
        0 => 229,
      ),
      'unicode' => 
      array (
        0 => 57905,
      ),
      'sjis' => 
      array (
        0 => 63441,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043356,
      ),
    ),
  ),
  718 => 
  array (
    'mapid' => '#e-B9D',
    'unicode' => 
    array (
      0 => 128075,
    ),
    'char_name' => 
    array (
      'title' => 'WAVING HAND SIGN',
      'desc' => 'Old name: WAVING HAND
Temporary Notes: Waving hello',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 88,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59029,
      ),
      'sjis' => 
      array (
        0 => 63734,
      ),
      'jis' => 
      array (
        0 => 30790,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60118,
      ),
      'sjis' => 
      array (
        0 => 62378,
      ),
      'jis' => 
      array (
        0 => 31276,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 60,
      ),
      'number_old' => 
      array (
        0 => 377,
      ),
      'unicode' => 
      array (
        0 => 58398,
      ),
      'sjis' => 
      array (
        0 => 64350,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043357,
      ),
    ),
  ),
  719 => 
  array (
    'mapid' => '#e-B9E',
    'unicode' => 
    array (
      0 => 128079,
    ),
    'char_name' => 
    array (
      'title' => 'CLAPPING HANDS SIGN',
      'desc' => 'Old name: CLAPPING HANDS
Temporary Notes: Clapping',
    ),
    'docomo' => 
    array (
      'kaomoji' => '[拍手]',
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 460,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60115,
      ),
      'sjis' => 
      array (
        0 => 62375,
      ),
      'jis' => 
      array (
        0 => 31273,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 61,
      ),
      'number_old' => 
      array (
        0 => 378,
      ),
      'unicode' => 
      array (
        0 => 58399,
      ),
      'sjis' => 
      array (
        0 => 64351,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043358,
      ),
    ),
  ),
  720 => 
  array (
    'mapid' => '#e-B9F',
    'unicode' => 
    array (
      0 => 128076,
    ),
    'char_name' => 
    array (
      'title' => 'OK HAND SIGN',
      'desc' => 'Temporary Notes: OK sign',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 135,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59147,
      ),
      'sjis' => 
      array (
        0 => 63920,
      ),
      'jis' => 
      array (
        0 => 30796,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 461,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60116,
      ),
      'sjis' => 
      array (
        0 => 62376,
      ),
      'jis' => 
      array (
        0 => 31274,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 57,
      ),
      'number_old' => 
      array (
        0 => 379,
      ),
      'unicode' => 
      array (
        0 => 58400,
      ),
      'sjis' => 
      array (
        0 => 64352,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043359,
      ),
    ),
  ),
  721 => 
  array (
    'mapid' => '#e-BA0',
    'unicode' => 
    array (
      0 => 128078,
    ),
    'char_name' => 
    array (
      'title' => 'THUMBS DOWN SIGN',
      'desc' => 'Temporary Notes: Thumbs down',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 156,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59136,
      ),
      'sjis' => 
      array (
        0 => 63909,
      ),
      'jis' => 
      array (
        0 => 31345,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 462,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60117,
      ),
      'sjis' => 
      array (
        0 => 62377,
      ),
      'jis' => 
      array (
        0 => 31275,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 58,
      ),
      'number_old' => 
      array (
        0 => 380,
      ),
      'unicode' => 
      array (
        0 => 58401,
      ),
      'sjis' => 
      array (
        0 => 64353,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043360,
      ),
    ),
  ),
  722 => 
  array (
    'mapid' => '#e-BA1',
    'unicode' => 
    array (
      0 => 128080,
    ),
    'char_name' => 
    array (
      'title' => 'OPEN HANDS SIGN',
      'desc' => 'Old name: OPEN HANDS
Temporary Notes: Ohhaa! Good morning gesture. Open hands with the money sign',
    ),
    'docomo' => 
    array (
      'number' => 
      array (
        0 => 88,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 59029,
      ),
      'sjis' => 
      array (
        0 => 63734,
      ),
      'jis' => 
      array (
        0 => 30790,
      ),
    ),
    'au' => 
    array (
      'number' => 
      array (
        0 => 463,
      ),
      'number_old' => 
      array (
      ),
      'unicode' => 
      array (
        0 => 60118,
      ),
      'sjis' => 
      array (
        0 => 62378,
      ),
      'jis' => 
      array (
        0 => 31276,
      ),
    ),
    'softbank' => 
    array (
      'number' => 
      array (
        0 => 69,
      ),
      'number_old' => 
      array (
        0 => 381,
      ),
      'unicode' => 
      array (
        0 => 58402,
      ),
      'sjis' => 
      array (
        0 => 64354,
      ),
      'jis' => 
      array (
      ),
    ),
    'google' => 
    array (
      'unicode' => 
      array (
        0 => 1043361,
      ),
    ),
  ),
); ?>