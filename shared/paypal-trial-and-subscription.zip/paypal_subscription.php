<?

error_reporting(E_ALL);

if(isset($_GET['message'])) {
$message = '<p style="padding-top: 80px; margin-left: 20px; color: red;">Please ensure you enter an email address, User Name and password.</p>';
}
?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Paypal Registration</title>
<link type="text/css" rel="stylesheet" href="style.css" title="default" media="all" />
</head>

<body>
	<div id="form">
		<form id="register" action="register.php" name="register" method="post" onsubmit="">
		
		
		<div class="formrow">
		<?
		if(isset($message)) {
		echo $message;
		}
		?>
					<span class="label" style="margin-top: 100px;">Email:</span>
					<span class="formw" ><input name="email" type="text" size="35" value="" style="margin-top: 100px;" /></span>
				</div>
		
		<div class="formrow">
					<span class="label">Username:</span>
					<span class="formw"><input name="username" type="text" size="35" value="" /></span>
		</div>
		
        <div class="formrow">
					<span class="label">Password:</span>
					<span class="formw"><input name="password" type="password" size="35" value="" /></span>
		</div>
		
		
		<div class="formrow">
					<span class="label">&nbsp;</span>
					<span class="formw"><input type="image" src="images/subscribe.jpg" name="submit" id="submit" alt="Pay with PayPal" title="Pay with PayPal" value="Pay with PayPal" style="margin-top: 20px; margin-left: 40px;" /></span>
		</div>
		</form>	
	</div>
</body>
</html>
