<?
session_start();
include('php/config.php');

// Error checking

ini_set('display_errors',1); 
error_reporting(E_ALL);

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link type="text/css" rel="stylesheet" href="style.css" title="default" media="all" />
<title>Members Area</title>
</head>
			<div id="form">
			  <p style="padding-left: 30px; padding-top: 70px;">You're logged in as, <?=$_SESSION['username'];?></p>
                  <p style="padding-left: 30px;">Welcome to the Members Area - here you can access protected content.</p>
				  			<?
if(isset($_SESSION['username'])) {
echo '<p style="padding-left: 30px; padding-top: 20px; width: 935px;"><a href="logout.php"><img src="images/logout.jpg" title="Logout button" alt="Logout Button" /></a></p>';
?>
              </div>
<?
}
else
{
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>You must be logged in..</title>
<link rel="stylesheet" type="text/css" href="style.css" media="screen" title="style (screen)" />
</head>
<div id="container">
<div id="banner" style="border: 1px solid #666666;"><img src="images/banner.jpg" width="933" height="145" border="0" usemap="#Map" /></div>
<div id="thankyou">
<p>You must be a subscribed member to view this content. Please subscribe <a href="paypal_subscription.php">here</a></p>
<p>Or if you are a registered member already, please <a href="login.php">Login</a></p>
</div>
</div>
<?
}
?>
</body>

</html>
