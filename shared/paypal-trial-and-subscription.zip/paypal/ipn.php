<?

# Database Connection - You will need to enter your database details here
	mysql_connect('get-slim-online.com', 'web141-getslim20', 'xxxxxx');
	mysql_select_db('web141-getslim20');

// read the post from PayPal system and add 'cmd'
$req = 'cmd=_notify-validate';

foreach ($_POST as $key => $value) {
$value = urlencode(stripslashes($value));
$req .= "&$key=$value";
}

// post back to PayPal system to validate
$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
$fp = fsockopen ('ssl://www.sandbox.paypal.com', 443, $errno, $errstr, 30);
#$fp = fsockopen ('ssl://www.paypal.com', 443, $errno, $errstr, 30);

// assign posted variables to local variables
$item_name = $_POST['item_name'];
$item_number = $_POST['item_number'];
$payment_status = $_POST['payment_status'];
$payment_amount = $_POST['mc_gross'];
$payment_currency = $_POST['mc_currency'];
$subscr_id = $_POST['subscr_id'];
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$id = $_POST['custom']; // This is the ID from the user table we passed in the form

if (!$fp) {
// HTTP ERROR
} else {
fputs ($fp, $header . $req);
while (!feof($fp)) {
$res = fgets ($fp, 1024);
if (strcmp ($res, "VERIFIED") == 0) {


		// process payment
		// Added pp_trans_id which is the unique Transaction ID provided by PayPal
		// Added reg_date which is in UNIX_TIME()
		// Set WHERE to be equal to $id for perfect match
		$insert = mysql_query("UPDATE `users` SET `paid` = 1, pp_trans_id='".$subscr_id."', reg_date='".time()."' WHERE `id` = '$id'");
		$message .= "UPDATE `users` SET `paid` = 1, pp_trans_id='".$subscr_id."', reg_date='".time()."' WHERE `id` = '$id'";

}
else if (strcmp ($res, "INVALID") == 0) {

// log for manual investigation
}
}
fclose ($fp);
}
?>
