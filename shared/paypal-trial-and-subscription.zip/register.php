<?
// Makes sure no one tries to access this page directly
if ($_POST['submit']!='') {

if (empty($_POST['username']) || empty($_POST['password']) || empty($_POST['email'])) {
$subscribe = 'fail';
header('Location: paypal_subscription.php?message='.$subscribe.'');
exit;
} 
# Database Connection - You will need to enter your database details here
	mysql_connect('database_hostname', 'database_username', 'database_password');
	mysql_select_db('database_name');

# Insert record into database
	$username	= addslashes($_POST['username']);
	$password	= addslashes($_POST['password']);
	$password 	= md5($_POST['password']);
	$email		= addslashes($_POST['email']);
	$insert		= mysql_query("INSERT INTO `users` (username, password, email) VALUES ('".$username."', '".$password."', '".$email."');");
	$id 		= mysql_insert_id();
	
#Paypal Configuration
	$ppTest = true; // Set to False for Live integration
	$ppDebug = false;
	if ($ppTest) {
	#Sandbox URL
		$paypalUrl="https://www.sandbox.paypal.com/us/cgi-bin/webscr";
	#Paypal ID
		$paypalID='';
	} else {
	#Live URL
		$paypalUrl="http://www.paypal.com/cgi-bin/webscr";
	#Paypal ID - Change to your Paypal Payment Address
		$paypalID='paypal@paypal.com';
	}
	#Site URL
	$siteUrl="http://www.yourwebsite.com";
		
	#Currency Code
	$paypalCurrency='GBP';
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: redirecting to PayPal ::</title>
</head>

<?php if ($ppDebug) { ?>
<body>
<?php } else { ?>
<body onload="JavaScript: document._xclick.submit();">
<?php } ?>
<table border="0" align="center">
<?
		if(isset($message)) {
		echo $message;
		}
		?>
<tr><td align="center"><h1>Please Wait...while we redirect to PayPal.com</h1></td></tr>
<tr><td align="center"></td></tr>
</table>
<form action="<?=$paypalUrl?>" method="post" name="_xclick"/>
    <!-- This needs to be _xclick-subscriptions for the Subscriptions to work -->
    <input type="hidden" name="cmd" value="_xclick-subscriptions"/>
    <!-- This is your PayPal Email Address -->
    <input type="hidden" name="business" value="<?=$paypalID?>"/> 
    <!-- This is the Item Name which is pulled from the Database based on the form selection -->
    <input type="hidden" name="item_name" value="www.yourwebsite.com Subscription" />
    <!-- This is the Item Number that was selected. This should probably be something other than '1' for bookkeeping purpose -->
    <input type="hidden" name="item_number" value="1"/>
    <!-- This disables Shipping -->
    <input type="hidden" name="no_shipping" value="1"/>
    <!-- This identifies the currency -->
    <input type="hidden" name="currency_code" value="<?=$paypalCurrency;?>"/>
    <!-- This is the Trial Price - You can change this to any value -->
    <input type="hidden" name="a1" value="39.95" />
    <!-- This is the Trial Duration -->
    <input type="hidden" name="p1" value="3" />	
    <!-- This is the Trial Period -->
    <input type="hidden" name="t1" value="M" />
    <!-- This is the Subscription Price -->
    <input type="hidden" name="a3" value="4.95"/>
    <!-- This is the Subscription Duration -->
    <input type="hidden" name="p3" value="1"/>
    <!-- This is the Subscription Period -->
    <input type="hidden" name="t3" value="M"/>
    <!-- This enables Recurring Payments -->
    <input type="hidden" name="src" value="1"/>
    <!-- This is Reattempts on Recurring Payment on Failure before Cancelling -->
    <input type="hidden" name="sra" value="1"/>
    <!-- This is the return method  -->
    <input type="hidden" name="rm" value="2"/>
    <!-- This is the URL to return to your Site from PayPal when successfully Processed -->
    <INPUT type="hidden" name="return" value="<?=$siteUrl?>/thank_you.html"/>   
    <!-- This is the URL to return to your Site from PayPal when they cancel the checkout Process -->
    <INPUT type="hidden" name="cancel_return" value="<?=$siteUrl?>/cancel.html"/> 
    <!-- This is the URL to your Site to handle IPN -->
    <input type="hidden" name="notify_url" value="<?=$siteUrl?>/paypal/ipn.php" />
	<!-- This is the No Note option -->
	<input type="hidden" name="no_note" value="1">
    <!-- This is a custom field used to pass the ID from the user table -->
    <input type="hidden" name="custom" value="<?=$id;?>">

</form>

</body>
</html>
<?php 
} else {
	header('location: paypal_subscription.php');
	exit;
}
?>