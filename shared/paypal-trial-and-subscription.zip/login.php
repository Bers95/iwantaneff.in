<?php
ob_start();
session_start();

# Database Connection - You will need to enter your database details here
	mysql_connect('database_hostname', 'database_username', 'database_password');
	mysql_select_db('database_name');


if (isset($_POST['submit'])) {

if (empty($_POST['username']) || empty($_POST['password'])) {
$message = '<p>Please enter a User Name and Password</p>';
}
else { 		

//convert the field values to simple variables

//add slashes to the username and password
if (!get_magic_quotes_gpc()) {
$_POST['password'] = addslashes($_POST['password']);
$_POST['password'] = md5($_POST['password']);
$_POST['username'] = addslashes($_POST['username']);
}

//saying username and password are defined as variables
$sql = ('SELECT * FROM `users` WHERE `username` ="'.$_POST['username'].'"');
$res = mysql_query($sql) or die(mysql_error());
	
if(mysql_num_rows($res) > 0){
	
$sql2 = ('SELECT * FROM `users` WHERE (`username` ="'.$_POST['username'].'" AND `password` ="'.$_POST['password'].'") AND `paid` = "1"');
$res2 = mysql_query($sql2) or die(mysql_error());

if(mysql_num_rows($res2) > 0){

$row = mysql_fetch_assoc($res2);
$_SESSION['username'] = $row['username'];
header("Location: welcome.php");
}

if($row['paid'] == 0) {
$message = '<p style="color: red; margin-left: 20px;">You are not a valid subscriber.</p>';
}
else {

$message = '<p style="color: red; margin-left: 20px;">Username and Password combination is incorrect!</p>';
}
	
} else {
$message = '<p style="color: red; margin-left: 20px;">The username you supplied does not exist!</p>';
}
}
}

  ?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<title>Paypal Registration</title>
<link type="text/css" rel="stylesheet" href="style.css" title="default" media="all" />
</head>

<body>
	<div id="form">
		<form method="post" action="">
			
			<div class="formrow" style="padding-top: 100px;">
			<?
			if(isset($message)) {
			echo $message;
			}
			?>
					<span class="label">Username:</span>
					<span class="formw"><input name="username" type="text" size="35" value="" /></span>
		</div>
		
        <div class="formrow">
					<span class="label">Password:</span>
					<span class="formw"><input name="password" type="password" size="35" value="" /></span>
		</div>
						<div class="formrow" style="padding-left: 200px;">
						<input type="submit" name="submit" value="Login">
						</div>
		
			</form>
	</div>
	<? ob_flush(); ?> 
</body>
</html>
