<?php get_header(); ?>

	<div id="content">
		<div class="post">
		
			<h1>Error 404 - Not Found</h1>

		</div>
	</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>