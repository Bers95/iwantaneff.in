	</div>
	
	<div id="footer">
		<p>
			Copyright &copy; 2008. All right reserved. 
			Theme by <a href="http://deniart.ru">deniart</a>
		</p>
	</div>
</div>

</body>
</html>