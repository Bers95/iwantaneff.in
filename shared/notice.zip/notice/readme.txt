Anti Explorer is a small piece of code you can place in your site's HTML which stops Microsoft Internet Explorer (MSIE / Explorer) from rendering your page. Along-side this, a notification alerts the user he is using MSIE and prompts him / her to download Firefox instead.

We've all been there. We design our site with Internet Explorer in mind, only to find we have to resort to numerous hacks and complicated code to get our site looking like it should in MSIE. Numerous Web Citizens have written hacks and workarounds for MSIE, only to be dismayed at all the extra effort they had to put in to get their designs cross-compatible with MSIE.

Anti Explorer is very easy to setup. All you need is four lines of code, plus a notice page which you can download...

...Here: http://anti.eire-media.com/download.html

Once you download the relevent files, you can then proceed to place the code into the page you want Anti Explorer to run on.

The following code is a sample only. You must replace example.com with your own URL
[Or the location of the notice folder]

Try placing it into the HEAD HTML tag of the document.

<!--[if IE]>
<script>location.href='http://www.example.com/notice/'</script>
<noscript>
<meta http-equiv="refresh" content="0;url=http://www.example.com/notice/">
</noscript>
<![endif]-->


This folder contains the relevant Anti Explorer notice page. Do not change the filename of 'index.html' to anything else, otherwise your server will show a directory listing of the files contained herein.

Also, do not delete any of the GIF images, as they are used by 'index.html'.

For more information, visit:

http://anti.eire-media.com/

Or our support forums located here:

http://anti.eire-media.com/forum/

