function go(URL)
{
	window.location.href = URL;
}