<?php
/******************************************************************************************

	Copyright (C) 2007, 2008 da3rX (i.r.da3rx@gmail.com)

	This file is part of decode explorer.

	Decode explorer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Decode explorer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with decode explorer.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************************/


if(!defined('DECODE_EXPLORER'))
	die('DECODE_EXPLORER constant not defined.');

//Icons
$icons = array(
'acrobat'	=>	array('pdf'),
'application'	=>	array('exe'),
'code_blue' 	=>	array('css', 'js', 'sql', 'xml', 'phps'),
'code_red'	=>	array('java', 'class', 'cpp'),
'compressed'	=>	array('zip', 'rar', 'ace', 'gz', 'tar', '7z'),
'excel'		=>	array('xls', 'ods'),
'film'		=>	array('avi', 'mpg', 'mpeg', 'mov', 'wmv', 'swf', 'asf'),
'image'		=>	array('jpg', 'jpeg', 'gif', 'png', 'bmp', 'ico'),
'powerpoint'	=>	array('ppt', 'odp'),
'sound'		=>	array('mp3', 'wma', 'mid', 'midi', 'ogg', 'wav', 'ape', 'flac'),
'text'		=>	array('txt', 'nfo'),
'word'		=>	array('doc', 'rtf', 'odt'),
'world'		=>	array('html', 'htm', 'xhtml', 'tpl'),
'world_link'	=>	array('php', 'php3', 'asp', 'jsp'),
);

//Code
$code = array('css', 'js', 'sql', 'xml', 'phps', 'java', 'cpp');
?>