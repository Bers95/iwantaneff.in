<?php
/******************************************************************************************

	Copyright (C) 2007, 2008 da3rX (i.r.da3rx@gmail.com)

	This file is part of decode explorer.

	Decode explorer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Decode explorer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with decode explorer.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************************/


if(!defined('DECODE_EXPLORER'))
	die('DECODE_EXPLORER constant not defined.');


$languages = array(

	//English
	'en'	=>	array(
		'name'			=>	'Name',
		'size'			=>	'Size',
		'modified'		=>	'Modified',
		'objects'		=>	'objects',
		'used_space'		=>	'Used space',
		'free_space'		=>	'Free space',
		'total_space'		=>	'Total space',
		'password'		=>	'Password',
		'upload'		=>	'Upload',
		'upload_failed'		=>	'Failed to upload the file',
		'move_failed'		=>	'Failed to move the file',
		'chmod_failed'		=>	'Failed to chmod the file',
		'file_exists'		=>	'File already exists',
		'file_size'		=>	'File size too big',
		'invalid_password'	=>	'Invalid password',
		'upload_successful'	=>	'File successfully uploaded',
	),
	
	//Estonian
	'et'	=>	array(
		'name'			=>	'Nimi',
		'size'			=>	'Suurus',
		'modified'		=>	'Muudetud',
		'objects'		=>	'objekti',
		'used_space'		=>	'Kasutatud ruum',
		'free_space'		=>	'Vaba ruum',
		'total_space'		=>	'Kogu ruum',
		'password' 		=>	'Parool',
		'upload' 		=>	'Lae üles',
		'upload_failed'		=>	'Faili üleslaadimine ebaõnnestus',
		'move_failed'		=>	'Faili liigutamine ebaõnnestus',
		'chmod_failed'		=>	'Faili chmod ebaõnnestus',
		'file_exists'		=>	'Fail on juba olemas',
		'file_size'		=>	'Fail on liiga suur',
		'invalid_password'	=>	'Vale parool',
		'upload_successful'	=>	'Faili üleslaadimine õnnestus',
	),
	
	//Finnish
	'fi'	=>	array(
		'name'			=>	'Nimi',
		'size'			=>	'Koko',
		'modified'		=>	'Muutettu',
		'objects'		=>	'kohdetta',
		'used_space'		=>	'Käytetty tila',
		'free_space'		=>	'Vapaa tila',
		'total_space'		=>	'Tilaa yhteensä',
		'password'		=>	'Salasana',
		'upload' 		=>	'Lisää',
		'upload_failed'		=>	'Lisääminen epäonnistui',
		'move_failed'		=>	'Siirtäminen epäonnistui',
		'chmod_failed'		=>	'Tiedoston chmodaaminen epäonnistui',
		'file_exists'		=>	'Tiedosto on jo olemassa',
		'file_size'		=>	'Tiedoston koko on liian suuri',
		'invalid_password'	=>	'Väärä salasana',
		'upload_successful'	=>	'Tiedosto on lisätty onnistuneesti',
	),
);
?>