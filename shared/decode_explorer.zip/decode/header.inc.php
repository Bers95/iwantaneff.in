<?php
/******************************************************************************************

	Copyright (C) 2007, 2008 da3rX (i.r.da3rx@gmail.com)

	This file is part of decode explorer.

	Decode explorer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Decode explorer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with decode explorer.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************************/


if(!defined('DECODE_EXPLORER'))
	die('DECODE_EXPLORER constant not defined.');


/* Code */
if(!empty($_GET['code']) && is_file($_GET['code']) && is_valid_name($_GET['code'])) {
	$fileextension = d_fileextension($_GET['code']);
	if(in_array($fileextension, $code)) {
		echo '<code style="float: left; color: gray; text-align: right; margin-right: 1em; padding-right: .5em; border-right: 1px solid gray;">' . implode(range(1, count(file($_GET['code']))), '<br />') . '</code>' . "\r\n";
		highlight_file($_GET['code']);
		die();
	}
}


/* Specify the MIME type */
if(stristr($_SERVER['HTTP_ACCEPT'], 'application/xhtml+xml') || stristr($_SERVER['HTTP_USER_AGENT'], 'W3C_Validator'))
	$mime_type = 'application/xhtml+xml';
else
	$mime_type = 'text/html';
header('Content-type: ' . $mime_type . '; charset=UTF-8');


/* Get the directory path */
if(!empty($_GET['dir']) && is_dir($_GET['dir']) && is_valid_name($_GET['dir']))
	$dir = $_GET['dir'];
else //If something's wrong with the directory path
	$dir = '';


/* Get the upload max filesize */
$upload_max_filesize = ini_get('upload_max_filesize');
$upload_max_filesize_in_bytes = return_bytes($upload_max_filesize);

/* Upload */
if(!empty($_FILES['upload']['name']) && !empty($_POST['password']) && !empty($password) && $_POST['password'] == $password) {
	if(get_magic_quotes_gpc())
		$_FILES['upload']['name'] = stripslashes($_FILES['upload']['name']);
	
	$uploadfile = (empty($dir) ? '.' : $dir) . '/' . $_FILES['upload']['name'];
	

	if($_FILES['upload']['error'] == UPLOAD_ERR_INI_SIZE)
		$error = $languages[$language]['file_size'];
	elseif($_FILES['upload']['error'] != UPLOAD_ERR_OK)
		$error = $languages[$language]['upload_failed'] . ', error: ' . $_FILES['upload']['error'];
	elseif(file_exists($uploadfile))
		$error = $languages[$language]['file_exists'];
	elseif(!is_uploaded_file($_FILES['upload']['tmp_name']))
		$error = $languages[$language]['upload_failed'];
	elseif(!@move_uploaded_file($_FILES['upload']['tmp_name'], $uploadfile))
		$error = $languages[$language]['move_failed'];
	elseif(!@chmod($uploadfile, 0644))
		$error = $languages[$language]['chmod_failed'];
	elseif($_FILES['upload']['error'] == UPLOAD_ERR_OK)
		$success = $languages[$language]['upload_successful'];
}
elseif(!empty($_POST['password']) && $_POST['password'] != $password)
	$error = $languages[$language]['invalid_password'];

//Get the files array
$files = d_files();

//Get the back button (..) path
$back = d_back();
?>