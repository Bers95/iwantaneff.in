<?php
/******************************************************************************************

	Copyright (C) 2007, 2008 da3rX (i.r.da3rx@gmail.com)

	This file is part of decode explorer.

	Decode explorer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Decode explorer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with decode explorer.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************************/


if(!defined('DECODE_EXPLORER'))
	die('DECODE_EXPLORER constant not defined.');


/* CONFIGURATION */

$title		=	'decode';				//Page title
$total_space	=	25;					//Total space in MegaBytes
$logo		=	true;					//Display logo (true/false)
$language	=	'en';					//Language (en - English / et - Estonian / fi - Finnish)
$password	=	'';					//Upload password (leave empty to disable upload)
$uploaddir	=	array('');				//Upload-allowed directories (leave empty to allow upload in all directories)
$newwindow	=	false;					//Open files in a new window (true/false)
$private	=	array('decode', 'index.php', 'private');//Private files and folders (wont be listed)
$opendirectly	=	array('direct');			//Direct open folders (will be opened directly instead of listing their content)
$cachetimeout	=	10;					//Used/free space cache timeout in minutes
?>