<?php
/**
 *
 * decode explorer
 *
 * @author     da3rX (i.r.da3rx@gmail.com)
 * @www        http://da3rx.com/decode/
 * @version    Beta 9
 * @modified   2008 Feb
 * @created    2007 April
 *
 */

/******************************************************************************************

	Copyright (C) 2007, 2008 da3rX (i.r.da3rx@gmail.com)

	This file is part of decode explorer.

	Decode explorer is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	Decode explorer is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with decode explorer.  If not, see <http://www.gnu.org/licenses/>.

******************************************************************************************/


define('DECODE_EXPLORER', true);

/* Includes */
require('decode/languages.inc.php');
require('decode/icons.inc.php');
require('decode/config.inc.php');
require('decode/functions.inc.php');
require('decode/header.inc.php');
@include('decode/cache.inc.php');

//Start the output buffer
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $language ?>">
<head>
	<meta http-equiv="Content-Type" content="<?php echo $mime_type ?>; charset=UTF-8" />
	<meta name="author" content="da3rX" />
	<meta name="description" content="decode explorer" />
	<title>decode explorer: <?php echo $title . d_dirtree(false) ?></title>
	<link rel="stylesheet" type="text/css" href="decode/style/style.css" media="screen" />
	<!--[if lt IE 7]>
		<link rel="stylesheet" type="text/css" href="decode/style/style_ie.css" media="screen" />
	<![endif]-->
	<script type="text/javascript" src="decode/script/go.js" defer="defer"></script>
</head>

<body>
<div id="wrapper">
<?php
if($logo)
	echo '<h1>decode explorer</h1>' . "\r\n";
if($error)
	echo '<div id="error"><img src="decode/img/error.png" alt="Error:" /> ' . $error . ' <img src="decode/img/error.png" alt=":Error" /></div>' . "\r\n";
if($success)
	echo '<div id="success"><img src="decode/img/success.png" alt="Success:" /> ' . $success . ' <img src="decode/img/success.png" alt=":Success" /></div>' . "\r\n";
?>
<div id="dirtree"><h2><a href="?dir="><?php echo $title ?></a></h2><?php echo d_dirtree() ?></div>
<table>
	<thead>
		<tr>
			<th class="icon"><?php echo d_sorting('icon') ?></th>
			<th class="name"><?php echo d_sorting('name') ?></th>
			<th class="size"><?php echo d_sorting('size') ?></th>
			<th class="modified"><?php echo d_sorting('modified') ?></th>
		</tr>
	</thead>
	<tfoot>
		<tr>
			<td>&nbsp;</td>
			<td><?php echo $files['filecount'] . ' ' . $languages[$language]['objects'] ?></td>
			<td><?php echo d_filesizefrombytes($files['totalfilesize']) ?></td>
			<td>&nbsp;</td>
		</tr>
	</tfoot>
	<tbody>
		<tr class="one" onclick="go('<?php echo $back ?>')">
			<td>&nbsp;</td>
			<td colspan="3"><a href="<?php echo $back ?>">..</a></td>
		</tr>
		<?php echo $files['tbody'] ?>
	</tbody>
</table>
</div>
<?php
if((empty($uploaddir) || in_array($dir, $uploaddir)) && !empty($password))
{
?>
<div id="upload">
<form action="" method="post" enctype="multipart/form-data">
<input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $upload_max_filesize_in_bytes ?>" />
<table>
	<tr>
		<td><label for="password"><?php echo $languages[$language]['password']; ?>: </label><input type="password" name="password" id="password" /></td>
		<td><input name="upload" type="file" /></td>
		<td><input type="submit" value="<?php echo $languages[$language]['upload']; ?>" /></td>
	</tr>
</table>
</form>
</div>
<?php
}
?>
<div id="footer">
	<?php
	$usedfreespace = d_usedfreespace();
	echo $languages[$language]['used_space'] . ': ' . $usedfreespace['used_space'] . ' (' . $usedfreespace['used_percent'] . '%) | ';
	echo $languages[$language]['free_space'] . ': ' . $usedfreespace['free_space'] . ' (' . $usedfreespace['free_percent'] . '%) | ';
	echo $languages[$language]['total_space'] . ': ' . d_filesizefrombytes(d_megabytes2bytes($total_space));
	?>
<br />
	<a href="http://da3rx.com/decode/">decode explorer</a> Beta 9 | Copyright &copy; 2007, 2008 da3rX
	<!-- decode explorer - Copyright (C) 2007, 2008 da3rX | icons by Mark James - www.famfamfam.com -->
</div>
</body>
</html>
<?php
//Echo the output buffer
echo ob_get_clean();
?>