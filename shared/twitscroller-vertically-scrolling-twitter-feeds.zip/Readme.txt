Instructions
-------------

Import the jQuery library and either scroller.js or scroller.min.js.
Create a <div> element which will contain the scroller.
Run the twitscroller() method on the div.

Options
--------
user - Required. The username of the twitter account.

visible - Amount of tweets visible at once (Default - 1).

speed - The time, in ms, that each tweet is displayed for before scrolling to the next. (Default - 2500).