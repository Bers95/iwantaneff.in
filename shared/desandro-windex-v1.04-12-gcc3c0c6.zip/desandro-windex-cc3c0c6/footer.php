<?php require_once('config.php'); ?>

    </div> <!-- #dirlist -->

    <?php echo $readmeMarkup; ?>

</div> <!-- #wrap -->


</body>
</html>
