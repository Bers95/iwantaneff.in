<?php

define('MYSQL_HOST', 'localhost');
define('MYSQL_USER', 'user');
define('MYSQL_PASSWORD', 'password');
define('MYSQL_DATABASE', 'database');
define('TWITTER_USERNAME', 'mathias');
define('GOOGLE_PLUS_ID', '106697091536876736486');
define('SHORT_URL', 'http://mths.be/'); // include the trailing slash!
define('DEFAULT_URL', 'http://mathiasbynens.be'); // omit the trailing slash!

?>