# `evil.js` Version 42

Is someone hot-linking your script, wasting your precious bandwidth? No problem; simply include `evil.js` and watch the chaos ensue! You might also be interested in [`evil.css`](https://github.com/tlrobinson/evil.css) for deterring pesky bandwidth leeches.

## Credits

* [Mathias Bynens](http://mathiasbynens.be/)
* [Kit Cambridge](http://kitcambridge.github.com/)
* [Devon Govett](http://badassjs.com/)
* [Paul Irish](http://paulirish.com/)
* [Bradley Meck](https://github.com/bmeck)
* [Alex Sexton](http://alexsexton.com/)
* [Craig Stuntz](http://blogs.teamb.com/craigstuntz/)
* [Mike Taylor](http://miketaylr.com/)
* [Christian Wirkus](https://github.com/Walfisch)

## Usage

    { curl http://kitcambridge.github.com/evil.js/evil.min.js; cat source.js } > distribution.js

## License

Public domain.