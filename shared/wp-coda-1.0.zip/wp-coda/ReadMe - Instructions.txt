####################################################################
#                        WP CODA version 1.0                       #
#                                                                  #                                                             #                                                                  #
#  Author: Greg Johnson                                            #
#       @: http://greg-j.com/wp-coda/                              #
#     URL: http://bustatheme.com/wordpress/wp-coda/                #
# License: http://wordpress.bustatheme.com/coda/#license           #
#                                                                  #
####################################################################




Installation Instructions

   1. Download and extract wp-coda-1.0.zip.
   2. Upload the wp-content folder to the folder wordpress 
      is installed. (It is okay to merge/overwrite if asked 
      by your FTP program)
   3. Activate the theme and the wp-coda plugin from your 
      wordpress admin panel.




Usage Notes

    * WP CODA only displays Pages, not Posts. You can change 
      this opening up wp-coda/index.php and changing the 
      post_type from page to post on line 2
    * WP CODA displays content tabs from oldest(first) to 
      newest(last). This behavior can be changed by changing 
      the order parameter in the same place mentioned above.
    * WP CODA�s behavior is handled with the query_posts() 
      function. For more information, go to the wordpress codex 
      page dedicated to query_posts()
    * The wp-coda plugin modifies the [gallery] functionality
      built into wordpress 2.5 and later. Once activated, you
      only need to include the phrase "[gallery]" (without the
      quotes) in your wordpress page and any images attached to
      that page will be displayed in the gallery. (multiple media
      types are not supported yet).
    * To get the fancy image zooming effect, put your image(s) 
      in a paragraph with a class name of "gallery". If you 
      want your image to have a title, put it as the title 
      attribute of the link to the image.




Know Issues

   [gallery]
      The wp-coda.php plugin does not currently support multiple
      media types.

   [ie6 images]
      Internet Explorer < 6 doesn't display




Fixed Issues

   [fade-in/fade-out]
      There is an annoying bug in the header menu that sometimes
      prevents the background images from fading in.




Releast Notes

   7.23.2008
      - Released WP CODA 1.0
      - Fixed fade-in/fade-out bug

   7.22.2008
      - Pre-Release WP CODA 0.9





Thanks for downloading!