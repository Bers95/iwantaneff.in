<?php
// Copyright 2011 Toby Zerner, Simon Zerner
// This file is part of esoTalk. Please see the included license file for usage information.

// English Definitions for the BBCode plugin.

$definitions["Fixed"] = "Fixed";
$definitions["Image"] = "Image";
$definitions["Link"] = "Link";
$definitions["Strike"] = "Strike";
$definitions["Header"] = "Header";
$definitions["Italic"] = "Italic";
$definitions["Bold"] = "Bold";