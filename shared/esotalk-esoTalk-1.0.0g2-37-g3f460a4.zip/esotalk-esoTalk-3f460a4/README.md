esoTalk is free, open-source Internet forum software written in PHP and MySQL. It is intent on being extremely simple, fast, and modern, containing all of the essential features a forum might need, and a powerful plugin system allowing developers to extend it in any way they like.

If you like this software, please consider [donating to support the developer](http://esotalk.org/donate).

### Installing esoTalk

1. Upload the contents of this folder to the location on your web server where you would like esoTalk to be accessible at.
2. Visit this location in your web browser. You will be taken to the esoTalk installer.
3. Follow the instructions in the installer. If you need help, visit the [esoTalk Support Forum](http://esotalk.org/forum).