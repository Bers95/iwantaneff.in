<?php

    /**
     * Romanian file for plugin textile
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author Cosmin Huţanu <urecheatu007@gmail.com>
     * @version Wolf 0.6.0
     */

    return array(
    	'Allows you to compose page parts or snippets using the Textile text filter.' => 'Permite compunerea de fragmente sau părţi de pagină folosind filtrul de text Textile.',
	'Textile filter' => 'Filtru Textile',
    );