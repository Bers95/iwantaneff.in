<?php

    /**
     * Indonesian file for plugin textile
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author Devi Mandiri <devi.mandiri@gmail.com>
     * @version Wolf 0.7.x
     */

    return array(
    	'Allows you to compose page parts or snippets using the Textile text filter.' => 'Memungkinkan anda untuk membuat halaman atau snippet menggunakan Textile teks filter',
		'Textile filter' => 'Textile filter',
    );

