<?php

    /**
     * Japanese file for plugin textile
     *
     * @package Plugins
     * @subpackage textile
     *
     * @author Your Name <email@domain.something>
     * @version Wolf 0.7.3
     */

    return array(
    	'Allows you to use the Textile text filter.' => 'あなたはTextileのテキストフィルタを使用することができます。',
	'Textile' => 'Textile',
	'Textile filter' => 'Textileフィルタ',
    );