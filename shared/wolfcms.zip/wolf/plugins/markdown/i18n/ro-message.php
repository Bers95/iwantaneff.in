<?php

    /**
     * Romanian file for plugin markdown
     *
     * @package Plugins
     * @subpackage markdown
     *
     * @author Cosmin Huţanu <urecheatu007@gmail.com>
     * @version Wolf 0.6.0
     */

    return array(
    'Allows you to compose page parts or snippets using the Markdown text filter.' => 'Permite compunerea de fragmente sau părţi de pagină folosind filtrul de text Markdown.',
	'Markdown filter' => 'Filtru Markdown',
    );