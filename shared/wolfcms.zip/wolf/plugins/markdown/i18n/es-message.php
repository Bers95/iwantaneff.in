<?php

    /**
     * Spanish file for plugin markdown
     *
     * @package Plugins
     * @subpackage markdown
     *
     * @author andrewmman
     * @version Wolf 0.6.0
     */

    return array(
    'Allows you to compose page parts or snippets using the Markdown text filter.' => 'Permite componer piezas de una página o fragmentos usando el filtro de texto Markdown.',
	'Markdown filter' => 'Filtro Markdown',
    );