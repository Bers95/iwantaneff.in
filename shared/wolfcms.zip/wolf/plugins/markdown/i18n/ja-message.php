<?php

    /**
     * Japanese file for plugin markdown
     *
     * @package Plugins
     * @subpackage markdown
     *
     * @author Your Name <email@domain.something>
     * @version Wolf 0.7.3
     */

    return array(
    	'Allows you to use the Markdown text filter.' => 'あなたはMarkdownのテキストフィルタを使用することができます。',
	'Markdown' => 'Markdown',
	'Markdown filter' => 'Markdownのフィルタ',
    );
