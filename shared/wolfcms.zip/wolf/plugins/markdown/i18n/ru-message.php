<?php

   /**
     * Russian language file
     *
     * @package Plugins
     * @subpackage markdown
     *
     * @author Dmitry Kostromin <kostromind@gmail.com>
     * @version Wolf 0.6.0
     * @last modifed from 07 February 2010
     */
	 
	 
	 
    return array(
    	'Allows you to compose page parts or snippets using the Markdown text filter.' => 'Позволяет создавать страницы или фрагменты с использованием текстового фильтра Markdown',
		'Markdown filter' => 'Фильтр Markdown',
    );