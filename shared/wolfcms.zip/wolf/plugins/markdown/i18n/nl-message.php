<?php

    /**
     * Dutch translation for plugin markdown
     *
     * @package Plugins
     * @subpackage markdown
     *
     * @author Fortron
     * @version Wolf 0.6.0
     */

    return array(
    'Allows you to compose page parts or snippets using the Markdown text filter.' => 'Biedt de mogelijkheid tot het samenstellen van een pagina of snippers met de Markdown filter',
	'Markdown filter' => 'Markdown filter',
    );