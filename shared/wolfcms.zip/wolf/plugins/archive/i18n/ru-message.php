<?php


    /**
     * Russian language file
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author Dmitry Kostromin <kostromind@gmail.com>
     * @version Wolf 0.6.0
     * @last modifed from 07 February 2010
     */

    return array(
    'Archive' => 'Архив',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Обеспечивает новый тип страниц — «Архив», для использования в блоге или архиве новостей.',
    );

