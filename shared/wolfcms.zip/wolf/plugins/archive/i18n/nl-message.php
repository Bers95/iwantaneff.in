<?php

    /**
     * Dutch translation for plugin archive
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author Fortron
     * @version Wolf 0.6.0
     */

    return array(
    'Archive' => 'Archief',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Biedt een archief paginatype welke zich leent voor een blog of nieuwsarchief',
    );
