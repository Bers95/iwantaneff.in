<?php

    /**
     * Romanian file for plugin archive
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author Cosmin Huţanu <urecheatu007@gmail.com>
     * @version Wolf 0.6.0
     */

    return array(
    'Archive' => 'Arhivă',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Oferă un tip de pagină Arhivă care se comportă similar cu cea a unui blog sau site de ştiri',
    );