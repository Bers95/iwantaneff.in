<?php


    /**
     * French language file for plugin archive
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author Dimitri “Diti” Torterat <diti@adelieland.eu>
     * @version Wolf 0.6.0
     * @last modifed from 24 June 2010
     */

    return array(
    'Archive' => 'Archive',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Fournit un type de page offrant un comportement similaire à un blog ou à un recueil d’actualités.',
    );

