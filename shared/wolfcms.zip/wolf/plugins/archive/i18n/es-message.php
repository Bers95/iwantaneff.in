<?php

    /**
     * Spanish file for plugin archive
     *
     * @package Plugins
     * @subpackage archive
     *
     * @author 
     * @version Wolf 0.6.0
     */

    return array(
    'Archive' => 'Archivador',
	'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Implementa un tipo de página similar al de un blog o archivo de noticias.',
    );
