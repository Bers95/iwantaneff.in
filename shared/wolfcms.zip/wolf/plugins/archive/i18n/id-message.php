<?php

    /**
     * Indonesian file for plugin archive
     *
     * @package wolf
     * @subpackage archive
     *
     * @author Devi Mandiri <devi.mandiri@gmail.com>
     * @version Wolf 0.7.x
     */

    return array(
    	'Archive' => 'Arsip',
		'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Menyediakan tipe halaman Arsip yang berfungsi mirip dengan blog atau arsip berita',
    );
