<?php

    /**
     * Polish file for plugin archive
     *
     * @package wolf
     * @subpackage archive
     *
     * @author Piotr Fuz <piotr.fuz@gmail.com> and Pawel Balicki <kilab1@o2.pl>
     * @version Wolf 0.7.3
     */

    return array(
    	'Archive' => 'Archiwum',
		'Provides an Archive pagetype behaving similar to a blog or news archive.' => 'Wtyczka dostarcza nowy typ strony - Archiwum. Podobny jest on do bloga, lub archiwum newsów.',
    );