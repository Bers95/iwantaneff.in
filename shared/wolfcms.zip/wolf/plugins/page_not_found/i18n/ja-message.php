<?php

    /**
     * YourLanguage file for plugin page_not_found
     *
     * @package Plugins
     * @subpackage page_not_found
     *
     * @author Your Name <email@domain.something>
     * @version Wolf x.y.z
     */

    return array(
    	'Page not found' => 'ページが見つかりませんでした',
	//'Provides Page not found page types.' => '',
    );