<?php if (!defined('APPLICATION')) exit();
echo Anchor(T('Start a New Conversation'), '/messages/add', 'BigButton NewConversation Popup');