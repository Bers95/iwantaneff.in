<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo T('Thank You!'); ?></h1>
<div class="Box">
   <p><?php echo T('Your application will be reviewed by an administrator. You will be notified by email if your application is approved.'); ?></p>
</div>