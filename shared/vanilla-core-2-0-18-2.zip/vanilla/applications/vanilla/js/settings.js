jQuery(document).ready(function($) {

   // Settings->Index()

});