<?php
define('MYSQL_SERVER', 'localhost');
define('MYSQL_USERNAME', 'root');
define('MYSQL_PASSWORD', '');
define('MYSQL_DATABASE', 'nucleo_stats');
define('LOGIN_USERNAME', 'admin');
define('LOGIN_PASSWORD', 'password');