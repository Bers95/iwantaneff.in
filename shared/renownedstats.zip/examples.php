<?php
include_once('renownedstats.php');
if (!empty($_GET['s'])) {
	add_hit($_GET['s']);
}
?>
<a href="?s=alpha">Alpha</a> |
<a href="?s=beta">Beta</a> |
<a href="?s=delta">Delta</a> |
<a href="?s=gamma">Gamma</a>