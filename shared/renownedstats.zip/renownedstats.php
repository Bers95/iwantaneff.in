<?php
include_once("config.php");

# This function adds a "hit" to our database. All you need to send is the page name, the rest is figured out.
function add_hit($page) {
	$browser_id = find_browser($_SERVER['HTTP_USER_AGENT']);
	$os_id = find_os($_SERVER['HTTP_USER_AGENT']);
	$ip_id = ip2long($_SERVER['REMOTE_ADDR']);
	$refer = $_SERVER['HTTP_REFERER'];
	$oa = parse_url($refer);
	$domain = str_replace('www.', '', $oa['host']);
	# we log bad user agents so that the administrator can add new browsers / operating systems hitting their website
	if (($os_id == '?') || ($browser_id == '?')) {
		$newdata = "OS($os_id) Br($browser_id) IP($ip_id) ORIG(".$_SERVER['HTTP_USER_AGENT'].")\n";
		$f=fopen("bad_useragents.txt","a");
		fwrite($f,$newdata);
		fclose($f);
	}
	runQueryStats("INSERT INTO users SET ip = '$ip_id', browser_id = '$browser_id', os_id = '$os_id', origin = '$refer', domain = '$domain'");
	runQueryStats("UPDATE users SET last_hit = NOW() WHERE ip = '$ip_id' AND browser_id = '$browser_id' AND os_id = '$os_id' LIMIT 1");
	$result = runQueryStats("SELECT id FROM users WHERE ip = '$ip_id' AND browser_id = '$browser_id' AND os_id = '$os_id' LIMIT 1");
	$row = mysql_fetch_assoc($result);
	$sql = "INSERT INTO user_hits SET page = '$page', user_id = '{$row['id']}'";
	runQueryStats($sql);
}

# This draws a large table of the last X number of hits to the website.
function stats_get_details($amount) {
	$sql = "SELECT u.id, u.ip, u.last_hit, u.origin, u.domain, (SELECT COUNT(*) FROM user_hits WHERE user_hits.user_id = u.id) AS hits, (SELECT name FROM os WHERE os.id = u.os_id) AS os, (SELECT name FROM browser WHERE browser.id = u.browser_id) AS browser FROM users AS u ORDER BY u.last_hit DESC LIMIT $amount";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing='0'>";
	echo "<tr><th>IP Address</th><th>Last Visit</th><th>Hits</th><th>System</th><th>Browser</th><th>Origin</th></tr>\n";
	$i=0;
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$data = 'e';
		} else {
			$data = 'o';
		}
		if (empty($row['origin'])) {
			$origin = some_or_none('');
		} else {
			$origin = "<a href=\"{$row['origin']}\">{$row['domain']}</a>";
		}
		
		echo "<tr class=\"$data\"><td>".long2ip($row['ip'])."</td><td>".date("n/j/y H:i:s",strtotime($row['last_hit']))."</td><td class='num'><a href='?user_id={$row['id']}'>".return_4_char_number($row['hits'])."</a></td><td>".some_or_none($row['os'])."</td><td>".some_or_none($row['browser'])."</td><td>$origin</td></tr>\n";
	}
	echo "</table>";	
}

# This returns an array of the last X number of hits to the website.
function stats_get_details_array($amount) {
	$sql = "SELECT u.id, u.ip, u.last_hit, u.origin, u.domain, (SELECT COUNT(*) FROM user_hits WHERE user_hits.user_id = u.id) AS hits, (SELECT name FROM os WHERE os.id = u.os_id) AS os, (SELECT name FROM browser WHERE browser.id = u.browser_id) AS browser FROM users AS u ORDER BY u.last_hit DESC LIMIT $amount";
	$result = runQueryStats($sql);
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		$data[] = $row;
	}
	return $data;
}

# This draws a table of the X most popular pages on the website.
function stats_get_popular($amount) {
	$sql = "SELECT page, COUNT(*) AS count FROM user_hits GROUP BY page ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing = '0'>";
	echo "<tr><th>Page</th><th>&nbsp;</th></tr>\n";
	$i = 0;
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$data = 'e';
		} else {
			$data = 'o';
		}
		echo "<tr class=\"$data\"><td>".some_or_none($row['page'])."</td><td class='num'>".return_4_char_number($row['count'])."</td></tr>\n";
	}
	echo "</table>\n";
}

# This returns an array of the X most popular pages on the website.
function stats_get_popular_array($amount) {
	$sql = "SELECT page, COUNT(*) AS count FROM user_hits GROUP BY page ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		$data[] = $row;
	}
	return $data;
}

# This draws a table of the X most popular referring domains.
function stats_get_domains($amount, $show_links=true) {
	$sql = "SELECT domain, COUNT(*) AS count FROM users WHERE domain != '' GROUP BY domain ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing = '0'>";
	if ($show_links)
		echo "<tr><th>Domain</th><th>&nbsp;</th></tr>\n";
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$data = 'e';
		} else {
			$data = 'o';
		}
		echo "<tr class=\"$data\"><td><a href=\"http://".some_or_none($row['domain'])."\">".some_or_none($row['domain'])."</a></td>";
		if ($show_links)
			echo "<td class='num'>".return_4_char_number($row['count'])."</td>";
		echo "</tr>\n";
	}
	echo "</table>\n";
}

# This returns an array of the X most popular referring domains.
function stats_get_domains_array($amount) {
	$sql = "SELECT domain, COUNT(*) AS count FROM users WHERE domain != '' GROUP BY domain ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		$data[] = $row;
	}
	return $data;
}

# This draws a table of the X most popular browsers.
function stats_get_browsers($amount) {
	$sql = "SELECT COUNT(u.id) AS count, b.name FROM users AS u, browser AS b WHERE u.browser_id >= 1 AND u.browser_id = b.id AND b.robot=0 GROUP BY u.browser_id ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing = '0'>";
	echo "<tr><th>Browser</th><th>&nbsp;</th></tr>\n";
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$data = 'e';
		} else {
			$data = 'o';
		}
		echo "<tr class=\"$data\"><td class=\"left\">{$row['name']}</td><td class='num'>".return_4_char_number($row['count'])."</td></tr>\n";
	}
	echo "</table>\n";
}

# This returns an array of the X most popular browsers.
function stats_get_browsers_array($amount) {
	$sql = "SELECT COUNT(u.id) AS count, b.name FROM users AS u, browser AS b WHERE u.browser_id >= 1 AND u.browser_id = b.id AND b.robot=0 GROUP BY u.browser_id ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		$data[] = $row;
	}
	return $data;
}

# This draws a table of the X most popular operating systems.
function stats_get_systems($amount) {
	$sql = "SELECT COUNT(u.id) AS count, b.name FROM users AS u, os AS b WHERE u.browser_id >= 1 AND u.os_id = b.id AND b.robot=0 GROUP BY u.os_id ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing = '0'>";
	echo "<tr><th>System</th><th>&nbsp;</th></tr>\n";
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$data = 'e';
		} else {
			$data = 'o';
		}
		echo "<tr class=\"$data\"><td>{$row['name']}</td><td class='num'>".return_4_char_number($row['count'])."</td></tr>\n";
	}
	echo "</table>\n";
}

# This returns an array of the X most popular operating systems.
function stats_get_systems_array($amount) {
	$sql = "SELECT COUNT(u.id) AS count, b.name FROM users AS u, os AS b WHERE u.browser_id >= 1 AND u.os_id = b.id AND b.robot=0 GROUP BY u.os_id ORDER BY count DESC LIMIT $amount";
	$result = runQueryStats($sql);
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		$data[] = $row;
	}
	return $data;
}

# This draws a graph showing traffic over the last X number of days.
function stats_graph_days($days) {
	include ("nucleoGraph.php");
	# $sql = "SELECT COUNT(DISTINCT user_id) AS uniques, COUNT(user_id) AS hits, date_format(time, '%Y-%m-%d') AS mydate FROM user_hits GROUP BY mydate DESC LIMIT $days";
	$sql = "SELECT COUNT(DISTINCT user_id) AS uniques, COUNT(user_id) AS hits, date_format(time, '%Y-%m-%d') AS mydate FROM user_hits WHERE DATEDIFF(CURDATE(), date_format(time, '%Y-%m-%d')) < $days GROUP BY mydate ASC";
	$result = runQueryStats($sql);
	$myGraph = new nucleoGraph;
	$myGraph->construct(100, 1000, 1000, 'monthly', true, 4, 40);
	$myGraph->setColors(1, 'cde9a7', 'e4f6cd', '9ac65e');
	$myGraph->setColors(2, '828282', 'aeaeae', '5e5e5e');
	while ($row = mysql_fetch_assoc($result)) {
		$date_readable = date("F j", strtotime($row['mydate']));
		$myGraph->addBar($date_readable, $row['uniques'], $row['hits']);
	}
	$myGraph->displayGraph(TRUE);
}

# This returns the total number of unique visitors.
function stats_get_count() {
	$sql = "SELECT count(*) AS count FROM `users`";
	$result = runQueryStats($sql);
	$row = mysql_fetch_assoc($result);
	return $row['count'];
}

# This is the function we use for executing MySQL queries. Connection variables configured at the top of the page.
function runQueryStats($query) {
	$connect = mysql_connect(MYSQL_SERVER, MYSQL_USERNAME, MYSQL_PASSWORD);
	if (!$connect) {
		die("<div class=\"error\">" . mysql_error() . "</div>");
	}
	mysql_select_db(MYSQL_DATABASE, $connect);
	$result = mysql_query($query, $connect);
	return $result;
}

# This returns a digit with leading zero's so that the digit is four characters long.
function return_4_char_number($number) {
	if ($number >= 1000) {
		return $number;
	} else if ($number >= 100) {
		return ("<span>0</span>$number");
	} else if ($number >= 10) {
		return ("<span>00</span>$number");
	} else {
		return ("<span>000</span>$number");
	}
}

# This returns fuzzy time, e.g. 1d 4h or 1m 30s
function fuzzy_time($pastTimestamp, $compare = NULL) {
	if (!$compare)
    	$timePassed = time() - $pastTimestamp;
	else
		$timePassed = $compare - $pastTimestamp;
		
	$positions = 0;

    $elapsedString = "";
    if($timePassed > 604800) {
        $weeks = floor($timePassed / 604800);
        $timePassed -= $weeks * 604800;
        $elapsedString = $weeks."w ";
		$positions++;
    }
    if($timePassed > 86400) {
        $days = floor($timePassed / 86400);
        $timePassed -= $days * 86400;
        $elapsedString .= $days."d ";
		$positions++;
    }
    if($timePassed > 3600 && $positions < 2) {
        $hours = floor($timePassed / 3600);
        $timePassed -= $hours * 3600;
        $elapsedString .= $hours."h ";
		$positions++;
    }
    if($timePassed > 60 && $positions < 2) {
        $minutes = floor($timePassed / 60);
        $timePassed -= $minutes * 60;
        $elapsedString .= $minutes."m ";
		$positions++;
    }
    if ($positions < 2) {
        $elapsedString .= $timePassed."s";
		$positions++;
	}

    return $elapsedString;
}

# We compare the user agent to our database of browsers to determin the browser id.
function find_browser($string) {
	$sql = "SELECT id, identify FROM browser";
	$result = runQueryStats($sql);
	while ($row = mysql_fetch_assoc($result)) {
		if (strpos($string, $row['identify']) !== false) {
			return $row['id'];
		}
	}
	return '?';
}

# We compare the user agent to our database of operating systems to determin the operating systems id.
function find_os($string) {
	$sql = "SELECT id, identify FROM os";
	$result = runQueryStats($sql);
	while ($row = mysql_fetch_assoc($result)) {
		if (strpos($string, $row['identify']) !== false) {
			return $row['id'];
		}
	}
	return '?';
}

# If we have an empty string, we return the blank HTML character so that our table fields don't collapse.
function some_or_none($string) {
	if (empty($string)) {
		return "&nbsp;";
	} else {
		return $string;
	}
}
