<?php
session_start();
$start = time() + microtime();
include_once("config.php");
include_once("renownedstats.php");

if (isset($_GET['logout'])) {
	$_SESSION['admin'] = false;
}

if ($_POST['username'] == LOGIN_USERNAME && $_POST['password'] == LOGIN_PASSWORD) {
	$_SESSION['admin'] = true;	
	$error = false;
} else if (!empty($_POST)) {
	$error = true;
} else {
	$error = false;
}

if ($_SESSION['admin']) {
	$auth = true;
	$body = 'logged_in';
} else {
	$auth = false;
	$body = 'logged_out';
}
?>
<html>
<head>
<title>RenownedStats</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body id="<?=$body?>">
<div id="container">
<?php
if ($auth) {
if (!isset($_GET['user_id'])) {
	echo "<div id='logout_link'><a href='?logout'>Logout</a></div>\n";
	echo "<div id='graph'><h2>Visitors over the last week</h2>\n";
	stats_graph_days(7);
	echo "<div><span style='color: #7AA054;'>Unique Visitors</span> and <span style='color: #828282;'>Total Hits</span></div>";
	echo "</div>";
	
	echo "<div id='details'><h2>Last 300 Visitors (".stats_get_count()." total)</h2>\n";
	stats_get_details(300);
	echo "</div>";
	
	echo "<div id='popular'>";
	echo "<h2>Popular Pages</h2>\n";
	stats_get_popular(20);
	echo "</div>";
	
	echo "<div id='domains'>";
	echo "<h2>Top Referrers</h2>\n";
	stats_get_domains(20);
	echo "</div>";
	
	echo "<div id='browsers'>";
	echo "<h2>Popular Browsers</h2>\n";
	stats_get_browsers(20);
	echo "</div>";
	
	echo "<div id='systems'>";
	echo "<h2>Popular Systems</h2>\n";
	stats_get_systems(20);
	echo "</div>";
	
} else {
	$user = $_GET['user_id'] + 0;
	echo "<div id='logout_link'><a href='./'>Back to Stats</a></div>\n";
	echo "<h2>Specific User $user</h2>\n";
	$sql = "SELECT * FROM user_hits WHERE user_id = '$user' ORDER BY id";
	$result = runQueryStats($sql);
	echo "<table cellpadding='0' cellspacing = '0'>";
	echo "<tr><th align='left'>Page Viewed</th><th align='left'>Time of Action</th><th align='left'>Time for Action</th></tr>\n";
	$data = array();
	while ($row = mysql_fetch_assoc($result)) {
		if ($i++ % 2) {
			$tr = 'e';
		} else {
			$tr = 'o';
		}
		if (!empty($data)) {
			$seconds = fuzzy_time(strtotime($data['time']), strtotime($row['time']));
			echo "<tr class=\"$tr\"><td>".some_or_none($data['page'])."</td><td>".date("n/j/y H:i:s",strtotime($data['time']))."</td><td>$seconds</td></tr>\n";
		}
		$data = $row;
		
	}
	echo "<tr><td>".some_or_none($data['page'])."</td><td>".date("n/j/y H:i:s",strtotime($data['time']))."</td><td>exit</td></tr>\n";
	echo "</table>";
}
} else {
?>
<div id="login_box">
<h3><?php if ($error) { ?>Invalid Login Try Again<?php } else { ?>Authentication Required<?php } ?></h3>
<form method="post" action="./">
<table>
<tr><td>Username</td><td><input name="username" /></td></tr>
<tr><td>Password</td><td><input name="password" type="password" /></td></tr>
<tr><td>&nbsp;</td><td><input type="submit" value="login" /></td></tr>
</table>
</form>
</div>
<?php
}
?>
	<div id="footer">
		RenownedStats took <?=printf("%01.2f", (time() + microtime() - $start)); ?> seconds to render.
	</div>
</div>