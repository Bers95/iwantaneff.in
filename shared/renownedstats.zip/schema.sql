CREATE TABLE `browser` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(31) collate latin1_general_ci NOT NULL default '',
  `identify` varchar(31) collate latin1_general_ci NOT NULL default '',
  `robot` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`,`identify`),
  KEY `robot` (`robot`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=41 ;

INSERT INTO `browser` VALUES (1, 'Firefox 1.x', 'Firefox/1.', 0);
INSERT INTO `browser` VALUES (2, 'Firefox 2.x', 'Firefox/2.', 0);
INSERT INTO `browser` VALUES (3, 'Firefox 3.x', 'GranParadiso/3.', 0);
INSERT INTO `browser` VALUES (4, 'Firefox 3.x', 'Firefox/3.', 0);
INSERT INTO `browser` VALUES (5, 'Internet Explorer 5.5', 'MSIE 5.5', 0);
INSERT INTO `browser` VALUES (6, 'Internet Explorer 5.x', 'MSIE 5.', 0);
INSERT INTO `browser` VALUES (7, 'Internet Explorer 6.x', 'MSIE 6.', 0);
INSERT INTO `browser` VALUES (8, 'Internet Explorer 7.x', 'MSIE 7.', 0);
INSERT INTO `browser` VALUES (9, 'Konqueror', 'Konqueror', 0);
INSERT INTO `browser` VALUES (10, 'Mozilla', 'Mozilla/5.', 0);
INSERT INTO `browser` VALUES (11, 'Google', 'Google', 1);
INSERT INTO `browser` VALUES (12, 'Yahoo', 'Yahoo', 1);
INSERT INTO `browser` VALUES (13, 'America Online', 'AOL', 0);
INSERT INTO `browser` VALUES (14, 'Crazy Browser', 'Crazy Browser', 0);
INSERT INTO `browser` VALUES (15, 'cURL', 'libcurl', 1);
INSERT INTO `browser` VALUES (16, 'wget', 'wget', 1);
INSERT INTO `browser` VALUES (17, 'Dillo', 'Dillo', 0);
INSERT INTO `browser` VALUES (18, 'ELinks', 'ELinks', 0);
INSERT INTO `browser` VALUES (19, 'Galeon', 'Galeon', 0);
INSERT INTO `browser` VALUES (20, 'Links', 'Links', 0);
INSERT INTO `browser` VALUES (21, 'Lynx', 'Lynx', 0);
INSERT INTO `browser` VALUES (22, 'Opera', 'Opera', 0);
INSERT INTO `browser` VALUES (23, 'Safari', 'Safari', 0);
INSERT INTO `browser` VALUES (24, 'MSN', 'msnbot', 1);
INSERT INTO `browser` VALUES (25, 'Handheld', 'Opera Mini', 1);
INSERT INTO `browser` VALUES (26, 'Baidu Spider', 'Baiduspider', 1);
INSERT INTO `browser` VALUES (27, 'Ask Jeeves', 'Ask Jeeves', 1);
INSERT INTO `browser` VALUES (28, 'PicSearch Bot', 'psbot', 1);
INSERT INTO `browser` VALUES (29, 'RI Checker', 'RI Checker', 1);
INSERT INTO `browser` VALUES (30, 'Findlinks', 'findlinks', 1);
INSERT INTO `browser` VALUES (31, 'MSRBot', 'MSRBOT', 1);
INSERT INTO `browser` VALUES (32, 'Snap', 'Snapbot', 1);
INSERT INTO `browser` VALUES (33, 'Larbin', 'larbin', 1);
INSERT INTO `browser` VALUES (34, 'SBIder', 'SBIder', 1);
INSERT INTO `browser` VALUES (35, 'EmeraldShield', 'EmeraldShield', 1);
INSERT INTO `browser` VALUES (36, 'INET Library', 'inet library', 1);
INSERT INTO `browser` VALUES (37, 'Java', 'Java', 1);
INSERT INTO `browser` VALUES (38, 'Snoopy', 'Snoopy v', 1);
INSERT INTO `browser` VALUES (39, 'Gigabot', 'Gigabot', 1);
INSERT INTO `browser` VALUES (40, 'Larbin', 'LarbinWebCrawler', 1);

CREATE TABLE `os` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(31) collate latin1_general_ci NOT NULL default '',
  `identify` varchar(31) collate latin1_general_ci NOT NULL default '',
  `robot` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `name` (`name`,`identify`),
  KEY `robot` (`robot`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=32 ;

INSERT INTO `os` VALUES (1, 'Windows 95', 'Windows 95', 0);
INSERT INTO `os` VALUES (2, 'Windows 7', 'Windows NT 6.1', 0);
INSERT INTO `os` VALUES (3, 'Windows 98', 'Windows 98', 0);
INSERT INTO `os` VALUES (4, 'Windows 2000', 'Windows NT 5.0', 0);
INSERT INTO `os` VALUES (5, 'Windows XP', 'Windows NT 5.1', 0);
INSERT INTO `os` VALUES (6, 'Windows 2003', 'Windows NT 5.2', 0);
INSERT INTO `os` VALUES (7, 'Windows Vista', 'Windows NT 6.0', 0);
INSERT INTO `os` VALUES (8, 'OS X', 'OS X', 0);
INSERT INTO `os` VALUES (9, 'Mac OS', 'PPC', 0);
INSERT INTO `os` VALUES (10, 'Windows NT', 'Windows NT', 0);
INSERT INTO `os` VALUES (11, 'Google', 'Google', 1);
INSERT INTO `os` VALUES (12, 'Yahoo', 'Yahoo', 1);
INSERT INTO `os` VALUES (13, 'Linux', 'Linux', 0);
INSERT INTO `os` VALUES (14, 'MSN', 'msnbot', 1);
INSERT INTO `os` VALUES (15, 'Windows XP', 'Windows XP', 0);
INSERT INTO `os` VALUES (16, 'Baidu Spider', 'Baiduspider', 1);
INSERT INTO `os` VALUES (17, 'IRLbot', 'IRLbot', 1);
INSERT INTO `os` VALUES (18, 'Ask Jeeves', 'Ask Jeeves', 1);
INSERT INTO `os` VALUES (19, 'PicSearch Bot', 'psbot', 1);
INSERT INTO `os` VALUES (20, 'RI Checker', 'RI Checker', 1);
INSERT INTO `os` VALUES (21, 'Findlinks', 'findlinks', 1);
INSERT INTO `os` VALUES (22, 'MSRBot', 'MSRBOT', 1);
INSERT INTO `os` VALUES (23, 'Snap', 'Snapbot', 1);
INSERT INTO `os` VALUES (24, 'Larbin', 'larbin', 1);
INSERT INTO `os` VALUES (25, 'SBIder', 'SBIder', 1);
INSERT INTO `os` VALUES (26, 'EmeraldShield', 'EmeraldShield', 1);
INSERT INTO `os` VALUES (27, 'INET Library', 'inet library', 1);
INSERT INTO `os` VALUES (28, 'Java', 'Java', 1);
INSERT INTO `os` VALUES (29, 'Snoopy', 'Snoopy v', 1);
INSERT INTO `os` VALUES (30, 'Gigabot', 'Gigabot', 1);
INSERT INTO `os` VALUES (31, 'Larbin', 'LarbinWebCrawler', 1);

CREATE TABLE `user_hits` (
  `id` int(11) NOT NULL auto_increment,
  `user_id` int(11) NOT NULL default '0',
  `page` varchar(63) collate latin1_general_ci NOT NULL default '',
  `time` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`,`page`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;

CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `ip` varchar(15) collate latin1_general_ci NOT NULL default '',
  `browser_id` int(11) NOT NULL default '0',
  `os_id` int(11) NOT NULL default '0',
  `last_hit` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `origin` varchar(255) collate latin1_general_ci NOT NULL default '',
  `domain` varchar(63) collate latin1_general_ci NOT NULL default '',
  `search` varchar(255) collate latin1_general_ci NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `ip_2` (`ip`,`browser_id`,`os_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=1 ;



-- IE8, Win7, Safari PATCH
INSERT INTO `browser` SET name = 'Internet Explorer 8.x', identify = 'MSIE 8.', robot = 0;
INSERT INTO `os` VALUES (2, 'Windows 7', 'Windows NT 6.1', 0);
ALTER TABLE `os`  ORDER BY `id`;
UPDATE `browser` SET `name` = 'Safari1', `identify` = 'Safari1' WHERE `browser`.`id` =10 LIMIT 1 ;
DELETE FROM browser WHERE id = 23;
INSERT INTO `browser` (`id` ,`name` ,`identify` ,`robot`)VALUES (NULL , 'Mozilla', 'Mozilla/5.', '0');
UPDATE `browser` SET `name` = 'Safari', `identify` = 'Safari' WHERE `browser`.`id` =10 LIMIT 1 ;
ALTER TABLE `browser`  ORDER BY `id`;