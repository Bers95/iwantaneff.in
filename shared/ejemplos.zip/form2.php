<table width="276" border="0" cellspacing="0" cellpadding="2">
	<tr>
		<td>Campo  texto: </td>
		<td><?=$campo_texto?></td>
	</tr>
	<tr>
		<td valign="top">Text Area : </td>
		<td><?=$text_area?></td>
	</tr>
	<tr>
		<td valign="top">Radio button : </td>
		<td><?=$radiobutton?></td>
	</tr>
	<tr>
		<td valign="top">
		checkbox
:		</td>
		<td>
		<?=$checkbox1?><br>
		<?=$checkbox2?><br>
		<?=$checkbox3?>
		</td>
	</tr>
	<tr>
		<td>Listbox :</td>
	    <td><?=$lista?></td>
	</tr>
</table> 
