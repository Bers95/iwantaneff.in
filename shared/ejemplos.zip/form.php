<table width="276" border="0" cellspacing="0" cellpadding="2">
	<tr>
		<td>Campo  texto: </td>
		<td><input name="campo_texto" type="text" id="campo_texto" style="font-size:10px " value="se enviara esto" size="30"></td>
	</tr>
	<tr>
		<td valign="top">Text Area </td>
		<td><textarea name="text_area" rows="4" id="text_area" style="font-size:10px ">Este texto es del text area
</textarea></td>
	</tr>
	<tr>
		<td valign="top">Radio button </td>
		<td><input name="radiobutton" type="radio" value="radiobutton1" checked>
			opcion1<br>
			<input name="radiobutton" type="radio" value="radiobutton2">
			opcion2<br>
			<input name="radiobutton" type="radio" value="radiobutton3">
			opcion3<br>
			<input name="radiobutton" type="radio" value="radiobutton4">
			opcion4
		</td>
	</tr>
	<tr>
		<td>Chekbox</td>
		<td>1
			<input name="checkbox1" type="checkbox" id="checkbox1" style="font-size:10px " value="checkbox 1">
			Chequea para enviar <br>
		    2
		    <input name="checkbox2" type="checkbox" id="checkbox2" style="font-size:10px " value="checkbox 2">
		    Chequea para enviar <br>
		3
		<input name="checkbox3" type="checkbox" id="checkbox3" style="font-size:10px " value="checkbox 3">
		Chequea para enviar </td>
	</tr>
	<tr>
		<td>Listbox</td>
	    <td><select name="lista" id="lista">
	    	<option value="1">lista 1</option>
	    	<option value="2" selected>lista2</option>
	    	<option value="3">lista3</option>
	    	<option value="4">lista4</option>
    	</select></td>
	</tr>
	<tr>
		<td>&nbsp;</td>
		<td align="right"><input type="submit" name="Submit" value="Enviar" onclick="INNERDIV.cargar('fab','form2.php',null)"></td>
	</tr>
</table> 
