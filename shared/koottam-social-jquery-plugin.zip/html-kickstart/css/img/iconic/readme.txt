/*
	http://www.somerandomdude.com/work/iconic/
	http://creativecommons.org/licenses/by-sa/3.0/us/
*/