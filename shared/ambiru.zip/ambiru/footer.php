</div>
<div id="footer"><?php bloginfo('name'); ?> is proudly using the <a href="http://ifelse.co.uk/ambiru">Ambiru theme</a> originally designed by <a href="http://ifelse.co.uk">Phu</a>. Powered by <a href="http://wordpress.org/">WordPress</a>
<!-- <?php echo get_num_queries(); ?> queries. <?php timer_stop(1); ?> seconds. -->
<?php wp_footer(); ?>
</div>