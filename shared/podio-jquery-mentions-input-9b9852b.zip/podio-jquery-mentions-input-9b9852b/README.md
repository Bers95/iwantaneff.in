jquery.mentionsInput
=================

To get started -- checkout http://podio.github.com/jquery-mentions-input
