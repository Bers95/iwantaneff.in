BeeHive - Dhtml Library. August 15, 2002
(c) 2002, Peter Nederlof, http://www.xs4all.nl/~peterned/
---------------------------------------------------------------------

Hi, and thanks for downloading the BeeHive Dhtml Library.
This file contains relevant info about BeeHive, please read it.

BeeHive is a dhtml library, or api, that makes dhtml easier. 
Everytime you make a script you normally have to code the routines 
for all browsers you want to support, like showing, hiding and moving 
layers, interacting with the user, and more. Sometimes you might not 
even know how to achieve a certain effect in a certain browser or on 
a certain platform. 

This is where BeeHive kicks in. Instead of coding dhtml you use the 
objects and functions available in BeeHive, and all the crossbrowser 
and crossplatform stuff is done for you.

BeeHive has been succesfully tested Windows and Mac systems, IE5+,
NS4 and Mozilla. IE4 could work. Opera will not unless you predefine
all layers in you document.

The examples all have commented source. You can also use them as a 
template for your own projects. In that case you can remove the 
comment from the example files. Please leave the comments in the .js
files intact though. A link to my site would be nice, but is by no
means required.

updated: 15-08-02
-----------------------------
- sliding was accidently molested in the last update

updated: 14-08-02
-----------------------------
- Reduced source file sizes

updated: 11-08-02
-----------------------------
- added custom cursor choice for scrollbar
- fixed some minor bugs

updated: 02-07-02
-----------------------------
- changed the dynMenu.js (NOT COMPATIBLE WITH PREVIOUS VERSION)
  smaller file (not much tho)
  submenu labels can now contain any character, hence not compatible
- fixed an IE5.0 dynScrollbar2.js bug, arrowclicking errored.
- Read the comment in the menu html to find out how to update your
  old dynmenu if you want to.


Updated: 27-04-02
-----------------------------
- added dynObject.setOpacity(opacity), opacity 0-100, IE and Moz only.
- added dynObject.setBorder(width, style, color).
- added dynObject.removeEvents(), removes ALL attached layer events.
- added various settings and options. 


A couple of notes/terms
---------------------------------------------------------------------

- BeeHive is free, and the use of it is completely at your own risk. 
  I cannot and will not guarantee anything, nor will I be held 
  responsible for any kind trouble that may arise from its use. 

- You must leave the original source files intact. If you wish to
  make a change, or add a feature, please mail me, because it might 
  just be something great that BeeHive should have featured to begin 
  with. 

- If you don't mail me in the above case, at least put a note in the 
  source pointing out the changes, along with the date of change.

- Please do not mirror BeeHive from your own site, since BeeHive is 
  subject to updates you might find yourself mirrorring an old or 
  even outdated version.

- You are not allowed to commercially use BeeHive 


A couple of remarks
---------------------------------------------------------------------

- beehive.js combines previously separately existing files named 
  dynobject.js, dynevents.js and dragdrop.js but have been combined
  in one file to cut back on script includes, and because all the 
  files were needed anyway most of the time.

- Any updates of BeeHive will be backwards compatible with any older
  version, so your original scripts will alway run on any version of 
  BeeHive. You should however prepare a backup when you plan to 
  patch your files :) you never know. On the other hand new scripts 
  running on BeeHive might not be compatible with older beehive 
  versions, because of previously not existing used features.

- At this point there is no documentation. I'm still working on that
  but the examples all contain comments, reading that would be very
  usefull. I realise though that I really have to write those docs.


About the files
---------------------------------------------------------------------

- beehive.js
Enables dynamic creation of (nested)layers and altering properties.
Enables event handlers for layers and the document itself.
Enables easy drag drop for layers.

- dynscrollbar.js
Basic scrollbar, small in filesize, and featuring limited options

- dynscrollbar2.js
Advanced scrollbar, larger filesize, but way more features.

- dynmenu.js
A menu system script, be sure to test it thouroughly, it's tested 
back to win98 IE5.0, but you never know.


Future plans
---------------------------------------------------------------------
None. BeeHive is pretty versatile and stable, and adding more and 
more options would only make it crappier. I'm currently working on
BeeHive2, which will ultimately replace BeeHive. Netscape4 will no
longer be supported, it's 5 years old, go away evil thing.

It will be DOM-complient with no real browsercheck, since that's 
no longer needed.
Current test versions are less than half the filesize of BeeHive, are
capable of more things, and run at thrice the speed of BeeHive 
(creating layers and executing dynObject stuff). It's all backward
compatible except for the event attachers, which changed slightly.

---------------------------------------------------------------------
                                                           15-08-2002