<?php $this->load->view("defaults/header");?>

<div class="about">
	<h1>About</h1>
	To edit this page edit system/application/views/about.php.
</div>

<?php $this->load->view("defaults/footer");?>
