<?php $this->load->view('defaults/header'); ?>

<?php $this->load->view('defaults/paste_form'); ?>

<?php $this->load->view('defaults/footer');?>
