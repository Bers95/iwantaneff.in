		<?php $this->load->view('defaults/footer_message.php'); ?>
		<?php $this->load->view("defaults/stats")?>
	</body>
</html>
