<div class="footer">
	<!-- Insert your message here -->
	
	<!-- Removing this breaches the license -->Created by <a href="http://benmcredmond.com">Ben McRedmond</a> and Powered By <a href="http://code.google.com/p/stikked/">Stikked</a><!-- Removing this breaches the license -->
</div>