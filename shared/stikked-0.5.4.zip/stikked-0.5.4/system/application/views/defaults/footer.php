					</div>
				</div>
			<?php $this->load->view('defaults/footer_message'); ?>
			</div>
		</div>	
		<?php $this->load->view("defaults/stats")?>
	</body>
</html>
