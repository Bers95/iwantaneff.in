<?
	session_start();
	$user='admin';//set admin username here!
	$pass='admin';//set admin password here
	
	if(isset($_POST['_login'])){
		if($_POST['user']==$user && $_POST['pass']==$pass){
			$_SESSION['isadmin']=1;
		}else{
			$error='<font color="red">Wrong username/password!</font>';
		}
	}
	
	if(isset($_SESSION['isadmin'])){
		header("Location: ../index.php");
	}else{
?>
<html>
<head>
	<title>Dynamic Comments Administration panel</title>
	<link href="admin.css" rel="stylesheet" type="text/css" media="all" /> 	
</head>
<body>	
	<div class='loginbox'>
			<form class="login_form" action="" method="post">
				<fieldset>
					<label><strong>Username</strong> <?=$error?> </label>
					<input name="user" type="text" />
					<label><strong>Password</strong></label>

					<input name="pass" type="password" />
					<input class="autentificare" name="_login" type="submit" value="Log in!" />
				</fieldset>
			</form>
	</div>
</body>
</html>
<?}?>