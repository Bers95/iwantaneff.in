(function($) {
   publicMethod = $.fn.comments = function(options) {
	var $this = this, autoOpen;
	var loc='';
        var settings = {
            direction 			: 'nf', // of for oldest first, nf for newest first
			pagination			: 'on',
			pagelimit 			: '15',
			pagination_location	: 'bottom',
			form_location		: 'top',
			folder				: '', // Please set this relative to your base url, Required if you use REWRITE MOD in PHP
			hideloading			: true
        };
                
        if(options) {
            $.extend(settings, options);
        };
		
		if(settings.folder){
			loc=location.protocol+"//"+location.hostname+"/"+settings.folder;
		}
		
	var cURL = "dir="+settings.direction+"&divid="+$this.attr('id')+"&pagination="+settings.pagination+"&pagination_location="+settings.pagination_location+"&form_location="+settings.form_location+"&pagelimit="+settings.pagelimit+"&url="+window.location.href; 
	
	showloading = function(){
		if(!settings.hideloading){
			$this.html('<center><img src="jscomms/loading.gif" alt="Please Wait, Loading..."/></center>');
		}
	}
	
	showloading();
			$.ajax({
			  url: loc+'jscomms/jscomms.php',
			  type: 'POST',
			  data: cURL,
			  success: function(data) {
				$this.html(data);
			  },
			  error: function(data) {
				$this.html('<center><b>Could not load comments!<br>Please check the relative location of your script!<br>( '+loc+'/jscomms/ )</b></center>');
			  }
			});

	publicMethod.add = function (){
		name		=	$('#yourname').val();
		message		=	$('#yourcomm').val();	
		showloading();
		dataa=cURL+'&addcom=add&'+'username='+name+'&message='+message;
			$.ajax({
			  url: loc+'jscomms/jscomms.php',
			  type: 'POST',
			  data: dataa,
			  success: function(data) {
				$this.html(data);
			  },
			  error: function(data) {
				$this.html('Could not load comments!');
			  }
			});		
	}	
	
	publicMethod.remove = function (remove){
	showloading();	
		dataa=cURL+'&remove=add&'+'id='+remove;
			$.ajax({
			  url: loc+'jscomms/jscomms.php',
			  type: 'POST',
			  data: dataa,
			  success: function(data) {
				$this.html(data);
			  },
			  error: function(data) {
				$this.html('Could not load comments!');
			  }
			});		
	}	
	
	publicMethod.changepage = function (page){
	showloading();
		dataa=cURL+'&page='+page;
			$.ajax({
			  url: loc+'jscomms/jscomms.php',
			  type: 'POST',
			  data: dataa,
			  success: function(data) {
				$this.html(data);
			  },
			  error: function(data) {
				$this.html('Could not load comments!');
			  }
			});		
	}
}	
  
})(jQuery);