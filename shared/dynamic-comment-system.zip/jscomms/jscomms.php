<?
session_start();

	if(isset($_SESSION['isadmin'])){	//check if user has administrator privileges
		$admin=1;
	}
$url			=	str_replace('http://www.','http://',$_POST['url']);	
$url			=	md5($url);
$display_pages	=	4;
$page			=	1;
$pagination		=	'';
$maxlength		=	300;

if($_POST['pagelimit']=='')$_POST['pagelimit']=10;
if($_POST['page']!='')$page	=	$_POST['page'];

function fixcomm($string){
global $maxlength;
$rand=rand(1,999);
$str=$string;
	if(strlen($string)>$maxlength){
		$str=substr($string,0,$maxlength)."<a href='javascript:void(0)' onclick=\"$('#comm-".$rand."').fadeIn();$(this).hide()\" class='readall'>Read All</a>";
		$str.="<span id='comm-".$rand."' style='display:none'>".substr($string,$maxlength,strlen($string))."</span>";
	}
	return $str;
}


if(isset($_POST['addcom'])){
	if($_POST['username']=='')	$nf['user']='notfilled';	//check if the username field si empty
	if($_POST['message']=='')	$nf['message']='notfilled';	//check if the message field si empty

$data=date('m.d.Y h:i');	//generating the date when the comment has been posted. You can change this

$_POST['message']=htmlentities($_POST['message']);
$_POST['message']=str_replace('|','[line]',$_POST['message']);
$_POST['message']=str_replace( array("\n","\r","\r\n"), '<br />', $_POST['message'] );


	if(!$nf){	//if no errors have occured proceed to adding the comment
		$myFile = 'storage/'.$url;	//opens the file for writing
		$fh = fopen($myFile, 'a+') or die("can't open file");	//the file doesn't exist/does not have CHMOD 777
		$stringData = $_POST['username']."|".$_POST['message']."|".$data."|".$_SERVER['REMOTE_ADDR']."\n";
		fwrite($fh, $stringData);	//writes the comment to the file
		fclose($fh);	//closes the file
		$added='1';
	}
}

if(isset($_POST['remove'])&&$admin==1){//if the delete is requested and the user is administrator proceed to delete
	if ($f = fopen('storage/'.$url, 'r'))  //opens the file for writing
	while (!feof($f)){
		$line[] = fgets($f);	//logs all the comments in an array
	}	
	fclose($f);

if($_POST['dir']=='nf')$line=array_reverse($line);	//checks the direction of the comments
unset($line[$_POST['id']]);	//deletes the comment specified
if($_POST['dir']=='nf')$line=array_reverse($line);	//reverses the array again for writing

		$myFile = 'storage/'.$url;	//opening the file again for writing all the comments without the one deleted
		$fh = fopen($myFile, 'w+') or die("can't open file");
		foreach($line as $val){
			fwrite($fh, $val);
		}
		fclose($fh);
unset($line);
}


if(!is_file('storage/'.$url)){	//if the file doesn't exist, there are no comments added
	$alert="<div class='nocomments'>No comments added yet!</div>";
}else{
	if ($f = fopen('storage/'.$url, 'r'))  
	while (!feof($f)){
		$line[] = fgets($f);	
	}	
	fclose($f);	//logs all the comments in the $line array.

if($_POST['dir']=='nf')$line=array_reverse($line);		//checks the direction of the comments

if($_POST['pagination']=='on'){
	$arr			=	array_chunk($line, intval($_POST['pagelimit']), true);
	$line			=	$arr[($page-1)];
	$total_pages	=	count($arr);
}

	$z=0;
	
	foreach($line as $tag=>$linie){		//for each comment do something
		if($linie!=''){
		list($user,$message,$data,$ip)=explode('|',$linie);
		if($admin==1)$del=" (<b>".$ip."</b>)<div style='float:right; cursor:pointer;'><img src='jscomms/delete.png' onclick=\"$('#".$_POST['divid']."').comments.remove('".$tag."');\"></div>";	//if is admin show delete button
			$display.= "<div class='comment'>";
			$display.= "<div class='author'>".$data." <span class='owner'>".$user."</span> said:".$del."</div>";
			$display.= "<div class='comment_content'>".fixcomm($message)."</div>";
			$display.= "</div>";
		$z++;	
		}	
	}
	
	if($z==0){
		$alert="<div class='nocomments'>No comments added yet!</div>";	
	}
	
	unset($_POST['username'],$_POST['message']);
}
if($added=='1'){
	$alert="<div class='commentadded'>Your comment has been added!</div>";
}

$form="<div class='formcontainer'>
<form action='' method='post' onsubmit=\"$('#".$_POST['divid']."').comments.add(); return false;\">
	<table width='100%'>
		<tr>
			<td>Your Name</td>
			<td><input type='text' class='yourname ".$nf['user']."' id='yourname' value='".$_POST['username']."'></td>
		</tr>		
		<tr>
			<td valign='top'>Comment</td>
			<td><textarea name='comment' class='yourcomm ".$nf['message']."' id='yourcomm'>".$_POST['message']."</textarea> </td>
		</tr>		
		<tr>
			<td colspan='2'><input type='submit' value='Add Comment'></td>
		</tr>
	</table>
</div>";
 
 
if($total_pages>1){
$pagination="<div class='pagination_container'>";
 
if ($page!=1)$pagination.= "<a title='Start' href='javascript:void()' onclick=\"$('#".$_POST['divid']."').comments.changepage('1');\" class='comment_pagination'>&laquo; First</a> ";

if ($page>1) $pagination.= "</a><a title='Previous' href='javascript:void()' onclick=\"$('#".$_POST['divid']."').comments.changepage('".($page-1)."');\" class='comment_pagination'>&laquo; Previous </a> "; //Previous
 
for ($i = $page; $i <= $total_pages && $i<=($page+$display_pages); $i++) {
      if ($i == $page) $pagination.= "<strong class='comment_current'>$i</strong>";//not printing the link
      else $pagination.= "</a><a title='page $i' href='javascript:void()'  onclick=\"$('#".$_POST['divid']."').comments.changepage('".($i)."');\" class='comment_pagination'>$i</a>";//link
}
 
if (($page+$display_pages)< $total_pages) $pagination.= "..."; //etcetera...
if ($page<$total_pages) $pagination.= "<a title='Next' href='javascript:void()' onclick=\"$('#".$_POST['divid']."').comments.changepage('".($page+1)."');\"  class='comment_pagination'> Next &raquo; </a>  ";//Next
if ($page!=$total_pages)$pagination.= "<a title='End' href='javascript:void()' onclick=\"$('#".$_POST['divid']."').comments.changepage('".($total_pages)."');\" class='comment_pagination'>Last &raquo;</a>";//end

$pagination.='</div>';
}

if($_POST['pagination_location']=='top'){
	$display =$pagination.$display;
}else{
	$display.=$pagination;
}

if($_POST['form_location']=='top'){
	echo $form.$alert.$display;
}else{
	echo $display.$alert.$form;
}
?>