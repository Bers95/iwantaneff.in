<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<title>Dynamic Comments</title>
    <link rel='stylesheet' type='text/css' href='jscomms/style_light.css'/>	
	<script type="text/javascript" src="jscomms/jquery.js"></script>	
	<script type="text/javascript" src="jscomms/jquery.comments.js"></script>
		<script type='text/javascript'>
		$(document).ready(function(){
			$("#comments").comments();
		});		
		</script>
</head>
<body style='background:#494949;'>
		<div id='cont' style='width:400px; margin:auto;'>
			<div id='comments'>
				<noscript>You need to enable Javascript to acces the comment system</noscript>
			</div>
		</div>	
</body>
</html>