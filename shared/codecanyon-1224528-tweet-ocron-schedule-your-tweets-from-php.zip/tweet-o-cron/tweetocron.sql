CREATE TABLE IF NOT EXISTS `tweetocron_users` (
	`id` bigint(20) unsigned NOT NULL,
	`screen_name` varchar(24) NOT NULL DEFAULT '',
	`oauth_token` varchar(127) NOT NULL DEFAULT '',
	`oauth_token_secret` varchar(255) NOT NULL,
	`profile` text,
	PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `tweetocron_tweets` (
	`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
	`tweet` varchar(140) NOT NULL DEFAULT '',
	`publish` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
	`user_id` bigint(20) unsigned NOT NULL,
	`tweet_id` bigint(50) unsigned DEFAULT NULL,
	PRIMARY KEY (`id`),
	KEY `user_id` (`user_id`),
	KEY `idx_tweet_id` (`tweet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

ALTER TABLE `tweetocron_tweets`
	ADD CONSTRAINT `tweetocron_tweets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `tweetocron_users` (`id`) ON DELETE CASCADE;