<?php
/**
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
if ( ! defined('DOCROOT'))
	require_once 'config'.DIRECTORY_SEPARATOR.'init.php';

// Find and publish tweets for all users
TweetOCron::instance()->publish();

/**
 * The timespan interval to clean out tweets from the database
 * @link  http://dev.mysql.com/doc/en/date-and-time-functions.html#function_date-add
 */
$clean_out_interval = '-6 MONTH';

// Clean up old published tweets based on how old they are and if they have been published
Database::instance()->delete("DELETE FROM `:table` WHERE `publish` < DATE_ADD(UTC_TIMESTAMP(), INTERVAL :interval) AND `tweet_id` IS NOT NULL;", array(
	':table'    => Database::instance()->prefix.'tweets',
	':interval' => $clean_out_interval
));