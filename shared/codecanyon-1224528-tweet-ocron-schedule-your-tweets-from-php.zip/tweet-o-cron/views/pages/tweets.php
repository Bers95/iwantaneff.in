<?php
if ( ! isset($_SESSION[Database::instance()->prefix.'user']) OR empty($_SESSION[Database::instance()->prefix.'user']))
{
	// Redirect to signin if no user signed in
	header('Location: '.Core::url('signin'));
	exit;
}

// Get all the tweets for this user
$tweets = TweetOCron::instance()->tweets($_SESSION[Database::instance()->prefix.'user']->id)->as_array('id');

// Matching on the URI to identify tweet task
preg_match('^tweets/(?<task>[a-zA-Z0-9-+_]+)?(/(?<id>[0-9]+))?^', $uri['page'], $params);
$task = (isset($params['task'])) ? $params['task'] : 'default';

switch ($task)
{
	case 'schedule':
		if ($_POST)
		{
			// Schedule the tweet
			TweetOCron::instance()->schedule(
				$_POST['tweet'],
				Date::array_to_string($_POST['publish'], 'Y-m-d H:i:s')
			);

			// Redirect back to tweet list
			header('Location: '.Core::url('tweets'));
			exit;
		}
		break;
	case 'unschedule':
		if (isset($params['id']))
		{
			// Unschedule tweet using id from url
			TweetOCron::instance()->unschedule($params['id']);

			// Redirect back to tweet list
			header('Location: '.Core::url('tweets'));
			exit;
		}
		break;
	case 'edit':
		if ($_POST AND isset($params['id']))
		{
			// Update the tweet
			TweetOCron::instance()->update(
				$params['id'],
				$_POST['tweet'],
				Date::array_to_string($_POST['publish'])
			);

			// Redirect back to tweet list
			header('Location: '.Core::url('tweets'));
			exit;
		}
		break;
	case 'publish':
		if (isset($params['id']))
		{
			// Publish the tweet and publish all overdue tweets
			TweetOCron::instance()->publish($params['id']);

			// Redirect back to tweet list
			header('Location: '.Core::url('tweets'));
			exit;
		}
		break;
}

// Load page header
echo View::load('partials/header')->set('active', 'tweets');
?>
<!-- List of scheduled tweets -->
<section style="padding-top:0;">
	<div class="page-header">
		<h1>Scheduled tweets <small>
		<?php if (($tweet_count = count($tweets)) > 0): ?>
			<?php echo $tweet_count; ?> scheduled tweets
		<?php endif ?></small></h1>
	</div>
	<?php echo Message::render(); // Show messages here ?>
	<?php if (isset($tweets) AND ! empty($tweets)): ?>
	<table id="scheduled-tweets" class="zebra-striped">
	<thead>
		<tr>
			<th>Tweet</th>
			<th style="width: 180px;">Publish</th>
			<th style="width: 190px;">Tasks</th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($tweets as $tweet): ?>
		<tr>
			<td>
				<?php if (Date::schedule_missed($tweet['publish'])): ?>
				<span class="label warning">Missed</span>
				<?php endif; ?>
				<?php echo Linkify::text($tweet['tweet']); ?>
			</td>
			<td><?php echo Date::convert_local($tweet['publish']); ?></td>
			<td>
			<ul class="unstyled tasks">
				<li><a href="<?php echo Core::url('tweets/publish/'.$tweet['id']); ?>" class="btn small">Publish</a></li>
				<li><a href="<?php echo Core::url('tweets/edit/'.$tweet['id']); ?>" class="btn small edit" data-controls-modal="edit-tweet-<?php echo $tweet['id']; ?>" data-backdrop="true" data-keyboard="true">Edit</a>
				<?php echo View::load('modals/edit')->set('edit', $tweet); ?>
				</li>
				<li><a href="<?php echo Core::url('tweets/unschedule/'.$tweet['id']); ?>" data-controls-modal="unschedule-tweet" data-backdrop="true" data-keyboard="true" class="btn small danger unschedule">Unschedule</a></li>
			</ul>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
	</table>
	<?php else: ?>
	<p>You don't have any tweets scheduled. <a href="#" data-controls-modal="new-tweet" data-backdrop="true" data-keyboard="true">Schedule a new tweet</a></p>
	<?php endif; ?>
</section>
<?php
// Load modal views
echo View::load('modals/unschedule');

// Load page footer
echo View::load('partials/footer');
?>