<?php
// Load page header
echo View::load('partials/header');
?>
<section style="padding-top:0;">
	<!-- Hero Unit -->
	<div class="hero-unit" id="tweetocron-hero">
		<p>Tweet O&apos;cron allows you to conveniently schedule tweets using PHP</p>
		<?php if ( ! isset($_SESSION[Database::instance()->prefix.'user']) OR empty($_SESSION[Database::instance()->prefix.'user'])): ?>
		<a href="<?php echo Core::url('signin'); ?>" class="btn primary large">Sign in with <b>Twitter</b></a>
		<?php else: ?>
		<button class="btn primary large" data-controls-modal="new-tweet" data-backdrop="true" data-keyboard="true">Schedule a new tweet »</button>
		<?php endif; ?>
	</div> <!-- /Hero Unit -->

	<h1>Welcome to <?php echo APPNAME; ?></h1>
	<p>To get started just click <a href="<?php echo Core::url('signin'); ?>">Sign in with <b>Twitter</b></a>.</p>
	<p>You can edit this page to display your own content. Just look in <code>views/pages/home.php</code></p>
</section>
<?php
echo View::load('partials/footer');
?>