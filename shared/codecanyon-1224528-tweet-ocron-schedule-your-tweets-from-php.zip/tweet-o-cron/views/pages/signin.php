<?php
// Load the config
$config = (array) Core::config('tweetocron', TRUE)->twitter;

// Matching on the URI to identify signin task
preg_match('^signin/(?<task>[a-zA-Z0-9-+_]+)?^', $uri['page'], $params);
$task = (isset($params['task'])) ? $params['task'] : 'default';

// Store database instance for convenience
$db = Database::instance();

switch ($task)
{
	case 'oauth':
		if (empty($_SESSION[$db->prefix.'oauth_request_token']) OR empty($_SESSION[$db->prefix.'oauth_request_token_secret']))
		{
			// Something's missing, try again
		    header('Location: '.Core::url('signin'));
		    exit;
		}

		// Create TwitterOAuth object with app key/secret and request token key/secret
		$twitter = new TwitterOAuth($config['consumer_key'], $config['consumer_secret'], $_SESSION[$db->prefix.'oauth_request_token'], $_SESSION[$db->prefix.'oauth_request_token_secret']);

		// Request access tokens from twitter and the users profile
		$response = $twitter->getAccessToken();
		$user = $twitter->get('account/verify_credentials');

		if (isset($user->error))
		{
			// Something went wrong
			throw new Exception($user->error);
		}

		// Insert the user to the database or update if they already exist
		$db->insert("INSERT INTO `:table` (`id`, `screen_name`, `oauth_token`, `oauth_token_secret`, `profile`)
			VALUES (:user_id, :screen_name, :oauth_token, :oauth_token_secret, :profile)
			ON DUPLICATE KEY UPDATE `screen_name` = :screen_name, `oauth_token` = :oauth_token, `oauth_token_secret` = :oauth_token_secret, `profile` = :profile;", array(
				':table'              => $db->prefix.'users',
				':user_id'            => $db->escape($response['user_id']),
				':screen_name'        => $db->escape($response['screen_name']),
				':oauth_token'        => $db->escape($response['oauth_token']),
				':oauth_token_secret' => $db->escape(Core::encrypt($response['oauth_token_secret'])), // encrypt the secret so it's safer in the DB
				':profile'            => $db->escape(serialize($user))
			));

		// Grab the user database record
		$user_record = $db->select("SELECT * FROM `:table` WHERE `id` = :user_id;", array(
				':table'   => $db->prefix.'users',
				':user_id' => $db->escape($response['user_id'])
			))->current();

		// Save the access tokens and user data in session for convenience
		$_SESSION[$db->prefix.'user'] = unserialize($user_record['profile']);

		// To the Tweets!
		header('Location: '.Core::url('tweets'));
		exit;
		break;

	default:
		// Create TwitterOAuth object with app key/secret
		$twitter = new TwitterOAuth($config['consumer_key'], $config['consumer_secret']);

		/* Request tokens from twitter */
		$response = $twitter->getRequestToken();

		if ($twitter->http_code != 200)
		{
			// Something went wrong, but what
			throw new Exception(implode(', ', array_keys($response)));
		}

		// Save tokens for later
		$_SESSION[$db->prefix.'oauth_request_token'] = $response['oauth_token'];
		$_SESSION[$db->prefix.'oauth_request_token_secret'] = $response['oauth_token_secret'];

		// Build the authorization URL
		$request_link = $twitter->getAuthorizeURL($response['oauth_token']);

		// Let's go!
		header('Location: '.$request_link);
		exit;
}
