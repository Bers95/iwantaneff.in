<?php
// Load the timeline
$timeline = TweetOCron::instance()->get_timeline(20);

// Load tweets to match against timeline
$tweets = TweetOCron::instance()->tweets($_SESSION[Database::instance()->prefix.'user']->id, NULL, TRUE)->as_array('tweet_id');

// Load page header
echo View::load('partials/header')->set('active', 'timeline');
?>
<!-- Timeline tweets -->
<section style="padding-top:0;">
	<div class="page-header">
		<h1>Timeline <small>Your Twitter timeline</small></h1>
	</div>
	<?php echo Message::render(); // Show messages here ?>
<?php if (isset($timeline) AND ! empty($timeline)): ?>
	<table id="scheduled-tweets" class="zebra-striped">
	<thead>
		<tr>
			<th>Tweet</th>
			<th style="width: 180px;">Published</th>
			<th style="width: 60px;">Tasks</th>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($timeline as $tweet): ?>
		<tr>
			<td>
				<?php if (array_key_exists($tweet->id_str, $tweets)): ?>
				<span class="label notice"><?php echo APPNAME; ?></span>
				<?php endif; ?>
				<?php echo Linkify::text($tweet->text); ?>
			</td>
			<td><?php echo Date::convert_local($tweet->created_at); ?></td>
			<td>
			<ul class="unstyled tasks">
				<li><a href="//twitter.com/<?php echo $tweet->user->screen_name; ?>/status/<?php echo $tweet->id_str; ?>" class="btn small" target="_blank">View</a></li>
			</ul>
			</td>
		</tr>
	<?php endforeach; ?>
	</tbody>
	</table>
	<?php else: ?>
	<p>You don't have any tweets in your timeline. <a href="#" data-controls-modal="new-tweet" data-backdrop="true" data-keyboard="true">Schedule a new tweet</a></p>
	<?php endif; ?>
</section>
<?php
// Load page footer
echo View::load('partials/footer');
?>