<?php
// Clear the SESSION
session_unset();
session_destroy();

// Redirect back to the homepage
header('Location: '.Core::url());