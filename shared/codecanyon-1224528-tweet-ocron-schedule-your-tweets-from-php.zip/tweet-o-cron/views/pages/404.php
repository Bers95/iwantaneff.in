<?php
// Load page header
echo View::load('partials/header');
?>
<section style="padding-top:0;">
	<div class="page-header">
		<h1>Oops, page not found <sup class="label important">404</sup></h1>
	</div>
		<p>The page you're looking for could not be found. <a href="<?php echo Core::url(); ?>">Back to the homepage</a></p>
</section>
<?php
echo View::load('partials/footer');
?>