<!-- Edit Tweet Modal -->
<div id="edit-tweet-<?php echo $edit['id'] ?>" class="modal hide fade tweet-form">
<div class="modal-header">
	<a href="#" class="close">&times;</a>
	<h3>Edit a scheduled tweet</h3>
</div>
<form action="<?php echo Core::url('tweets/edit/'.$edit['id']); ?>" method="POST" class="form-stacked">
<div class="modal-body">
	<div class="clearfix">
		<textarea class="span9 tweet" name="tweet" rows="4" data-limit="140"><?php echo $edit['tweet']; ?></textarea>
		<span class="help-block"></span>
	</div>
	<div class="clearfix">
		<label for="publish">Publish this tweet</label>
		<div class="input">
			<input type="text" class="span1" value="<?php echo Date::convert_local($edit['publish'], 'd'); ?>" name="publish[day]" id="publish_day" maxlength="2">
			<input type="text" class="span1" value="<?php echo Date::convert_local($edit['publish'], 'M'); ?>" name="publish[month]" id="publish_month">
			<input type="text" class="span1" value="<?php echo Date::convert_local($edit['publish'], 'Y'); ?>" name="publish[year]" id="publish_year" maxlength="4">
			at
			<input type="text" class="span1" value="<?php echo Date::convert_local($edit['publish'], 'H'); ?>" name="publish[hour]" id="publish_hour" maxlength="2"> :
			<input type="text" class="span1" value="<?php echo Date::convert_local($edit['publish'], 'i'); ?>" name="publish[minute]" id="publish_minute" maxlength="2">
			<?php if (Date::schedule_missed($edit['publish'])): ?>
			<span class="label warning">Missed</span>
			<?php endif ?>
		</div>
	</div>
</div>
<div class="modal-footer">
	<button class="btn close">Cancel</button>
	<button type="submit" class="btn primary">Save</button>
</div>
</form>
</div> <!-- /Edit Tweet Modal -->