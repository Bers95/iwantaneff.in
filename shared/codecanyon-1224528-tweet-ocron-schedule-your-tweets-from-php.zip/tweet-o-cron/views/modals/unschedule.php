<!-- Unschedule Modal -->
<div id="unschedule-tweet" class="modal hide fade">
<div class="modal-header">
	<a href="#" class="close">&times;</a>
	<h3>Unschedule a tweet</h3>
</div>
<div class="modal-body">
	<p>Are you sure you want to unschedule this tweet?</p>
</div>
<div class="modal-footer">
	<button class="btn close">Cancel</button>
	<a href="#" class="btn danger">Unschedule</a>
</div>
</div> <!-- /Unschedule Modal -->