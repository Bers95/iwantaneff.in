<!-- New Tweet Modal -->
<div id="new-tweet" class="modal hide fade tweet-form">
<div class="modal-header">
	<a href="#" class="close">&times;</a>
	<h3>Schedule a new tweet</h3>
</div>
<form action="<?php echo Core::url('tweets/schedule'); ?>" method="POST" class="form-stacked">
<div class="modal-body">
	<div class="clearfix">
		<textarea class="span9 tweet" name="tweet" rows="4" data-limit="140"></textarea>
		<span class="help-block"></span>
	</div>
	<div class="clearfix">
		<label for="publish">Publish this tweet</label>
		<div class="input">
			<input type="text" class="span1" name="publish[day]" id="publish_day" value="<?php echo date('d'); ?>" maxlength="2">
			<input type="text" class="span1" name="publish[month]" id="publish_month" value="<?php echo date('M'); ?>">
			<input type="text" class="span1" name="publish[year]" id="publish_year" value="<?php echo date('Y'); ?>" maxlength="4">
			at
			<input type="text" class="span1" name="publish[hour]" id="publish_hour" value="<?php echo date('H'); ?>" maxlength="2"> :
			<input type="text" class="span1" name="publish[minute]" id="publish_minute" value="<?php echo date('i', strtotime('+15 minutes')); ?>" maxlength="2">
		</div>
	</div>
</div>
<div class="modal-footer">
	<button type="submit" class="btn primary">Schedule</button>
</div>
</form>
</div> <!-- /New Tweet Modal -->