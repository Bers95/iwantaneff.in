<div class="alert-message <?php echo $type; ?> fade in" data-alert="alert" <?php echo $static ?>>
	<a class="close" href="#">×</a>
	<p><?php echo $message; ?></p>
</div>