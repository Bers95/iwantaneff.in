<style type="text/css">
body {
	background-color: #<?php echo $user->profile_background_color; ?>;
	<?php echo ($user->profile_use_background_image == TRUE) ? 'background-image: url('.$user->profile_background_image_url.');' : ''; ?>
	<?php echo ($user->profile_background_tile == TRUE) ? 'background-repeat: repeat;' : 'background-repeat: no-repeat;'; ?>
}
</style>