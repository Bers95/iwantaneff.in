</div>
<footer>
	<p>&copy; 2011 Orange Peel Studios (<a href="http://twitter.com/orangepeeled" target="_blank">orangepeeled</a>)</p>
</footer>
</div> <!-- /container -->

<!-- Load javascript -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script src="<?php echo Core::url('media/js/bootstrap-modal.js'); ?>"></script>
<script src="<?php echo Core::url('media/js/bootstrap-alerts.js'); ?>"></script>
<script src="<?php echo Core::url('media/js/bootstrap-scrollspy.js'); ?>"></script>
<script src="<?php echo Core::url('media/js/bootstrap-dropdown.js'); ?>"></script>
<script src="<?php echo Core::url('media/js/jquery.tweetocron.textcount.js'); ?>"></script>
<script src="<?php echo Core::url('media/js/tweetocron.js'); ?>"></script>
</body>
</html>