<?php
// Make sure $active exists
! isset($active) and $active = '';
$custom_css = '';

// Find the api limit status for this user
if (isset($_SESSION[Database::instance()->prefix.'user']) AND ! empty($_SESSION[Database::instance()->prefix.'user']))
{
	$status = TweetOCron::instance()->api_status();

	if (Core::config('tweetocron', TRUE)->profile_css === TRUE)
	{
		// Match the page css to Twitter account
		$custom_css = View::load('partials/twitter-css')->set('user', $_SESSION[Database::instance()->prefix.'user']);
	}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo APPNAME; ?> - Schedule your tweets with PHP</title>
	<meta name="description" content="Tweet O&rsquo;cron allows you to conveniently schedule tweets from a PHP website.">
	<meta name="author" content="orangepeelstudios.com">

	<link href="<?php echo Core::url('media/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo Core::url('media/css/style.css'); ?>" rel="stylesheet">
	<?php echo $custom_css; ?>
</head>
<body>
<div class="topbar" data-scrollspy="scrollspy">
<?php echo View::load('modals/schedule'); ?>
<div class="topbar-inner">
	<nav class="container">
		<a class="brand" href="<?php echo Core::url(); ?>"><?php echo APPNAME; ?></a>
		<?php if (isset($_SESSION[Database::instance()->prefix.'user']) AND ! empty($_SESSION[Database::instance()->prefix.'user'])): ?>
		<ul class="nav" data-dropdown="dropdown">
			<li class="dropdown <?php echo ($active == 'tweets') ? 'active' : ''; ?>">
				<a href="#" title="Your scheduled tweets" class="dropdown-toggle">Tweets</a>
				<ul class="dropdown-menu">
					<li><a href="<?php echo Core::url('tweets'); ?>" title="Manage your scheduled tweets">List scheduled tweets</a></li>
					<li><a href="#" data-controls-modal="new-tweet" data-backdrop="true" data-keyboard="true" title="Schedule a new tweet">Schedule a new tweet</a></li>
				</ul>
			</li>
			<li class="<?php echo ($active == 'timeline') ? 'active' : ''; ?>">
				<a href="<?php echo Core::url('timeline'); ?>" title="View your timeline">Timeline</a>
			</li>
		</ul>
		<ul class="nav secondary-nav" data-dropdown="dropdown">
			<li class="schedule-tweet">
				<a href="#" data-controls-modal="new-tweet" data-backdrop="true" data-keyboard="true" title="Schedule a new tweet">Schedule a new tweet</a>
			</li>
			<li id="user" class="dropdown">
				<a href="#" class="dropdown-toggle">
					<img src="<?php echo $_SESSION[Database::instance()->prefix.'user']->profile_image_url; ?>" alt="<?php echo $_SESSION[Database::instance()->prefix.'user']->screen_name; ?>">
					<span class="screen-name"><?php echo $_SESSION[Database::instance()->prefix.'user']->screen_name; ?></span>
				</a>
				<ul class="dropdown-menu">
					<li>
						<a href="http://support.twitter.com/articles/15364-about-twitter-limits-update-api-dm-and-following" title="What does this mean?" target="_blank">API Status: <?php echo $status->remaining_hits; ?> of <?php echo $status->hourly_limit; ?></a>
					</li>
					<li class="divider">&nbsp;</li>
					<li><a href="<?php echo Core::url('signout'); ?>" title="Sign Out">Sign Out</a></li>
				</ul>
			</li>
		</ul>
		<?php else: ?>
		<div class="pull-right" style="padding-top:5px;">
			<a href="<?php echo Core::url('signin'); ?>" class="btn primary" title="Sign in with Twitter">Sign in with <b>Twitter</b></a>
		</div>
		<?php endif ?>
	</nav>
</div>
</div>
<div class="container">
<div class="content">