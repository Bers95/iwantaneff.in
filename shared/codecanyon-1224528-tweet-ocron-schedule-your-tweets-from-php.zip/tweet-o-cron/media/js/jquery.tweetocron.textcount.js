/* ============================================================
 * jquery.tweetocron.textcount.js v1.0
 * http://orangepeelstudios.com
 * ============================================================
 * Copyright 2011-2012 Orange Peel Studios
 * http://orangepeelstudios.com/envato/license
 * ============================================================ */
$.fn.counter = function ( options ) {
	$(this).each(function () {
		var $this = $(this);
		var limit = $this.data('limit');
		var count = limit - $this.val().length;
		var $counter = $this.next('.help-block');
		$counter.text(count);

		$this.keyup( function ( event ) {
			count = limit - $this.val().length;
			$counter.text(count);

			if (count < 0)
			{
				$this.parent().addClass('error');
			}
			else
			{
				$this.parent().removeClass('error');
			}
		});
	});
}