/* ============================================================
 * tweetocron.js v1.0
 * http://orangepeelstudios.com
 * ============================================================
 * Copyright 2011-2012 Orange Peel Studios
 * http://orangepeelstudios.com/envato/license
 * ============================================================ */
$(document).ready(function () {

	// Assign the counter to all tweet text areas
	$('textarea.tweet').counter();

	// Open a modal when you try to unschedule a tweet
	$('a.unschedule').click(function (event) {
		var href = $(this).attr('href');
		$('#unschedule-tweet a.danger').attr('href', href);
		event.preventDefault();
	});

	// Make alerts fade after 5s
	window.setTimeout(function () {
		var $alert = $('.alert-message');

		if ($alert.data('static') == undefined)
		{
			$alert.fadeTo(500, 0).slideUp(500, function () {
				$(this).remove();
			});
		}
	}, 5000);
});