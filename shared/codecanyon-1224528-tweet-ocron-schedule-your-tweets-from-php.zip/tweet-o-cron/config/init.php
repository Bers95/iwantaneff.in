<?php
/**
 * Home to our initialisation logic to make the application work and to define some constants
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
session_name('tweetocron');
session_start();

// Set the full path to the docroot
define('DOCROOT', realpath(dirname(dirname(__FILE__))).DIRECTORY_SEPARATOR);

/**
 * Set the path to app relative to the domain with trailing slash. Example, if the url to access
 * Tweet O'cron is example.com/tweet-o-cron/ the the WEBROOT value should be /tweet-o-cron/. If
 * Tweet O'cron is in the domain root this can be left as /
 *
 * NOTE: This value should be the same as RewriteBase in your .htaccess file
 */
define('WEBROOT', '/');

/**
 * Change this to index.php if your hosting doesn't support url rewriting. Leave as an empty string
 * to produce nice URLs.
 */
define('INDEX_FILE', '');

// Set the name of the application
define('APPNAME', 'Tweet O&apos;cron');

// Load the core class
require_once DOCROOT.'classes'.DIRECTORY_SEPARATOR.'core.php';

// Enable the auto-loader and shutdown
spl_autoload_register(array('Core', 'auto_load'));
register_shutdown_function(array('Core', 'shutdown'));

/**
 * Set the time zone for the application.
 *
 * @see  http://php.net/timezones
 */
date_default_timezone_set('Europe/London');

/**
 * Set the PHP error reporting level. If you set this in php.ini, you remove this.
 * @see  http://php.net/error_reporting
 *
 * When developing your application, it is highly recommended to enable notices
 * and strict warnings. Enable them by using: E_ALL | E_STRICT
 *
 * In a production environment, it is safe to ignore notices and strict warnings.
 * Disable them by using: E_ALL ^ E_NOTICE
 *
 * When using a legacy application with PHP >= 5.3, it is recommended to disable
 * deprecated notices. Disable with: E_ALL & ~E_DEPRECATED
 */
error_reporting(E_ALL ^ E_NOTICE);