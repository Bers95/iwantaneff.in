<?php
/**
 * Options to configure Tweet O'cron
 *
 * string   encryption_key    key to use for encryption
 * string   profile_css       change background to match users Twitter profile
 * array    twitter           twitter api credentials
 */
return array(
	'encryption_key' => 'Tweet O\'cron is awesome!',
	'profile_css'    => TRUE,
	'twitter'        => array(
		'consumer_key'    => '',
		'consumer_secret' => ''
	)
);