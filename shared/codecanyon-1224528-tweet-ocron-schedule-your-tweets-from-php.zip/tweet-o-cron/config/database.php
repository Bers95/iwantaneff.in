<?php
/**
 * The following options are available for MySQL:
 *
 * string   hostname     server hostname, or socket
 * string   username     database username
 * string   password     database password
 * string   database     database name
 * string   charset      database character set (you shouldn't need to change this)
 * string   prefix       prefix for database tables
 *
 * Ports and sockets may be appended to the hostname.
 */
return array(
	'hostname' => 'localhost:3306', // the default localhost:3306 is usually correct for most environments
	'username' => '',
	'password' => '',
	'database' => '',
	'charset'  => 'utf8',
	'prefix'   => 'tweetocron_'
);