<?php
/**
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
require_once 'config'.DIRECTORY_SEPARATOR.'init.php';

/**
 * Rename or delete install.php once you're setup
 */
if (is_file(DOCROOT.'install.php'))
{
	// Load the installation check
	return include DOCROOT.'install.php';
	exit;
}

// Some simple URI matching so we can use the URI to find views
preg_match('^'.WEBROOT.INDEX_FILE.'(?<page>[a-zA-Z0-9-+_\/]+)?^', $_SERVER['REQUEST_URI'], $uri);

if (isset($uri['page']) AND ($page = Core::find_page($uri['page'])))
{
	// If the URI contains an 'action' and a view exists for it
	require_once $page;
}
elseif ( ! isset($uri['page']))
{
	// No action, it must be the home page
	require_once Core::find_file('views/pages', 'home');
}
else
{
	// None of the above, return 404
	header("HTTP/1.0 404 Not Found");
	header("Status: 404 Not Found");
	require_once Core::find_file('views/pages', '404');
	exit;
}