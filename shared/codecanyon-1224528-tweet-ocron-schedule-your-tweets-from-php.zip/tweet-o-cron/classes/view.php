<?php
/**
 * View helper class
 * Modified from the brilliant Kohana View class.
 *
 * @package    Tweet O'cron
 * @author     Kohana Team, modified by: Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2008-2012 Kohana Team
 * @license    http://orangepeelstudios.com/envato/license
 * @license    http://kohanaphp.com/license
 */
class View {

	protected $_file;
	protected $_data = array();

	/**
	 * Creates a new view object for the requested view and data array if supplied.
	 *
	 * @param   string  $file  file location relative to view folder
	 * @param   array   $data  k => v data array to pass into view
	 * @return  View
	 */
	public static function load($file, array $data = array())
	{
		return new View($file, $data);
	}

	/**
	 * Create the view object, throw exception if it's not found.
	 *
	 * @param   string  $file  file location relative to view folder
	 * @param   array   $data  k => v data array to pass into view
	 * @return void
	 */
	public function __construct($file, array $data = array())
	{
		if (($path = Core::find_file('views', $file)) === FALSE)
		{
			// No file found? That's a problem
			throw new View_Exception('The requested view could not be found at: '.$path);
		}

		// Store the file path
		$this->_file = $path;

		// Store the data array
		$this->_data = $data;
	}

	/**
	 * Prepares the view for display.
	 *
	 * @return mixed
	 */
	public function render()
	{
		// Import the view variables to local namespace
		extract($this->_data, EXTR_SKIP);

		// Capture the view output
		ob_start();

		try
		{
			// Load the view within the current scope
			include $this->_file;
		}
		catch (Exception $e)
		{
			// Delete the output buffer
			ob_end_clean();

			// Re-throw the exception
			throw $e;
		}

		// Get the captured output and close the buffer
		return ob_get_clean();
	}

	/**
	 * Magic method, returns the output of [View::render].
	 *
	 * @return  string
	 * @uses    View::render
	 */
	public function __toString()
	{
		try
		{
			return $this->render();
		}
		catch (Exception $e)
		{
			// Display the exception message
			throw new View_Exception($e->getMessage());

			return '';
		}
	}

	/**
	 * Assigns a variable by name. Assigned values will be available as a
	 * variable within the view file:
	 *
	 *     // This value can be accessed as $foo within the view
	 *     $view->set('foo', 'my value');
	 *
	 * You can also use an array to set several values at once:
	 *
	 *     // Create the values $food and $beverage in the view
	 *     $view->set(array('food' => 'bread', 'beverage' => 'water'));
	 *
	 * @param   string   variable name or an array of variables
	 * @param   mixed    value
	 * @return  $this
	 */
	public function set($key, $value = NULL)
	{
		if (is_array($key))
		{
			foreach ($key as $name => $value)
			{
				$this->_data[$name] = $value;
			}
		}
		else
		{
			$this->_data[$key] = $value;
		}

		return $this;
	}
} // END class View

class View_Exception extends Exception {}