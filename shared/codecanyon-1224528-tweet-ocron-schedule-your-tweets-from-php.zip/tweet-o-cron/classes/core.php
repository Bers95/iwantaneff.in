<?php
/**
 * Core helper class to make life easier
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
class Core {

	/**
	 * Provides auto-loading support of classes that follow naming convention.
	 *
	 * Class names are converted to file names by making the class name
	 * lowercase and converting underscores to slashes:
	 *
	 * @param   string   $class  class name
	 * @return  boolean
	 */
	public static function auto_load($class)
	{
		try
		{
			// Transform the class name into a path
			$file = str_replace('_', '/', strtolower($class));

			if ($path = Core::find_file('classes', $file))
			{
				// Load the class file
				require $path;

				// Class has been found
				return TRUE;
			}

			// Class is not in the filesystem
			return FALSE;
		}
		catch (Exception $e)
		{
			throw $e;
			die;
		}
	}

	/**
	 * Shutdown handlers
	 *
	 * @return  void
	 */
	public static function shutdown()
	{
		session_write_close();
	}

	/**
	 * Checks for a file at the specified dir/path
	 *
	 * @param   string   $dir   directory name
	 * @param   string   $file  filename with subdirectory
	 * @param   string   $ext   extension to search for
	 * @return  string
	 */
	public static function find_file($dir, $file, $ext = 'php')
	{
		if ( ! empty($ext))
		{
			// Prefix the extension with a period
			$ext = ".{$ext}";
		}
		else
		{
			// Use no extension
			$ext = '';
		}

		// Create a partial path of the filename
		$path = $dir.DIRECTORY_SEPARATOR.$file.$ext;

		// The file has not been found yet
		$found = FALSE;

		if (is_file(DOCROOT.$path))
		{
			// A path has been found
			$found = DOCROOT.$path;
		}

		return $found;
	}

	/**
	 * Recurrsive search for a page view, broadens the search after each loop by
	 * trimming the last segment from the path until it finds a match.
	 *
	 * @param  string   $uri  uri to parse and search
	 * @return string
	 * @return boolean
	 */
	public static function find_page($uri = '')
	{
		// Split the uri up into segments using the forward slash
		$segments = explode('/', $uri);

		// File has not been found yet
		$found = FALSE;

		// Reverse the array and search for a file starting with the most specific file path
		foreach (array_reverse($segments) as $segment)
		{
			if (($file = Core::find_file('views/pages', $uri)) !== FALSE)
			{
				// Found it! We're done here
				$found = $file;
				break;
			}
			// Trim this segment from the end of the uri
			$uri = rtrim($uri, $segment);
			$uri = rtrim($uri, '/');
		}

		return $found;
	}

	/**
	 * Loads a file within a totally empty scope and returns the output.
	 *
	 * @param   string  $file  file to load
	 * @return  mixed
	 */
	public static function load($file)
	{
		return include $file;
	}

	/**
	 * Returns configuration array from file.
	 *
	 * @param   string   $name       name of config file
	 * @param   booelan  $as_object  return as object
	 * @return  mixed
	 */
	public static function config($file, $as_object = FALSE)
	{
		if ($as_object === TRUE)
		{
			// Cast as stdObject
			return (object) Core::load(Core::find_file('config', $file));
		}

		return Core::load(Core::find_file('config', $file));
	}

	/**
	 * Creates an absolute URL for the site.
	 *
	 * @param  string  $url  url to create
	 * @return string
	 */
	public static function url($url = '')
	{
		$index = INDEX_FILE;
		if ( ! empty($url) AND ! empty($index))
		{
			$url = '/'.$url;
		}
		return WEBROOT.INDEX_FILE.$url;
	}

	/**
	 * Encrypts a string
	 *
	 * @param   string   $encrypt  string to encrypt
	 * @return  string
	 */
	public static function encrypt($encrypt)
	{
		// Create a random initialization vector of the proper size for the current cipher
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

		// Load Tweet O'cron config
		$config = Core::config('tweetocron');
		$key = md5($config['encryption_key']);

		// Encrypt the data
		$encrypted = trim(mcrypt_encrypt(MCRYPT_RIJNDAEL_256, $key, trim($encrypt), MCRYPT_MODE_ECB, $iv));

		// Use base64 encoding to convert to a string
		return base64_encode($encrypted);
	}

	/**
	 * Decrypts an encrypted string
	 *
	 * @param   string   $decrypt  encrypted string to decrypt
	 * @return  string
	 */
	public static function decrypt($decrypt)
	{
		$decoded = base64_decode($decrypt);

		// Create a random initialization vector of the proper size for the current cipher
		$iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
		$iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);

		// Load Tweet O'cron config
		$config = Core::config('tweetocron');
		$key = md5($config['encryption_key']);

		$decrypted = trim(mcrypt_decrypt(MCRYPT_RIJNDAEL_256, $key, trim($decoded), MCRYPT_MODE_ECB, $iv));

		return $decrypted;
	}
} // END Core