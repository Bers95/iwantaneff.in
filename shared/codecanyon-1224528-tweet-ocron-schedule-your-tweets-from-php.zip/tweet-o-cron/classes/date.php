<?php
/**
 * Date helper class
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
class Date {

	/**
	 * Takes date and time array of values and returns formated string
	 * @link [http://php.net/manual/en/function.date.php] for compatible format values
	 *
	 * @param   array    $datetime  array of date time values to process
	 * @param   string   $format    format of date to return, default ISO 8601 date
	 * @return  string
	 */
	public static function array_to_string(array $datetime, $format = 'c')
	{
		// Extract array variables into scope
		extract($datetime, EXTR_SKIP);

		// Check month is in the right format
		$month = date("n", strtotime('01-'.$month.'-'.$year.' 00:00:00'));

		// Created new DateTime object and set the date and time
		$dt = new DateTime();
		$dt->setDate($year, $month, $day);
		$dt->setTime($hour, $minute);

		// Convert all dates to UTC timezone
		$dt->setTimezone(new DateTimeZone('UTC'));

		// Return correctly formated DateTime string
		return (string) $dt->format($format);
	}

	/**
	 * Converts MySQL datetime in UTC format to local datetime
	 *
	 * @param  string  $datetime   UTC date time from database
	 * @return string
	 */
	public static function convert_local($datetime, $format = 'd M Y \a\t G:i T')
	{
		$local_dt = new DateTime($datetime, new DateTimeZone('UTC'));
		$local_dt->setTimezone(new DateTimeZone(date_default_timezone_get()));
		return (string) $local_dt->format($format);
	}

	/**
	 * Tests to see if the datetime supplied from the database record is less than now
	 *
	 * @param  string  $datetime   UTC date time from database
	 * @return boolean
	 */
	public static function schedule_missed($datetime)
	{
		$now = new DateTime('now', new DateTimeZone('UTC'));
		$utc_dt = new DateTime($datetime, new DateTimeZone('UTC'));

		return (bool) ($utc_dt < $now);
	}
} // END class Date