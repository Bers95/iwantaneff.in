<?php
/**
 * Handles connecting and querying a MySQL database.
 * Modified from the brilliant Kohana Database module incorporating the MySQL driver.
 *
 * @package    Tweet O'cron
 * @category   Database
 * @author     Kohana Team, modified by: Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2008-2012 Kohana Team
 * @license    http://kohanaphp.com/license
 */
class Database {

	// Query types
	const SELECT =  1;
	const INSERT =  2;
	const UPDATE =  3;
	const DELETE =  4;

	/**
	 * @var  array   default instance name
	 */
	public static $default = 'default';

	/**
	 * @var  array  Database instances
	 */
	public static $instances = array();

	/**
	 * @var  array
	 */
	protected $_config;

	/**
	 * @var  array  Database table prefix
	 */
	public $prefix = 'tweetocron_';

	/**
	 * Singleton instance
	 *
	 * @param   string    $name     instance name
	 * @param   array     $config   connection configuration options
	 * @return  Database
	 */
	public static function instance($name = NULL, array $config = NULL)
	{
		if ($name === NULL)
		{
			// Use the default instance name
			$name = Database::$default;
		}

		if ( ! isset(Database::$instances[$name]))
		{
			if ($config === NULL)
			{
				// Load the configuration for this database
				$config = Core::config('database');
			}

			return new Database($name, $config);
		}

		return Database::$instances[$name];
	}

	/**
	 * Build and execute a select SQL query
	 *
	 * @param   string   $sql     SQL query to run
	 * @param   array    $params  query params to replace
	 * @return  Database_Result
	 */
	public function select($sql, array $params = array())
	{
		return $this->query(Database::SELECT, $sql, $params);
	}

	/**
	 * Build and execute a insert SQL query
	 *
	 * @param   string   $sql     SQL query to run
	 * @param   array    $params  query params to replace
	 * @return  array
	 */
	public function insert($sql, array $params = array())
	{
		return $this->query(Database::INSERT, $sql, $params);
	}

	/**
	 * Build and execute a update SQL query
	 *
	 * @param   string   $sql     SQL query to run
	 * @param   array    $params  query params to replace
	 * @return  integer
	 */
	public function update($sql, array $params = array())
	{
		return $this->query(Database::UPDATE, $sql, $params);
	}

	/**
	 * Build and execute a delete SQL query
	 *
	 * @param   string   $sql     SQL query to run
	 * @param   array    $params  query params to replace
	 * @return  integer
	 */
	public function delete($sql, array $params = array())
	{
		return $this->query(Database::DELETE, $sql, $params);
	}

	// Server connection
	protected $_connection;

	// Instance name
	protected $_instance;

	/**
	 * Setup the class and store the instance
	 *
	 * @param   string   $name     instance name
	 * @param   array    $config   connection configuration options
	 * @return  void
	 */
	protected function __construct($name, array $config = NULL)
	{
		// Set the instance name
		$this->_instance = $name;

		// Store the config locally
		$this->_config = $config;

		// Store table prefix
		$this->prefix = $this->_config['prefix'];

		// Store the instance
		Database::$instances[$name] = $this;
	}

	final public function __destruct()
	{
		if ($this->disconnect())
		{
			unset(Database::$instances[$this->_instance]);
			return TRUE;
		}

		return FALSE;
	}

	/**
	 * Connect to the database using supplied credentials in $_config.
	 *
	 * @return  void
	 */
	public function connect()
	{
		if ($this->_connection)
			return;

		// Extract the connection parameters, adding required variabels
		extract($this->_config + array(
			'database'   => '',
			'hostname'   => '',
			'username'   => '',
			'password'   => ''
		));

		// Prevent this information from showing up in traces
		unset($this->_config['username'], $this->_config['password']);

		try
		{
			// Create a connection and force it to be a new link
			$this->_connection = mysql_connect($hostname, $username, $password, TRUE);
		}
		catch (Exception $e)
		{
			// No connection exists
			$this->_connection = NULL;

			throw $e;
		}

		// Select the database
		if ( ! mysql_select_db($database, $this->_connection))
		{
			// Unable to select database
			throw new Database_Exception(mysql_error($this->_connection));
		}

		if ( ! empty($this->_config['charset']))
		{
			// Set the character set
			mysql_set_charset($this->_config['charset'], $this->_connection);
		}
	}

	/**
	 * Close the MySQL connection and unset the instance
	 *
	 * @return  boolean
	 */
	public function disconnect()
	{
		try
		{
			// Database is assumed disconnected
			$status = TRUE;

			if (is_resource($this->_connection))
			{
				if ($status = mysql_close($this->_connection))
				{
					// Clear the connection
					$this->_connection = NULL;

					// Clear the instance
					Database::$instances[$this->_instance] = NULL;
				}
			}
		}
		catch (Exception $e)
		{
			// Database is probably not disconnected
			$status = ! is_resource($this->_connection);
		}

		return $status;
	}

	/**
	 * Build and execute SQL query
	 *
	 * @param   integer  $type    Database::SELECT, Database::INSERT, etc
	 * @param   string   $sql     SQL query to run
	 * @param   array    $params  query params to replace
	 * @return  mixed
	 */
	public function query($type, $sql, array $params = array())
	{
		// Make sure the database is connected
		$this->_connection or $this->connect();

		// Replace sql param markers with real values
		$sql = strtr($sql, $params);

		// Execute the query
		if (($result = mysql_query($sql, $this->_connection)) === FALSE)
		{
			throw new Database_Exception(mysql_error($this->_connection).' ['.$sql.']');
		}

		if ($type === Database::SELECT)
		{
			return new Database_Result($result, $sql);
		}
		elseif ($type === Database::INSERT)
		{
			// Return a list of insert id and rows created
			return array(
				'id'   => mysql_insert_id($this->_connection),
				'rows' => mysql_affected_rows($this->_connection)
			);
		}
		else
		{
			// Return the number of rows affected
			return mysql_affected_rows($this->_connection);
		}
	}

	/**
	 * Escape the value and surround with single-quotes
	 *
	 * @param   string   $value  value to escape
	 * @return  void
	 */
	public function escape($value)
	{
		// Make sure the database is connected
		$this->_connection or $this->connect();

		if (($value = mysql_real_escape_string( (string) $value, $this->_connection)) === FALSE)
		{
			throw new Database_Exception(mysql_error($this->_connection));
		}

		// SQL standard is to use single-quotes for all values
		return "'$value'";
	}
} // END Database

class Database_Result implements Countable, Iterator, SeekableIterator, ArrayAccess {

	// Executed SQL for this result
	protected $_query;

	// Raw result resource
	protected $_result;

	// Total number of rows and current row
	protected $_total_rows  = 0;
	protected $_current_row = 0;
	protected $_internal_row = 0;

	/**
	 * Sets the total number of rows and stores the result locally.
	 *
	 * @param   mixed   query result
	 * @param   string  SQL query
	 * @return  void
	 */
	public function __construct($result, $sql)
	{
		// Store the result locally
		$this->_result = $result;

		// Store the SQL locally
		$this->_query = $sql;

		// Find the number of rows in the result
		$this->_total_rows = mysql_num_rows($result);
	}

	public function __destruct()
	{
		if (is_resource($this->_result))
		{
			mysql_free_result($this->_result);
		}
	}

	public function seek($offset)
	{
		if ($this->offsetExists($offset) AND mysql_data_seek($this->_result, $offset))
		{
			// Set the current row to the offset
			$this->_current_row = $this->_internal_row = $offset;

			return TRUE;
		}
		else
		{
			return FALSE;
		}
	}

	public function current()
	{
		if ($this->_current_row !== $this->_internal_row AND ! $this->seek($this->_current_row))
			return NULL;

		// Increment internal row for optimization assuming rows are fetched in order
		$this->_internal_row++;

		// Return an array of the row
		return mysql_fetch_assoc($this->_result);
	}

	/**
	 * Return all of the rows in the result as an array.
	 *
	 *     // Indexed array of all rows
	 *     $rows = $result->as_array();
	 *
	 *     // Associative array of rows by "id"
	 *     $rows = $result->as_array('id');
	 *
	 *     // Associative array of rows, "id" => "name"
	 *     $rows = $result->as_array('id', 'name');
	 *
	 * @param   string  column for associative keys
	 * @param   string  column for values
	 * @return  array
	 */
	public function as_array($key = NULL, $value = NULL)
	{
		$results = array();

		if ($key === NULL AND $value === NULL)
		{
			// Indexed rows

			foreach ($this as $row)
			{
				$results[] = $row;
			}
		}
		elseif ($key === NULL)
		{
			// Indexed columns
			foreach ($this as $row)
			{
				$results[] = $row[$value];
			}
		}
		elseif ($value === NULL)
		{
			// Associative rows
			foreach ($this as $row)
			{
				$results[$row[$key]] = $row;
			}
		}
		else
		{
			// Associative columns
			foreach ($this as $row)
			{
				$results[$row[$key]] = $row[$value];
			}
		}

		$this->rewind();

		return $results;
	}

	/**
	 * Return the named column from the current row.
	 *
	 *     // Get the "id" value
	 *     $id = $result->get('id');
	 *
	 * @param   string  column to get
	 * @param   mixed   default value if the column does not exist
	 * @return  mixed
	 */
	public function get($name, $default = NULL)
	{
		$row = $this->current();

		if (isset($row[$name]))
			return $row[$name];

		return $default;
	}

	/**
	 * Implements [Countable::count], returns the total number of rows.
	 *
	 *     echo count($result);
	 *
	 * @return  integer
	 */
	public function count()
	{
		return $this->_total_rows;
	}

	/**
	 * Implements [ArrayAccess::offsetExists], determines if row exists.
	 *
	 *     if (isset($result[10]))
	 *     {
	 *         // Row 10 exists
	 *     }
	 *
	 * @return  boolean
	 */
	public function offsetExists($offset)
	{
		return ($offset >= 0 AND $offset < $this->_total_rows);
	}

	/**
	 * Implements [ArrayAccess::offsetGet], gets a given row.
	 *
	 *     $row = $result[10];
	 *
	 * @return  mixed
	 */
	public function offsetGet($offset)
	{
		if ( ! $this->seek($offset))
			return NULL;

		return $this->current();
	}

	/**
	 * Implements [ArrayAccess::offsetSet], throws an error.
	 *
	 * [!!] You cannot modify a database result.
	 *
	 * @return  void
	 * @throws  Exception
	 */
	final public function offsetSet($offset, $value)
	{
		throw new Database_Exception('Database results are read-only');
	}

	/**
	 * Implements [ArrayAccess::offsetUnset], throws an error.
	 *
	 * [!!] You cannot modify a database result.
	 *
	 * @return  void
	 * @throws  Exception
	 */
	final public function offsetUnset($offset)
	{
		throw new Database_Exception('Database results are read-only');
	}

	/**
	 * Implements [Iterator::key], returns the current row number.
	 *
	 *     echo key($result);
	 *
	 * @return  integer
	 */
	public function key()
	{
		return $this->_current_row;
	}

	/**
	 * Implements [Iterator::next], moves to the next row.
	 *
	 *     next($result);
	 *
	 * @return  $this
	 */
	public function next()
	{
		++$this->_current_row;
		return $this;
	}

	/**
	 * Implements [Iterator::prev], moves to the previous row.
	 *
	 *     prev($result);
	 *
	 * @return  $this
	 */
	public function prev()
	{
		--$this->_current_row;
		return $this;
	}

	/**
	 * Implements [Iterator::rewind], sets the current row to zero.
	 *
	 *     rewind($result);
	 *
	 * @return  $this
	 */
	public function rewind()
	{
		$this->_current_row = 0;
		return $this;
	}

	/**
	 * Implements [Iterator::valid], checks if the current row exists.
	 *
	 * [!!] This method is only used internally.
	 *
	 * @return  boolean
	 */
	public function valid()
	{
		return $this->offsetExists($this->_current_row);
	}

} // End Database_Result

class Database_Exception extends Exception { }