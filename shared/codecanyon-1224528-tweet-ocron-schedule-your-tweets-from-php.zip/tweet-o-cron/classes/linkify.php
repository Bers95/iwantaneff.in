<?php
/**
 * Helper class to process known linkable patterns in tweet strings
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
class Linkify {

	/**
	 * Runs all conversions on the string.
	 *
	 * @param   string  $string  text to process
	 * @return  string
	 */
	public static function text($string)
	{
		// Convert URLs
		$string = Linkify::urls($string);

		// Convert users
		$string = Linkify::at_tags($string);

		// Convert hash tags
		$string = Linkify::hash_tags($string);

		return $string;
	}

	/**
	 * Converts all urls strings to html anchors.
	 *
	 * @param   string  $string  text to process
	 * @return  string
	 */
	public static function urls($string)
	{
		$string = preg_replace("/(^|[\n ])([\w]*?)((ht|f)tp(s)?:\/\/[\w]+[^ \,\"\n\r\t<]*)/is", "$1$2<a href=\"$3\" >$3</a>", $string);
		$string = preg_replace("/(^|[\n ])([\w]*?)((www|ftp)\.[^ \,\"\t\n\r<]*)/is", "$1$2<a href=\"http://$3\" >$3</a>", $string);
		$string = preg_replace("/(^|[\n ])([a-z0-9&\-_\.]+?)@([\w\-]+\.([\w\-\.]+)+)/i", "$1<a href=\"mailto:$2@$3\">$2@$3</a>", $string);

		return $string;
	}

	/**
	 * Converts all @ tags to html anchors.
	 *
	 * @param   string  $string  text to process
	 * @return  string
	 */
	public static function at_tags($string)
	{
		return preg_replace("/@(\w+)/", '<a href="//twitter.com/$1" target="_blank">@$1</a>', $string);
	}

	/**
	 * Converts all hash tags to html anchors.
	 *
	 * @param   string  $string  text to process
	 * @return  string
	 */
	public static function hash_tags($string)
	{
		return preg_replace("/\#(\w+)/", '<a href="//search.twitter.com/search?q=$1" target="_blank">#$1</a>', $string);
	}
}