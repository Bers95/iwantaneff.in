<?php
/**
 * Simple flash session handler, returns nice HTML messages
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
class Message {

	/**
	 * @var  string  default session key used for storing messages
	 */
	public static $session_key = 'messages';

	// Message types
	const SUCCESS = 'success';
	const INFO    = 'info';
	const ERROR   = 'error';
	const WARNING = 'warning';

	/**
	 * Adds a new message.
	 *
	 * @param   string  message type (e.g. Message::SUCCESS)
	 * @param   string  message text
	 * @param   array   any options for the message
	 * @return  void
	 */
	public static function set($type, $text, $static = FALSE)
	{
		// Load existing messages
		$messages = (array) Message::get();

		// Add new message
		$messages[] = (object) array(
			'type'    => $type,
			'text'    => $text,
			'static'  => $static,
		);

		// Store the updated messages
		Message::_session();
		$_SESSION[Message::$session_key] = $messages;
	}

	/**
	 * Returns all messages.
	 *
	 * @return  array or NULL
	 */
	public static function get()
	{
		Message::_session();

		if (isset($_SESSION[Message::$session_key]))
			return $_SESSION[Message::$session_key];
	}

	/**
	 * Clears all messages.
	 *
	 * @return  void
	 */
	public static function clear()
	{
		Message::_session();
		$_SESSION[Message::$session_key] = array();
	}

	/**
	 * Renders the message(s), and by default clears them too.
	 *
	 * @param   mixed    string of the view to use, or a Kohana_View object
	 * @param   boolean  set to FALSE to not clear messages
	 * @return  string   message output (HTML)
	 */
	public static function render($clear = TRUE)
	{
		// Nothing to render
		if (($messages = Message::get()) === NULL)
			return '';

		// Clear all messages
		if ($clear)
		{
			Message::clear();
		}

		$html = '';

		foreach ($messages as $message)
		{
			$html .= View::load('message', array(
				'type'    => $message->type,
				'message' => $message->text,
				'static'  => ($message->static === FALSE) ? '' : 'data-static="true"'
			))->render();
		}

		// Return the rendered view
		return $html;
	}

	/**
	 * Start a session if one doesn't exist
	 *
	 * @return void
	 */
	protected static function _session()
	{
		// Do not allow PHP to send Cache-Control headers
		session_cache_limiter(FALSE);

		if ( ! isset($_SESSION))
		{
			session_name('tweetocron');
			session_start();
		}
	}
} // END class Message
