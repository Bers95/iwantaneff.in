<?php
/**
 * Manage and schedule tweets using PHP
 *
 * @package    Tweet O'cron
 * @author     Orange Peel Studios (orangepeeled)
 * @copyright  (c) 2012 Orange Peel Studios
 * @license    http://orangepeelstudios.com/envato/license
 */
class TweetOCron {

	const VERSION = '2.0';

	/**
	 * @var  TweetOCron   Object singleton storage
	 */
	protected static $_instance;

	/**
	 * @var  array   Config array
	 */
	protected $_config;

	/**
	 * Singleton pattern, returns a Tweet O'cron instance.
	 *
	 * @param  array   $config   config array to override default filesystem config
	 * @return TweetOCron
	 */
	public static function instance(array $config = array())
	{
		if (empty($config))
		{
			// No config supplied, use our own
			$config = Core::config('tweetocron');
		}

		if ( ! isset(TweetOCron::$_instance))
		{
			// No instance already created so let's make one
			return new TweetOCron($config);
		}

		// Instance already exists
		return TweetOCron::$_instance;
	}

	/**
	 * No access to this publically, use static instance method.
	 *
	 * @param   array    $config  configuration array
	 * @return  void
	 */
	protected function __construct(array $config)
	{
		// Store config locally
		$this->_config = $config;

		// Store instance
		TweetOCron::$_instance = $this;
	}

	/**
	 * Schedules a tweet by saving it to the database
	 *
	 * @param   string   $tweet    tweet string
	 * @param   string   $publish  mysql formated timestamp
	 * @param   integer  $user_id  id of user to associate tweet with if not logged in user
	 * @return  array
	 */
	public function schedule($tweet, $publish, $user_id = NULL)
	{
		// Get the user
		$user_id = $this->get_user($user_id, TRUE)->id;

		try
		{
			// Shortcut to the DB
			$db = Database::instance();

			// Insert new tweet into the database
			$result = $db->insert("INSERT INTO `:table` (`tweet`, `publish`, `user_id`) VALUES (:tweet, :publish, :user_id);", array(
				':table'   => $db->prefix.'tweets',
				':tweet'   => $db->escape(strip_tags($tweet)), // No tags allowed :)
				':publish' => $db->escape($publish),
				':user_id' => $db->escape($user_id)
			));

			if ($result['rows'] == 1)
			{
				// Set message if row is saved
				Message::set(Message::SUCCESS, '<strong>Success!</strong> Your tweet has been scheduled.');
			}
			else
			{
				throw new Database_Exception('Tweet was not saved to the database');
			}

			return $result;
		}
		catch (Database_Exception $e)
		{
			// Catch any Database_Exceptions and return a nice message instead
			Message::set(Message::ERROR, '<strong>Uh oh!</strong> Your tweet could not be scheduled, please try again.');
		}
	}

	/**
	 * Unschedules a tweet by removing it from the database
	 *
	 * @param   integer  $id  id of the tweet to remove
	 * @return  boolean
	 */
	public function unschedule($id)
	{
		try
		{
			// Shortcut to the DB
			$db = Database::instance();

			// Insert new tweet into the database
			$result = (bool) $db->delete("DELETE FROM `:table` WHERE `id` = :id LIMIT 1;", array(
				':table' => $db->prefix.'tweets',
				':id'    => $db->escape($id)
			));

			if ($result)
			{
				// Set message if row is saved
				Message::set(Message::SUCCESS, '<strong>Success!</strong> Your tweet has been unscheduled.');
			}
			else
			{
				throw new Database_Exception('Record not removed');
			}

			return $result;
		}
		catch (Database_Exception $e)
		{
			// Catch any Database_Exceptions and return a nice message instead
			Message::set(Message::ERROR, '<strong>Uh oh!</strong> Your tweet could not be unscheduled, please try again.');
		}
	}

	/**
	 * Publish tweet to Twitter, will also check for overdue tweets.
	 *
	 * @param   integer  $id   id of the tweet to publish
	 * @param   boolean  $all  find all the overdue tweets
	 * @return  void
	 */
	public function publish($id = NULL, $all = TRUE)
	{
		// Empty tweets array
		$tweets = array();
		if ($all === TRUE)
		{
			// Get all tweets waiting to be scheduled
			$tweets = $this->check();
		}

		try
		{
			// Shortcut to the database
			$db = Database::instance();

			if ($id !== NULL)
			{
				// Add a tweet by its database ID, if it already exists it will replace itself so no duplicates exist
				$tweets = $tweets + $this->tweets(NULL, $id)->as_array('id');
			}

			// Check we have some tweets to publish
			if ( ! empty($tweets))
			{
				// Start array we want to store tweets to publish
				$publish = array();
				foreach ($tweets as $tweet)
				{
					// Add tweets and group by user_id so we only need to make one connection to Twitter & DB per user
					$publish[$tweet['user_id']][$tweet['id']] = $tweet;
				}

				// Loop through tweets to publish
				foreach ($publish as $user_id => $tweets)
				{
					try
					{
						// Start the TwitterOAuth connection
						$twitter = $this->connect($user_id);

						foreach ($tweets as $tweet)
						{
							if ( ! empty($tweet['tweet_id']))
								continue; // Double check, skip if it's already been tweeted

							// Post each tweet to the Twitter API
							$result = $twitter->post('statuses/update', array('status' => $tweet['tweet']));

							if (isset($result->error))
							{
								// If an error exists throw this as exeception
								throw new TweetOCron_Exception($result->error);
							}
							else
							{
								// The tweets been posted so remove it from the database
								$db->update('UPDATE `:table` SET `tweet_id` = :tweet_id  WHERE `id` = :id;',
									array(
										':table'    => $db->prefix.'tweets',
										':id'       => $db->escape($tweet['id']),
										':tweet_id' => $db->escape($result->id)
									));
							}
						}
					}
					catch (TweetOCron_Exception $e)
					{
						// Catch the TweetOCron_Exception and show a nice looking error message instead
						Message::set(Message::ERROR, '<strong>Uh oh!</strong> Tweet could not be published: '.$e->getMessage());
					}
				}

				if ($id !== NULL AND $result)
				{
					// If this was a call to specific tweet and result is still TRUE by the end of the loop show success message
					Message::set(Message::SUCCESS, '<strong>Success!</strong> Your tweet has been published on Twitter.');
				}
			}
		}
		catch (Database_Exception $e)
		{
			// Database problem
			Message::set(Message::ERROR, '<strong>Uh oh!</strong> There was a problem with the database. '.$e->getMessage());
		}
	}

	/**
	 * Update a tweet record in the database.
	 *
	 * @param   integer  $id       tweet id to update
	 * @param   string   $tweet    the tweet
	 * @param   string   $publish  MySQL date to publish
	 * @return  boolean
	 */
	public function update($id, $tweet, $publish)
	{
		try
		{
			// Shortcut to the DB
			$db = Database::instance();

			// Update tweet in the database
			$result = (bool) $db->insert("UPDATE `:table` SET `tweet` = :tweet, `publish` = :publish WHERE `id` = :id;", array(
				':table'   => $db->prefix.'tweets',
				':tweet'   => $db->escape(strip_tags($tweet)), // No tags allowed :)
				':publish' => $db->escape($publish),
				':id'      => $db->escape($id)
			));

			// Set message if row is saved
			if ($result)
			{
				Message::set(Message::SUCCESS, '<strong>Success!</strong> Your tweet has been updated.');
				return $result;
			}
			else
			{
				throw new Database_Exception('Tweet wasn\'t updated.');
			}

		}
		catch (Database_Exception $e)
		{
			// Catch any Database_Exceptions and return a nice message instead
			Message::set(Message::ERROR, '<strong>Uh oh!</strong> Your tweet could not be updated, please try again.');
		}
	}

	/**
	 * Returns the Twitter API rate limit status for user
	 *
	 * @param  integer  $user_id  user to find api status for
	 * @return TwitterOAuth
	 */
	public function api_status($user_id = NULL)
	{
		$twitter = $this->connect($user_id);
		return $twitter->get('account/rate_limit_status');
	}

	/**
	 * Finds the user, if no id is supplied finds the logged in user
	 *
	 * @param   integer  $id         id of user to find
	 * @param   boolean  $as_object  return as stdObject
	 * @return  array
	 */
	public function get_user($id = NULL, $as_object = FALSE)
	{
		// Shortcut to the DB
		$db = Database::instance();

		if ($id === NULL)
		{
			// Set the ID of the currently signed in user
			$id = $_SESSION[$db->prefix.'user']->id;
		}

		// Check the session first to save a DB call, double check the id matches the id in the user session
		if ((isset($_SESSION[$db->prefix.'user']) AND ! empty($_SESSION[$db->prefix.'user'])) AND ($id === NULL AND $_SESSION[$db->prefix.'user']->id == $id))
		{
			// Return session as an array
			$user = (array) $_SESSION[$db->prefix.'user'];
		}
		else
		{
			// Return the users record
			$user = $db->select("SELECT * FROM `:table` WHERE `id` = :id;", array(
				':table' => $db->prefix.'users',
				':id'    => $db->escape($id)
			))->current();
		}

		// Return array
		if ($as_object === FALSE)
			return $user;

		// Return an object
		return (object) $user;
	}

	/**
	 * Connect to Twitter using users credentials.
	 *
	 * @param   integer  $user_id  user_id of the Twitter account to connect
	 * @return  TwitterOAuth
	 */
	public function connect($user_id = NULL)
	{
		// Find the user record
		$user = $this->get_user($user_id);

		// Load the config
		$config = (array) Core::config('tweetocron', TRUE)->twitter;

		// Decrypt the secret
		$secret = Core::decrypt($user['oauth_token_secret']);

		// Create TwitterOAuth object with app key/secret and request token key/secret
		return new TwitterOAuth($config['consumer_key'], $config['consumer_secret'], $user['oauth_token'], $secret);
	}

	/**
	 * Finds all tweets, allow filtering by user_id and tweet id.
	 *
	 * @param   integer  $user_id  find all tweets matching user_id
	 * @param   integer  $id       find this tweet id
	 * @param   boolean  $all      set TRUE to return all tweets regardless of published status
	 * @return  array
	 */
	public function tweets($user_id = NULL, $id = NULL, $all = FALSE)
	{
		// Shortcut to the DB
		$db = Database::instance();

		if ($user_id === NULL)
		{
			// Set the user_id
			$user_id = $_SESSION[$db->prefix.'user']->id;
		}

		$filter = array();
		if ($user_id !== NULL)
		{
			// Filter by user_id
			$filter[] = '`user_id` = '.$db->escape($user_id);
		}

		if ($id !== NULL)
		{
			// Filter by tweet id
			$filter[] = '`id` = '.$db->escape($id);
		}

		if ($all === FALSE)
		{
			// Grab all records with blank tweet_id
			$filter[] = '`tweet_id` IS NULL';
		}

		$query = '';
		if (count($filter))
		{
			// Build query if we want filtering
			$query = 'WHERE '.implode(' AND ', $filter);
		}

		// Select the tweets from the database
		$tweets = $db->select("SELECT * FROM `:table` :query ORDER BY `publish` ASC;", array(
			':table' => $db->prefix.'tweets',
			':query' => $query
		));

		// Return array of results
		return $tweets;
	}

	/**
	 * Finds all overdue tweets and returns an array with ids as keys.
	 *
	 * @return array
	 */
	public function check()
	{
		// Return all the records that need publishing
		return Database::instance()->select("SELECT * FROM `:table` WHERE `publish` < UTC_TIMESTAMP() AND `tweet_id` IS NULL ORDER BY `publish` ASC;", array(
			':table' => Database::instance()->prefix.'tweets'
		))->as_array('id');
	}

	/**
	 * Returns a users tweet timeline.
	 *
	 * @param   integer  $count    number of tweets to return
	 * @param   integer  $user_id  id of the user to get tweets for
	 * @return  array
	 */
	public function get_timeline($count = 10, $user_id = NULL)
	{
		// Setup API parameters
		$params = array(
			'count'            => $count,
			'include_entities' => TRUE,
		);

		if ($user_id !== NULL)
		{
			// If the user is not NULL set the user
			$params['user_id'] = $user_id;
		}

		// Connect to twitter
		$twitter = $this->connect($user_id);

		// Return the users timeline as an array
		return (array) $twitter->get('statuses/user_timeline', $params);
	}
} // END TweetOCron

class TweetOCron_Exception extends Exception { }