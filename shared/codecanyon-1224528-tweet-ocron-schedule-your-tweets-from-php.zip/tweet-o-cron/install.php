<?php
// Sanity check, install should only be checked from index.php
defined('DOCROOT') or exit('Install tests must be loaded from within index.php!');

if (version_compare(PHP_VERSION, '5.3', '<'))
{
	// Clear out the cache to prevent errors. This typically happens on Windows/FastCGI.
	clearstatcache();
}
else
{
	// Clearing the realpath() cache is only possible PHP 5.3+
	clearstatcache(TRUE);
}

if (isset($_GET['action']))
{
switch ($_GET['action'])
{
	case 'install':
		try
		{
			$db = Database::instance();

			// Create the users table
			$db->insert("CREATE TABLE IF NOT EXISTS `:users` (
							`id` bigint(20) unsigned NOT NULL,
							`screen_name` varchar(24) NOT NULL DEFAULT '',
							`oauth_token` varchar(127) NOT NULL DEFAULT '',
							`oauth_token_secret` varchar(255) NOT NULL,
							`profile` text,
							PRIMARY KEY (`id`)
						) ENGINE=InnoDB DEFAULT CHARSET=utf8;", array(
				':users'  => $db->prefix.'users'
			));

			// Create the tweets table
			$db->insert("CREATE TABLE IF NOT EXISTS `:tweets` (
							`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
							`tweet` varchar(140) NOT NULL DEFAULT '',
							`publish` datetime NOT NULL DEFAULT '0001-01-01 00:00:00',
							`user_id` bigint(20) unsigned NOT NULL,
							`tweet_id` bigint(50) unsigned DEFAULT NULL,
							PRIMARY KEY (`id`),
							KEY `user_id` (`user_id`),
							KEY `idx_tweet_id` (`tweet_id`)
						) ENGINE=InnoDB DEFAULT CHARSET=utf8;", array(
				':tweets'  => $db->prefix.'tweets'
			));

			// Setup relationship
			$db->insert("ALTER TABLE `:tweets`
					ADD CONSTRAINT `:tweets_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `:users` (`id`) ON DELETE CASCADE;", array(
				':tweets'  => $db->prefix.'tweets',
				':users'  => $db->prefix.'users'
			));

			// Hooray!
			Message::set(Message::SUCCESS, '<strong>Hooray!</strong> Tweet O&apos;cron is ready to use, delete or rename <strong>install.php</strong>', TRUE);

			header('Location: '.Core::url());
			exit;
		}
		catch (Database_Exception $e)
		{
			Message::set(Message::ERROR, '<strong>Uh oh!</strong> Tweet O&apos;cron could not create the tables: '.$e->getMessage(), TRUE);
		}
		break;
}
}

$failed = FALSE;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Tweet O&apos;cron - Installation</title>
	<meta name="description" content="Tweet O&apos;cron allows you to conveniently schedule tweets from a PHP website.">
	<meta name="author" content="orangepeelstudios.com">

	<link href="<?php echo Core::url('media/css/bootstrap.css'); ?>" rel="stylesheet">
	<link href="<?php echo Core::url('media/css/style.css'); ?>" rel="stylesheet">
	<style type="text/css">
	body {
		padding-top:30px;
	}
	table.tests span.label {
		font-size:.85em;
		padding:.3em .5em;
	}
	table.tests .result {
		width: 280px;
	}
	</style>
</head>
<body>
<div class="container">
<div class="content">
	<div class="alert-message block-message warning" data-static="true">
		<h3>Thanks for purchasing Tweet O&apos;cron &ndash; you&rsquo;re awesome!</h3>
		<p>Tweet O&apos;cron needs to check a few things out so you can start using it to schedule your tweets. See the checklist below, if everything is showing <span class="label success">Success!</span> click install at the bottom of the page to install the Tweet O&apos;cron database tables.</p><br>
		<p><b>Please note:</b> Don't forget to update <code>WEBROOT</code> and <code>INDEX_FILE</code> values in the <code>config/init.php</code> file and the <code>RewriteBase</code> value found in <code>.htaccess</code> (you may need to turn on hidden files to view this file) to ensure they match your environment. Refer to the Tweet O&apos;cron documentation for more details.
	</div>
	<section style="padding-top:0;">
		<div class="page-header">
			<h1>Tweet O&apos;cron Installation</h1>
		</div>
		<?php echo Message::render(); // Show messages here ?>

		<!-- Environmental Tests -->
		<h3>Environmental Tests</h3>
		<table id="evironmental-tests" class="tests zebra-striped">
		<tbody>
			<tr>
				<td>PHP Version (Tweet O&apos;cron requires PHP 5.2 or later)</td>
				<td class="result">
					<?php if (version_compare(PHP_VERSION, '5.2', '>=')): ?>
						<span class="label success">Success! <?php echo PHP_VERSION; ?> detected</span>
					<?php else: $failed = TRUE; ?>
						<span class="label important">Failed! <?php echo PHP_VERSION; ?> detected</span>
					<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>SPL Enabled (Required for class autoloading)</td>
				<td class="result">
				<?php if (function_exists('spl_autoload_register')): ?>
					<span class="label success">Success! SPL Enabled</span>
				<?php else: $failed = TRUE; ?>
					<span class="label important">Failed! PHP <a href="http://www.php.net/spl">SPL</a> is either not loaded or not compiled</span>
				<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>Mcrypt Enabled (Required for encryption of user API keys)</td>
				<td class="result">
				<?php if (extension_loaded('mcrypt')): ?>
					<span class="label success">Success! Mcrypt Enabled</span>
				<?php else: $failed = TRUE; ?>
					<span class="label important">Failed! Tweet O&apos;cron requires the <a href="http://php.net/mcrypt">mcrypt</a></span>
				<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>MySQL Enabled (Required to connect to the database)</td>
				<td>
				<?php if (function_exists('mysql_connect')): ?>
					<span class="label success">Success! MySQL Enabled</span>
				<?php else: $failed = TRUE; ?>
					<span class="label important">Failed! Tweet O&apos;cron requires the <a href="http://php.net/mysql">MySQL</a> extension</span>
				<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>URI Determination (Check if <code>$_SERVER['REQUEST_URI']</code> is available)</td>
				<td>
				<?php if (isset($_SERVER['REQUEST_URI'])): ?>
					<span class="label success">Success!</span>
				<?php else: $failed = TRUE; ?>
					<span class="label important">Failed!</span>
				<?php endif ?>
				</td>
			</tr>
		</tbody>
		</table>

		<?php if ($failed === FALSE): ?>
		<!-- Configuration Tests -->
		<h3>Configuration Tests</h3>
		<table id="configuration-tests" class="tests zebra-striped">
		<tbody>
			<tr>
				<td>Tweet O&apos;cron Encryption Key (Config: <code>config/tweetocron.php</code>)</td>
				<td class="result">
					<?php if (Core::config('tweetocron', TRUE)->encryption_key != 'Tweet O\'cron is awesome!'): ?>
						<span class="label success">Success! You have changed the encryption key</span>
					<?php else: ?>
						<span class="label warning">Warning! You should change this</span>
					<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>Twitter API Credentials Available (Config: <code>config/tweetocron.php</code>)</td>
				<td class="result">
					<?php
						$config = Core::config('tweetocron', TRUE)->twitter;
						if ( ! empty($config['consumer_key']) AND ! empty($config['consumer_secret'])): ?>
						<span class="label success">Success! API keys found</span>
					<?php else: $failed = TRUE; ?>
						<span class="label important">Failed! Enter your API keys</span>
					<?php endif ?>
				</td>
			</tr>

			<tr>
				<td>MySQL Database Connection (Config: <code>config/database.php</code>)</td>
				<td class="result">
					<?php
					try {
						$db = Database::instance();
						$tables = $db->select("SHOW TABLES FROM :db;", array(
							':db' => Core::config('database', TRUE)->database
						));
					?>
						<span class="label success">Success! Database connected</span>
					<?php } catch (Database_Exception $e) {
						$failed = TRUE; ?>
						<span class="label important">Failed! An error occurred checking your database</span>
						<pre style="margin-top:5px;"><?php echo $e->getMessage(); ?></pre>
					<?php } ?>
				</td>
			</tr>

		</tbody>
		</table>
		<?php endif; ?>

		<?php if ($failed === FALSE): ?>
		<div class="alert-message block-message success" data-static="true">
			<h3>You're ready to install Tweet O&apos;cron&hellip;</h3>
			<p>What are you waiting for!</p>
			<a href="?action=install" class="btn success" style="margin-top:10px;">Install Tweet O&apos;cron »</a>
		</div>
		<?php else: ?>

		<?php endif ?>

	</section>
</div>
<footer>
	<p>&copy; 2011 Orange Peel Studios (<a href="http://twitter.com/orangepeeled" target="_blank">orangepeeled</a>)</p>
</footer>
</div> <!-- /container -->
</body>
</html>
