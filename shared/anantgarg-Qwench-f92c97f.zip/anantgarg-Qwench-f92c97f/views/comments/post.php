<div class="comment">
<?php echo $comment;?> - <a href="<?php echo basePath();?>/users/<?php echo $userid;?>/<?php echo $username;?>"><?php echo $username;?></a>
</div>