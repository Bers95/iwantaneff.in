<h1><?php echo $user['name'];?></h1>

<h3>Points: <?php echo $user['points'];?></h3>
