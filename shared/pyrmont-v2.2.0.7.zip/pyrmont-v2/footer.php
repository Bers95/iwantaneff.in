</div><!-- end page_wrap -->
<div id="footer">
	<div class="footer_wrapper">
		<div class="footer_left">
			&copy;&nbsp;<?php bloginfo('name'); ?>.&nbsp;<?php _e('Powered by <a href="http://wordpress.org/" title="CODE IS POETRY">WordPress</a>&nbsp;and&nbsp;<a href="http://imotta.cn/" title="Pyrmont V2 theme">Pyrmont V2</a>.', 'pyrmont_v2'); ?>
		</div>
	</div>
</div><!-- end footer -->

<?php wp_footer(); ?>

</body>
</html>