﻿Thanks for choosing Pyrmont V2 Theme. Before start, take a minute to have a look at this file.

1. Links Page and Archives Page are ready to use. When creating a new page, you can choose the template (Links or Archives), leave the content blank, click publish and it's done.

2. Sticky post is supported. It'll have a darker background color.

3. Got twitter? Open header.php file with your favorite text editor, uncomment line 38 (delete BOTH "<!--" and "-->") and replace "your_user_name" with your real twitter user name. Save and refresh the web page. You should see the cute bird.

Support: WordPress 2.7 and later.

The theme is tested only on IE 6-8, Firefox and Chrome at the local environment, and works well.

If any cross browser capability problems, or any bugs found, please contact me.

Email: mottaed@gmail.com.

Enjoy!