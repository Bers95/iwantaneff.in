<? extend('templates/master.php') ?>
<? startblock('title') ?><?=$issue->title?><? endblock() ?>
<? startblock('extra_head') ?>
<script src="<?=base_url()?>js/jquery.lightbox_me.js" type="text/javascript"></script> 	
<script type="text/javascript">
$(document).ready(function() {
	$("#delete-topic").click(function() {
		$("#delete-topic-overlay").lightbox_me({
			centered: true
		});
		return false;
	});
	$("a.delete-reply").click(function() {
		var url = $(this).attr('href');
		$("#delete-reply-overlay").lightbox_me({
			centered: true,
			onLoad: function() { 
	            $('#delete-reply-confirm').attr('href',url);
            }
    	});
		return false;
	});
});
</script>
<? endblock() ?>
<? startblock('content') ?>
<h1><?=$issue->title?></h1>

<div class="post first">
<div class="author">
<p class="name"><strong><?=$issue->author_username?></strong></p>
<p class="date"><?=date('F j, g:ia',strtotime($issue->date_submitted))?></p>
</div>
<div class="issue <?=$issue->type?>">
<?=$issue->content?>
</div>
</div>

<? if (!empty($comments)): ?>
<? foreach($comments as $comment): ?>
<div class="post">

<div class="author">
<? if ($comment->author_group > 1): ?>
	<p class="employee-name"><strong><?=$comment->author_username?></strong></p>
	<p class="employee-title">Employee</p>
<? else: ?>
	<p class="name"><strong><?=$comment->author_username?></strong></p>
<? endif; ?>
<p class="date"><?=date('F j, g:ia',strtotime($comment->date))?></p>
<? if (get_user_group() > 1): ?>
<p><?=anchor('feedback/delete_reply/'.$comment->id.'/'.$issue->type,'Delete','class="delete-reply"')?></p>
<? endif; ?>
</div>
<div class="issue">
<?=$comment->content?>
</div>
</div>
<? endforeach; ?>
<? else: ?>
<div class="post">
<div class="author"></div>
<div class="issue"><p>No comments have been posted<?php echo ($issue->active == 1) ? ' yet' : ''?>.</p></div>
</div>
<? endif; ?>


<? if (is_logged_in() && ($issue->active == 1)): ?>
<h2 class="reply">Post a reply</h2>
<? if (validation_errors()): ?>
<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif;?>
<?=form_open('feedback/postreply')?>
<?=form_hidden('feedback_type',$issue->type)?>
<?=form_hidden('feedback_item',$issue->id)?>
<textarea name="reply_message" id="reply_message"></textarea>
<input type="submit" id="post" name="post" class="form_button" value="Post reply" />
</form>
<? endif; ?>

<? endblock() ?>

<? startblock('sidebar') ?>
<h3>This <?=$issue->type?>&hellip;</h3>
<ul class="nomargin">
<li><strong><?=$issue->vote_count?></strong> <?= ($issue->vote_count == 1) ? 'star' : 'stars' ?></li>
<li><strong><?=count($comments)?></strong> <?= (count($comments) == 1) ? 'reply' : 'replies' ?></li>
<? if ($issue->type != 'praise'): ?>
<li>is <strong><?= ($issue->active == 1) ? 'active' : 'resolved' ?></strong>.</li>
<? endif; ?>
</ul>

<? if (is_logged_in()): ?>
<p>If this is important to you then star it!</p>
<p><? $class = "voteup"; if (isset($vote_record[$issue->id])) { $class .= " voted"; } ?>
<?=anchor('feedback/vote/'.$issue->id,$issue->vote_count,'class="'.$class.'"')?>

<? if (get_user_group() > 1): ?>
<h3 class="tools">Employee tools</h3>
<ul>
<? if ($issue->type != 'praise'): ?>
	<? $string = ((1-$issue->active) == 1) ? 'active' : 'resolved' ?>
	<li id="mark-as"><?= anchor('feedback/status/'.$issue->id.'/'.(1-$issue->active),'Mark as '.$string)?></li>
<? endif; ?>
<li><?= anchor('feedback/delete/'.$issue->id,'Delete topic','id="delete-topic"')?></li>
<? endif; ?>
</ul>

<? endif; ?>

<? if (is_logged_in() && (get_user_group() > 1)): ?>
<div class="overlay" id="delete-topic-overlay">
<h3>Are you sure?</h3>
<p>Are you sure you want to delete this topic? This cannot be undone!</p>
<p><?=anchor('feedback/delete/'.$issue->id,'Yes, delete this topic','id="delete-topic-confirm"')?> or <a href="#" class="close">cancel</a></p>
</div>
<div class="overlay" id="delete-reply-overlay">
<h3>Are you sure?</h3>
<p>Are you sure you want to delete this reply? This cannot be undone!</p>
<p><?=anchor('feedback/delete/'.$issue->id,'Yes, delete this reply','id="delete-reply-confirm"')?> or <a href="#" class="close">cancel</a></p>
</div>
<? endif; ?>
<? endblock() ?>
<? end_extend() ?>