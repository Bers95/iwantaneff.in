<? extend('templates/master.php') ?>
<? startblock('title') ?><?=$title?><? endblock() ?>
<? startblock('content') ?>
<h1 class="<?=singular($title)?>"><?=$title?></h1>

<? if(!empty($items)): ?>
<ul class="feedback">
	<? foreach($items as $item): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($item->comments == 1) ? $item->comments.' reply' : $item->comments.' replies';
	?>
	<li>
		<div class="feedback-info">
		<p class="title"><?=anchor($item->type.'/v/'.$item->id,$item->title)?></p>
		<p class="meta">by <?=$item->author_username?> on <?=date('F j, g:ia',strtotime($item->date_submitted))?> - <?=$replies_string?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$item->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$item->id : ''; ?>
		<?=anchor($url,$item->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<?=$links?>
<? else: ?>
<p>There have been no recent <?=strtolower($title)?>.</p>
<? endif; ?>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?><h3>Change your view</h3><ul><li><?php echo anchor($this->uri->segment(1),'View most recent') ?></li><li><?php echo anchor($this->uri->segment(1).'/top/0','View most popular') ?></li></ul>
<? endblock() ?>
<? end_extend() ?>