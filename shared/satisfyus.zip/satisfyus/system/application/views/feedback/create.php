<? extend('templates/master.php') ?>
<? startblock('title') ?>Post new feedback!<? endblock() ?>
<? startblock('extra_head') ?>
<script type="text/javascript" src="<?=base_url()?>js/wysiwyg/jquery.wysiwyg.js"></script> 
<link rel="stylesheet" href="<?=base_url()?>js/wysiwyg/jquery.wysiwyg.css" type="text/css" /> 
<script type="text/javascript" charset="utf-8">
$(document).ready(function() {
	$('.wysiwyg').wysiwyg();
});
</script>
<? endblock() ?>
<? startblock('content') ?>
<h1>Give us some feedback</h1>
<? if (validation_errors()): ?>
<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif; ?>
<?=form_open('feedback/add')?>
<label for="feedback_type" class="label">What kind of feedback do you want to give us?</label>
<span class="question"><?=form_radio('feedback_type', 'question', TRUE)?> Question</span>
<span class="idea"><?=form_radio('feedback_type', 'idea')?> Idea</span>
<span class="problem"><?=form_radio('feedback_type', 'problem')?> Report a problem</span>
<span class="praise"><?=form_radio('feedback_type', 'praise')?> Give some praise</span>

<label for="feedback_message" class="label">Describe it to us</label>
<textarea name="feedback_message" id="feedback_message"><?=set_value('feedback_message')?></textarea>

<label for="feedback_title" class="label">Now give it a title</label>
<input type="text" id="feedback_title" name="feedback_title" class="input title" value="<?=set_value('feedback_title')?>" />

<input type="submit" id="add" name="add" class="form_button" value="Post your topic" />

<? endblock() ?>
<? startblock('sidebar') ?>
<h3>Tips</h3>
<p>Increase your chances of getting answered:</p>
<ul>
	<li>Add some detail, one or two paragraphs works best.</li>
	<li>Add a title.</li>
	<li>Describe how the topic makes you feel!</li>
	<li>Make sure you pick the feedback type that most accurately reflects your comments.</li>
</ul>
<? endblock() ?>
<? end_extend() ?>