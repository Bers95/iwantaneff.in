<? $site_title = get_setting('site_title'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"> 
<head> 
<title><? start_block_marker('title') ?>Welcome<? end_block_marker() ?> &mdash; <?=$site_title?></title> 
<link href=' http://fonts.googleapis.com/css?family=Nobile' rel='stylesheet' type='text/css' />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>js/satisfyus.worx.js"></script>
<link rel="stylesheet" href="<?=base_url()?>css/style.css" type="text/css" /> 
<? start_block_marker('extra_head') ?><? end_block_marker() ?>
</head> 
<body>
<div id="container">
<div id="header">
	<div id="title">
	<? if (!@$home_page): ?>
	<span id="site_title"><?=$site_title?></span>
	<? else: ?>
	<h1 id="site_title"><?=$site_title?></h1>
	<? endif; ?>
	<span id="tagline"><?=get_setting('site_tagline')?></span>
	</div>
<div id="bar">
<ul id="nav">
	<li><?=anchor('','Overview')?></li>
	<li><?=anchor('questions','Questions')?></li>
	<li><?=anchor('ideas','Ideas')?></li>
	<li><?=anchor('problems','Problems')?></li>
	<li><?=anchor('praise','Praise')?></li>
	<li class="separator"><?=anchor('feedback/add','Start a topic')?></li>
</ul>
<div id="search">
<?=form_open('feedback/search')?>
<p><?=form_input('terms')?>
<?=form_submit('search','Search')?></p>
</form>
</div>
</div>
</div>
<div id="content">
<? start_block_marker('content') ?>
<? end_block_marker() ?>
</div>
<div id="sidebar">
<? start_block_marker('sidebar_login') ?>
<div class="loginpanel">
<? if (is_logged_in()): ?>
<h3>Welcome back, <?=get_username()?></h3>
<p><?=anchor('auth/settings','Your settings')?> &mdash; <?=anchor('auth/logout','Log out')?></p>

<?php if (get_user_group() == 3): ?><p><?=anchor('admin','Administrator panel')?></p><?php endif; ?>
 
 
<? else: ?>
<h3>Login to your account</h3>
<? $this->load->view('auth/login_partial'); ?>
<? endif; ?>
</div>
<? end_block_marker() ?>
<? start_block_marker('sidebar') ?>
<? end_block_marker() ?>
</div>
<div id="footer">
<div class="left">&copy; <?=$site_title?> <?=date('Y')?></div>
<div class="right">Powered by <a href="http://www.wooshy.com" title="Wooshy web development">Wooshy</a></div>
</div>
</div>
</body> 
</html> 