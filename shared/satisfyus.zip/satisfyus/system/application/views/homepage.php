<? extend('templates/master.php') ?>
<? startblock('title') ?>Welcome<? endblock() ?>
<? startblock('content') ?>
<h2 class="question"><?php echo ($popular) ? 'Popular' : 'Recent'?> questions</h2>

<? if(!empty($questions)): ?>
<ul class="feedback">
	<? foreach($questions as $question): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($question->comments == 1) ? $question->comments.' reply' : $question->comments.' replies';
	?>
	<li>
		<div class="feedback-info">
		<p class="title"><?=anchor($question->type.'/v/'.$question->id,$question->title)?></p>
		<p class="meta">Asked by <?=$question->author_username?> on <?=date('F j, g:ia',strtotime($question->date_submitted))?> - <?=$replies_string?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$question->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$question->id : ''; ?>
		<?=anchor($url,$question->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<? else: ?>
<p>There have been no recent questions.</p>
<? endif; ?>


<h2 class="idea"><?php echo ($popular) ? 'Popular' : 'Recent'?> ideas</h2>
<? if(!empty($ideas)): ?>
<ul class="feedback">
	<? foreach($ideas as $idea): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($idea->comments == 1) ? $idea->comments.' reply' : $idea->comments.' replies';
	?>
	<li>
		<div class="feedback-info">
		<p class="title"><?=anchor($idea->type.'/v/'.$idea->id,$idea->title)?></p>
		<p class="meta">Asked by <?=$idea->author_username?> on <?=date('F j, g:ia',strtotime($idea->date_submitted))?> - <?=$replies_string?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$idea->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$idea->id : ''; ?>
		<?=anchor($url,$idea->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<? else: ?>
<p>There are currently no ideas that have been submitted by the community.</p>
<? endif; ?>


<h2 class="problem"><?php echo ($popular) ? 'Popular' : 'Recent'?> problems</h2>
<? if(!empty($problems)): ?>
<ul class="feedback">
	<? foreach($problems as $problem): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($problem->comments == 1) ? $problem->comments.' reply' : $problem->comments.' replies';
	?>
	<li>
		<div class="feedback-info">
		<p class="title"><?=anchor($problem->type.'/v/'.$problem->id,$problem->title)?></p>
		<p class="meta">Asked by <?=$problem->author_username?> on <?=date('F j, g:ia',strtotime($problem->date_submitted))?> - <?=$replies_string?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$problem->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$problem->id : ''; ?>
		<?=anchor($url,$problem->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<? else: ?>
<p>There are currently no problems that have been submitted by the community.</p>
<? endif; ?>


<h2 class="praise"><?php echo ($popular) ? 'Popular' : 'Recent'?> praise</h2>
<? if(!empty($praise)): ?>
<ul class="feedback">
	<? foreach($praise as $item): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($item->comments == 1) ? $item->comments.' reply' : $item->comments.' replies';
	?>
	<li>
		<div class="feedback-info">
		<p class="title praise"><?=anchor($item->type.'/v/'.$item->id,$item->title)?></p>
		<p class="meta">by <?=$item->author_username?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$item->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$item->id : ''; ?>
		<?=anchor($url,$item->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<? else: ?>
<p>No praise has been submitted recently.</p>
<? endif; ?>



<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<h3>Change your view</h3>
<ul>
<li><?php echo anchor('','View most recent')?></li>
<li><?php echo anchor('top','View most popular')?></li>
</ul>

<? endblock() ?>
<? end_extend() ?>