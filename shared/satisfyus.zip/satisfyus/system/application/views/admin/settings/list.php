<? extend('templates/master.php') ?>
<? startblock('title') ?>Site settings<? endblock() ?>
<? startblock('content') ?>
<h1>Site settings</h1>
<h2>Header</h2>
<?=form_open('admin/settings')?>
<label class="label" for="site_title">Site title</label>
<input type="text" name="site_title" value="<?=$info['site_title']?>" id="site_title" size="40" />

<label class="label" for="site_tagline">Site tagline</label>
<input type="text" name="site_tagline" value="<?=$info['site_tagline']?>" id="site_tagline" size="40" />
<br /><br />
<h2>Sidebar information</h2>
<label class="label" for="site_about_title">Sidebar title</label>
<input type="text" name="site_about_title" value="<?=$info['site_about_title']?>" id="site_about_title" size="40" />

<label class="label" for="site_about_content">Sidebar content</label>
<textarea name="site_about_content" id="site_about_content" rows="10" cols="40"><?=$info['site_about_content']?></textarea>

<input type="submit" name="save" value="Save" id="save" class="form_button" />
</form>
<? endblock() ?>
<? startblock('sidebar') ?>
<?php // Display some stats here maybe? ?>
<? endblock() ?>
<? end_extend() ?>