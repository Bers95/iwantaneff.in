<? extend('templates/master.php') ?>
<? startblock('title') ?>Welcome<? endblock() ?>
<? startblock('content') ?>
<h1>Administrator Panel</h1>
<h2>Users</h2>
<ul>
	<li><?=anchor('admin/add_user','Add user')?></li>
	<li><?=anchor('admin/users','List users')?></li>
	<li><?=anchor('admin/search_user','Search for a user')?></li>
</ul>

<h2>Site settings</h2>
<ul>
	<li><?=anchor('admin/settings','Configure settings')?></li>
</ul>

<? endblock() ?>
<? startblock('sidebar') ?>
<h3>Tips</h3>
<ul>
	<li>If you make users an administrator then they can remove your access.</li>
	<li>Employees don't have any access to this panel, they can only delete and edit posts.</li>
</ul>
<? endblock() ?>
<? end_extend() ?>