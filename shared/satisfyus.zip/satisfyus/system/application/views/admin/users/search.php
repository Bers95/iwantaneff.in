<? extend('templates/master.php') ?>
<? startblock('title') ?>Search users<? endblock() ?>
<? startblock('content') ?>
<?php if (validation_errors()): ?>
<div class="error">
<?php echo validation_errors('<p>','</p>');?>
</div><br />
<?php endif; ?>
<h1>Search users</h1>
<?=form_open('admin/search_user')?>
<label for="username" class="label">Username</label>
<input type="text" name="username" value="" id="username" size="40" />
<input type="submit" name="search_user" value="Search" id="search_user" class="form_button" />
</form>
<? endblock() ?>
<? startblock('sidebar') ?>
<?php // Display some stats here maybe? ?>
<? endblock() ?>
<? end_extend() ?>