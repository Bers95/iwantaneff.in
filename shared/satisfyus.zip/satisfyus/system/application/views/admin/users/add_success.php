<? extend('templates/master.php') ?>
<? startblock('title') ?>Successfully added<? endblock() ?>
<? startblock('content') ?>
<h1>User successfully added</h1>
<p>User has been added!</p>
<p><?=anchor('admin/add_user','Add another')?></p>
<? endblock() ?>
<? startblock('sidebar') ?>
<?php // Display some stats here maybe? ?>
<? endblock() ?>
<? end_extend() ?>