<? extend('templates/master.php') ?>
<? startblock('title') ?>View '<?=$info->username?>'<? endblock() ?>
<? startblock('content') ?>

<?php if (validation_errors()): ?>
<div class="error">
<?php echo validation_errors('<p>','</p>');?>
</div><br />
<?php endif; ?>
<?php if (isset($message)): ?>
<div class="message"><?php echo $message; ?></div>
<br />
<?php endif; ?>


<h1><?=$info->username?></h1>

<table>
<tr><th>Account type</th><td><?=$info->title?></td></tr>
<tr><th>Member since</th><td><?=date('F j Y, g:ia',strtotime($info->date))?></td></tr>
<tr><th>E-mail address</th><td><?=$info->email?></td></tr>
</table>

<h2 class="reply">Change user's password</h2>
<?=form_open('admin/change_user_pass')?>
<?=form_hidden('id',$info->id)?>
<label for="password" class="label">Password</label>
<input type="password" name="password" id="password" size="40" />
<?=form_submit('change','Change','class="form_button"')?>
</form>

<h2 class="reply">Change user's email address</h2>
<?=form_open('admin/change_user_email')?>
<?=form_hidden('id',$info->id)?>
<label for="email" class="label">E-mail address</label>
<input type="text" name="email" id="email" size="40" />
<?=form_submit('change','Change','class="form_button"')?>
</form>

<h2 class="reply">Change user's account type</h2>
<?=form_open('admin/change_user_type')?>
<?=form_hidden('id',$info->id)?>
<label for="type" class="label">Type</label>
<?php 
foreach($groups as $group)
{
	$options[$group->id] = $group->title;
}
echo form_dropdown('type',$options,$info->group);
?>
<?=form_submit('change','Change','class="form_button"')?>
</form>

<? endblock() ?>
<? startblock('sidebar') ?>
<?php // Display some stats here maybe? ?>
<? endblock() ?>
<? end_extend() ?>