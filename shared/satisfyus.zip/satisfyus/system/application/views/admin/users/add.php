<? extend('templates/master.php') ?>
<? startblock('title') ?>Create a user<? endblock() ?>
<? startblock('content') ?>
<h1>Create a user</h1>
<? if (validation_errors()): ?>
<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif; ?>
<?=form_open('admin/add_user')?>
<label for="username" class="label">Username</label>
<input type="text" id="username" name="username" class="input" size="40"/>
<label for="email" class="label">E-mail address</label>
<input type="text" id="email" name="email" class="input" size="40" />
<label for="password" class="label">Password</label>
<input type="password" id="password" name="password" class="input" size="40" />
<label for="passconf" class="label">Confirm your password</label>
<input type="password" id="passconf" name="passconf" class="input" size="40" />

<input type="submit" id="create" name="create" class="form_button" value="Create user" />
</form>

<? endblock() ?>
<? startblock('sidebar') ?>
<? endblock() ?>
<? end_extend() ?>