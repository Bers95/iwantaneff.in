<? extend('templates/master.php') ?>
<? startblock('title') ?>Users<? endblock() ?>
<? startblock('content') ?>
<h1>Users</h1>

<? if(!empty($items)): ?>
<ul class="feedback">
	<? foreach($items as $item): ?>
	<li>
		<div class="feedback-info">
		<p class="title"><?=anchor('admin/view_user/'.$item->id,$item->username)?></p>
		<p class="meta"><?=$item->email?> &mdash; Member since <?=date('F j, g:ia',strtotime($item->date))?></p>
		</div>
	</li>
	<? endforeach ?>
</ul>
<?=$links?>
<? else: ?>
<p>No users have been found.</p>
<? endif; ?>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>