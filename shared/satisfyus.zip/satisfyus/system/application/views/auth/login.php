<? extend('templates/master.php') ?>
<? startblock('title') ?>Login to your account<? endblock() ?>
<? startblock('sidebar_login') ?><? endblock() ?>
<? startblock('content') ?>
<h1>Login to your account</h1>
<? $this->load->view('auth/login_partial')?>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>