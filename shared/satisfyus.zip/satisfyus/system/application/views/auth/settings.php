<? extend('templates/master.php') ?>
<? startblock('title') ?>Your settings<? endblock() ?>
<? startblock('content') ?>
<h1>Your settings</h1>
<? if (validation_errors()):?>
<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif; ?>
<? if (!empty($message)): ?>
<div class="msg-<?=$message['type']?>">
	<?=$message['msg']?>
</div>
<? endif; ?>

<h2 class="subheader">Change your password</h2>
<?=form_open('auth/change_pass')?>
<label for="password" class="label">New password</label>
<input type="password" name="password" id="password" size="40" />
<label for="passconf" class="label">Confirm new password</label>
<input type="password" name="passconf" id="passconf" size="40" />
<?=form_submit('change','Change my password','class="form_button"')?>
</form>

<h2 class="subheader">Change your e-mail address</h2>
<?=form_open('auth/change_email')?>
<label for="email" class="label">New e-mail address</label>
<input type="text" name="email" id="email" size="40" />
<p>Your current e-mail address: <?=$this->session->userdata('email')?></p>
<?=form_submit('change','Change my e-mail address','class="form_button"')?>
</form>

<? endblock() ?>
<? startblock('sidebar') ?>
<h3>Tips</h3>
<ul>
	<li>If you change your password you will be logged out.</li>
</ul>
<? endblock() ?>
<? end_extend() ?>