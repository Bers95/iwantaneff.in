<div class="login">
<?= form_open('auth/login') ?>
<? if (validation_errors()): ?>
	<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif; ?>

<p><?=form_label('Username','username')?>
<?=form_input(array(
			'name' => 'username',
            'id'          => 'username',
            'value'       => '',
            'maxlength'   => '64',
            'size'        => '24'))?></p>
<p><?=form_label('Password','password')?>
<?=form_password(array(
			'name'		  => 'password',
            'id'          => 'password',
            'value'       => '',
            'size'        => '24'))?></p>
<p><?=form_submit(array(
			'name'		  => 'login',
            'id'          => 'login',
            'class'		  => 'button',
            'value'       => 'Login')
	)?> or <?=anchor('auth/register','create an account')?></p>
<?=form_close()?>
</div>