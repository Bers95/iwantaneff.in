<? extend('templates/master.php') ?>
<? startblock('title') ?>Account banned<? endblock() ?>
<? startblock('sidebar_login') ?><? endblock() ?>
<? startblock('content') ?>
<h1>Account banned!</h1>
<p>Sorry, this account has been disabled and you are not permitted to login.</p>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>