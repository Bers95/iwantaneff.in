<? extend('templates/master.php') ?>
<? startblock('title') ?>Invalid details<? endblock() ?>
<? startblock('content') ?>
<h1>Invalid!</h1>
<p>Sorry, the details you provided were invalid.</p>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>