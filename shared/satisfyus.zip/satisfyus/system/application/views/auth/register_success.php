<? extend('templates/master.php') ?>
<? startblock('title') ?>Account created<? endblock() ?>
<? startblock('content') ?>
<h1>Account created</h1>
<p>Success! Your account has been created, you can now log in and start contributing your feedback.</p>
<? $this->load->view('auth/login_partial') ?>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>