<? extend('templates/master.php') ?>
<? startblock('title') ?>Create an account<? endblock() ?>
<? startblock('sidebar_login') ?><? endblock() ?>
<? startblock('content') ?>
<h1>Create an account</h1>
<p>Signing up allows you to give your feedback to the employees responsible!</p>
<? if (validation_errors()): ?>
<div class="error"><?=validation_errors('<p>','</p>')?></div>
<? endif; ?>
<?=form_open('auth/register')?>
<label for="username" class="label">Username</label>
<input type="text" id="username" name="username" class="input" size="40"/>
<label for="email" class="label">E-mail address</label>
<input type="text" id="email" name="email" class="input" size="40" />
<label for="password" class="label">Password</label>
<input type="password" id="password" name="password" class="input" size="40" />
<label for="passconf" class="label">Confirm your password</label>
<input type="password" id="passconf" name="passconf" class="input" size="40" />

<input type="submit" id="register" name="register" class="form_button" value="Create my account" />
</form>

<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>