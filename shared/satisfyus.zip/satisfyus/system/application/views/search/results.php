<? extend('templates/master.php') ?>
<? startblock('title') ?>Search results for &lsquo;<?=$terms?>&rsquo;<? endblock() ?>
<? startblock('content') ?>
<h1>Search results for &lsquo;<?=$terms?>&rsquo;</h1>
<? if(!empty($items)): ?>
<p>Displaying the first <?=count($items)?> matches.</p>
<ul class="feedback">
	<? foreach($items as $item): ?>
	<? //prepare suffix for number of replies 
	$replies_string = ($item->comments == 1) ? $item->comments.' reply' : $item->comments.' replies';
	?>
	<li class="<?=$item->type?>">
		<div class="feedback-info">
		<p class="title"><?=anchor($item->type.'/v/'.$item->id,$item->title)?></p>
		<p class="meta">by <?=$item->author_username?> on <?=date('F j, g:ia',strtotime($item->date_submitted))?> - <?=$replies_string?></p>
		</div>
		<? $class = "voteup"; if (isset($vote_record[$item->id])) { $class .= " voted"; } ?>
		<? $url = (is_logged_in()) ? 'feedback/vote/'.$item->id : ''; ?>
		<?=anchor($url,$item->vote_count,'class="'.$class.'"')?>
	</li>
	<? endforeach ?>
</ul>
<? else: ?>
<p>Sorry! No topics match your search terms.</p>
<? endif; ?>
<? endblock() ?>
<? startblock('sidebar') ?>
<h3><?=get_setting('site_about_title')?></h3>
<?=get_setting('site_about_content')?>
<? endblock() ?>
<? end_extend() ?>