<?php

function get_setting($key)
{
	$ci =& get_instance();
	
	$ci->db->where('key',$key);
	$query = $ci->db->get('settings');
	
	if ($query->num_rows() > 0)
	{
		$data = $query->row();
		return $data->value;
	}
	else
		return false;
}

function get_settings()
{
	$ci =& get_instance();
	
	$query = $ci->db->get('settings');
	$result = $query->result();
	
	$details = array();
	foreach ($result as $row)
	{
		$details[$row->key] = $row->value;
	}
	
	return $details;
}

function set_setting($key,$value)
{
	$ci =& get_instance();
	
	$data = array('value' => $value);
	
	$ci->db->where('key',$key);
	$ci->db->update('settings',$data);
}