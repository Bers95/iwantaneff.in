<?php

function is_logged_in()
{
	$ci =& get_instance();
	return ($ci->worxauth->logged_in() == TRUE);
}

function get_username()
{
	$ci =& get_instance();
	return $ci->session->userdata('username');
}

function get_user_id()
{
	$ci =& get_instance();
	return $ci->session->userdata('id');
}

function restric_to_group($level)
{
	$ci =& get_instance();
	return ($ci->session->userdata('group') >= $level);
}

function get_user_group()
{
	$ci =& get_instance();
	return $ci->session->userdata('group');
}

function username_check($str)
{
	$ci =& get_instance();
	$ci->db->select("id");
	$ci->db->from('users');
	$ci->db->where('username',$str);
	$query = $ci->db->get();
	
	if($query->num_rows == 0)
		return TRUE;
	else
	{
		$ci->form_validation->set_message('username_check', "Sorry! This username has already been registered.");
		return FALSE;
	}
}

function valid_group($id)
{
	$ci =& get_instance();
	$ci->db->from('groups');
	$ci->db->where('id',$id);
	$query = $ci->db->get();
	
	if($query->num_rows > 0)
		return TRUE;
	else
	{
		$ci->form_validation->set_message('valid_group', "This is not a valid group.");
		return FALSE;
	}
}

