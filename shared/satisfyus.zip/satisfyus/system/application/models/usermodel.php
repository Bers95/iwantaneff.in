<?php

class Usermodel extends Model
{
	function Usermodel()
	{
		parent::Model();
	}
	
	function count_users()
	{
		$this->db->select('count(*) as count');
		$this->db->from('users');
		$query = $this->db->get();
		$query = $query->row();
		return $query->count;
	}
	
	function get_users($limit,$offset)
	{
		$query = $this->db->get('users',$limit,$offset);
		return $query->result();
	}
	
	function get_user($id)
	{
		$this->db->select('users.*,groups.title');
		$this->db->from('users as users,groups as groups');
		$this->db->where('users.group','groups.id',FALSE);
		$this->db->where('users.id',$id);
		$query = $this->db->get();
		return $query->row();
	}
	
	function get_groups()
	{
		$this->db->order_by('id ASC');
		$query = $this->db->get('groups');
		return $query->result();
	}
	
	function search($where,$what)
	{
		$this->db->like($where,$what);
		$query = $this->db->get('users');
		return $query->result();
	}

}