<?php

class Feedbackmodel extends Model {

	function Feedbackmodel()
	{
		parent::Model();
		
	}
	
	function add($author, $type, $title, $msg)
	{
		$this->load->helper('typography');
		$data = array(
			'title'=>$title,
			'type'=>$type,
			'author'=>$author,
			'content'=>auto_typography($msg),
			'date_submitted'=>date("Y-m-d H:i:s"),
			'date_resolved'=>0,
			'active'=>1
		);
		$this->db->insert('feedback',$data);
		return $this->db->insert_id();
	}
	
	function get_list($type,$limit,$offset = 0)
	{
		$query = 'SELECT feedback. * , COUNT( votes.issue ) AS vote_count, users.username as author_username, 
				(SELECT count( * ) FROM '.$this->db->dbprefix('feedback_comments').' as feedback_comments WHERE issue = feedback.id) AS comments
				FROM ('.$this->db->dbprefix('feedback').' as feedback LEFT JOIN '.$this->db->dbprefix('votes').' as votes ON ( votes.issue = feedback.id ))
				LEFT JOIN '.$this->db->dbprefix('users').' as users ON ( feedback.author = users.id ) 
				WHERE feedback.type = "'.$type.'"
				GROUP BY feedback.id
				ORDER BY date_submitted DESC
				LIMIT '.$offset.' , '.$limit;
				
		$query = $this->db->query($query);
		
		return $query->result();
	}
	
	function get_popular($type,$limit,$offset = 0)
	{
		$query = 'SELECT feedback. * , COUNT( votes.issue ) AS vote_count, users.username as author_username, 
				(SELECT count( * ) FROM '.$this->db->dbprefix('feedback_comments').' as feedback_comments WHERE issue = feedback.id) AS comments
				FROM ('.$this->db->dbprefix('feedback').' as feedback LEFT JOIN '.$this->db->dbprefix('votes').' as votes ON ( votes.issue = feedback.id ))
				LEFT JOIN '.$this->db->dbprefix('users').' as users ON ( feedback.author = users.id ) 
				WHERE feedback.type = "'.$type.'"
				AND feedback.active = 1
				GROUP BY feedback.id
				ORDER BY vote_count DESC
				LIMIT '.$offset.' , '.$limit;
				
		$query = $this->db->query($query);
		
		return $query->result();
	}
	
	function add_comment($id,$type,$author,$message)
	{
		
		$this->db->where('type',$type);
		$this->db->where('id',$id);
		$query = $this->db->get('feedback');
		
		if ($query->num_rows() > 0)
		{
			$this->load->helper('typography');
			
			$data = array(
				'author'=>$author,
				'issue'=>$id,
				'date'=>date("Y-m-d H:i:s"),
				'content'=>auto_typography($message)
			);
			$this->db->insert('feedback_comments',$data);
		}
	}
	
	function get_vote_record($user)
	{
		$this->db->where('user',$user);
		$query = $this->db->get('votes');
		
		if ($query->num_rows() > 0)
		{
			$results = $query->result();
			foreach($results as $result)
				$votes[$result->issue] = $result->date;
			return $votes;
		}
		else
			return array();
	}
	
	function get_issue($type,$id)
	{
		$query = 'SELECT feedback. * , COUNT( votes.issue ) AS vote_count, users.username as author_username, 
				(SELECT count( * ) FROM '.$this->db->dbprefix('feedback_comments').' as feedback_comments WHERE issue = feedback.id) AS comments
				FROM ('.$this->db->dbprefix('feedback').' as feedback LEFT JOIN '.$this->db->dbprefix('votes').' as votes ON ( votes.issue = feedback.id ))
				LEFT JOIN '.$this->db->dbprefix('users').' as users ON ( feedback.author = users.id ) 
				WHERE feedback.type = "'.$type.'"
				AND feedback.id = '.$id.'
				GROUP BY feedback.id
				ORDER BY vote_count DESC
				LIMIT 1';
		$query = $this->db->query($query);
	
		return $query->row();
	}
	function get_comments($id)
	{
		$this->db->select('feedback_comments.*,users.username as author_username, users.group as author_group');
		$this->db->from('feedback_comments,users');
		$this->db->where('feedback_comments.author = users.id',null,false);
		$this->db->where('feedback_comments.issue',$id);
		$this->db->order_by('feedback_comments.date ASC');
		$query = $this->db->get();
		
		return $query->result();
	}
	
	function count_items($type)
	{
		$this->db->select('count(*) as num');
		$this->db->from('feedback');
		$this->db->where('type',$type);
		$query = $this->db->get();
		$query = $query->row();
		return $query->num;
	}
	
	function vote($user,$item)
	{
		$this->db->where('user',$user);
		$this->db->where('issue',$item);
		$this->db->limit(1);
		$query = $this->db->get('votes');
		
		if ($query->num_rows() == 0)
		{
			$data = array(
				'user'=>$user,
				'issue'=>$item,
				'date'=>date("Y-m-d H:i:s")
			);
			$this->db->insert('votes',$data);
			
			
			$status = 1;
		}
		else
		{
			// delete the vote
			$this->db->where('user',$user);
			$this->db->where('issue',$item);
			$this->db->limit(1);
			$this->db->delete('votes');
			$status = 0;
		}
		
		$this->db->select('COUNT(*) as vote_count');
		$this->db->from('votes');
		$this->db->where('issue',$item);
		$query = $this->db->get();
		$query = $query->row();
		
		return array(
			'status'=>$status,
			'count'=>$query->vote_count
		);
		
	}
	
	function set_status($id,$status)
	{
		$data = array('active'=>$status);
		$this->db->where('id',$id);
		$this->db->update('feedback',$data);
	}
	
	function delete_topic($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('feedback');
		$this->db->where('issue',$id);
		$this->db->delete('feedback_comments');
		$this->db->where('issue',$id);
		$this->db->delete('votes');
	}
	
	function delete_reply($id)
	{
		$comment = $this->get_comment($id);
		$this->db->where('id',$id);
		$this->db->delete('feedback_comments');
		return $comment->issue;
	}
	
	function get_comment($id)
	{
		$this->db->where('id',$id);
		$query = $this->db->get('feedback_comments');
		
		return $query->row();
	}
	
	function search($terms)
	{
		$query = 'SELECT feedback. * , COUNT( votes.issue ) AS vote_count, users.username as author_username, 
				(SELECT count( * ) FROM '.$this->db->dbprefix('feedback_comments').' as feedback_comments WHERE issue = feedback.id) AS comments
				FROM ('.$this->db->dbprefix('feedback').' as feedback LEFT JOIN '.$this->db->dbprefix('votes').' as votes ON ( votes.issue = feedback.id ))
				LEFT JOIN '.$this->db->dbprefix('users').' as users ON ( feedback.author = users.id ) 
			    WHERE feedback.title LIKE \'%'.$terms.'%\' OR feedback.content LIKE \'%'.$terms.'%\'
				GROUP BY feedback.id
				ORDER BY vote_count DESC
					
				LIMIT 50';
		$query = $this->db->query($query);
		return $query->result();
	}

}