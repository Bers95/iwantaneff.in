<?php
class Admin extends Controller
{
	function Admin()
	{
		parent::Controller();
		if ((!is_logged_in()) || (get_user_group() != 3)) { redirect(); }
		$this->load->model('usermodel');
	}
	
	function index()
	{
		$this->load->view('admin/dashboard');
	}
	
	function users($offset = 0)
	{
		$perpage = 15;
		
		$this->load->library('pagination');

		$config['base_url'] = site_url('admin/users');
		$config['total_rows'] = $this->usermodel->count_users();
		$config['per_page'] = $perpage;
		$config['uri_segment'] = 3;

		$this->pagination->initialize($config);
	
		$data['links'] = $this->pagination->create_links();
		$data['items'] = $this->usermodel->get_users($perpage,$offset);
			
		$this->load->view('admin/users/list',$data);
	}
	
	function view_user($id = null, $extra = null)
	{
		if (is_numeric($id) && $id != null)
		{
			$data['info'] = $this->usermodel->get_user($id);
			$data['groups'] = $this->usermodel->get_groups();
			
			if ($extra != null)
			{
				foreach ($extra as $k => $v)
					$data[$k] = $v;
			}
			
			if (!empty($data['info']))
				$this->load->view('admin/users/view',$data);
			else
				show_error('No such user.');
		}
		else
		{
			show_error('Invalid user ID.');
		}
	}
	
	function change_user_pass()
	{
		if ($this->input->post('change'))
		{
			$this->load->library('form_validation');
				
			$this->form_validation->set_rules('password', 'password', 'required');
			$this->form_validation->set_rules('id', 'user id', 'required|integer');
			
			if ($this->form_validation->run())
			{
				$this->worxauth->change_password(set_value('id'), set_value('password'));
				$this->view_user(set_value('id'), array('message'=>'Password successfully changed.'));
			}
			else
			{
				if (set_value('id'))
					$this->view_user(set_value('id'));
				else
					show_error('Invalid form submission');
			}
		}
	}
	
	function change_user_email()
	{
		if ($this->input->post('change'))
		{
			$this->load->library('form_validation');
				
			$this->form_validation->set_rules('email', 'email', 'required|valid_email');
			$this->form_validation->set_rules('id', 'user id', 'required|integer');
			
			if ($this->form_validation->run())
			{
				$this->worxauth->change_email(set_value('id'), set_value('email'));
				$this->view_user(set_value('id'), array('message'=>'E-mail address successfully changed.'));
			}
			else
			{
				if (set_value('id'))
					$this->view_user(set_value('id'));
				else
					show_error('Invalid form submission');
			}
		}
	}
	
	function change_user_type()
	{
		if ($this->input->post('change'))
		{
			$this->load->library('form_validation');
				
			$this->form_validation->set_rules('type', 'user type', 'required|callback__valid_group');
			$this->form_validation->set_rules('id', 'user id', 'required|integer');
			
			if ($this->form_validation->run())
			{
				$this->worxauth->change_group(set_value('id'), set_value('type'));
				$this->view_user(set_value('id'), array('message'=>'User type successfully changed.'));
			}
			else
			{
				if (set_value('id'))
					$this->view_user(set_value('id'));
				else
					show_error('Invalid form submission');
			}
		}
	}
	
	function search_user()
	{
		if ($this->input->post('search_user'))
		{
			$data['items'] = $this->usermodel->search('username',$this->input->post('username'));
			$data['links'] = '';
			$this->load->view('admin/users/list',$data);
		}
		else
		{
			$this->load->view('admin/users/search');
		}
	}
	
	function add_user()
	{
		if ($this->input->post('create'))
		{
			$this->load->library('form_validation');
			/* Validate our fields */
			$this->form_validation->set_rules('username', 'username', 'trim|alphadash|required|max_length[32]|callback__username_check');
			$this->form_validation->set_rules('password', 'password', 'required|matches[passconf]');
			$this->form_validation->set_rules('passconf', 'password confirmation', 'required');
			$this->form_validation->set_rules('email', 'e-mail address', 'required|max_length[255]|valid_email');
			if ($this->form_validation->run()) /* Data is valid */
			{
				$this->worxauth->create(set_value('username'),set_value('password'),set_value('email'));
				$this->load->view('admin/users/add_success');
			}
			else
				$this->load->view('admin/users/add');
		}
		else
			$this->load->view('admin/users/add');
	}
	
	function _username_check($str)
	{
		$this->db->select("id");
		$this->db->from('users');
		$this->db->where('username',$str);
		$query = $this->db->get();
		
		if($query->num_rows == 0)
			return TRUE;
		else
		{
			$this->form_validation->set_message('_username_check', "Sorry! This username has already been registered.");
			return FALSE;
		}
	}
	
	function _valid_group($id)
	{
		$this->db->from('groups');
		$this->db->where('id',$id);
		$query = $this->db->get();
		
		if($query->num_rows > 0)
			return TRUE;
		else
		{
			$this->form_validation->set_message('_valid_group', "This is not a valid group.");
			return FALSE;
		}
	}
	
	function settings()
	{
		if ($this->input->post('save'))
		{
			set_setting('site_title',$this->input->post('site_title'));
			set_setting('site_tagline',$this->input->post('site_tagline'));
			set_setting('site_about_title',$this->input->post('site_about_title'));
			set_setting('site_about_content',$this->input->post('site_about_content'));
			redirect('admin/settings');
		}
		else
		{
			$data['info'] = get_settings();
			$this->load->view('admin/settings/list',$data);
		}
	}
	
}


?>