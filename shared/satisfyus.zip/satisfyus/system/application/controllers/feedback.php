<?php
class Feedback extends Controller {
	
	function Feedback()
	{
		parent::Controller();
		$this->load->model('feedbackmodel');
	}
	
	function display($type,$offset = 0,$top = null)
	{
		$pages = array('questions','ideas','praise','problems');
		if (in_array($type,$pages))
		{
			$this->load->helper('inflector');
			
			$perpage = 10;
			$search_type = singular($type);
			
			$this->load->library('pagination');
	
			$config['base_url'] = site_url($type);
			$config['total_rows'] = $this->feedbackmodel->count_items($search_type);
			$config['per_page'] = $perpage;
			$config['uri_segment'] = 2;
	
			$this->pagination->initialize($config);
		
			$data['links'] = $this->pagination->create_links();						if ($top != null)
				$data['items'] = $this->feedbackmodel->get_popular($search_type,$perpage,$offset);			else 				$data['items'] = $this->feedbackmodel->get_list($search_type,$perpage,$offset);				
			$data['title'] = ucwords($type);
			if (is_logged_in())
				$data['vote_record'] = $this->feedbackmodel->get_vote_record( get_user_id() );
			else
				$data['vote_record'] = array();
			
			$this->load->view('feedback/list',$data);
		}
		else
			show_404();
	}
	
	function search()
	{
		if ($this->input->post('search'))
		{
			$data['items'] = $this->feedbackmodel->search($this->input->post('terms'));
			$data['terms'] = $this->input->post('terms');
			if (is_logged_in())
				$data['vote_record'] = $this->feedbackmodel->get_vote_record( get_user_id() );
			else
				$data['vote_record'] = array();
			$this->load->view('search/results',$data);
		}
		else
			$this->load->view('search/index');
	}
	
	function vote($id)
	{
		if (is_logged_in())
		{
			$data = $this->feedbackmodel->vote(get_user_id(),$id);
			echo json_encode($data);
		}
		else
			redirect('');
	}
	
	function view($type, $id)
	{
		$pages = array('questions','ideas','praise','problems');
		if (in_array($type,$pages))
		{
			$this->load->helper('inflector');
			$issue = $this->feedbackmodel->get_issue(singular($type),$id);
			
			if ($issue != false)
			{
				$data['issue'] = $issue;
				$data['comments'] = $this->feedbackmodel->get_comments($id);
				if (is_logged_in())
					$data['vote_record'] = $this->feedbackmodel->get_vote_record( get_user_id() );
				else
					$data['vote_record'] = array();
				$this->load->view('feedback/view',$data);
			}	
			else
				show_404();
		}
		else
			show_404();
	}
	
	function valid_feedback_type($type)
	{
		$pages = array('question','idea','praise','problem');
		return (in_array($type,$pages));
	}
	
	function add()
	{
		if (is_logged_in())
		{
			if ($this->input->post('add'))
			{
				$this->load->library('form_validation');
				
				$this->form_validation->set_rules('feedback_type', 'feedback type', 'required|callback_valid_feedback_type');
				$this->form_validation->set_rules('feedback_message', 'feedback description', 'required');
				$this->form_validation->set_rules('feedback_title', 'title', 'required|max_length[128]|min_length[5]');
				
				if ($this->form_validation->run())
				{
					// logged in, their data validates, so let's add it to the database!
					$id = $this->feedbackmodel->add(get_user_id(), set_value('feedback_type'), set_value('feedback_title'), set_value('feedback_message'));
					redirect(set_value('feedback_type').'/v/'.$id);
				}
				else
				{
					$this->load->view('feedback/create');
				}
			}
			else 
			{
				$this->load->view('feedback/create');
			}
		}
		else
			redirect('auth/login');
	}
	
	function postreply()
	{
		/* Need to do this as the plural() function CI has isn't that great... 	*/
									
		$lookup = array(
			'praise'=>'praise',
			'question'=>'questions',
			'idea'=>'ideas',
			'problem'=>'problems'
		);
		
		if (is_logged_in())
		{
			if ($this->input->post('post'))
			{
				$this->load->library('form_validation');
				
				$this->form_validation->set_rules('feedback_item', 'hidden ID', 'required|integer');
				$this->form_validation->set_rules('feedback_type', 'hidden type', 'required');
				$this->form_validation->set_rules('reply_message', 'message', 'required|min_length[6]|max_length[3000]');
				
				if ($this->form_validation->run())
				{					$issue = $this->feedbackmodel->get_issue(set_value('feedback_type'),set_value('feedback_item'));										if ($issue && ($issue->active == 1)) 					{					
						$this->feedbackmodel->add_comment(	
									set_value('feedback_item'),	
									set_value('feedback_type'),	
									get_user_id(),	
									set_value('reply_message')	
								);					}					redirect(set_value('feedback_type').'/v/'.set_value('feedback_item'));
				}
				else
				{
					$this->view($lookup[set_value('feedback_type')],set_value('feedback_item'));
				}
			}
			else
			{
				redirect('');
			}
		}
		else
		{
			redirect('');
		}
	}
	
	function status($id,$status)
	{
		if (is_logged_in() && (get_user_group() > 1))
		{
			$this->load->library('user_agent');
			$this->feedbackmodel->set_status($id, $status);
			
			if ($this->agent->is_referral())
			    redirect($this->agent->referrer());
			else
				redirect('');
		}
		else
			show_error('Insufficient access.');
	}
	
	function delete()
	{
		if (is_logged_in() && (get_user_group() > 1))
		{
			$id = $this->uri->segment(3);
			$this->feedbackmodel->delete_topic($id);
			redirect('');
		}
		else
			show_404();
	}
	
	function delete_reply()
	{
		if (is_logged_in() && (get_user_group() > 1))
		{
			$id = $this->uri->segment(3);
			$topic = $this->feedbackmodel->delete_reply($id);
			redirect($this->uri->segment(4) .'/v/'. $topic);
		}
		else
			show_404();
	}
}