<?php

class Auth extends Controller
{

	function Auth()
	{
		parent::Controller();
		$this->load->library('user_agent');
		if (!array_key_exists('login_attempts', $_COOKIE))
		{
			setcookie("login_attempts", 0, time() + 900, '/');
		}
	}
	
	function index()
	{
		if ( ! is_logged_in())
		{
			redirect('auth/login');
		}
		else
		{
			redirect('auth/settings');
		}
	}
	
	function settings()
	{
		if (is_logged_in())
		{
			$this->load->view('auth/settings');
		}
		else
			redirect('auth/login');
	}
	
	function login()
	{
		if (is_logged_in())
		{
			redirect('auth/settings');
		}
		/* Let's check if they've made too many login attempts */
		elseif((array_key_exists("login_attempts", $_COOKIE)) && ($_COOKIE['login_attempts'] >= 5))
		{
			$this->load->view('auth/too_many_attempts');
		}
		else /* Nope they haven't, let's process their attempt */
		{ 
			if ($this->input->post('login')) /* Has there been a form submitted? */
			{
				$this->load->library('form_validation');
				/* Validate our fields */
				$this->form_validation->set_rules('username', 'username', 'trim|required|max_length[32]');
				$this->form_validation->set_rules('password', 'password', 'required');
				
				if ($this->form_validation->run()) /* Data is valid */
				{
					/* Let's verify their details... */
					$check = $this->worxauth->verify(set_value('username'),set_value('password'));
					if ($check->status)
					{
						if ($this->agent->is_referral() && ($this->agent->referrer() != site_url('auth/login')))
						{
						    redirect($this->agent->referrer());
					    }
						else
						{
							redirect('');
						}
					}
					/* Invalid details or disabled account. */
					else
					{
						setcookie("login_attempts", $_COOKIE['login_attempts'] + 1, time()+900, '/'); // Expiry of 15 minutes
						$this->load->view('auth/'.$check->view);
					}
				}
				else /* Data is invalid */
					$this->load->view('auth/login');
			}
			else /* No form submitted */ 
				$this->load->view('auth/login');
		}
	}
	
	function register()
	{
		if (is_logged_in())
		{
			redirect('auth/settings');
		}
		if ($this->input->post('register'))
		{
			$this->load->library('form_validation');
			/* Validate our fields */
			$this->form_validation->set_rules('username', 'username', 'trim|required|max_length[32]|callbac__username_check');
			$this->form_validation->set_rules('password', 'password', 'required|matches[passconf]');
			$this->form_validation->set_rules('passconf', 'password confirmation', 'required');
			$this->form_validation->set_rules('email', 'e-mail address', 'required|max_length[255]|valid_email');
			if ($this->form_validation->run()) /* Data is valid */
			{
				$this->worxauth->create(set_value('username'),set_value('password'),set_value('email'));
				$this->load->view('auth/register_success');
			}
			else
				$this->load->view('auth/register');
		}
		else
			$this->load->view('auth/register');
	}
	
	function change_pass()
	{
		if (is_logged_in())
		{
			if ($this->input->post('change'))
			{
				$this->load->library('form_validation');
				/* Validate our fields */
				$this->form_validation->set_rules('password', 'password', 'required|matches[passconf]');
				$this->form_validation->set_rules('passconf', 'password confirmation', 'required');
				if ($this->form_validation->run()) /* Data is valid */
				{
					$this->worxauth->change_password(get_user_id(),set_value('password'));
					$this->logout();
				}
				else
					$this->load->view('auth/settings');
			}
			else
				redirect('auth/settings');
		}
		else
			show_error('You must be logged in to do that.');	
	}
	
	function change_email()
	{
		if (is_logged_in())
		{
			if ($this->input->post('change'))
			{
				$this->load->library('form_validation');
				/* Validate our fields */
				$this->form_validation->set_rules('email', 'email', 'required|valid_email|max_length[255]');
				$data = array();
				if ($this->form_validation->run()) /* Data is valid */
				{
					$this->worxauth->change_email(get_user_id(),set_value('email'));
					$data['message'] = array(
						'type'=>'ok',
						'msg'=>'Your email address has been successfully changed.'
					);
					$this->session->set_userdata('email',set_value('email'));
				}
				$this->load->view('auth/settings',$data);
			}
			else
				redirect('auth/settings');
		}
		else
			show_error('You must be logged in to do that.');	
	}
	
	function logout()
	{
		$this->session->sess_destroy();
		redirect('');
	}
	
	function _username_check($str)
	{
		$this->db->select("id");
		$this->db->from('users');
		$this->db->where('username',$str);
		$query = $this->db->get();
		
		if($query->num_rows == 0)
			return TRUE;
		else
		{
			$this->form_validation->set_message('_username_check', "Sorry! This username has already been registered.");
			return FALSE;
		}
	}
	
}

?>