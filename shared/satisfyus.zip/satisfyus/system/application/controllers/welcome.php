<?php

class Welcome extends Controller {

	function Welcome()
	{
		parent::Controller();	
		$this->load->model(array('feedbackmodel'));
	}
	
	function index($displayPopular = null)
	{
		if ($displayPopular != null)
		{
			$data['questions'] = $this->feedbackmodel->get_popular('question',3);
			$data['praise'] = $this->feedbackmodel->get_popular('praise',3);
			$data['problems'] = $this->feedbackmodel->get_popular('problem',3);
			$data['ideas'] = $this->feedbackmodel->get_popular('idea',3);
			$data['popular'] = true;
		}
		else
		{
			$data['questions'] = $this->feedbackmodel->get_list('question',3);
			$data['praise'] = $this->feedbackmodel->get_list('praise',3);
			$data['problems'] = $this->feedbackmodel->get_list('problem',3);
			$data['ideas'] = $this->feedbackmodel->get_list('idea',3);
			$data['popular'] = false;
		}
		$data['home_page'] = true;
		
		if (is_logged_in())
			$data['vote_record'] = $this->feedbackmodel->get_vote_record( get_user_id() );
		else
			$data['vote_record'] = array();
			
		$this->load->view('homepage',$data);
	}
}

/* End of file welcome.php */
/* Location: ./system/application/controllers/welcome.php */