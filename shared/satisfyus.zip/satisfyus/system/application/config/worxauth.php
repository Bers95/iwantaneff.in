<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/* You should probably change this */
$config['worxauth_static_salt'] = 'NlDuh2PO08Ll7SMRaVFeDWV22gCrKs8qWyeKGO8V';

?>