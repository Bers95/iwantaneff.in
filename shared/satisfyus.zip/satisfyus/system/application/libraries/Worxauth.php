<?php
/**
 * WorxAuth library
 *
 * @author Andrew Richards, Wooshy <andrew@wooshy.com>
 * @version 1.0
 * @copyright Wooshy 2010
 */


class WorxAuth {
	
	var $CI;
	var $user_table;
	var $group_table; 
	
	function WorxAuth()
	{
		$this->CI =& get_instance();
		$this->users_table = $this->CI->config->item('worxauth_users_table');
		$this->groups_table = $this->CI->config->item('worxauth_groups_table');
		
		/* Check if they're logged in, then verify that cookie! */
		if($this->logged_in())
			$this->_verify_cookie();
		
		/* If they don't have a cookie entry for setting login attempts, set one */
		if(!array_key_exists('login_attempts', $_COOKIE))
		{
			setcookie("login_attempts", 0, time()+900, '/'); // Expiry of 15 minutes
		}
	}
	
	/**
 	 * Verify the cookie
	 *
 	 * Check to make sure the cookie information reflects the information stored in the DB
 	 * If there isn't a cookie, then we'll generate one.
	 */			
	function _verify_cookie()
	{
		if (array_key_exists('logged_in', $_COOKIE))
		{
			$this->CI->db->where('id',$this->CI->session->userdata('id'));
			$query = $this->CI->db->get('users');
			if ($query->num_rows == 0) { $this->CI->session->sess_destroy(); redirect(''); }
			else 
			{
				$user = $query->row();
				$ident = $this->_hash($user->id,$user->token);
				if ($ident['hash'] != $_COOKIE['logged_in'])
				{
					$this->CI->session->sess_destroy(); redirect('');
				}
			}
		}
		else
		{
			$this->_generate_cookie();
		}
	}
	
	function _generate_cookie()
	{
		$token = $this->_hash($this->CI->session->userdata('id'));
		$data = array(
			'token'	=> $token['salt']
		);
		
		$this->CI->db->where('id',$this->CI->session->userdata('id'));
		$this->CI->db->update('users',$data);
		
		setcookie("logged_in", $token['hash'], time()+3600, '/');
	}
	
	
	/**
	 * Salt function
	 *
	 * Returns the input salted and hashed with SHA1
	 */
	function _hash($raw,$salt = null)
	{
		if ($salt == null)
			$salt = md5(uniqid(mt_rand(), true));
			
	 	return array(
	 		'salt'=>$salt,
	 		'hash'=>sha1($this->CI->config->item('worxauth_static_salt').$salt.$raw)
	 		);
		 
	}
	
	/**
	 * Create user
	 *	 	
	 * Returns the input salted and hashed with SHA1
	 */
	function create($username,$password,$email)
	{
		/* We have checked the lengths of these in the controller 
		   but this is one last ditch effort at making sure */
		$username = substr($username, 0, 32);
		$email = substr($email, 0, 255);
		
		/* Hash the password */
		$salt = $this->_hash($password);
		$password = $salt['hash'];
		$salt = $salt['salt'];
		
		$data = array(
			'username'=>$username,
			'password'=>$password,
			'salt'=>$salt,
			'email'=>$email,
			'group'=>1,
			'date'=>date("Y-m-d H:i:s")
		);
		
		$this->CI->db->insert('users',$data);
		return $this->CI->db->insert_id();		
	}

	
	function verify($username,$password)
	{
		$this->CI->db->where('username',$username);
		$query = $this->CI->db->get('users');
		
		$return = new stdClass();
		
		if ($query->num_rows == 0)
		{
			$return->status = false;
			$return->view = "invalid-details";
			return $return;
		}
		else
		{
			$user = $query->row();
			$password = $this->_hash($password,$user->salt);
			
			if (($password['hash'] == $user->password))
			{
				if ($user->group > 0)
				{
					$data = array(
						'id'=>$user->id,
						'username'=>$user->username,
						'email'=>$user->email,
						'logged_in'=>true,
						'group'=>$user->group
					);
					$this->CI->session->set_userdata($data);
					$this->_generate_cookie();
					
					$return->status = true;
					return $return;
				}
				else
				{
					$return->status = false;
					$return->view = "account-disabled";
					return $return;
				}
			}
			else
			{
				$return->status = false;
				$return->view = "invalid-details";
				return $return;
			}
		}
		
	}

	
   /** 
	* Check to see if a user is logged in
	*
	* Look in the session and return the 'logged_in' item
	*/
	function logged_in()
	{
		return ($this->CI->session->userdata('logged_in') == TRUE);
	}
	
	function change_password($id,$password)
	{
		$pw = $this->_hash($password);
		$data = array(
			'salt'=>$pw['salt'],
			'password'=>$pw['hash']
			);
		$this->CI->db->where('id',$id);
		$this->CI->db->update('users',$data);
	}
	
	function change_email($id,$email)
	{
		$this->CI->db->where('id',$id);
		
		$data = array(
			'email'=>$email
		);
		
		$this->CI->db->update('users',$data);
	}
	
	function change_group($id,$type)
	{
		$this->CI->db->where('id',$id);
		$data = array(
			'group'=>$type
		);
		$this->CI->db->update('users',$data);
	}
	
}

?>