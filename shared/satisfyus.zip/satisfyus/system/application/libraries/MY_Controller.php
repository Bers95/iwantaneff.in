<?php

class WorxAuthController extends Controller 
{

	function WorxAuthController()
	{
		parent::Controller();
		$this->load->library('worxauth');
	}
	
	function username_check($str)
	{

		$auth_type = $this->auth->_auth_type($str);

		$user_table = user_table();
		$query = $this->db->query("SELECT * FROM `$user_table` WHERE `$auth_type` = '$str'");

		if($query->num_rows === 1)
		{
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('username_check', $this->lang->line('username_callback_error'));
			return FALSE;
		}

	} // function username_check()

	function reg_username_check($str)
	{
		$user_table = user_table();
		$query = $this->db->query("SELECT * FROM `$user_table` WHERE `username` = '$str'");

		if($query->num_rows <> 0)
		{
			$this->form_validation->set_message('reg_username_check', $this->lang->line('reg_username_callback_error'));
			return FALSE;
		}
		else
		{
			return TRUE;
		}

	} // function reg_username_check()

	function reg_email_check($str)
	{	
		$user_table = user_table();
		$query = $this->db->query("SELECT * FROM `$user_table` WHERE `email` = '$str'");

		if($query->num_rows <> 1)
		{
			return TRUE;
		}
		else
		{
			$this->form_validation->set_message('reg_email_check', $this->lang->line('reg_email_callback_error'));
			return FALSE;
		}

	} // function reg_email_check()

}

?>