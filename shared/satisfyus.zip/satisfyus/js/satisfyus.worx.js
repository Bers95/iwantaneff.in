$(document).ready(function() {
	
	/* Base URL to the main page of the site, INCLUDING the trailing / */
	// var base_url = "http://etc.andrew-wooshy.mylha.com/satisfyus/index.php/";
	
    $("a.voteup").click(function() {
    	var link = $(this);
    	$.getJSON(link.attr('href'), function(data) {
			if (data.status == 1)
				link.addClass('voted');
			else
				link.removeClass('voted');
			link.text(data.count);
		});
		return false;
    });
});