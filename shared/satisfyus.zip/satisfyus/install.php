<?php
define('BASEPATH','needed for CI inclusion');
require 'system/application/config/database.php';
require 'system/application/config/config.php';
require 'system/application/config/worxauth.php';

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en"> 
<head> 
<title>Install &mdash; SatisfyUs</title> 
<link href=' http://fonts.googleapis.com/css?family=Nobile' rel='stylesheet' type='text/css'> 
<link rel="stylesheet" href="css/style.css" type="text/css" /> 
</head> 
<body> 
<div id="container"> 
<div id="header"> 
	<div id="title"> 
		<h1 id="site_title">Install SatisfyUs</h1> 
		<span id="tagline">Thank you for purchasing</span> 
	</div> 
</div> 
<div id="content"> 
<?php
if (isset($_POST['install']))
{
	mysql_connect($db['default']['hostname'],$db['default']['username'],$db['default']['password']);
	mysql_select_db($db['default']['database']);
	// now lets create those tables!
	mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."feedback` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) NOT NULL,
  `type` enum('question','idea','praise','problem') NOT NULL,
  `author` int(11) NOT NULL,
  `content` text NOT NULL,
  `date_submitted` datetime NOT NULL,
  `date_resolved` datetime NOT NULL,
  `active` int(1) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `type` (`type`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;");

	mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."feedback_comments` (
  `id` int(11) NOT NULL auto_increment,
  `author` int(11) NOT NULL,
  `issue` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `issue` (`issue`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."groups` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(128) NOT NULL,
  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1;");

mysql_query("INSERT INTO `".$db['default']['dbprefix']."groups` (`id`, `title`) VALUES
(1, 'User'),
(2, 'Employee'),
(3, 'Administrator'),
(-1, 'Banned');");

mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."sessions` (
  `session_id` varchar(40) NOT NULL default '0',
  `ip_address` varchar(16) NOT NULL default '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL default '0',
  `user_data` text NOT NULL,
  PRIMARY KEY  (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."settings` (
  `key` varchar(32) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY  (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");

mysql_query("INSERT INTO `".$db['default']['dbprefix']."settings` (`key`, `value`) VALUES
('site_title', 'Your website'),
('site_tagline', 'Community powered support'),
('site_about_title', 'About this community'),
('site_about_content', '<p>This is a community-powered support website</p>');
");

mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(40) NOT NULL,
  `group` int(11) NOT NULL,
  `salt` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM  DEFAULT CHARSET=latin1;");
	
mysql_query("INSERT INTO `".$db['default']['dbprefix']."users` (`id`, `username`, `email`, `password`, `group`, `salt`, `token`, `date`) VALUES
(1, 'admin', 'changeme@yourdomain.com', 'b7c974c2e244ed22ea227c4e6bd460c62984730d', 3, '47fc7413fca2372cb9340b86ad70381b', '', '".date("Y-m-d H:i:s")."')");

mysql_query("CREATE TABLE IF NOT EXISTS `".$db['default']['dbprefix']."votes` (
  `issue` int(11) NOT NULL,
  `user` int(11) NOT NULL,
  `date` datetime NOT NULL,
  KEY `issue` (`issue`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;");
echo '<h2 class="praise">Installed!</h2>';
echo '<p>You can now navigate to <a href="'.$config['base_url'].'">'.$config['base_url'].'</a> and login with the account you specified during install.</a>';
}
else
{
?>
<h2 class="question">Your database details</h2> 
<table>
	<tr><th>Host</th><td><?php echo $db['default']['hostname'] ?></td></tr>
	<tr><th>Username</th><td><?php echo $db['default']['username'] ?></td></tr>
	<tr><th>Password</th><td><?php echo $db['default']['password'] ?></td></tr>
	<tr><th>Database</th><td><?php echo $db['default']['database'] ?></td></tr>
	<?php if ($db['default']['dbprefix'] != ""): ?>
	<tr><th>Table prefix</th><td><?php echo $db['default']['dbprefix'] ?></td></tr>
	<? endif; ?>
</table>

<h2 class="praise">Administrator account</h2> 
<form method="post" action="install.php">
<table>
	<tr><th>Username</th><td>admin</td></tr>
	<tr><th>Password</th><td>admin</td></tr>
</table>
<input type="submit" name="install" value="Install" id="install" class="form_button" />
 
<?php } ?>
</div>
<div id="sidebar"> 
<h3>Important</h3>
<p>Once you have completed this install you must delete the install.php file.</p>
</div> 
<div id="footer"> 
<div class="right">Powered by <a href="http://www.wooshy.com" title="Wooshy web development">Wooshy</a></div> 
</div> 
</div> 
</body> 
</html> 