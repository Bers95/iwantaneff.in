	<div id="footer">
		<p><strong><?php bloginfo('name')?></strong> <a href="<?php bloginfo('rss2_url') ?>">(RSS)</a> + <strong>Sator-ii</strong> theme by <a href="http://yukei.net">Felipe Lavín</a></p>
		<?php wp_footer() ?>
	</div><!-- #footer -->
</div><!-- #wrapper .hfeed -->
</body>
</html>
