=== SATORII TRANSLATIONS : NOTE ===

Translation files in this directory are the ones that came with the 
Sandbox Theme for localization purposes, updated (but not completed)
to use with Satorii.

If you want to complete a translation or create a new one, you can do it
using poEdit [http://www.poedit.net/ - available for Windows, Mac and 
Linux] and the provided "messages.po", which holds all the stuff 
(also called "strings", if you're geek enough) that should be 
translated.

If you do, you might want to send it to the Satorii Google Code Project 
at http://satorii.googlecode.com so others can also use your
translation.


===

BELOW THIS LINE IS THE ORIGINAL SANDBOX README:

=== Sandbox Translations ===

This folder contains the source files for the translations provided with
the Sandbox. The sandbox.pot file included here should be used for 
generating your translations.

For more information on creating a Sandbox translation in your language, 
please visit

	http://code.google.com/p/sandbox-theme/wiki/SandboxInYourLanguage
