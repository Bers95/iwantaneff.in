require 'compass'
Compass::Frameworks.register("zocial", :path => "#{File.dirname(__FILE__)}/..")

module Zocial
  
  VERSION = "0.0.3"
  DATE = "2011-11-08"

end