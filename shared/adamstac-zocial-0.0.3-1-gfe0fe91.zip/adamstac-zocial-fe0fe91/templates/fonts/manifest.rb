description "Zocial font"

font 'zocial/zocial-regular-webfont.eot'
font 'zocial/zocial-regular-webfont.svg'
font 'zocial/zocial-regular-webfont.ttf'
font 'zocial/zocial-regular-webfont.woff'

help %Q{
If you need help, ask Adam Stacoviak (@adamstac).
}

welcome_message %Q{
Congrats! You have installed the Zocial font!
}