description "Zocial CSS"

stylesheet 'zocial.css'
stylesheet 'zocial-min.css'

help %Q{
If you need help, ask Adam Stacoviak (@adamstac).
}

welcome_message %Q{
Welcome. You have installed Zocial's CSS.
}