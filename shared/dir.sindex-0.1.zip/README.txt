-------------------------------------------------------------------------------
Project Information
-------------------------------------------------------------------------------
  
  sindex.php - a simple directory listing script made with PHP

  Project home: http://jomppa.net/projects/sindex/
       Version: 0.1
          Date: 2011-02-20
        Author: Joni Rantala 2011
                joni@jonirantala.fi
                http://jomppa.net/
				
-------------------------------------------------------------------------------
Installation
-------------------------------------------------------------------------------

  Without mod_rewrite:
  
    1) copy sindex.php to your web directory

  With Apache's mod_rewrite enabled:
  
    1) copy .htaccess and sindex.php to your web directory
    2) open .htaccess and edit RewriteBase to correspond your settings,
       i.e. if your web directory is at http://example.com/~user/dir/,
       your RewriteBase should be /~user/dir/
