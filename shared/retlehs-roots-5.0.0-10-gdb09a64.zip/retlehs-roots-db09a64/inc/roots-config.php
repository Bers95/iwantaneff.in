<?php

define('POST_EXCERPT_LENGTH',  40);
define('BOOTSTRAP_RESPONSIVE', true);
define('WRAP_CLASSES',         'container');
define('CONTAINER_CLASSES',    'row');
define('MAIN_CLASSES',         'span8');
define('SIDEBAR_CLASSES',      'span4');
define('FULLWIDTH_CLASSES',    'span12');
define('GOOGLE_ANALYTICS_ID',  '');

?>