/* Author:

*/


$(document).ready(function(){
	
	// Run Matt Kersley's jQuery Responsive menu plugin (see plugins.js)
	if ($.fn.mobileMenu) {
		$('ol#id').mobileMenu({
			switchWidth: 768,                   // width (in px to switch at)
			topOptionText: 'Choose a page',     // first option text
			indentString: '&nbsp;&nbsp;&nbsp;'  // string for indenting nested items
		});
	}

	// Run Mathias Bynens jQuery placeholder plugin (see plugins.js)
	if ($.fn.placeholder) {
		$('input, textarea').placeholder();		
	}
});

// http://www.learningjquery.com/2006/09/slicker-show-and-hide






$(function() {$('#copyright').hide(); });
    $('a[href="#copyright"]').click(function(event) {
		event.preventDefault();
      $("#copyright").slideToggle("fast");
    });




// dropdown on masthead
$('#masthead').dropdown()

// menu convert to dropdown on mobile
$(document).ready(function(){

	$('#sitenav').mobileMenu({
	  switchWidth: 480,                   //width (in px to switch at)
	  topOptionText: 'Select a page...',     //first option text
	  indentString: '&nbsp;&nbsp;&nbsp;'  //string for indenting nested items
	});
	
	/*
	$('#post-list').mobileMenu({
	  switchWidth: 753,                   //width (in px to switch at)
	  topOptionText: 'Select a post...',     //first option text
	  indentString: '&nbsp;&nbsp;&nbsp;'  //string for indenting nested items
	});
	*/
	
	//$("h3.post-title").fitText(1.2); // Turn the compressor up   (text shrinks more aggressively)

});

