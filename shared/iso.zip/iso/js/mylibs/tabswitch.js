jQuery(document).ready(function() {
	jQuery("#tabswitch ul li:first").addClass("active");
	jQuery("#tabswitch .tab-container:first").show();

	jQuery("#tabswitch ul li").click(function(){
		jQuery("#tabswitch .tab-container").hide();
		jQuery("#tabswitch ul li").removeClass("active");

		var tab_class = jQuery(this).attr("class");

		jQuery("#tabswitch section." + tab_class).show();
		jQuery("#tabswitch ul li." + tab_class).addClass("active");
	});
});