<? php /* Template Name: blogroll */ ?>
<?php get_header(); ?>

<div id="content">

	<div class="entry">

		<h2>Links</h2>
		
		<p>Here are the collections of useful links I found throughout the Internet. If you like my website and interested in banner exchange, please contact me. Every request is reviewed and approved manually.</p>
		
		<h4>Banner EXCHANGE</h4>

		<p>If you are using banners for links exchange, this might be useful for you. Otherwise, you can just delete this part in blogroll.php.</p>
		<div id="links">

			<ul>
		
			<?php wp_list_bookmarks('categorize=0&category=6&before=<span>&after=</span>&show_images=1&show_description=0&orderby=url&title_li=0'); ?>

			</ul>
		</div>


		<h4>Wordpress Resources</h4>


			<div class="blocklist">

			<ul>

			<li>
		
			<?php wp_list_bookmarks('categorize=0&category=2&before=<span>&after=</span>&show_images=1&show_description=0&orderby=url&title_li=0'); ?>


			</li>

			</ul>

			</div>

			<div class="clear"></div>


		<h4>TUTORIALS and other web resources</h4>


			<div class="blocklist-2">

			<ul>

			<li>
		
			<?php wp_list_bookmarks('categorize=0&category=5&before=<span>&after=</span>&show_images=1&show_description=0&orderby=url&title_li=0'); ?>


			</li>

			</ul>

			</div>

		<br/>



	</div>


<?php include(TEMPLATEPATH . '/works.php'); ?>
<?php get_sidebar(); ?>

</div>
<?php get_footer(); ?>
