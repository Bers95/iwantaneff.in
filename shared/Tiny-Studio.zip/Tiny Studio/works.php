<div class="list">

	<h2>Latest works</h2>
	<p>This part of sidebar is using custom fields. If you wish to display your artworks here, simply create a new category, for example "Artworks". Take note of the category's ID. Then open works.php and edit the number of the category.</p>

	<?php
	$lastposts = get_posts('category=4&numberposts=10');
	foreach($lastposts as $post) :
	setup_postdata($post);
	?>
	<a href="<?php the_permalink(); ?>"><img 
	src="<?php echo get_post_meta($post->ID, "works", true); ?>" alt="photo" 
	/></a>
	<?php endforeach; ?>

</div>