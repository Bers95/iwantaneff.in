<div id="box">


	<div class="leftbox">
<h3>Previous Posts</h3>
<ul>
<?php get_archives('postbypost', 5); ?>
</ul>
</div>

	<div class="rightbox"><h3>Categories</h3><ul><?php wp_list_categories('show_count=0&title_li=0'); ?></ul></div>

<div>

<div class="bottom">


<h3>Browse by Tags</h3>


<div class="down">

<p>You can put your tags here of anything you want. If you have any question or suggestion or doubt in mind, please email me [fath_at_pelangipetang_com].</p>

</div>



</div>