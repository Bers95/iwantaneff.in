<?php get_header();?>



	<div id="content">

		<div class="entry">

		<?php if(have_posts()) : ?><?php while(have_posts()) : the_post(); ?>

			
		<div class="post" id="post-<?php the_ID(); ?>">


		    <div class="count">

			<div class="month"><?php the_time('M') ?></div>

			<div class="day"><?php the_time('d') ?></div>

		</div>


		<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
			

		<div class="metadata"><?php _e('Filed under'); ?> <?php the_category(', ') ?>.</div>
		
				<div class="view">
	
				<?php the_content();?>


				<p class="postmetadata">
<strong><?php _e('Written by'); ?> <?php  the_author(); ?>. <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?> <?php edit_post_link('Edit', ' &#124; ', ''); ?></strong>
				</p>

				</div>

				<div class="comments-template">

				<?php comments_template(); ?>


				</div>

			</div>



		<?php endwhile; ?>


		<div class="navigation">

		<?php posts_nav_link(); ?>

		</div>
			




			<?php else : ?>

			<div class="post">

			<h2><?php _e('Not Found'); ?></h2>

			</div>



		<?php endif; ?>

		
		</div>
	

		<?php include(TEMPLATEPATH . '/works.php'); ?>

		<?php get_sidebar();?>



	</div>

<?php get_footer();?>

</div>

</body>
</html>