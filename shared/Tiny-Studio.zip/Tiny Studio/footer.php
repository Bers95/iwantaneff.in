<div id="footer">

	<p>&copy; 2008 <a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>. Designed by <a href="http://studio.pelangipetang.com">One Winged Angel</a> | <a href='http://www.skidzopedia.com' title="Technology Blog">skidzopedia</a> | <a href='http://www.bloggertemplatesblog.com' title="Free Blogger Templates">Blogger</a>.<br/><a href='http://www.wpthemehub.com' title="Wordpress Themes">Wordpress Themes</a>, <a href='http://www.bloggertemplatesgenie.com' title="Blogger Templates">Blogger Templates</a>, <a href='http://www.bloggertemplateblog.com' title="Blogger Templates">Blogger Templates</a>. Sponsored: <a title="Free Wordpress Themes" href="http://www.wordpressthemeshut.com">Wordpress Themes</a> | <a href='http://www.wp-magazine-themes.com' title="Free Magazine Themes">Wordpress Themes</a><br/>

Valid CSS and XHTML. <a href="<?php bloginfo('rss2_url'); ?>">Entries RSS</a> | <a href="<?php bloginfo('comments_rss2_url'); ?>">Comments RSS</a>. Distributed by <a title="Free Wordpress Themes" href="http://www.themesplice.com">Wordpress</a>.</p>

</div>