-- Simple URL Shortener SQL Dump

CREATE TABLE IF NOT EXISTS `shorturl` (
  `ID` int(10) NOT NULL auto_increment,
  `fullURL` varchar(200) NOT NULL,
  `shortURL` varchar(60) NOT NULL,
  `hits` int(255) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY  (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=256 ;


