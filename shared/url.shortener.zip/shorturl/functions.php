<?php

//function to connect to the MySQL database
function connect()
{

	global $host;
	global $username;
	global $password;
	global $database;

   	$link = mysql_pconnect($host, $username, $password);
   	$db_selected = mysql_select_db($database);
}


//function to generate short URLs
function shorten($fullURL)
{

	global $length;

	
	$shortURL = substr(str_shuffle('abcdefghijklmnopqrstuvwxyz1234567890'),0,$length);
	$timestamp = time();
   	$insert_query = "INSERT INTO `shorturl` (`shortURL`, `fullURL`, `timestamp`) VALUES ('$shortURL', '$fullURL', NOW() );";
   	$result = mysql_query($insert_query);

	return $shortURL;

}




?>