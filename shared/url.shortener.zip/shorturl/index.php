<?php

//including of�the configuration and the required functions
include "config.php";
include "functions.php";

$shortURL = $_SERVER['QUERY_STRING'];
$sQuery = strlen($_SERVER['QUERY_STRING']);

if ($sQuery != 0) {

	connect();
	global $shortURL; 

	$result = mysql_query("SELECT * FROM `shorturl` WHERE `shortURL` = '$shortURL'");

	//dissolves the requested short url in�its full URL and directs to it

   	if (mysql_num_rows($result) > 0) {



			$row = mysql_fetch_object($result);

				if($counthits == 1){
				$hit=$row->hits+1;
				$update = mysql_query("UPDATE shorturl Set hits = '$hit' WHERE shortURL = '$shortURL'");
				}
			
			header("Location: $row->fullURL");
    	
				}
	else {

	//Shows the 404.tpl if a death link appears
	include "./templates/404.tpl";

	}

}
else
{
	//shows the index.tpl
	include "./templates/index.tpl";
}















?>