<?php

//declare the file as xml
header("Content-type: text/xml"); 

include "functions.php";
include "config.php";

$fullURL = strip_tags($_GET["URL"]);

$xml_output  = "<?xml version=\"1.0\"?>\n";
$xml_output .= "<results>\n"; 

$xml_output  .=  "\t<result>\n"; 

if(eregi("\.+[a-z]{2,4}",
  $fullURL)) {



  			if(!eregi("^[http]{4}[\:][\/]{2}",
  			$fullURL)) {


			//generates the short URL and collects them in the $xml_output variable
			connect();

			$fullURL = "http://" . $fullURL;
			$token = shorten($fullURL);
 
			$xml_output  .=  "\t\t<shortURL>\n";
			$xml_output  .=  "\t\t\t<shortURL>" .  $URL . "/" . $token . "</shortURL>\n"; 
			$xml_output  .=  "\t\t\t<token>" .  $token . "</token>\n"; 
			$xml_output  .=  "\t\t</shortURL>\n";
			$xml_output  .=  "\t\t<fullURL>" .  $fullURL . "</fullURL>\n"; 
			$xml_output  .=  "\t\t<timestamp>" .  time() . "</timestamp>\n"; 
					




			}
			else
			{

			//generates the short URL and collects them in the $xml_output variable

			connect();

			$token = shorten($fullURL);


			$xml_output  .=  "\t\t<shortURL>\n";
			$xml_output  .=  "\t\t\t<shortURL>" .  $URL . "/" . $token . "</shortURL>\n"; 
			$xml_output  .=  "\t\t\t<token>" .  $token . "</token>\n"; 
			$xml_output  .=  "\t\t</shortURL>\n";
			$xml_output  .=  "\t\t<fullURL>" .  $fullURL . "</fullURL>\n"; 
			$xml_output  .=  "\t\t<timestamp>" .  time() . "</timestamp>\n"; 

			}
}
else
{

			//shows an error message
			$xml_output  .=  "\t\t<error>" .  $errormessage . "</error>\n"; 
}


//The collected data will be displayed as the result

$xml_output  .=  "\t</result>\n";
$xml_output .= "</results>"; 

echo  $xml_output; 
?>