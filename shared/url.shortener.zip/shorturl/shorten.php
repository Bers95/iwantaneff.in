<?php

include "functions.php";
include "config.php";

$fullURL = strip_tags($_GET["URL"]);

if(eregi("\.+[a-z]{2,4}",
  $fullURL)) {


			//request if the URL includes http://
  			if(!eregi("^[http]{4}[\:][\/]{2}",
  			$fullURL)) {


					 //adds http:// to the string and generates the short URL

					connect();
					$fullURL = "http://" . $fullURL;

					echo $URL;
					echo "/";
					echo shorten($fullURL);

			}
			else
			{

		//generates the short URL

		connect();
		echo $URL;
		echo "/";
		echo shorten($fullURL);
			}
}
else
{

//shows an errormessage

echo $errormessage;
}





?>