<?php


$host = "localhost"; //mysql host mostly localhost

$username = "username"; //mysql username mostly admin or administrator

$password = "password"; //mysql password

$database = "database"; //mysql database


$sitename = "Simple URL Shortener"; //title or name of the website

$message404 = "404 Sorry, we cant find the entered Url!"; //message which shows up by a death link

$errormessage = "Please check the entered URL!"; //message which�shows up by an incorrect input


$URL = "http://yoururl.com"; //full URL and path including http:// where Simple URL Shortener got installed

$length = 6; //length of the short URL token

$counthits = 1; //Choose if the hits on the URL get counted�- 1 means yes (default) 0 means no

?>