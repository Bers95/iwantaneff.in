<?php
session_start();
new ExponentWebMediaPinterest();

class ExponentWebMediaPinterest {
    
    var $plugin_name = "pin_presser";
	var $plugin_name3 = "pin_presser";
    var $plugin_name2 = "Pin Presser";
	var $db_table;
    function ExponentWebMediaPinterest() {
		
		$this->db_table = $this->plugin_name."_return_urls";
		
        add_action('future_to_publish', array(&$this,'email'), 10, 1);
        add_action('init', array(&$this, 'handle_posts') );
        add_action('admin_menu', array(&$this,'createMenu') );

        $options = get_option("{$this->plugin_name}_options");
        if($options['fireEvent'] == True) {
			add_action('future_to_publish', array(&$this,'email'));
            add_action('publish_page',array(&$this,'email'));
            add_action('publish_post',array(&$this,'email'));
        } else {
			add_action('future_to_publish', array(&$this,'email'));
            add_action('new_to_publish',array(&$this,'email'));
            add_action('draft_to_publish',array(&$this,'email'));
        }
		
		$api_options = get_option("{$this->plugin_name}_api_options");
		if($api_options['pinterest_account']['userspinimages'] == True) {
			add_action('wp_head',array(&$this,'add_my_pinterest_head_script'));
			add_filter('the_content',array(&$this,'add_button_beside_the_images'));
		}

		add_action('wp_dashboard_setup',array(&$this,'add_pinterest_dashboard_widgets'));

    }

    function getOption() {
        return get_option("{$this->plugin_name}_options");
    }
    
    function createMenu() {
        $dir = $this->plugin_name;
    
        add_menu_page("{$this->plugin_name2} Options", "{$this->plugin_name2}", 'administrator', $dir.'/general_settings', array(&$this,'createSettingsPage') );
        add_submenu_page($dir.'/general_settings', 'General Settings', 'General Settings', 'administrator', $dir.'/general_settings', array(&$this,'createSettingsPage') );
        add_submenu_page($dir.'/general_settings', 'Account', 'Account', 'administrator', $dir.'_api_settings', array(&$this,'createAPIOptionsPage') );
        add_submenu_page($dir.'/general_settings', 'Post Status', 'Post Status', 'administrator', $dir.'/poststatus', array(&$this,'createPostStatus') );
		add_submenu_page($dir.'/general_settings', 'Page Status', 'Page Status', 'administrator', $dir.'/pagestatus', array(&$this,'createPageStatus') );
        add_action('admin_init', array(&$this,'init'));

    }

    function handle_posts() {
        if( $_REQUEST['page'] != "{$this->plugin_name}_api_settings" ) {
            return;
        }
        $options = get_option("{$this->plugin_name}_api_options");
        global $wpdb;
        
        //ACTION ID 3: DELETE
        if($_GET['nl_action_id']==3 && isset($_GET['nl_social_network']) ) {
            if($_GET['nl_social_network']=='pinterest') {
                $options['pinterest_account'] = array();
            }
        }
        
        // UPDATE
        if( isset($_POST['nl_api_update_pinterest']) ) {
            $post = $_POST["{$this->plugin_name}"];
			
            // Pinterest
            $pinterest_account['social_network'] = 'Pinterest';
            $pinterest_account['pinterest_client_id'] = $post['pinterest_client_id'];
            $pinterest_account['pinterest_client_secret'] = $post['pinterest_client_secret'];
            $pinterest_account['pinterest_username'] = $post['pinterest_username'];
			$pinterest_account['pinterest_password'] = $post['pinterest_password'];

			//$access_token = $this->getPinterestAccessToken($post['pinterest_client_id'],$post['pinterest_client_secret'],$post['pinterest_username'],$post['pinterest_password']);
			$access_token = $this->getPinterestAccessToken('1234567','ab04920a718c1e35ae5b08ffa4603dd62ef7c8fc',$post['pinterest_username'],$post['pinterest_password']);
			$pinterest_account['pinterest_access_token'] = $access_token;
						
						
			/*$getpinterest_user_info = $this->getPinterestUserInfo($post['pinterest_username'],$access_token);
			foreach ($getpinterest_user_info->boards as $boards)	{
				$boards_url = $boards->url;
				$boards_id = $boards->id;
			}*/
			//$pinterest_account['pinterest_boards_url'] = $boards_url;
			$pinterest_account['pinterest_board_id'] = $post['pinterest_board_id'];
			
			$pinterest_account['userspinimages'] = $post['userspinimages'];

			$pinterest_account['pinterestPreText'] = $post['pinterestPreText'];
			
            $options['pinterest_account'] = $pinterest_account;

            //For checkboxes
            $options['social_network_pinterest'] = $post['social_network_pinterest'];

        }

        update_option("{$this->plugin_name}_api_options", $options);
    }
    
    function curlData($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
        
    }

	function getFirstBoard() {
        $options = get_option("{$this->plugin_name}_api_options");
		$pinterest_user_info = $this->getPinterestUserInfo($options['pinterest_account']['pinterest_username'],$options['pinterest_account']['pinterest_access_token']);
		if( !isset($boardID) ) {
			$count = $pinterest_user_info->user->stats->boards_count;
			if( $count >= 1 ) {
				$boards = $pinterest_user_info->boards;
				$board1 = $boards[0];
				return $board1;
			}
		}
		return False;
	}
	
    public function pinterestStatusUpdate($detailsContent, $subject, $photos_valid_href) {
		global $wpdb, $table_prefix,$current_user,$post_id;

		$mypost = get_post($post_id);
		$guid = $mypost->guid ;
		$content = $mypost->post_content;
		
        $options = get_option("{$this->plugin_name}_api_options");
 
		$directory = dirname(__FILE__);
		preg_match( '@src="([^"]+)"@' , $content , $match );
		$image_url = $match[1];

		$ch = curl_init();
		$timeout = 0;
		curl_setopt ($ch, CURLOPT_URL, $image_url);
		curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_BINARYTRANSFER, 1);
		$image = curl_exec($ch);
		curl_close($ch);
		$f = fopen($directory.'/images/'.$subject.'.jpg', 'w');
		fwrite($f, $image);
		fclose($f);

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_VERBOSE, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Pinterest For iPhone / 1.4.3');
		curl_setopt($ch, CURLOPT_URL, "https://api.pinterest.com/v2/pin/");
		curl_setopt($ch, CURLOPT_POST, true);
		$pinterest_user_info = $this->getPinterestUserInfo($options['pinterest_account']['pinterest_username'],$options['pinterest_account']['pinterest_access_token']);
		$boardID = $options['pinterest_account']['pinterest_board_id'];
		if( !isset($boardID) ) {
			$board1 = $this->getFirstBoard();
			$boardID = $board1->id;
		}
		$post = array(
			'access_token' => $options['pinterest_account']['pinterest_access_token'],
			'board' => $boardID,
			'details' => $detailsContent,
			'image' => '@'.$directory.'/images/'.$subject.'.jpg',
			'latitude' => 0,
			'longitude' => 0,
			'publish_to_twitter' => 0,
			'publish_to_facebook' => 0 
		);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post); 
		$response = curl_exec($ch);
		$json = json_decode($response);
		
		$return_url = 'http://pinterest.com/pin/'.$json->id.'/';
		
		$wpdb->query("
			INSERT INTO 
				`{$this->db_table}`
			(`post_id`, `sn`, `sn_username`, `returnurl`)
				VALUES
			('".$post_id."','pinterest','".$pinterest_user_info->user->username."','".$return_url."')
		");
		curl_close($ch);
    }
    
    function getHREFs($post){
        $post2 = stripslashes($post);

        if(!preg_match_all("/(<a.*>)(.*)(<\/a>)/ismU",$post2,$matches,PREG_SET_ORDER)){
            return $post;
        }

        foreach($matches as $key => $value){
            
            preg_match("/href\s*=\s*[\'|\"]\s*(.*)\s*[\'|\"]/i",$value[1],$href);
            if((substr($href[1],0,7)!="http://" && substr($href[1],0,8)!="https://") ){
                unset($matches[$key]);
            }else{
                $temp_href = $href[1];
                $arr = explode(" ", $temp_href);
                if( $arr ) {
                    if( !empty($arr) ) {
                        $temp_href = $arr[0];
                        $temp_href = str_replace("\"","",$temp_href);
                        $href_arr[] = $temp_href;
                    }
                }
            }
        }
        return $href_arr;
    }
    
    function stripTags($post){
        $post2 = stripslashes($post);

        if(!preg_match_all("/(<a.*>)(.*)(<\/a>)/ismU",$post2,$matches,PREG_SET_ORDER)){
            return $post;
        }

        foreach($matches as $key => $value){
            
            preg_match("/href\s*=\s*[\'|\"]\s*(.*)\s*[\'|\"]/i",$value[1],$href);
            if((substr($href[1],0,7)!="http://" && substr($href[1],0,8)!="https://") ){
                unset($matches[$key]);
            }else{
                $post2 = str_replace($matches[$key][0],$href[1],$post2);
            }
        }
        return $post2;
    }

    function snippet($text='', $count='5') {
        if( empty($text)) {
            return '';
        }
        $arr = explode(' ', $text);
        $total = 0;
        foreach( $arr as $val ) {
            if( $total < $count ) {
                if( !empty($val) ) {
                    $arr2[] = $val;
                    $total++;
                }
            }
        }
        if( !empty($arr2) ) {
            return implode(" ",$arr2)."...";
        }
        return '';
    }
    
    function createAPIOptionsPage() {
        global $wpdb;

        $cur = $_SERVER['PHP_SELF'];
        $options = get_option("{$this->plugin_name}_api_options");
        if( !$options ) {
            $options = array();
            add_option("{$this->plugin_name}_api_options", $options);
        }
		if( !isset($options['pinterest_account']['pinterest_board_id']) ) {
			$board1 = $this->getFirstBoard();
			$options['pinterest_account']['pinterest_board_id'] = $board1->id;
		}
        $accounts['pinterest'] = $options['pinterest_account'];
        
        foreach( $accounts as $key=>$acc ) {
            if( !empty($acc) ) {
                if( $key=='pinterest' ) {
                    $data->id = 1;
                }
                if($data->id != '' ) {
                    $info['data'][$key] = $data;
                }
            }
        }
        
        $plugin_url = trailingslashit( get_bloginfo('wpurl') ).PLUGINDIR.'/'. dirname( plugin_basename(__FILE__) );
        $redirect_url = trailingslashit( get_bloginfo('wpurl') )."wp-admin/admin.php?page={$this->plugin_name}_api_settings";
        ?>
        <form method="post" action="admin.php?page=<?php echo $this->plugin_name3."_api_settings";?>" id="form_exppinterest">
            <div class="wrap">
                <h2><?php _e("Account"); ?></h2>
				<?php
				if( $options['pinterest_account']['pinterest_access_token'] != '' ) {
					if($options['pinterest_account']['pinterest_board_id'] == '')	{ 
						?>
						<span id="successmessage"><div class="error below-h2"> <p><strong>ERROR</strong>: No board found in your pinterest account. Please create one.</p> </div></span> 
						<?php
					}
				}
				?>
                <p>
								
					<?php $pinterest_user_info = $this->getPinterestUserInfo($options['pinterest_account']['pinterest_username'],$options['pinterest_account']['pinterest_access_token']); ?>
					<style>
						.pp-postbox, .menu-item-settings {
							background-color: #F5F5F5;
							background-image: -moz-linear-gradient(center top , #F9F9F9, #F5F5F5);
							border-color: #DFDFDF;
							border-radius: 3px 3px 3px 3px;
							box-shadow: 0 1px 0 #FFFFFF inset;
							min-width: 255px;
							position: relative;
							border-style: solid;
							border-width: 1px;
							line-height: 1;
							margin-bottom: 20px;
							padding: 0;
						}
						.pp-postbox .handlediv {
							cursor: pointer;
							float: right;
							height: 30px;
							width: 27px;
						}
						.pp-postbox, .stuffbox {
							border-style: solid;
							line-height: 1;
						}
						
						.pp-postbox h3 {
							color: #464646;
							border-bottom-color: #DFDFDF;
							box-shadow: 0 1px 0 #FFFFFF;
							text-shadow: 0 1px 0 #FFFFFF;
							background-color: #F1F1F1;
							background-image: -moz-linear-gradient(center top , #F9F9F9, #ECECEC);
							font-size: 15px;
							font-weight: normal;
							line-height: 1;
							margin: 0;
							padding: 7px 10px;
							 -moz-user-select: none;
							border-bottom-style: solid;
							border-bottom-width: 1px;
							font-family: Georgia,"Times New Roman","Bitstream Charter",Times,serif;	
						}
						.pp-postbox .handle  {
						border-top-left-radius: 3px;
						border-top-right-radius: 3px;
						cursor: move;
						}
						#pp-dashboard_right_now p.sub {
							color: #8F8F8F;
							font-size: 14px;
							left: 15px;
							padding: 5px 0 15px;
							position: absolute;
							top: -17px;
						}
						#pp-dashboard_right_now p.sub, #pp-dashboard_right_now .table, #pp-dashboard_right_now .versions {
							margin: -12px;
						}
						#pp-dashboard_right_now .table_content {
							border-top: 1px solid #ECECEC;
							float: left;
							width: 45%;
						}
						#pp-dashboard_right_now .table {
							margin: 0;
							padding: 0;
							position: relative;
						}
						#pp-dashboard_right_now .inside {
							font-size: 12px;
							padding-top: 20px;
						}
						.pp-postbox .inside {
							margin: 10px 0;
							position: relative;
						}
						.pp-postbox .inside, .stuffbox .inside {
							line-height: 1.4em;
							padding: 0 10px;
						}
						.widget, .pp-postbox, .stuffbox {
							border-style: solid;
							line-height: 1;
						}						
						#pp-dashboard_right_now p.sub {
							color: #8F8F8F;
							font-size: 14px;
							left: 15px;
							padding: 5px 0 15px;
							position: absolute;
							top: -17px;
						}						
						#pp-dashboard_right_now .table_discussion {
							border-top: 1px solid #ECECEC;
							float: right;
							width: 45%;
						}
						#pp-dashboard_right_now .table {
							margin: 0;
							padding: 0;
							position: relative;
						}
						#pp-dashboard_right_now .inside {
							font-size: 12px;
						}
						.pp-postbox .inside, .stuffbox .inside {
							line-height: 1.4em;
						}
						#pp-dashboard_right_now .versions {
							clear: both;
							padding: 6px 10px 12px;
						}
						#pp-dashboard_right_now .inside {
							font-size: 12px;
						}
						.pp-postbox .inside, .stuffbox .inside {
							line-height: 1.4em;
						}
						.pp-postbox, .stuffbox {
							border-style: solid;
							line-height: 1;
						}						
						#pp-dashboard_right_now .inside {
							font-size: 12px;
						}
						.pp-postbox .inside, .stuffbox .inside {
							line-height: 1.4em;
						}		
						#pp-dashboard_right_now table tr.first td {
							border-top: medium none;
						}
						#pp-dashboard_right_now td.b {
							font-size: 14px;
							padding-right: 6px;
							text-align: right;
							width: 1%;
						}
						#pp-dashboard_right_now td.b a {
							font-size: 18px;
						}
						#pp-dashboard_right_now td.first a {
							text-decoration: none;
							font-family: Georgia,"Times New Roman","Bitstream Charter",Times,serif;
						}
						a:hover, a:active, a:focus {
							color: #D54E21;
						}
						
						.table_content {
							font-family: sans-serif;
						}
						
						.table_content a{
							font-family:inherit;
							text-decoration: none;
						}
					</style>
					<div class="pp-postbox " id="pp-dashboard_right_now" style="width: 33%; ">
						<div title="Click to toggle" class="handlediv"><br></div>
						<h3 class="hndle"><span>Statistics</span></h3>
						<div class="inside">
							<?php
							$options3 = get_option("{$this->plugin_name}_api_options");
							$pinterest_user_info = $this->getPinterestUserInfo($options3['pinterest_account']['pinterest_username'],$options3['pinterest_account']['pinterest_access_token']);
							//echo "<pre>";print_r($pinterest_user_info);echo "</pre><br />";
							
							$username = $pinterest_user_info->user->username;
							$followers = $pinterest_user_info->user->stats->followers_count;
							$followers = $followers>0?$followers:0;
							
							$likes = $pinterest_user_info->user->stats->likes_count; 
							$likes = $likes>0?$likes:0;
							
							$pins = $pinterest_user_info->user->stats->pins_count; 
							$pins = $pins>0?$pins:0;
							
							$following = $pinterest_user_info->user->stats->following_count; 
							$following = $following>0?$following:0;
							
							$boards = $pinterest_user_info->user->stats->boards_count; 
							$boards = $boards>0?$boards:0;
							?>
							<div class="table table_content">
								<p class="sub">Content</p>
								<table>
									<tbody>
										<tr class="first">
											<td class="first b b-posts">
												<a href="http://pinterest.com/<?php echo $username; ?>/followers/"><?php echo $followers; ?></a>
											</td>
											<td class="t posts">
												<a href="http://pinterest.com/<?php echo $username; ?>/followers/">Follower<?php if( $followers > 1 || $followers <= 1) { echo "s"; } ?></a>
											</td>
										</tr>
										<tr>
											<td class="first b b_pages">
												<a href="http://pinterest.com/<?php echo $username; ?>/pins/?filter=likes"><?php echo $likes; ?></a>
											</td>
											<td style="color:green;" class="t pages">
												<a style="color:green;" href="http://pinterest.com/<?php echo $username; ?>/pins/?filter=likes">Like<?php if( $likes > 1 || $likes <= 1) { echo "s"; } ?></a>
											</td>
										</tr>
										<tr>
											<td class="first b b-cats">
												<a href="http://pinterest.com/<?php echo $username; ?>/pins"><?php echo $pins; ?></a>
											</td>
											<td style="color:#E66F00;" class="t cats">
												<a style="color:#E66F00;" href="http://pinterest.com/<?php echo $username; ?>/pins">Pin<?php if( $pins > 1 || $pins <= 1) { echo "s"; } ?></a>
											</td>
										</tr>
										<tr>
											<td class="first b b-cats">
												<a href="http://pinterest.com/<?php echo $username; ?>/following/"><?php echo $following; ?></a>
											</td>
											<td style="color:#ff00ff;" class="t cats">
												<a style="color:#ff00ff;" href="http://pinterest.com/<?php echo $username; ?>/following/">Following</a>
											</td>
										</tr>
										<tr>
											<td class="first b b-tags">
												<a href="http://pinterest.com/<?php echo $username; ?>"><?php echo $boards; ?></a>
											</td>
											<td style="color:##341fff;" class="t tags">
												<a style="color:##341fff;" href="http://pinterest.com/<?php echo $username; ?>">Board<?php if( $boards > 1 || $boards <= 1) { echo "s"; } ?></a>
											</td>
										</tr>
									</tbody>
								</table>
								</div>
							<div class="versions">
							</div>
						</div>
					</div>
				</p>
                <table class="widefat">
                    <thead>
                        <tr>
                            <th><?php _e('Social Network'); ?></th>
                            <th><?php _e('Social Account Link'); ?></th>
                            <th colspan="2"><?php _e('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    if( empty($info['data']) ) {
                        ?>
                        <tr colspan="5"><td><?php _e('You currently have no accounts added.  Add one below!') ?></td></tr>
                        <?php
                    }
                    if(!empty($accounts) ) {
                        foreach( $accounts as $key=>$acc ) {
                            if( !empty($acc) ) {
                                $data = $info['data'][$key];
                                if( !empty($data->id) ) {
                                ?>
								
                                <tr class="<?php echo $class; ?>">
                                    <td><input id='social_network_<?php echo $key; ?>' name='<?php echo $this->plugin_name; ?>[social_network_<?php echo $key; ?>]' style="margin: 0 5px 0 2px;" type='checkbox' <?php echo isset($options["social_network_{$key}"])?"checked":"" ?>/><img style="margin: 0 3px <?php echo $key=='identica' || $key=='qaiku'?'-6':'-4'; ?>px 2px; padding: 0; width:16px; height:16px;" src="<?php echo $plugin_url; ?>/social-icons/<?php echo $key; ?>.png" width="16" height="16"/><label style="position: relative; top: 1px" for="social_network_<?php echo $key; ?>"><?php echo $acc['social_network']; ?></label></td>
                                    <td>
                                    <?php if( $key =='pinterest' ) { ?>
											<a href="http://pinterest.com/<?php echo $pinterest_user_info->user->username;?>/">
												<img align="top" width="50" height="50" alt="" src="<?php echo $pinterest_user_info->user->image_url;?>" style="border: none">
												<span style="margin-left:5px;"><?php echo $pinterest_user_info->user->full_name;?></span>
											</a>
											<?php
                                        }
									?>
                                    </td>
                                    <?php
                                    echo "<td><a class='delete' href='admin.php?page={$this->plugin_name}_api_settings&amp;nl_action_id=3&amp;nl_social_network={$key}' onclick=\"return confirm('" . js_escape(sprintf( __("You are about to delete the Account with ID '%d'.\n'OK' to delete, 'Cancel' to stop."), $acc->social_account_id)) . "' );\">Delete</a></td>\n";
                                    ?>
                                </tr>
                                <?php 
                                }
                            }
                        }
                    }
            ?>
                    </tbody>
                </table>
            </div>
            <div class="wrap narrow">
            <?php
                $action_name = 'nl_api_update';
                $header = __('Application Settings');
                $button_text = __('Update');
                $after = '';
            ?>			
                <br />
                <h2><?php echo $header ?></h2>
                    <br />
                    <p><?php echo $header_text ?></p>
                    <p><?php echo $header_text2 ?></p>
                    <div><label><b>Pinterest</b></label></div>
                    <table class="form-table">
                        <tbody>
                            <!--<tr valign="top">
                                <th scope="row">Client ID <span class="description">(required)</span></th>
                                <td>
                                    <input id="pinterest_client_id" type="text" value="<?php echo $options['pinterest_account']['pinterest_client_id']; ?>" size="40" name="<?php echo $this->plugin_name; ?>[pinterest_client_id]" />
                                    <br />
                                </td>
                            </tr>
                            <tr valign="top">
                                <th scope="row">Client Secret <span class="description">(required)</span></th>
                                <td>
                                    <input id="pinterest_client_secret" type="text" value="<?php echo $options['pinterest_account']['pinterest_client_secret']; ?>" size="40" name="<?php echo $this->plugin_name; ?>[pinterest_client_secret]" />
                                    <br />
                                </td>
                            </tr>-->
                            <tr valign="top">
                                <th scope="row">Username <span class="description">(required)</span></th>
                                <td>
                                    <input id="pinterest_username" type="text" value="<?php echo $options['pinterest_account']['pinterest_username']; ?>" size="40" name="<?php echo $this->plugin_name; ?>[pinterest_username]" />
                                </td>
                            </tr>
                            <tr valign="top">
                                <th scope="row">Password <span class="description">(required)</span></th>
                                <td>
                                    <input id="pinterest_password" type="password" value="<?php echo $options['pinterest_account']['pinterest_password']; ?>" size="40" name="<?php echo $this->plugin_name; ?>[pinterest_password]" />
                                </td>
                            </tr>
                            <tr valign="top">
                                <th scope="row">Access Token</th>
                                <td>
									<input id="pinterest_access_token" type="text" readonly value="<?php echo $options['pinterest_account']['pinterest_access_token']; ?>" size="40" name="<?php echo $this->plugin_name; ?>[pinterest_access_token]" />
                                </td>
                            </tr>
							<tr>
                                <th scope="row">Board ID</th>
                                <td>
									<?php
										$curBoardID = $options['pinterest_account']['pinterest_board_id'];
										
									?>
									<select style="width:200px" id="pinterest_board_id" name="<?php echo $this->plugin_name; ?>[pinterest_board_id]">
										<?php
										foreach ($pinterest_user_info->boards as $board) {
											$board_url = $board->url;
											$board_id = $board->id;
											$board_name = $board->name;
										?>
										<option value="<?php echo $board_id; ?>" <?php selected($curBoardID, $board_id); ?>><?php echo $board_name; ?></option>
										<?php
										}
										?>
									</select>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row">Allow Users to Pin Images</th>
								<td>
									<input id='userspinimages' name='<?php echo $this->plugin_name; ?>[userspinimages]' type='checkbox' <?php echo isset($options['pinterest_account']['userspinimages'])?"checked":""; ?> style="padding: 0; margin: 0"/>
								</td>
							</tr>
							<tr valign="top">
								<th scope="row">Pin Description</th>
								<td>
									<textarea rows='5' style='width:500px;' id='pinterestPreText' name='<?php echo $this->plugin_name;?>[pinterestPreText]'><?php echo $options['pinterest_account']['pinterestPreText']; ?></textArea>
								</td>
							</tr>
                        </tbody>
                    </table>
                    <div style="margin: 20px 0 0 0"></div>

					<!--<input type="hidden" id="task_nl_api_update" name="task_nl_api_update" value="" />-->
                    <p class="submit"><input type="submit" name="nl_api_update_pinterest" value="Update" /></p>
					<!--<p class="submit" id="loadpinterest"><input type="button" name="nl_api_update1" value="Update" onclick="submitFormPinterest()"/></p>-->
            </div>
        </form>
        <?php
    }
    
    function init(){
		
		$this->createDBTables();
		
        register_setting( "{$this->plugin_name}_options", "{$this->plugin_name}_options", array(&$this,'validate') );
        if( !get_option("{$this->plugin_name}_api_options") ) {
            add_option("{$this->plugin_name}_api_options", array());
        }

        add_settings_section('generalSection', 'General Settings', array(&$this,'setGeneralSectionText'), "{$this->plugin_name}_general_page");

        add_settings_field('allowToSendFrom', 'Allow to Send from', array(&$this,'setAllowToSendFrom'), "{$this->plugin_name}_general_page", 'generalSection');
        add_settings_field('fireEvent', 'Allow Post Update', array(&$this,'setFireEvent'), "{$this->plugin_name}_general_page", 'generalSection');

        add_settings_field('numberOfCharacters', 'Number of Characters in Post:', array(&$this, 'setNumberOfCharacters'), "{$this->plugin_name}_general_page",'generalSection');
        add_settings_field('linkToShow', 'Choose URL to show', array(&$this, 'setURLToShow'), "{$this->plugin_name}_general_page", 'generalSection');

    }

    function setFireEvent() {
        $options = get_option("{$this->plugin_name}_options"); ?>
        <input id='fireEvent' name='<?php echo "{$this->plugin_name}";?>_options[fireEvent]' type='checkbox' <?php echo isset($options['fireEvent'])?"checked":""; ?> style="padding: 0; margin: 0"/><br />
        <label for='fireEvent'>Allow Posts to be sent out when the Update button is clicked</label>
        <?php
    }

    function setAllowToSendFrom() {
        $options = get_option("{$this->plugin_name}_options");
        if($options['checkbox_init'] == False ) {
            $options['allowToSendFromPages'] = 'on';
            $options['allowToSendFromPosts'] = 'on';
            $options['checkbox_init'] = True;
            update_option("{$this->plugin_name}_options", $options);
        }
        ?>
        <input type="hidden" name="<?php echo "{$this->plugin_name}";?>_options[checkbox_init]" value="<?php echo $options['checkbox_init']; ?>"/>
        <input style="margin:0; padding:0" id='allowToSendFromPages' name='<?php echo "{$this->plugin_name}";?>_options[allowToSendFromPages]' type='checkbox' <?php echo isset($options['allowToSendFromPages'])?"checked":""; ?>/><label for="allowToSendFromPages" style="margin: 0 0 0 5px; padding: 0; position: relative; top: 0" for="allowToSendFromPage">Pages</label><br />
        <input style="margin:0; padding:0" id='allowToSendFromPosts' name='<?php echo "{$this->plugin_name}";?>_options[allowToSendFromPosts]' type='checkbox' <?php echo isset($options['allowToSendFromPosts'])?"checked":""; ?>/><label for="allowToSendFromPosts" style="margin: 0 0 0 5px" for="allowToSendFromPost">Posts</label>
        <?php
    }

    function setMaximumMediaFileSize() {
        $options = get_option("{$this->plugin_name}_options");
        $filesize = trim($options['file_size']);
        if(!is_numeric($filesize)) {
            $filesize = 20;
            $options['file_size'] = $filesize;
            update_option("{$this->plugin_name}_options", $options);
        } else {
            if( $filesize < 1 ) {
                $filesize = 20;
                $options['file_size'] = $filesize;
                update_option("{$this->plugin_name}_options", $options);
            }
        }
        echo "<input id='maximumMediaFileSize' name='{$this->plugin_name}_options[file_size]' size='10' type='text' value='{$options['file_size']}' />";
    }

    function setFromName() {
            $options = get_option("{$this->plugin_name}_options");
            echo "<input id='fromName' name='{$this->plugin_name}_options[fromName]' size='40' type='text' value='{$options['fromName']}' />";
    }

    function setFromEmailAddress() {
            $options = get_option("{$this->plugin_name}_options");
            echo "<input id='fromEmailAddress' name='{$this->plugin_name}_options[fromEmailAddress]' size='40' type='text' value='{$options['fromEmailAddress']}' onsubmit='return validateForm();' />";
    }

    function setNumberOfCharacters() {
        $options = get_option("{$this->plugin_name}_options");
        echo "<input id='numberOfCharacters' name='{$this->plugin_name}_options[characters]' size='10' type='text' value='{$options['characters']}' />";
    }

    function setPinterestPreText() {
        $options = get_option("{$this->plugin_name}_options");
        echo "<textarea rows='5' style='width:500px;' id='pinterestPreText' name='{$this->plugin_name}_options[pinterestPreText]'>{$options['pinterestPreText']}</textArea>";
    }	
    
    function setLinkTag(){
        $options = get_option("{$this->plugin_name}_options");
        $linktag = isset($options['linktag'])?$options['linktag']:"Read more..."; ?>
        <input id="linkTag" type="text" name="<?php echo "{$this->plugin_name}_options[linktag]";?>" size="40" value="<?php echo $linktag; ?>" />
    <br /><label for="linkTag" >Text to show before any links below</label>
    <?php
    }

    function setURLToShow() {
        $options = get_option("{$this->plugin_name}_options");
        if(  $options['urlToShow'] != 'homeurl' && $options['urlToShow'] != 'posturl' && $options['urlToShow'] != 'nourl' && $options['urlToShow'] != 'customurl' && $options['urlToShow'] != 'randomurl') {
             $options['urlToShow'] = 'nourl';
             update_option("{$this->plugin_name}_options", $options);
        }
        ?>
    
        <script type="text/javascript">
            jQuery(document).ready(function(){
                jQuery("#form1")[0].reset();
                jQuery("#sitetitleurl").click(function(){
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#randomurlspan").hide();
                });
                jQuery("#posttitleurl").click(function(){
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#randomurlspan").hide();
                });
                jQuery("#sitetexturl").click(function(){
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#randomurlspan").hide();
                });
                jQuery("#posttexturl").click(function(){
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#randomurlspan").hide();
                    jQuery("#posttexturlspan").show();
                });
                jQuery("#homeurl").click(function(){
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#randomurlspan").hide();
                    jQuery("#homeurlspan").show();
                });
                jQuery("#posturl").click(function(){
                    jQuery("#customurlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#randomurlspan").hide();
                    jQuery("#posturlspan").show();
                });
                jQuery("#customurl").click(function(){
                    jQuery("#homeurlspan").hide();
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#randomurlspan").hide();
                    jQuery("#customurlspan").show();
                });
                jQuery("#randomurl").click(function(){
                    jQuery("#homeurlspan").hide();
                    jQuery("#posturlspan").hide();
                    jQuery("#nourlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#randomurlspan").show();
                });
                jQuery("#nourl").click(function(){
                    jQuery("#posturlspan").hide();
                    jQuery("#homeurlspan").hide();
                    jQuery("#customurlspan").hide();
                    jQuery("#randomurlspan").hide();
                    jQuery("#nourlspan").show();
                });
            });
        </script>

        <input type='radio' id="homeurl" name='<?php echo "{$this->plugin_name}_options[urlToShow]";?>' value='homeurl' <?php checked( $options['urlToShow'], "homeurl" ); ?> />
        <label for="homeurl">Home URL &nbsp;</label>
    
        <input type='radio' id="posturl" name='<?php echo "{$this->plugin_name}_options[urlToShow]";?>' value='posturl' <?php checked( $options['urlToShow'], "posturl" ); ?> />
        <label for="posturl">Post URL &nbsp;</label>
    
        <input type='radio' id="customurl" name='<?php echo "{$this->plugin_name}_options[urlToShow]";?>' value='customurl' <?php checked( $options['urlToShow'], "customurl" ); ?> />
        <label for="customurl">Custom URL &nbsp;</label>
    
        <input type='radio' id="randomurl" name='<?php echo "{$this->plugin_name}_options[urlToShow]";?>' value='randomurl' <?php checked( $options['urlToShow'], "randomurl" ); ?> />
        <label for="randomurl">Random URL &nbsp;</label>
        
        <input type='radio' id="nourl" name='<?php echo "{$this->plugin_name}_options[urlToShow]";?>' value='nourl' <?php checked( $options['urlToShow'], "nourl" ); ?> />
        <label for="nourl">No URL</label>

        <span id="homeurlspan" style="display:<?php echo $options['urlToShow'] != "homeurl"?'none':''; ?>"><br /><b><i>You are using home URL.</i></b></span>
        <span id="posturlspan" style="display:<?php echo $options['urlToShow'] != "posturl"?'none':''; ?>"><br /><b><i>You are using post URL.</i></b></span>
        <span id="customurlspan" style="display:<?php echo $options['urlToShow'] != "customurl"?'none':''; ?>">
            <br />
            <label style="margin: 0 5px 0 0" for="custom_url_url">URL</label><input id="custom_url_url" type="text" name="<?php echo "{$this->plugin_name}_options[custom_url_url]";?>" value="<?php echo $options['custom_url_url']; ?>" size="40"/> 
        </span>
        <span id="randomurlspan" style="display:<?php echo $options['urlToShow'] != "randomurl"?'none':''; ?>">
            <div style="clear: both"></div>
            <label style="position: relative; top: 2px"><b>URL types to randomize</b></label>
            <ul style="margin-top: 0">
                <li><input id="home_url_ch" name="<?php echo "{$this->plugin_name}_options[random][home_url_ch]";?>" style="margin: 0 5px 0 0; padding: 0" type="checkbox" <?php echo isset($options['random']['home_url_ch'])?"checked":""; ?>/><label for="home_url_ch">Home URL</label></li>
                <li><input id="post_url_ch" name="<?php echo "{$this->plugin_name}_options[random][post_url_ch]";?>" style="margin: 0 5px 0 0; padding: 0" type="checkbox" <?php echo isset($options['random']['post_url_ch'])?"checked":""; ?>/><label for="post_url_ch">Post URL</label></li>
                <li><input id="custom_url_ch" name="<?php echo "{$this->plugin_name}_options[random][custom_url_ch]";?>" style="margin: 0 5px 0 0; padding: 0" type="checkbox" <?php echo isset($options['random']['custom_url_ch'])?"checked":""; ?>/><label for="custom_url_ch">Custom URL</label></li>
                <li><input id="no_url_ch" name="<?php echo "{$this->plugin_name}_options[random][no_url_ch]";?>" style="margin: 0 5px 0 0; padding: 0" type="checkbox" <?php echo isset($options['random']['no_url_ch'])?"checked":""; ?>/><label for="no_url_ch">No URL</label></li>
            </ul>
        </span>
        <span id="nourlspan" style="display:<?php echo $options['urlToShow'] != "nourl"?'none':''; ?>"><br /><b><i>No URL.</i></b></span>
    
        <?php
    }
    
    function setGeneralSectionText() {
            ?>
    <p>General <?php echo $this->plugin_name2; ?> settings can be set here</p>
            <?php
    }

    function createSettingsPage() {
        ?>

    <div class="wrap">
            <h2><?php $this->plugin_name2; ?> Settings Page</h2>
            <form action="options.php" method="post" id="form1">
            <?php settings_fields("{$this->plugin_name}_options"); ?>
            <?php do_settings_sections("{$this->plugin_name}_general_page"); ?>
                    <br /><p class="submit"><input name="submit" type="submit"
                            value="<?php esc_attr_e('Save Changes'); ?>" /></p>
            </form>
    </div>
            <?php
    }

    function generateContent( $post_ID, $commentContent='' ) {

        $options = get_option("{$this->plugin_name}_options");

        if( $commentContent=='' ) {

            $postType = get_post_type($post_ID);

            $cont = False;

            $postType = get_post_type($post_ID);

            $pagesSet = isset($options['allowToSendFromPages'])?True:False;

            $postsSet = isset($options['allowToSendFromPosts'])?True:False;



            if( $postType == 'page' && $pagesSet ) {

                $cont = True;

            } else if( $postType == 'post' && $postsSet ) {

                $cont = True;

            }

            if( !$cont ) {

                return $post_ID;

            }
        }


        $permalink = get_permalink($post_ID);

        $siteLink = get_bloginfo("siteurl");

        $customURL = $options['custom_url_url'];

        $post = get_post($post_ID);

        $subject = $post->post_title;

        if( $commentContent != '' ) {
            $post->post_content = $commentContent;
        }
        $content = $post->post_content;

        $gid = $this->checkShortcode($content);

        $galleryPaths = $this->getGalleryPaths($gid);

        $post->post_content = do_shortcode($content);

        $hrefArray = $this->getHREFs($post->post_content);

        $validHREFs = $this->getValidHREF($hrefArray, True,"");

		$emailBefore = '';
		$emailAfter = '';
		
        $plainContent = strip_tags($emailBefore.$post->post_content.$emailAfter);

        $headersPlain = "From: {$options['fromName']} <{$options['fromEmailAddress']}>\r\nContent-type: text/plain\r\n";

        $headersPlainISO = "From: {$options['fromName']} <{$options['fromEmailAddress']}>\r\nContent-type: text/plain; charset=ISO-8859-1\r\n";

		

        $htmlContent = $emailBefore.$post->post_content.$emailAfter;

        $headersHTML = "From: {$options['fromName']} <{$options['fromEmailAddress']}>\r\nContent-type: text/html\r\n";

		

        $contentHREFedited = $post->post_content;

        if(is_array($validHREFs ) ) {

            if(!empty($validHREFs) ) {

                $all = "";

                foreach($validHREFs as $vh ) {

                    if(!empty($all)) {

                        $all.=" ";

                    }

                    $all.=$vh;

                    $contentHREFedited = $this->removeValidHREF($contentHREFedited, $vh);

                }

                if(!empty($all)) {

                    // $content = $all." ".$content;

                }

            }

        }



        if ($options['urlToShow'] == "homeurl"){

            $plainLink = $siteLink;

        } else if ($options['urlToShow'] == "posturl"){

            $plainLink = $permalink;

        } else if ($options['urlToShow'] == "customurl"){

            $plainLink = $customURL;

        } else if ($options['urlToShow'] == "randomurl"){

            $randomlinks = $options['random'];

            if(!is_array($randomlinks)) {

                $randomlinks = array();

            }

            if( !empty($randomlinks) ) {

                $randomlinks2 = array();

                foreach( $randomlinks as $key=>$value) {

                    $randomlinks2[] = $key;

                }

                if( !empty($randomlinks2) ) {

                    shuffle($randomlinks2);

                    $randomtype = $randomlinks2[0];

                    

                    if( $randomtype == 'home_url_ch' ) {

                        $randomURL = $siteLink;

                        $randomtext = $siteLink;

                    } else if( $randomtype == 'post_url_ch' ) {

                        $randomURL = $permalink;

                        $randomtext = $permalink;

                    } else if( $randomtype == 'custom_url_ch' ) {

                        $randomURL = $customURL;

                        $randomtext = $customLink;

                    } else if( $randomtype == 'no_url_ch' ) {

                        $randomURL = "";

                        $randomtext = "";

                        

                    }

                }

            }

            

            if( $randomtype == 'no_url_ch' ) {

            } else {

                $plainLink = $randomURL;

            }

        } else if($options['urlToShow'] == "nourl") {

        }



        $mediaPlainContent = $linkTag.$plainLink." ".$plainContent;

        $mediaPlainContent2 = $linkTag.$plainLink."\r\n".$plainContent;

        $mediaHTMLContent = $htmlLink." <br /> ".$htmlContent;



        $blogHTMLContent2 = "{$htmlContent}\r\n".$plainLink;

        $blogPlainContent = "{$plainContent} ".$plainLink;



        $hyvesContent = html_entity_decode($hyvescontent, ENT_QUOTES, "UTF-8");

        

        $attachments = array();



        $photos_valid_href = $this->getValidHREF($hrefArray, False, "photos");

		

        if( !empty($galleryPaths) ) {

            $mediaHTMLContent = $this->removeHREF($mediaHTMLContent, $galleryPaths);

        } else {

            $mediaHTMLContent = $this->removeValidHREF($mediaHTMLContent, $photos_valid_href);

            if( $photos_valid_href != '' ) {

                $galleryPaths[] = $photos_valid_href;

            }

        }

		

        $videos_valid_href = $this->getValidHREF($hrefArray, False, "videos");

        $mediaHTMLContent = $this->removeValidHREF($mediaHTMLContent, $videos_valid_href);

        

        $audios_valid_href = $this->getValidHREF($hrefArray, False, "audios");

        $mediaHTMLContent = $this->removeValidHREF($mediaHTMLContent, $audios_valid_href);

        

        $optionsMedia = get_option("{$this->plugin_name}_media_options");

        $attachmentsMedia = array();

		

        if( !is_array($galleryPaths) ) {

            $galleryPaths = array();

        }
        
		$data = array();
        $data['plainContent'] = $plainContent;
        $data['mediaPlainContent'] = $mediaPlainContent;
        $data['mediaHTMLContent'] = $mediaHTMLContent;
        $data['plainLink'] = $plainLink;
        $data['linkTag'] = $linkTag;
        $data['subject'] = $subject;
        $data['photos_valid_href'] = $photos_valid_href;
        return $data;
    }
	
    function email( $post_ID ) {
        $options = get_option("{$this->plugin_name}_options");
        $data = $this->generateContent($post_ID);		

        $plainContent = $data['plainContent'];
        $plainLink = $data['plainLink'];
        $linkTag = $data['linkTag'];
        $subject = $data['subject'];
		$photos_valid_href = $data['photos_valid_href'];
        $maxChars = trim($options['characters']);

        if(is_numeric($maxChars) ) {

            $maxChars = intval($maxChars);

        } else {

            $maxChars = -1;

        }

        $api_options = get_option("{$this->plugin_name}_api_options");

        if( isset( $api_options['social_network_pinterest'] ) ) {
            $pinterestContent = $this->clipContent($plainContent, $maxChars-strlen(" ".$linkTag.$plainLink), False)." ".$linkTag.$plainLink;			
			$this->pinterestStatusUpdate($pinterestContent, $subject, $photos_valid_href);
        }
        return $post_ID;
    }

    function clipContent($content='', $maxChars='') {
        if( is_numeric($maxChars) ) {
            $lengthPlain = strlen($content);
            if( $lengthPlain > $maxChars && $maxChars >= 0 ) {
                $content = substr($content, 0, $maxChars);
            }
        }
        return $content;
    }

    function getGalleryPaths( $id='' ) {
        if( !is_numeric($id) ) {
            return array();
        }
        global $wpdb;
        $query = "SELECT CONCAT(path,'/',filename) as 'path' FROM wp_ngg_gallery, wp_ngg_pictures WHERE gid=galleryid and gid=$id";
        $rs = $wpdb->get_results($query);

        $retval = array();
        
        foreach( $rs as $val ) {
            $url = get_bloginfo('wpurl');
            if(strripos($url, "/")+1 != strlen($url)) {
                $url .= "/";
            }
            $retval[] = $url . $val->path;
        }
        return $retval;
    }
    
    function checkShortcode($content='', $shortcode='nggallery') {
        $pattern = get_shortcode_regex();
        preg_match_all( '/'. $pattern .'/s', $content, $matches );
        if( is_array( $matches ) && array_key_exists( 2, $matches ) && array_key_exists( 3, $matches ) && in_array( $shortcode, $matches[2] ) ) {
            foreach( $matches[2] as $key=>$val) {
                if( $val == $shortcode) {
                    $param = $matches[3][$key];
                    $param_e = explode("=", str_replace(" ", "", $param));
                    if( $param_e ) {
                        if( count($param_e)>=2 ) {
                            $galleryId = $param_e[1];
                            return $galleryId;
                        }
                    }
                }
            } 
        }
    }
    
    function getValidHREF($href_array_arg, $all, $type) {
        $blank_string = "";

	if(is_array($href_array_arg)){
        foreach ($href_array_arg as $href_value) {
            $href_extn = substr(strrchr($href_value,'.'),1);
            $valid = False;
            if( $type == 'photos' || $all) {
                if (strcasecmp ( $href_extn , "jpg" ) == 0 ||
                    strcasecmp ( $href_extn , "jpeg" ) == 0 ||
                    strcasecmp ( $href_extn , "tiff" ) == 0 ||
                    strcasecmp ( $href_extn , "png" ) == 0 ||
                    strcasecmp ( $href_extn , "gif" ) == 0 ) {
                    $valid = True;
                }
            } else if( $type=='videos'  || $all) {
                if( strcasecmp ( $href_extn , "mp4" ) == 0 ||
                    strcasecmp ( $href_extn , "m4v" ) == 0 ||
                    strcasecmp ( $href_extn , "mov" ) == 0 ||
                    strcasecmp ( $href_extn , "wmv" ) == 0 ||
                    strcasecmp ( $href_extn , "avi" ) == 0 ||
                    strcasecmp ( $href_extn , "mpg" ) == 0 ||
                    strcasecmp ( $href_extn , "ogv" ) == 0 ||
                    strcasecmp ( $href_extn , "3gp" ) == 0 ||
                    strcasecmp ( $href_extn , "3g2" ) == 0) {
                    $valid = True;
                }
            } else if( $type=='audios'  || $all) {
                if( strcasecmp ( $href_extn , "mp3" ) == 0 ||
                    strcasecmp ( $href_extn , "m4a" ) == 0 ||
                    strcasecmp ( $href_extn , "ogg" ) == 0 ||
                    strcasecmp ( $href_extn , "wma" ) == 0 ||
                    strcasecmp ( $href_extn , "wav" ) == 0 ) {
                    $valid = True;
                }
            }
            if( $valid ) {
                if( !$all ) {
                    $options = get_option("{$this->plugin_name}_options");
                    $filesize = trim($options['file_size']);
                    if( !is_numeric($filesize)) {
                        $filesize = 20;
                        $options['file_size'] = $filesize;
                        update_option("{$this->plugin_name}_options", $options);
                    } else {
                        if( $filesize < 1 ) {
                            $filesize = 20;
                            $options['file_size'] = $filesize;
                            update_option("{$this->plugin_name}_options", $options);
                        }
                    }
                    $filesize = 1024 * 1024 * $filesize;
                    //if ($this->remote_filesize($href_value) <= $filesize) {
                        return $href_value;
                    //}
                } else {
                    $media_arr[] = $href_value;
                }
            }
        }
        }
        if( !$all ) {
            return $blank_string;
        } else {
            return $media_arr;
        }
    }

    function removeHREF( $text, $href_arr ) {
        $text2 = stripslashes($text);

        if(!preg_match_all("/(<a.*>)(.*)(<\/a>)/ismU",$text2,$matches,PREG_SET_ORDER)){
            $text;
        }

        foreach($matches as $key => $value){
            
            preg_match("/href\s*=\s*[\'|\"]\s*(.*)\s*[\'|\"]/i",$value[1],$href);
            if((substr($href[1],0,7)!="http://" && substr($href[1],0,8)!="https://") ){
                unset($matches[$key]);
            }else{
                $temp_href = $href[1];
                $arr = explode(" ", $temp_href);
                if( $arr ) {
                    if( !empty($arr) ) {
                        $temp_href = $arr[0];
                        $temp_href = str_replace("\"","",$temp_href);
                        if(in_array($temp_href, $href_arr)) {
                            $text2 = str_replace($matches[$key][0],"",$text2);
                        }
                    }
                }
            }
        }
        return $text2;
    }
    
    function removeValidHREF($content_arg, $valid_href_arg) {
            $return_content = $content_arg;
            $regex_valid_href_arg = str_replace("/", "\/", $valid_href_arg);

            if (preg_match('/\<a.+?href\=[\"|\']' . $regex_valid_href_arg . "\s*(.*)\s*" . '[\"|\'].?\>(.+?)<\/a\>/', $return_content, $matches) == 1 ) {
                    $tagless_anchor = $matches[2];

                    if(preg_match('/<img.+?>/', $tagless_anchor) == 1 ) {
                            $tagless_anchor = '';
                    }
                    $tagless_content = preg_replace('/\<a[^<>]+?href\=[\"|\']' . $regex_valid_href_arg . '[\"|\'].?\>(.+?)<\/a\>/', $tagless_anchor, $return_content);
                    return $tagless_content;
            } else {
                    return $return_content;
            }
    }

    function validate($input) {
            return $input;
    }
	
	function getPinterestAccessToken($client_id, $client_secret, $username, $password)	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_USERAGENT, 'Pinterest For iPhone / 1.4.3');
		curl_setopt($ch, CURLOPT_URL, "https://api.pinterest.com/v2/oauth/access_token?");
		curl_setopt($ch, CURLOPT_HTTPHEADER, 
							array(	'Content-Type'=>'application/x-www-form-urlencoded; charset=utf-8',
									'Connection'=>'Close', 
									'Host'=>'api.pinterest.com',
									'User-Agent'=>'Pinterest For iPhone / 1.4.3',
									'Content-Length'=>'96',
									'Authorization'=>'BASIC',
									'Accept-Encoding'=>'gzip') );
		curl_setopt($ch, CURLOPT_COOKIEFILE, $GLOBALS['cookies']);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_POST, true);
		$post = array(
						"client_id" => $client_id,
						"client_secret" => $client_secret,
						"grant_type" => 'password',
						"scope" => 'read_write',
						"redirect_uri" => 'http://pinterest.com/about/iphone/',
						"redirect_uri" => '1234567',
					);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post); 
		curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
		$response = curl_exec($ch);
		$response =  explode('access_token=',$response);
		curl_close($ch);
		return $response[1];
	}

	function getPinterestUserInfo($username,$access_token)	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_VERBOSE, 0);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");	
		curl_setopt($ch, CURLOPT_URL, "https://api.pinterest.com/v2/users/".$username."/?access_token=".$access_token."");
		$response = curl_exec($ch);
		$json = json_decode($response);
		curl_close($ch);		
		return $json;
	}
	
	function createPostStatus()	{
		include 'poststatus.php';
	}
	
	function createPageStatus()	{
		include 'pagestatus.php';
	}

	function createDBTables() {
		$sql = "SHOW TABLES FROM ".DB_NAME."";
		$result = mysql_query($sql);
		while ($row = mysql_fetch_row($result)) {
			$tables[] = $row[0];
			$parsetable = explode('_',$row[0]);
			$tablenames[] = $parsetable[1];
		}
		$db_table = $this->db_table;
		if (!in_array($db_table, $tables)) {		
			$result = mysql_query("
							CREATE TABLE `{$this->db_table}` (
							  `id` bigint(20) NOT NULL auto_increment,
							  `post_id` int(20) default NULL,
							  `sn` varchar(255) NOT NULL,
							  `sn_username` varchar(255) NOT NULL,
							  `returnurl` varchar(255) NOT NULL,
							  PRIMARY KEY  (`id`),
							  KEY `postid` (`post_id`)
							)ENGINE=InnoDB  DEFAULT CHARSET=utf8;"
						);
		}
	}
	
	function add_button_beside_the_images()	{
		$options = get_option("{$this->plugin_name}_options");
		$wpurl = $options['urlToShow'];
		if( $wpurl == '' ) {
			$wpurl = get_bloginfo('wpurl');
		}
		$pluginame = $this->plugin_name;
	
		$content = get_the_content();
		preg_match_all('/<img[^>]+>/i',$content, $results); 
	
		$newimages = array();
		$dom = new DOMDocument;
		$dom->loadHTML($content);
		
		$div_image = $dom->createElement("div");
		
		$a_afterimage = $dom->createElement("a");
		$pintext = $dom->createTextNode('');
		
		$images = $dom->getElementsByTagName('img');
		$counter = 0;
		$counter_results = 0;
		foreach($images as $image) {
			$counter++;
			if(is_home())	{
				$counter = get_the_ID().'-'.$counter;
			}

			//$imagesrc = $image->getAttribute('src');			
			$image->setAttribute('class', 'imagepinterest');

			$newimages[] = $dom->saveXML($image);
			$nimage = $dom->saveXML($image);

			$content = str_replace($results[0][$counter_results], $nimage, $content);
			$counter_results++;
			
		}
		
		//$content .= '<input type="hidden" id="pinteresturl" name="pinteresturl" value="'.$wpurl.'">';
		return $content;
		
	}

	function add_my_pinterest_head_script()	{
		global $wpdb, $table_prefix,$current_user,$post_id;

		$options = get_option("{$this->plugin_name}_options");
		$options2 = get_option("{$this->plugin_name}_api_options");
		$wpurl = $options['urlToShow'];
		if( $wpurl == '' ) {
			$wpurl = get_bloginfo('wpurl');
		}

		?>
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<style type="text/css">
			.autopin-wrapper{
				position:relative;
				overflow:hidden;
			}

			.autopin-wrapper img{
				z-index:3;
				position:relative;
				display:block;
			}

			.autopin-wrapper span{
				display:none;
				z-index:1;
				height:100%;
				width:100%;
				position:absolute;
				top:0;
				float:left;
			}
			.pin-it-button	{
				background-image: url(<?php bloginfo('wpurl'); ?>/wp-content/plugins/exponent_web_media_pinterest/images/mypinit.png);
				width: 44px;
				height: 25px;
			}
		</style>
		<script type="text/javascript">
		var wpurl = '<?php bloginfo('wpurl'); ?>/';  
		var desc = '<?php echo urlencode($options2['pinterest_account']['pinterestPreText']); ?>';  
		var pluginame = '<?php echo $this->plugin_name; ?>';
		jQuery.noConflict();
		(function(a){
			a.fn.autoPin=
			function(c){
				var d={img_class:"imagepinterest",page_url:wpurl,alt_tags:!1},c=a.extend(d,c);
				a("img."+d.img_class).each(
					function(){
						var b=a(this);b.attr("src");
							b.parent().is("a")&&b.unwrap();
							b.wrap('<div class="autopin-wrapper"/>');
						var e=this.height,f=this.width;
							b.attr("height")&&(e=b.attr("height"));
							b.attr("width")&&(f=b.attr("width"));
						var c=encodeURI(b.attr("src")),g=encodeURI(b.attr("alt")),h=encodeURI(d.page_url),i=(e-20)/2,j=(f-43)/2;!1==d.alt_tags&&(g="");
							b.parent().css({width:f+"px",height:e+"px"});
							b.parent().append('<span><div style="position:absolute; top:'+i+"px; left:"+j+'px;"><a onclick="popUpPinterest(\''+wpurl+'\',\''+desc+'\',\''+c+'\')" style="cursor:pointer;text-decoration:none;" class="pin-it-button" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></span></div>');
							a(".autopin-wrapper img").mouseenter(
								function(){
									a(this).parent().children("span").css({display:"block"});
									a(this).stop().animate({opacity:"0.2"},300,null,function(){a(this).parent().children("span").css({"z-index":"999"})})
								}
							);
							a(".autopin-wrapper span").mouseleave(
								function(){
									a(this).css("z-index","1");
									a(this).stop().parent().children("img").animate({opacity:"1"},300);
									a(this).css("display","none")
								}
							)
					}
				);
				return!0
			}
		})(jQuery);	

		//var pinterest_url = jQuery("#pinteresturl").val();
		//alert(pinteresturl);
		jQuery(document).ready(function(){
			jQuery().autoPin(	{
				'img_class':'imagepinterest',
				'page_url':wpurl,
				'alt_tags':true
			});
		});

		function popUpPinterest(url,desc,imagsrc)	{
			var width = 800;
			var height = 520;
			var to = "http://pinterest.com/pin/create/button/?description="+desc+"&url="+url+"&media="+imagsrc+"";
			var left = parseInt((screen.availWidth/2) - (width/2));
			var top = parseInt((screen.availHeight/2) - (height/2));
			var windowFeatures = "width=" + width + ",height=" + height + 
				",status,left=" + left + ",top=" + top + 
				",screenX=" + left + ",screenY=" + top + ",menubar=1";
				myWindow = window.open(to, "subWind", windowFeatures);
			myWindow.focus();
		}

		
		</script>
		<?php
	}
	
	function add_pinterest_dashboard_widgets()	{
		wp_add_dashboard_widget('dashboard_widget', 'Pinterest', array(&$this,'pinterest_dashboard_widget_function'));
	}
	
	function pinterest_dashboard_widget_function() {
	?>
		<style>
		.pp_table_content {
			border-top: 1px solid #ECECEC;
			width: 45%;
			margin: 0;
			padding: 0;
			position: relative;
			padding-bottom: 20px;
			top: 20px;
		}
		.pp_table_content p.sub {
			color: #8F8F8F;
			font-size: 14px;
			left: 15px;
			padding: 5px 0 15px;
			position: absolute;
			top: -17px;
			margin:-12px;
		}
		.pp_table_content tr.first td {
			border-top: medium none;
		}
		.pp_table_content td.b {
			font-size: 14px;
			padding-right: 6px;
			text-align: right;
			width: 1%;
		}
		.pp_table_content td.b a {
			font-size: 18px;
		}
		.pp_table_content td.first a {
			text-decoration: none;
			font-family: Georgia,"Times New Roman","Bitstream Charter",Times,serif;
		}
		a:hover, a:active, a:focus {
			color: #D54E21;
		}
		
		.pp_table_content {
			font-family: sans-serif;
		}
		
		.pp_table_content a{
			font-family:inherit;
			text-decoration: none;
		}
	</style>
		<?php
		$options3 = get_option("{$this->plugin_name}_api_options");
		$pinterest_user_info = $this->getPinterestUserInfo($options3['pinterest_account']['pinterest_username'],$options3['pinterest_account']['pinterest_access_token']);
		//echo "<pre>";print_r($pinterest_user_info);echo "</pre><br />";
		
		$username = $pinterest_user_info->user->username;
		$followers = $pinterest_user_info->user->stats->followers_count;
		$followers = $followers>0?$followers:0;
		
		$likes = $pinterest_user_info->user->stats->likes_count; 
		$likes = $likes>0?$likes:0;
		
		$pins = $pinterest_user_info->user->stats->pins_count; 
		$pins = $pins>0?$pins:0;
		
		$following = $pinterest_user_info->user->stats->following_count; 
		$following = $following>0?$following:0;
		
		$boards = $pinterest_user_info->user->stats->boards_count; 
		$boards = $boards>0?$boards:0;
		
		?>
		<div class="pp_table_content">
			<p class="sub">Content</p>
			<table>
				<tbody>
					<tr class="first">
						<td class="first b b-posts">
							<a href="http://pinterest.com/<?php echo $username; ?>/followers/"><?php echo $followers; ?></a>
						</td>
						<td class="t posts">
							<a href="http://pinterest.com/<?php echo $username; ?>/followers/">Follower<?php if( $followers > 1 || $followers < 1) { echo "s"; } ?></a>
						</td>
					</tr>
					<tr>
						<td class="first b b_pages">
							<a href="http://pinterest.com/<?php echo $username; ?>/pins/?filter=likes"><?php echo $likes; ?></a>
						</td>
						<td style="color:green;" class="t pages">
							<a style="color:green;" href="http://pinterest.com/<?php echo $username; ?>/pins/?filter=likes">Like<?php if( $likes > 1 || $likes < 1) { echo "s"; } ?></a>
						</td>
					</tr>
					<tr>
						<td class="first b b-cats">
							<a href="http://pinterest.com/<?php echo $username; ?>/pins"><?php echo $pins; ?></a>
						</td>
						<td style="color:#E66F00;" class="t cats">
							<a style="color:#E66F00;" href="http://pinterest.com/<?php echo $username; ?>/pins">Pin<?php if( $pins > 1 || $pins < 1) { echo "s"; } ?></a>
						</td>
					</tr>
					<tr>
						<td class="first b b-cats">
							<a href="http://pinterest.com/<?php echo $username; ?>/following/"><?php echo $following; ?></a>
						</td>
						<td style="color:#ff00ff;" class="t cats">
							<a style="color:#ff00ff;" href="http://pinterest.com/<?php echo $username; ?>/following/">Following</a>
						</td>
					</tr>
					<tr>
						<td class="first b b-tags">
							<a href="http://pinterest.com/<?php echo $username; ?>"><?php echo $boards; ?></a>
						</td>
						<td style="color:##341fff;" class="t tags">
							<a style="color:##341fff;" href="http://pinterest.com/<?php echo $username; ?>">Board<?php if( $boards > 1 || $boards < 1) { echo "s"; } ?></a>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
		<?php
	}
	
	function pinterest_dashboard_widget_function2()	{
	
		global $wpdb, $table_prefix,$current_user,$post_id;
		
		$options = get_option("{$this->plugin_name}_api_options");
		$pinterest_user_info = $this->getPinterestUserInfo($options['pinterest_account']['pinterest_username'],$options['pinterest_account']['pinterest_access_token']);
		echo 'Followers count - '.$pinterest_user_info->user->stats->followers_count;
		echo '<br/>';
		echo 'Likes count  - '.$pinterest_user_info->user->stats->likes_count;
		echo '<br/>';
		echo 'Pins count  - '.$pinterest_user_info->user->stats->pins_count;
		echo '<br/>';
		echo 'Following count '.$pinterest_user_info->user->stats->following_count;
		echo '<br/>';
		echo 'Boards count - '.$pinterest_user_info->user->stats->followers_count;
		echo '<br/>';
	}
}
?>
