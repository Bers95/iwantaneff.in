<?php

/* @package Exponent PinPresser Standard
 * @version 0.93
 * Plugin Name: Pin Presser Standard
 * Plugin URI: http://exponent.co.nz 
 * Description: Wordpress to Pinterest
 * Author: Cossack 
 * Version: 0.93
 * Author URI: http://exponent.co.nz 
 */

include_once('exponent_web_media_pinterest.php');

?>