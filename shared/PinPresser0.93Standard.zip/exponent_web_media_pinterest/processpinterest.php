<?php

require('./../../../wp-load.php');



global $wpdb, $table_prefix,$current_user;
get_currentuserinfo();
$user_id = $current_user->ID;

date_default_timezone_set('UTC');
$mysqldate = date( 'Y-m-d H:i:s');	

$task = trim(addslashes($_POST['task']));
$wpurl = get_bloginfo('wpurl');


if($_POST['task'] == 'processPinterest')	{

	$client_id = trim($_POST['pinterest_client_id']);
	$client_secret = trim($_POST['pinterest_client_secret']);
	$username = trim($_POST['pinterest_username']);
	$password = trim($_POST['pinterest_password']);

	$pinterest = new ExponentWebMediaPinterest();
	$access_token = $pinterest->getPinterestAccessToken($client_id, $client_secret, $username, $password);
	$pinterest_user_info = $pinterest->getPinterestUserInfo($username,$access_token);
	
	echo count($pinterest_user_info->boards);

}
else {
	echo 'You are not allowed to visit this script.';
}