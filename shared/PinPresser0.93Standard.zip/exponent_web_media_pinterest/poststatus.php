<?php

	/*
		This file is part of the exponent web media pinterest plugin
	*/
	
	global $wpdb, $table_prefix,$current_user;

	$options = get_option("{$this->plugin_name}_api_options");
	if( !$options ) {
		$options = array();
		add_option("{$this->plugin_name}_api_options", $options);
	}

	$wpurl = get_bloginfo('wpurl');
	
	?>
	<div class="wrap">
		<h2>Post Status</h2>
		<div>
		
			<table cellspacing="0" class="widefat post fixed">
				<thead>
					<tr>
						<th scope="col" width="50%">Title</th>
						<th scope="col" >Author</th>
						<th scope="col" >Date Published</th>
				</thead>
				<tfoot>
					<tr>
						<th scope="col" width="50%">Title</th>
						<th scope="col" >Author</th>
						<th scope="col" >Date Published</th>
					</tr>
				</tfoot>
				<tbody>
					<?php
						
						$args = array(
							'post_type' => 'post',
							'post_status' => 'publish'
						 );
						$the_query = new WP_Query( $args );
						while ( $the_query->have_posts() ) {
							$the_query->the_post();							
							?>
							<tr>
								<td>
									<b><a href="<?php echo $wpurl; ?>/wp-admin/post.php?post=<?php echo get_the_ID(); ?>&action=edit">
										<?php the_title(); ?>
									</a></b>
									<ul>
										<?php
										$rows = $wpdb->get_results( "SELECT `returnurl` FROM `{$this->db_table}` WHERE `post_id` = '".get_the_ID()."' ORDER BY `id` DESC" );
										if(count($rows) > 0)	{
											foreach($rows as $row)	{
												?>
												<li><a target="_blank" href="<?php echo $row->returnurl ; ?>"><?php echo $row->returnurl ; ?></a></li>
												<?php
											}
										}
										?>
									</ul>
								</td>
								<td><?php the_author() ?></td>
								<td> <?php the_time('m/j/y g:i A') ?> </td>
							</tr>
							<?php
						}
						wp_reset_postdata();
						
					?>
				</tbody>
			</table>
		</div>
	</div>