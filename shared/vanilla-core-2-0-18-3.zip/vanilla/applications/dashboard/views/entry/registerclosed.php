<?php if (!defined('APPLICATION')) exit(); ?>
<h1><?php echo T('Register for Membership'); ?></h1>
<div class="Box">
   <p><?php echo T('Registration is currently closed.'); ?></p>
</div>