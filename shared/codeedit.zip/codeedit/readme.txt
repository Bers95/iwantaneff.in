======================================================================================================================
INTRODUCTION
======================================================================================================================
Use this script to create a code editor with realtime syntax hilighting. You can create as many editors as you
want. When put into a form, the contents can be submitted, e.g. to be written to a file.

Generally, code editing should work on Windows with Internet Explorer 5.5+ and with browsers using the Mozilla 1.3+ 
engine, i.e. all browsers that support "designMode".

NOTE: The script also works with browsers that don't support code editing - a simple textarea will replace the 
code editor.

======================================================================================================================
LICENSE
======================================================================================================================
This script is freeware for non-commercial use. If you like it, please feel free to make a donation!
However, if you intend to use the script in a commercial project, please donate at least EUR 10.
You can make a donation on my website: http://www.gerd-tentler.de/tools/codeedit/.

======================================================================================================================
USAGE
======================================================================================================================
Insert this script into your HTML page like this:

	<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
	<html>
	<head>
	...
	<script src="codeedit.js" type="text/javascript"></script>
	...
	</head>
	<body>
	...

Note the first line, it is needed to fix the CSS box model bug of Internet Explorer.

Then insert one or more textareas and use "codeedit" followed by the script language as class name:

	<textarea name="myEditor1" class="codeedit php" wrap="off"></textarea>
	...
	<textarea name="myEditor2" class="codeedit javascript" wrap="off"></textarea>
	...

It is also possible to add several options in any order. For instance, you can focus the textarea by adding the 
option "focus":

	<textarea name="myEditor" class="codeedit php focus" wrap="off"></textarea>

Note that if you focus more than one textarea, only the last one will actually get the focus.

Line numbers can be viewed by adding the option "lineNumbers":

	<textarea name="myEditor" class="codeedit php lineNumbers" wrap="off"></textarea>

As already said, you can combine these options in any order; just make sure that the class name starts with 
"codeedit" and the language name:

	<textarea name="myEditor" class="codeedit php lineNumbers focus" wrap="off"></textarea>

======================================================================================================================
LIST OF SUPPORTED LANGUAGES
======================================================================================================================
Currently the code editor supports the following languages:

PHP
JavaScript
HTML
CSS

======================================================================================================================
Source code + examples available at http://www.gerd-tentler.de/tools/codeedit/.
======================================================================================================================
