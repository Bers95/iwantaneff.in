=== WP2Cloud ===
Contributors: ArtemLivshits,Produced by OblakSoft
Donate link: http://www.oblaksoft.com/documentation/yapixx/
Tags: amazon, s3, cloud, aws, cloud storage, scale, fast, protect, photo, picture, image, media, upload, attachment
Requires at least: 3.3.2
Tested up to: 3.3.2
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Now WordPress site can store all its content (pages and media) in cloud. This makes site powered by enormous scale and reliability of Amazon S3.
== Description ==

**Take your WordPress site to cloud with the help of Cloud Storage Engine ([ClouSE](http://www.oblaksoft.com/documentation "Cloud Storage Engine"))!**

Now WordPress (or *any* dynamic Website, for that matter) can seamlessly get all the benefits of cloud storage - high availability, high reliability, quick and easy disaster recovery, and serving content in a highly scalable fashion.

WP2Cloud plugin is designed to complete the migration of a WordPress site to Amazon S3. 

With Cloud Storage Engine you have the following primary deployment choices:

1. Take the whole website data to Amazon S3
2. Only migrate website content to Amazon S3 while store media files in uploads folder on Web server running WordPress.
3. Only upload media files to the Amazon S3. 

*As the best deployment practice we recommend moving to the cloud the whole website, both its content (that is stored in WordPress database) and media files.* Consider using ready-to-run WordPress on S3 - [Oblaksoft Yapixx, the 1st WordPress website on Amazon S3](http://www.oblaksoft.com/documentation/yapixx/ "Yet Another Picture Sharing Site") as a starting point and a reference of such configuration.

WP2Cloud stores media files such as pictures, music, videos, documents in the cloud. Media files that are uploaded to the WordPress are actually uploaded to the cloud storage, not to the local file system of the Web server hosting this website.

The media files are served from the cloud, the website pages now refer to the media files via direct cloud storage URLs. This makes your site directly powered by the enormous scale and reliability of Amazon S3.

WP2Cloud plugin kills two birds with one stone: 

1. files are stored reliably in the cloud and don't need to be backed up, and 
2. site now can leverage the cloud power to scale out content delivery to the browser directly from the cloud storage. The file content is served by the cloud storage utility provider which takes load off the Web server. This is different from the default WordPress behavior where media files are local files, thus they are served by the Web server and consume network bandwidth, disk I/O and CPU power of the Web server.

Currently the plugin works only with Amazon S3-compatible storage, other storage providers may be added in the near future.

**Support**

This plugin is actively supported by [OblakSoft](http://www.oblaksoft.com/ "http://www.oblaksoft.com/") and we will do our best to help you. In return we simply ask:

1. Follow us at our [OblakSoft Facebook page](http://www.facebook.com/pages/OblakSoft-LLC/324769304220011/ "http://www.facebook.com/pages/OblakSoft-LLC/324769304220011/")
2. Support us by referring, blogging about WP2Cloud plugin and/or ClouSE storage engine.
3. Help Out. If you see a question on the forum you can help with or have a great idea and want to code it up and submit a patch, that would be just plain awesome and we will shower your with praise. Also, we are happy to post translations if you provide them.
4. Donate - if this plugin makes your life easier enough to support our time it makes all the difference in the world. We are a small self-funded startup. You can donate to OblakSoft development team via [PayPal](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=JMUHXKMNCQ75N "WP2Cloud PayPal URL").

== Installation ==

**Install**

If you plan to store all WordPress site on Amazon S3 storage, use a ready-to-run WordPress on Amazon S3 [Yapixx AMI appliance](http://www.oblaksoft.com/documentation/yapixx/ "Yapixx AMI appliance") as a starting point or check out the detailed instructions [here](http://www.oblaksoft.com/ "http://www.oblaksoft.com/").

In case you are interested only in uploading media files to cloud, please follow WP2Cloud installation instructions below.

You can download and install WP2Cloud using the built-in WordPress plugin installer.  If you download WP2Cloud manually, make sure it is uploaded to "/wp-content/plugins/wp2cloud/". WP2Cloud requires the Cloud Storage Engine for MySQL (ClouSE) to be installed and configured on the MySQL server.  **If ClouSE is not installed, WP2Cloud will fail to activate.**

Here are the steps for installation and configuration of ClouSE:

1. [Sign up](http://docs.amazonwebservices.com/AmazonS3/latest/gsg/SigningUpforS3.html "http://docs.amazonwebservices.com/AmazonS3/latest/gsg/SigningUpforS3.html") for an AWS account.
2. [Create](http://docs.amazonwebservices.com/AmazonS3/latest/gsg/CreatingABucket.html "http://docs.amazonwebservices.com/AmazonS3/latest/gsg/CreatingABucket.html") an S3 bucket if you don't have one.
3. [Install and configure](http://www.oblaksoft.com/documentation/getting-started-with-clouse/ "http://www.oblaksoft.com/documentation/getting-started-with-clouse/") ClouSE.

Once ClouSE is installed and configured, you can activate WP2Cloud plugin:

1. In your WordPress administration, go to the Plugins page
2. Activate the WP2Cloud plugin.

Now all new media files are going to be uploaded to the cloud.  

*Your website can gain higher availability and scalability!*

**Documentation and support**

The comprehensive documentation can be found [here](http://www.oblaksoft.com/documentation/yapixx/ "plugins at oblaksoft.com").

Please visit this [forum](http://wordpress.org/tags/wp2cloud/ "http://wordpress.org/tags/wp2cloud/") for questions or comments.

If you aren't able to find a resolution, please email us at bugs@oblaksoft.com. 
The authors are available for professional consulting to meet your configuration, troubleshooting and customization needs.

**Requirements**

* MySQL Server 5.5.19 or above
* Apache 2.2.15 or above
* PHP 5.3.2 or above
* ClouSE 1.0b.1.1 or above

== Frequently Asked Questions ==

= What makes WP2Cloud different from other plugins that upload files to Amazon S3? =
WP2Cloud plugin for WordPress:

1. Is the last piece in the puzzle of moving the whole WordPress site to Amazon S3 storage. It allows to take full advantage of cloud storage by consolidating both website content and media on the cloud storage.
2. Uploads files faster because it relies on [OblakSoft WebStor](http://www.oblaksoft.com/high-performance-amazon-s3-api-webstor/ "High Performance Library for Cloud Storage") - high performance library for Amazon S3.  
3. Handles media file uploads in a transactional manner. Either the whole file and all its derivative files (e.g. thumbnails for pictures) get uploaded or nothing does.

= Is there a limit on number or size of files being uploaded? =
Not at all. Since cloud storage space is nearly limitless, you can use as much of it as you need. WP2Cloud can upload very large files as it uses multi-part upload and thus it is not restricted by the available memory on the Web server.

= How long do I have to wait for the files to be uploaded to cloud storage? =
Media files are uploaded to cloud storage as fast as physically possible with the help of [WebStor](http://www.oblaksoft.com/high-performance-amazon-s3-api-webstor/ "High Performance Library") - high performance library for Amazon S3. 

= Can I update media files using this plugin? =
Absolutely, your media experience is not affected by this plugin. You can change image, add title, alternative text, media tags - whatever you might need.

= Where do I go to file a bug or ask a question? =
The comprehensive documentation can be found [here](http://www.oblaksoft.com/documentation/yapixx/ "plugins at oblaksoft.com").

Please visit this [forum](http://wordpress.org/tags/wp2cloud/ "http://wordpress.org/tags/wp2cloud/") for questions or comments.

If you aren't able to find a resolution, please email us at bugs@oblaksoft.com. 
The authors are available for professional consulting to meet your configuration, troubleshooting and customization needs.

== Screenshots ==

1. Add media: when media files are uploaded to the WordPress they are actually uploaded to the cloud storage.  The derivative media files (e.g. thumbnails for pictures) are also uploaded to the cloud storage. Note that Link URL points to the Amazon S3 object. Note that this changes the default WordPress behavior for media files and their related derivative files to be stored on the local file system of the Web server hosting the website.
2. Insert a picture into a post: when a picture is inserted into a post, WP2CLOUD shortcodes are stored in the post for the webpage instead of the actual picture and thumbnail URLs.  Such WP2CLOUD shortcode contains the ID that uniquely identifies the media file on the website.
3. View post source: before the page is delivered by the Web server to the Web client (browser), the WP2CLOUD shortcodes are translated into the actual direct URLs that point to the cloud storage on Amazon S3.  The web browser downloads all the media files (including thumbnails) from the cloud storage, bypassing the web server. Note that media files are served by Amazon S3 directly relying on enormous power of the cloud to make serving the content highly scalable.

== Changelog ==

= 1.0.1 =
* Fix error handling for MySQL errors
* Fail to activate if ClouSE is not configured, and provide guidance to the user

= 1.0.0 =
* WP2Cloud released

== Upgrade Notice ==

n/a
