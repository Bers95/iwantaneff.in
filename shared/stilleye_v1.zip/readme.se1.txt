Stilleye v1 (zipped)
by David Schontzler
(c) 2001-2002
http://www.stilleye.com/
http://www.stilleye.com/archived/v1.zip

This is the zipped version of Stilleye's first edition.  It is provided as a learning tool only.  If you have any questions, you may contact the author (http://www.stilleye.com/info/contact.asp), but you are not guaranteed any support.  Any help received comes as is.  Stilleye is in no way responsible for any harm this code may cause to your computer (although you shouldn't have any problems).  Thank you.

- DS