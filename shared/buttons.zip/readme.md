## CSS3 Buttons

### Prettify your website with these wonderful buttons, and other CSS goodness

Author: [David Higgins][1]

Website: [http://davidhiggins.me/][2]

Last Updated: January 31, 2012

This repository is my own little storehouse of CSS3 goodness (Mostly buttons), but some other things too.
Feel free to use them in your projects. Fork at will.

I submitted some of these to CSSDeck:

http://cssdeck.com/item/167/download-buttons
http://cssdeck.com/item/166/slick-border-gradients
http://cssdeck.com/item/165/google-buttons-2
http://cssdeck.com/item/164/delicious-buttons
http://cssdeck.com/item/163/dark-navigation-buttons
http://cssdeck.com/item/161/bonbon-buttons
http://cssdeck.com/item/160/apple-breadcrumb-navigation-menu

----------


  [1]: http://davidhiggins.me/
  [2]: http://iwantaneff.in/repo/